from util.azure_batch_logger import BatchLog
import argparse
import datetime
from util.redis_utils import RedisUtil
from config import Config
from util.read_write_data_azure_blob import ReadAndWriteFromAzureBlob
from util.meta_data_extractor import MetaDataExtractor
from util.target_indexer import TargetIndexer
from util.mongo_util_base import MongoUtilBase


class CampaignReconciliation:
    def __init__(self, environment):
        Config.switch_env(environment)
        print(
            "Running for environment - {}".format(
                Config.AzureConfig.ENV
            )
        )
        self.version = datetime.datetime.now()
        self.read_write_blob = ReadAndWriteFromAzureBlob()
        self.redis_client = RedisUtil(
            Config.AzureConfig.REDIS_HOST_NAME,
            Config.AzureConfig.REDIS_PASSWORD
        )
        self.metadata_extractor = MetaDataExtractor()
        self.retailers = self.__get_all_retailers()
        self.target_indexer = TargetIndexer(mode="reconciliation")
        self.mongo_util_base = MongoUtilBase(
            Config.AzureConfig.COSMOS_URI
        )

    def __get_live_campaigns(self, retailer_id):
        return list(
            self.mongo_util_base.get_all_documents(
                Config.AzureConfig.COSMOS_ACTIVE_CAMPAIGNS_DB,
                str(retailer_id)
            )
        )

    def __process_live_campaigns(self, retailer_id):
        campaigns = self.__get_live_campaigns(retailer_id)
        if campaigns:
            message = "Updating targets and metadata for live campaigns for " \
                      "the retailer - {}".format(str(retailer_id))
            BatchLog.info(message)
            print(message)

            for campaign in campaigns:
                campaign_id = campaign["_id"]
                try:
                    if campaign["campaign_type"] == "AUTOMATIC":
                        self.target_indexer.refresh_targets_v2(
                            str(retailer_id), campaign_id
                            )

                    if campaign["campaign_type"] == "MANUAL":
                        self.target_indexer.refresh_manual_targets(
                            str(retailer_id), campaign_id
                        )

                    message = "Targets updated for campaign {} in " \
                              "retailer {}".format(
                                campaign_id, retailer_id
                                )
                    print(message)
                    BatchLog.info(message)

                except Exception as e:
                    message = "Exception {} while refreshing target " \
                              "for campaign - {} in retailer - {} ".format(
                                    e, campaign_id, retailer_id
                                )
                    print(message)
                    BatchLog.exception(message)

        else:
            message = "No live campaigns available for the retailer - " \
                      "{}".format(str(retailer_id))
            BatchLog.info(message)
            print(message)

    def __get_all_retailers(self):
        all_retailers = self.metadata_extractor.get_retailer_matadata()
        retailers = [str(retailer['_id']) for retailer in all_retailers]
        return retailers

    def main(self):
        for retailer in self.retailers:
            self.target_indexer.reset_cache()
            self.__process_live_campaigns(retailer)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Campaign reconciliation job')
    parser.add_argument('-env', '--environment', type=str,
                        default='dev,qa,uat',
                        help='List of environments to run suggestions')
    input_args = vars(parser.parse_args())
    for env in input_args['environment'].strip().split(','):
        try:
            campaign_reconciliation = CampaignReconciliation(environment=env)
            campaign_reconciliation.main()
        except Exception as exception:
            print(exception)
            continue
