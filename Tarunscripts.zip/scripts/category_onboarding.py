from util.mongo_util import MongoUtil
from config import Config
from relevance.similar_category import SimilarCategoryPredictor 
from context.context import Context
import pandas as pd
import argparse
import os
import time
import sys


class CategoryOnboarding:
    def __init__(self, retailer_info, data=pd.DataFrame()):
        self.retailer_info = retailer_info
        self.retailer_id = self.retailer_info['id']
        Config.switch_env(self.retailer_info['env'])
        self.category_mongo_client = MongoUtil(
            Config.AzureConfig.COSMOS_URI,
            Config.AzureConfig.COSMOS_CATEGORY_TARGETING_DB,
            self.retailer_id
        )
        if not self.category_mongo_client:
            err_msg = "Category mongo client for retailer %s is not initialized." % self.retailer_id
            sys.exit(err_msg) 
        if data.empty:
            self.full_file_name = "full_data_" + self.retailer_info['name'] + ".pkl"
            self.data_path = '../data/' + self.retailer_info['id'] + '/'
            os.makedirs(self.data_path, exist_ok=True)
            if not os.path.exists(self.data_path + self.full_file_name): 
                Context.download_blob(self.full_file_name, self.data_path)
            self.data = pd.read_pickle(self.data_path + self.full_file_name)
        else:
            self.data = data
        self.data = self.data.drop(['similar_image_skus', 'similar_image_scores', 'similar_text_scores'], axis=1)

    def insert_to_mongo(self, catg_obj):
        for index, (k, v) in enumerate(catg_obj.items()):
            if index % 1000 == 0:
                print("ingested %d records into mongo" % index)
            new_v = {}
            new_v["_id"] = k
            new_v["target"] = v
            self.category_mongo_client.upsert(new_v)

    def main(self, category_path_col, do_refresh=False):
        if self.data.empty:
            err_msg = "Meta data for retailer %s is empty." % self.retailer_id
            sys.exit(err_msg)
        st = time.time()
        if do_refresh:
            list_of_products = self.data[self.data['is_new_data']==1]['sku'].values.tolist()
        else:
            list_of_products = self.data['sku'].values.tolist()
        similar_catg_predictor = SimilarCategoryPredictor()
        ci_obj, ct_obj = similar_catg_predictor.group_skus_by_similar_category(list_of_products, self.data, category_path_col, do_refresh=do_refresh)
        self.insert_to_mongo(ci_obj)
        et = time.time()
        print("time taken to run category onboarding:%s" % (et-st))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Category onboarding process of exisitng Retailers')
    parser.add_argument('-i', '--id', help='ID', required=True)
    parser.add_argument('-n', '--name', help='retailer_name', required=True)
    parser.add_argument('-r', '--refresh', help='catalog refresh', action='store_true')
    # pass such category path column name used in data file
    parser.add_argument('-cpname', '--category_path_col_name', help='category_path_col_name')
    parser.add_argument('-e', '--env', help='environment', type=str, default='dev')
    var_args = vars(parser.parse_args())
    co = CategoryOnboarding(var_args)
    co.main(var_args['category_path_col_name'], var_args['refresh'])
