from util.azure_batch_logger import BatchLog
import os
import argparse
from datetime import datetime, timedelta
import pandas as pd
from fastavro import reader
from util.read_write_data_azure_blob import ReadAndWriteFromAzureBlob
from util.mongo_util import MongoUtil
from azure.storage.blob import ContainerClient
from config import Config


class SuggestionFeedbackAggregator:
    def __init__(self, time_delta, environment):
        Config.switch_env(environment)
        print(
            "Running for environment - {}".format(
                Config.AzureConfig.ENV)
        )
        self.time_delta = time_delta
        self.current_run = datetime.strftime(
            datetime.now() - timedelta(self.time_delta),
            "%Y/%m/%d"
        )
        self.input_client = ContainerClient.from_connection_string(
            conn_str=Config.AzureConfig.SUGGESTION_FEEDBACK_EN_CONNECTION,
            container_name=Config.AzureConfig.SUGGESTION_FEEDBACK_EN_CONTAINER)
        self.read_write_azure = ReadAndWriteFromAzureBlob()

    @staticmethod
    def __create_suggestion_map(suggestion_type, suggestions):
        values = ['keyword', 'product', 'category']
        suggestion_values = []
        if suggestion_type.split('_')[1] in values:
            for i in suggestions:
                suggestion_values.append(i['targeting_value'])
            return suggestion_values
        else:
            return suggestions

    def __extract_latest_files(self):
        # Extracting latest blobs from event capture
        pattern = "{}-campaign-eventhub/suggestion-events/{}/{}"
        latest_blobs = []
        i = 0
        while True:
            master_list = list(
                self.input_client.list_blobs(
                    name_starts_with=pattern.format(
                        Config.AzureConfig.ENV, i, self.current_run)
                )
                                )
            i += 1
            if master_list:
                latest_blobs.extend(master_list)
            else:
                break
        latest_blobs = [blob for blob in latest_blobs if blob.size > 508]
        message = "Blob list for current run - {} - {}".format(
            self.current_run, latest_blobs)
        BatchLog.info(message)
        return latest_blobs

    def __aggregate_data(self):
        # Get latest blobs
        latest_files = self.__extract_latest_files()

        # Download and save the blobs
        local_files = []
        for blob in latest_files:
            blob_client = ContainerClient.get_blob_client(self.input_client,
                                                          blob=blob)
            blob_name = str.replace(blob.name, '/', '_')
            blob_name = os.getcwd() + '/' + blob_name
            local_files.append(blob_name)
            with open(blob_name, "wb+") as my_file:
                my_file.write(blob_client.download_blob().readall())

        # Aggregate the data in avro files
        consolidated_data = []
        for file in local_files:
            with open(file, 'rb') as fo:
                avro_reader = reader(fo)
                for emp in avro_reader:
                    try:
                        data = eval(emp['Body'])
                        consolidated_data.append(data)
                        os.remove(file)
                    except Exception as e:
                        print(e)
                        continue

        # Convert the aggregated data to dataframe
        if consolidated_data:
            message = "Data available, proceeding with aggregations"
            BatchLog.info(message)
            print(message)
            df = pd.DataFrame(consolidated_data)
            df = df.join(df['event_payload'].apply(pd.Series))
            df = df.sort_values('event_created_at').groupby(
                'campaign_id').last()
            df.reset_index(inplace=True)
            df = df[
                ['suggestion_id', 'campaign_id', 'retailer_id',
                 'suggestion_type', 'suggestions', 'status', 'version',
                 'expiry']
            ]
            return df
        else:
            message = "No data available, not proceeding with aggregations"
            BatchLog.info(message)
            print(message)
            return pd.DataFrame()

    def __parse_data(self):
        # Parse rejections and create necessary data
        df = self.__aggregate_data()
        if not df.empty:
            rejected_df = df[df['status'] == 'REJECTED']

            # Getting rejections
            if not rejected_df.empty:
                message = "Rejections available, consolidation in progress"
                BatchLog.info(message)
                print(message)
                rejected_df.reset_index(inplace=True, drop=True)
                rejected_df['suggestion_map'] = rejected_df.apply(
                    lambda row: self.__create_suggestion_map(
                        row['suggestion_type'], row['suggestions']), axis=1)
                rejected_df['data'] = rejected_df.apply(
                    lambda row: {
                        row['suggestion_type']: row['suggestion_map']
                    },
                    axis=1)
                rejected_df['mongo_data'] = rejected_df.apply(
                    lambda row: {
                        "_id": row['campaign_id'],
                        "rejected_suggestions_type": [row['suggestion_type']],
                        "rejected_suggestions": row['data']},
                    axis=1)
                rejected_df = rejected_df[
                    ['retailer_id', 'campaign_id', 'suggestion_type',
                     'suggestion_map', 'data', 'mongo_data']
                ]
            return df, rejected_df
        else:
            return pd.DataFrame(), pd.DataFrame()

    def __collect_suggestions(self):
        message = "Running suggestions feedback aggregator"
        BatchLog.info(message)
        print(message)

        year, month, day = self.current_run.split('/')
        df, aggregated_df = self.__parse_data()
        # Write aggregated events to Storage and rejected events to COSMOS
        if not df.empty:
            for retailer_id in set(df['retailer_id'].to_list()):
                data = df[df['retailer_id'] == retailer_id]
                data.reset_index(inplace=True, drop=True)
                message = "Writing data to blob for retailer - {}".format(
                    retailer_id
                )
                BatchLog.info(message)
                print(message)
                blob_name = "retailer_id={}/year={}/month={}/day={}/" \
                            "AggregatedEvents.csv".format(
                                retailer_id, year, month, day)
                self.read_write_azure.write_to_blob(
                    Config.AzureConfig.SUGGESTION_FEEDBACK_AI_CONNECTION,
                    Config.AzureConfig.SUGGESTION_FEEDBACK_AI_CONTAINER,
                    blob_name,
                    data
                )
        # Write only rejected suggestions to cosmos
        add_keys = ['increase_keyword_bid', 'decrease_keyword_bid',
                    'add_category', 'add_product', 'add_keyword',
                    'increase_category_bid', 'decrease_category_bid',
                    'increase_product_bid', 'decrease_product_bid']

        if not aggregated_df.empty:
            for retailer_id in set(aggregated_df['retailer_id'].to_list()):
                data = aggregated_df[
                    aggregated_df['retailer_id'] == retailer_id]
                data.reset_index(inplace=True, drop=True)

                if not data.empty:
                    # Create Mongo connection
                    mongo_client = MongoUtil(
                        Config.AzureConfig.COSMOS_URI,
                        Config.AzureConfig.REJECTED_SUGGESTIONS_DB,
                        str(retailer_id)
                    )
                    message = "Writing rejections to MongoDB"
                    BatchLog.info(message)
                    print(message)
                    # Iterate over dataframe and write values for each campaign
                    for index, row in data.iterrows():
                        existing_doc = [(
                            mongo_client.get_document(row['campaign_id'])
                        )]
                        existing_doc = list(
                            filter(None, existing_doc)
                        )
                        if existing_doc:
                            existing_doc = existing_doc[0]
                            rejected_suggestion_type = existing_doc[
                                'rejected_suggestions_type']
                            rejected_suggestions_dict = existing_doc[
                                'rejected_suggestions']
                            if row['suggestion_type'] in \
                                    rejected_suggestion_type:
                                if row['suggestion_type'] in add_keys:
                                    rejected_suggestion = \
                                        rejected_suggestions_dict[
                                            row['suggestion_type']]
                                    rejected_suggestion.extend(
                                        row['suggestion_map'])
                                    rejected_suggestions_dict[
                                        row['suggestion_type']] = list(
                                        set(rejected_suggestion))
                                    existing_doc['rejected_suggestions'] = \
                                        rejected_suggestions_dict
                                    mongo_client.upsert(existing_doc)
                            else:
                                rejected_suggestion_type.extend(
                                    row['suggestion_type'].split())
                                rejected_suggestions_dict[
                                    row['suggestion_type']] = row[
                                    'suggestion_map']
                                existing_doc[
                                    'rejected_suggestions_type'] = \
                                    rejected_suggestion_type
                                existing_doc[
                                    'rejected_suggestions'] = \
                                    rejected_suggestions_dict
                                mongo_client.upsert(existing_doc)
                        else:
                            mongo_client.insert(row['mongo_data'])

        message = "Completed suggestion feedback aggregator"
        BatchLog.info(message)
        print(message)

        date_string_split = datetime.strftime(
            datetime.now() - timedelta(self.time_delta),
            '%Y/%m/%d').split('/')

        # Write logs to Blob
        log_file = "BatchJobLogs/year={}/month={}/day={}/" \
                   "FeedbackAggregationJob.log".format(
                    date_string_split[0],
                    date_string_split[1],
                    date_string_split[2])
        self.read_write_azure.write_log_to_blob(
            Config.AzureConfig.RECOMMENDATION_OUT_STRING,
            Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME,
            log_file)

    def main(self):
        self.__collect_suggestions()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Suggestions Feedback '
                                                 'Aggregation Job')
    parser.add_argument('-d', '--day_count', type=int, default=1,
                        help='Number of days to look backward from current '
                             'date for suggestions')
    parser.add_argument('-env', '--environment', type=str,
                        default='dev,qa,uat',
                        help='List of environments to run suggestions')
    input_args = vars(parser.parse_args())
    for env in input_args['environment'].strip().split(','):
        try:
            FeedbackAggregator = SuggestionFeedbackAggregator(
                time_delta=input_args['day_count'],
                environment=env)
            FeedbackAggregator.main()
        except Exception as exception:
            print(exception)
            continue
