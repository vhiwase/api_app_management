from util.mongo_util import MongoUtil
from config import Config
import pandas as pd
import pickle
import argparse, os
from context.context import Context
import time
import sys

class ScoresCalculation:
    def __init__(self, retailer_info, data=pd.DataFrame()):
        self.retailer_info = retailer_info
        self.retailer_id = self.retailer_info['id']
        Config.switch_env(self.retailer_info['env'])
        self.k_nearest = 200
        self.product_mongo_client = MongoUtil(
            Config.AzureConfig.COSMOS_URI,
            Config.AzureConfig.COSMOS_PRODUCT_TARGETING_DB,
            self.retailer_id
        )
        if not self.product_mongo_client:
            err_msg = "Product mongo client for retailer %s is not initialized." % self.retailer_id
            sys.exit(err_msg)

        self.product_meta_data_mongo_client = MongoUtil(
            Config.AzureConfig.COSMOS_URI,
            Config.AzureConfig.COSMOS_PRODUCT_META_DB,
            self.retailer_id
        )
        if not self.product_meta_data_mongo_client:
            err_msg = "Product meta data mongo client for retailer %s is not initialized." % self.retailer_id
            sys.exit(err_msg)

        if data.empty:
            self.full_file_name = "full_data_" + self.retailer_info['name'] + ".pkl"
            self.data_path = '../data/' + self.retailer_info['id'] + '/'
            os.makedirs(self.data_path, exist_ok=True)
            if not os.path.exists(self.data_path + self.full_file_name): 
                Context.download_blob(self.full_file_name, self.data_path)
            self.data = pd.read_pickle(self.data_path + self.full_file_name)
        else:
            self.data = data
        self.model_importance = 0.7
        self.catg_importance = 0.3
        if self.retailer_info['create_img_embeddings']:
            self.text_importance = 0.6
            self.image_importance = 0.4
        else:
            self.text_importance = 1.0
            self.image_importance = 0.0

    def add_catg_boost_to_skus(self, nn_dict, catg, pt, catg_map, pt_map):
        new_nn_dict = {}
        for sku, score in nn_dict.items():
            boost_score = 0.0
            if catg == catg_map.get(sku, ''):
                boost_score += 0.5
            if pt == pt_map.get(sku, ''):
                boost_score += 0.5
            final_score = (self.model_importance * score) + \
                          (self.catg_importance * boost_score)
            if final_score < 0.8:
                 final_score = 0.8
            calibrated_score = (((0.99-0.01)*(final_score - 0.8))/0.2) + 0.01
            new_nn_dict[sku] = calibrated_score
        return new_nn_dict
           
    def main(self):
        if self.data.empty:
            err_msg = "Meta data for retailer %s is empty." % self.retailer_id
            sys.exit(err_msg)
        st = time.time()
        sku_list = self.data['sku'].values.tolist()
        catg_list = self.data['category'].values.tolist()
        pt_list = self.data['productType'].values.tolist()
        sku_catg_map = dict(zip(sku_list, catg_list))
        sku_pt_map = dict(zip(sku_list, pt_list))
        nn_dicts = []
        price_dicts = []
        for index, row in self.data.iterrows():
            if index % 1000 == 0:
                print("calculated score for %d records" %index)
            sku = row['sku']
            price = float(row['price'])
            catg = row['category']
            broad_category = row['Broad_Category'] 
            price_dicts.append({'_id': sku, 'price': price, 'aov': price, 'Broad_Category': broad_category, 'category': catg})
            try:
                is_new_data = row['is_new_data']
                if is_new_data == 0:
                    continue
            except:
                pass
            sim_img_skus = row['similar_image_skus']
            sim_img_scores = row['similar_image_scores']
            sim_skus = row['similar_text_skus']
            sim_scores = row['similar_text_scores']
            pt = row['productType']
            text_scores_obj = dict(zip(sim_skus, sim_scores))
            image_scores_obj = dict(zip(sim_img_skus, sim_img_scores)) 
            all_skus = list(set().union(sim_skus, sim_img_skus))
            all_scores = []
            for _sku in all_skus:
                text_dist = text_scores_obj.get(_sku, 4.0)
                image_dist = image_scores_obj.get(_sku, 4.0)
                combined_dist = (self.text_importance * text_dist) + (self.image_importance * image_dist)
                combined_score = (4.0 - combined_dist) / 4.0
                all_scores.append(combined_score)
            nn_dict = dict(zip(all_skus, all_scores))
            nn_dict = self.add_catg_boost_to_skus(nn_dict, catg, pt, sku_catg_map, sku_pt_map)
            sorted_tuples = sorted(nn_dict.items(), key=lambda x: x[1], reverse=True)[:self.k_nearest]
            sorted_k = [_tup[0] for _tup in sorted_tuples]
            sorted_v = [_tup[1] for _tup in sorted_tuples]
            target_list = []
            for nn_sku, nn_score in zip(sorted_k, sorted_v):
                target_list.append({'sku':nn_sku, 'relevance_score':nn_score})
                
            nn_dict_sorted = {'_id': sku, 'target': target_list}
            nn_dicts.append(nn_dict_sorted)

        st1 = time.time()
        self.product_mongo_client.upsert_bulk(nn_dicts)
        et1 = time.time()
        print("time taken to ingest documents into mongo:%s" %(et1-st1))

        st2 = time.time()
        self.product_meta_data_mongo_client.upsert_bulk(price_dicts)
        et2 = time.time()
        print("time taken to ingest product meta data documents into mongo:%s" %(et2-st2))
        et = time.time()
        print("time taken to run product nn's score calculation:%s" %(et-st))    

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Scores recalculation process of exisitng Retailers')
    parser.add_argument('-i', '--id', help='ID', required=True)
    parser.add_argument('-n', '--name', help='retailer_name', required=True)
    parser.add_argument('-img', '--create_img_embeddings', help='Create image embeddings', action='store_true')
    parser.add_argument('-e', '--env', help='environment', type=str, default='dev')
    var_args = vars(parser.parse_args())
    sr = ScoresCalculation(var_args)
    sr.main()

