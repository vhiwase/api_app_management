# KEYWORD SUGGESTIONS
# pylint: disable=all
from util.suggestions_util import PostCampaignSuggestionsUtil
from datetime import datetime, timedelta
from collections import ChainMap
from util.keyword_targetting_utils import KeywordHash


class KeywordSuggestion:
    def __init__(self, time_delta):
        self.time_delta = time_delta
        self.version = datetime.now().strftime('%Y-%m-%dT%H:%M:%SZ')
        self.expiry = (
                datetime.now() + timedelta(1)
        ).strftime('%Y-%m-%dT%H:%M:%SZ')
        self.keyword_hash = KeywordHash()
        self.suggestion_util = PostCampaignSuggestionsUtil(self.time_delta)

    def get_keyword_suggestions(
           self, campaign_list, retailer_metadata, product_meta_data_map,
            bid_map, negations, roas=5
    ):
        keyword_suggestions = {}
        acos = 100/roas

        for record in campaign_list:
            try:
                retailer_id = str(record['retailer_id'])
                campaign_id = str(record['campaignId'])
                ad_group_id = str(record["ad_group_id"])
                products_to_promote = [
                    sku.strip().lower() for sku in
                    record['products_to_promote']
                ]
                cost_type = record['cost_type'].lower()

                # Creating negations
                keyword_negation = self.suggestion_util.get_rejections(
                    record['campaignId'], negations, "keyword"
                )
                negations_keys = list(dict(ChainMap(*record['bid_map']))) + \
                    record['negative_targets']
                keyword_negation = keyword_negation + negations_keys
                keyword_negation = list(set(keyword_negation))

                # Getting keyword targets for the products to promote
                targets = \
                    self.suggestion_util.target_indexer.get_keywords(
                        retailer_id, products_to_promote, keyword_negation
                    )

                # Adding necessary metrics for further computations
                self.suggestion_util.target_indexer.\
                    fill_target_metrics_for_suggestion(
                        retailer_metadata, product_meta_data_map,
                        products_to_promote, targets, acos
                    )

                # Replacing bids with bid landscape based values where possible
                self.suggestion_util.target_indexer.\
                    update_bid_landscape_for_suggestion(
                        targets, bid_map, cost_type
                    )

                # Creating keyword suggestions
                suggestions = []
                for target in targets:
                    if len(suggestions) > 50:
                        break
                    for keyword in target['keywords']:
                        if keyword not in negations:
                            suggestions.append(
                                {
                                    "targeting_value": keyword,
                                    "recommended_bid": max(
                                        0.05, round(target['median_bid'], 2)
                                    )
                                }
                            )

                if suggestions:
                    suggestion_payload = {
                        "ad_group_id": ad_group_id,
                        "suggestions": suggestions
                    }

                    if keyword_suggestions.get(campaign_id):
                        keyword_suggestions.get(campaign_id).get(
                            "suggestions"
                        ).append(suggestion_payload)
                    else:
                        keyword_suggestions[campaign_id] = {
                            "retailer_id": str(retailer_id),
                            "campaign_id": campaign_id,
                            "suggestion_type": "add_keyword",
                            "suggestion_code": "A104",
                            "campaign_level_suggestion": False,
                            "version": self.version,
                            "expiry": self.expiry,
                            "suggestions": [suggestion_payload]
                        }

            except Exception as e:
                print(e)
                continue

        return list(keyword_suggestions.values())
