from util.azure_batch_logger import BatchLog
from config import Config
from keywords_suggestion import KeywordSuggestion
from category_suggestion import CategorySuggestion
from product_suggestion import ProductSuggestion
from bid_suggestion import BidSuggestion
from budget_suggestion import BudgetSuggestion
from util.meta_data_extractor import MetaDataExtractor
from util.suggestions_util import PostCampaignSuggestionsUtil
import argparse


class ManualSuggestions:
    def __init__(self, time_delta, environment):
        Config.switch_env(environment)
        print(
            "Running post campaign suggestions for manual campaigns in "
            "environment - {}".format(
                Config.AzureConfig.ENV
            )
        )
        self.time_delta = time_delta
        self.retailers = MetaDataExtractor.get_retailer_list_for_suggestions()
        self.keyword_suggestion = KeywordSuggestion(self.time_delta)
        self.category_suggestion = CategorySuggestion(self.time_delta)
        self.product_suggestion = ProductSuggestion(self.time_delta)
        self.bid_suggestion = BidSuggestion(self.time_delta)
        self.budget_suggestion = BudgetSuggestion(self.time_delta)
        self.suggestion_util = PostCampaignSuggestionsUtil(self.time_delta)
        self.retailer_meta_data = MetaDataExtractor.get_retailer_matadata()

    def main(self):
        campaign_data = self.suggestion_util.campaign_metadata_extractor()
        for retailer_id in self.retailers:
            retailer_suggestions = []

            message = "Creating suggestions for the retailer - {}".format(
                retailer_id
            )
            BatchLog.info(message)
            print(message)

            # Getting retailer metadata
            retailer_metadata = self.suggestion_util.get_retailer_metadata(
                self.retailer_meta_data, str(retailer_id)
            )

            # Getting all negation data for the retailer
            negations = self.suggestion_util.get_negations_for_retailer(
                str(retailer_id)
            )

            # Creating product metadata map for all products in the retailer
            product_meta_data_map = self.suggestion_util.get_retailer_prod_map(
                str(retailer_id)
            )

            # Creating bid landscape mapping for the retailer
            bid_landscape = self.suggestion_util.get_bid_landscape(
                str(retailer_id)
            )

            # Keyword suggestions
            keyword_suggestions = []
            campaign_list = self.suggestion_util.get_campaign_data(
                campaign_data, retailer_id, "keyword"
            )
            keyword_suggestions.extend(
                self.keyword_suggestion.get_keyword_suggestions(
                    campaign_list, retailer_metadata,
                    product_meta_data_map, bid_landscape, negations
                )
            )
            if keyword_suggestions:
                retailer_suggestions.extend(keyword_suggestions)
                message = "Created keyword suggestions for retailer - " \
                          "{}".format(retailer_id)
                BatchLog.info(message)
                print(message)
            else:
                message = "No keyword suggestions available for " \
                          "retailer - {}".format(retailer_id)
                BatchLog.info(message)
                print(message)

            # Product suggestions
            product_suggestions = []
            campaign_list = self.suggestion_util.get_campaign_data(
                campaign_data, retailer_id, "product"
            )
            product_suggestions.extend(
                self.product_suggestion.get_product_suggestions(
                    campaign_list, retailer_metadata,
                    product_meta_data_map, bid_landscape, negations
                )
            )
            if product_suggestions:
                retailer_suggestions.extend(product_suggestions)
                message = "Created product suggestions for retailer - " \
                          "{}".format(retailer_id)
                BatchLog.info(message)
                print(message)
            else:
                message = "No product suggestions available for " \
                          "retailer - {}".format(retailer_id)
                BatchLog.info(message)
                print(message)

            # Category suggestions
            category_suggestions = []
            campaign_list = self.suggestion_util.get_campaign_data(
                campaign_data, retailer_id, "category"
            )
            category_suggestions.extend(
                self.category_suggestion.get_category_suggestions(
                    campaign_list, retailer_metadata,
                    product_meta_data_map, bid_landscape, negations
                )
            )
            if category_suggestions:
                retailer_suggestions.extend(category_suggestions)
                message = "Created category suggestions for retailer - " \
                          "{}".format(retailer_id)
                BatchLog.info(message)
                print(message)
            else:
                message = "No category suggestions available for " \
                          "retailer - {}".format(retailer_id)
                BatchLog.info(message)
                print(message)

            # Bid suggestions
            bid_suggestions = []
            campaign_list = self.suggestion_util.get_campaign_data(
                campaign_data, retailer_id, "other"
            )
            bid_suggestions.extend(
                 self.bid_suggestion.get_bid_suggestions(
                    campaign_list, retailer_metadata, product_meta_data_map,
                    bid_landscape, negations)
            )
            if bid_suggestions:
                retailer_suggestions.extend(bid_suggestions)
                message = "Created bid suggestions for retailer - " \
                          "{}".format(retailer_id)
                BatchLog.info(message)
                print(message)
            else:
                message = "No bid suggestions available for " \
                          "retailer - {}".format(retailer_id)
                BatchLog.info(message)
                print(message)

            # Budget suggestions
            budget_suggestions = []
            campaign_list = self.suggestion_util.get_campaign_data(
                campaign_data, retailer_id, "other"
            )
            bid_landscape = self.suggestion_util.get_bid_landscape(
                retailer_id, budget_suggestion=True
            )
            ad_spent = self.suggestion_util.get_latest_ad_spent()
            search_count = self.suggestion_util.get_impression_data(
                retailer_id
            )
            budget_suggestions.extend(
                self.budget_suggestion.get_budget_suggestion(
                    campaign_list, retailer_metadata, product_meta_data_map,
                    ad_spent, bid_landscape, search_count, negations
                )
            )
            if budget_suggestions:
                retailer_suggestions.extend(budget_suggestions)
                message = "Created budget suggestions for retailer - " \
                          "{}".format(retailer_id)
                BatchLog.info(message)
                print(message)
            else:
                message = "No budget suggestions available for " \
                          "retailer - {}".format(retailer_id)
                BatchLog.info(message)
                print(message)

            # Sending suggestion events and uploading suggestions as CSV to
            # AI containers
            self.suggestion_util.send_data_to_azure(
                retailer_id, "Manual Suggestions", retailer_suggestions,
                BatchLog
            )

        # Uploading logs to AI container
        self.suggestion_util.send_logs_to_azure("Manual Suggestions")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Post campaign suggestions for manual campaigns"
    )
    parser.add_argument('-d', '--day_count', type=int, default=1,
                        help='Number of days to look backward from current '
                             'date for suggestions')
    parser.add_argument('-env', '--environment', type=str,
                        default='dev,qa,uat',
                        help='List of environments to run post campaign '
                             'suggestions for manual campaigns')
    input_args = vars(parser.parse_args())
    for env in input_args['environment'].strip().split(','):
        try:
            manual_suggestion = ManualSuggestions(
                time_delta=input_args['day_count'],
                environment=env
            )
            manual_suggestion.main()
        except Exception as exception:
            print(exception)
            continue
