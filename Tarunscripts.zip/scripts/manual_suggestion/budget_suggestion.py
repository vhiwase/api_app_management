from datetime import datetime, timedelta
from util.suggestions_util import PostCampaignSuggestionsUtil


class BudgetSuggestion:
    def __init__(self, time_delta):
        self.time_delta = time_delta
        self.version = datetime.now().strftime('%Y-%m-%dT%H:%M:%SZ')
        self.expiry = (
                datetime.now() + timedelta(1)
        ).strftime('%Y-%m-%dT%H:%M:%SZ')
        self.suggestion_util = PostCampaignSuggestionsUtil(self.time_delta)

    @staticmethod
    def get_potential_impressions(
            current_bid, bid_landscape, current_impressions
    ):
        # Method to calculate potential impressions from bid landscape for
        # the current bid value
        if not current_impressions:
            return 0

        potential_impressions = 0
        if bid_landscape:
            for k, v in bid_landscape.items():
                if float(k) < current_bid:
                    potential_impressions = v
                else:
                    break
        if potential_impressions > current_impressions:
            return potential_impressions
        else:
            return current_impressions * 2

    def get_new_budget(
            self, campaign, bid_landscape, search_count, budget
    ):
        budget = int(float(budget))
        # Method to calculate additional budget for the campaigns
        if not search_count:
            return 0

        for target in campaign['targets']:
            if target['target_type'] == 'keyword':
                current_bid = campaign['bid_map'][target['keyword']]
                cost_type = campaign['cost_map'][target['keyword']]
                impressions = search_count.get(target['keyword'].lower())
            else:
                current_bid = campaign['bid_map'][target['target_value']]
                cost_type = campaign['cost_map'][target['target_value']]
                impressions = search_count.get(target['target_value'].lower())

            if impressions and impressions > 0:
                potential_impressions = self.get_potential_impressions(
                    current_bid, bid_landscape.get(target['mongo_key']),
                    impressions
                )

                if cost_type.lower() == "cpm":
                    budget += (
                        (potential_impressions - impressions) * current_bid
                              ) / 1000
                if cost_type.lower() == "cpc":
                    current_bid = current_bid * target['ctr'] * 1000
                    budget += (potential_impressions - impressions) * \
                        current_bid
        return round(budget)

    def get_budget_suggestion(
            self, campaign_list, retailer_meta_data, product_meta_data_map,
            ad_spent, bid_landscape, search_count, negations
    ):
        budget_suggestions = []
        suggestions = {}

        for record in campaign_list:
            try:
                campaign_id = record["campaignId"]
                ad_group_id = record["ad_group_id"]

                # Current budget
                current_budget = record['budget']

                # Filtering search count of target values for the campaign
                try:
                    search_counter = search_count.get(
                        record['campaignId']
                    ).get(
                        "impression_map"
                    ).get(
                        ad_group_id
                    )
                except AttributeError:
                    continue

                # Getting campaigns that have rejected suggestions previously
                budget_negation = self.suggestion_util.get_rejections(
                    campaign_id, negations, "budget_suggestion"
                )

                # Processing only those campaigns that have either exhausted
                # their budget or not in negation list
                if record["budget_type"] == "DAILY":
                    total_spend = search_count.get(
                        record["campaignId"]
                    ).get("ad_spent")
                else:
                    total_spend = ad_spent.get(record["campaignId"])

                if total_spend < record['budget'] or budget_negation:
                    continue

                # Get targets, relevance score and update CTR
                self.suggestion_util.update_targets_using_indexer(
                    record, retailer_meta_data, product_meta_data_map
                )

                # Get recommended budget for the campaign
                new_budget = self.get_new_budget(
                    record, bid_landscape, search_counter,
                    current_budget
                )

                if suggestions.get(campaign_id):
                    suggestions[campaign_id][
                        "new_budget"
                    ] += new_budget
                else:
                    suggestions[campaign_id] = {
                        "current_budget": int(float(current_budget)),
                        "new_budget": new_budget
                    }

            except Exception as e:
                print(e)
                continue

        for key, value in suggestions.items():
            try:
                if value["new_budget"] > value["current_budget"]:
                    budget_suggestions.append(
                        {
                            "retailer_id": str(retailer_meta_data["_id"]),
                            "campaign_id": str(key),
                            "suggestion_type": "increase_budget",
                            "suggestion_code": "A101",
                            "campaign_level_suggestion": True,
                            "version": self.version,
                            "expiry": self.expiry,
                            "suggestions": [
                                {
                                    "current_budget": value["current_budget"],
                                    "recommended_budget": min(
                                        2*value["current_budget"],
                                        value["new_budget"]
                                    )
                                }
                            ]
                        }
                    )
            except Exception as e:
                print(e)
                continue

        return budget_suggestions
