# pylint: disable=all
from datetime import datetime, timedelta
from util.suggestions_util import PostCampaignSuggestionsUtil


class BidSuggestion:
    def __init__(self, time_delta):
        self.time_delta = time_delta
        self.version = datetime.now().strftime('%Y-%m-%dT%H:%M:%SZ')
        self.expiry = (
                datetime.now() + timedelta(1)
        ).strftime('%Y-%m-%dT%H:%M:%SZ')
        self.suggestion_util = PostCampaignSuggestionsUtil(self.time_delta)

    @staticmethod
    def update_bids_with_landscape(
            targets, bid_landscape, negations, aov
    ):
        suggestions = []
        for target in targets:
            if target['target_value'] in negations:
                continue
            if bid_landscape.get(target['mongo_key']):
                if target['cost_type'].lower() == 'cpm':
                    recommended_bid = bid_landscape[
                        target['mongo_key']
                    ]['median_bid']
                else:
                    bid = bid_landscape[
                        target['mongo_key']
                    ]['median_bid']
                    recommended_bid = bid / target['ctr'] / 1000
                if target['bid'] < recommended_bid:
                    recommended_bid = min(recommended_bid, 0.3 * aov)
                    if target['keyword']:
                        target['target_value'] = target['keyword']
                    suggestions.append(
                        {
                            "targeting_type": target['target_type'],
                            "targeting_value": target['target_value'],
                            "current_bid": target["bid"],
                            "recommended_bid": round(recommended_bid, 2)
                        }
                    )
        return suggestions

    def get_bid_suggestions(
            self, campaign_list, retailer_meta_data, product_meta_data_map,
            bid_map, negations
    ):
        bid_suggestions = {}

        for record in campaign_list:
            try:
                retailer_id = str(record['retailer_id'])
                campaign_id = str(record['campaignId'])
                ad_group_id = str(record["ad_group_id"])

                # Getting negations
                bid_negation = self.suggestion_util.get_rejections(
                    record['campaignId'], negations, "bid_suggestion"
                )

                # Get targets, relevance score and update CTR
                self.suggestion_util.update_targets_using_indexer(
                    record, retailer_meta_data, product_meta_data_map
                )

                # Get AOV for the products to promote
                aov = self.suggestion_util.get_aov(
                    record['products_to_promote'], product_meta_data_map
                )

                # Creating bid suggestions
                suggestions = self.update_bids_with_landscape(
                    record['targets'], bid_map, bid_negation, aov
                )

                if suggestions:
                    suggestion_payload = {
                        "ad_group_id": ad_group_id,
                        "suggestions": suggestions
                    }

                    if bid_suggestions.get(campaign_id):
                        bid_suggestions.get(campaign_id).get(
                            "suggestions"
                        ).append(suggestion_payload)
                    else:
                        bid_suggestions[campaign_id] = {
                            "retailer_id": str(retailer_id),
                            "campaign_id": campaign_id,
                            "suggestion_type": "increase_bid",
                            "suggestion_code": "A107",
                            "campaign_level_suggestion": False,
                            "version": self.version,
                            "expiry": self.expiry,
                            "suggestions": [suggestion_payload]
                        }

            except (TypeError, KeyError, ZeroDivisionError):
                continue

        return list(bid_suggestions.values())
