# pylint: disable=all
from config import Config, LocalConfig
from sentence_transformers import SentenceTransformer
import pandas as pd
import random
from azure.storage.blob import BlobServiceClient
from context.context import Context
from util.meta_data_extractor import MetaDataExtractor
import os, traceback, argparse
import sys
import nltk
import urllib
import requests
import cv2
import numpy as np
import faiss
import pickle
from training_pipeline import RelevanceFineTuning
from ner_training_pipeline import NERFineTuning
import tensorflow as tf
from tensorflow.keras.applications import DenseNet121
from tensorflow.keras.layers import GlobalAveragePooling2D
from tqdm import tqdm
from util.azure_search_clients import AzureSearchClients
from util.azure_search_clients import AzureSearchUtils
from azure.core.credentials import AzureKeyCredential
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents import SearchClient
from azure.search.documents.indexes.models import (ComplexField, CorsOptions, SearchIndex, ScoringProfile, SearchFieldDataType, SimpleField, SearchableField)
from io import StringIO
import json
from config import AzureCognitiveSearchConfig, AzureCognitiveSearchSchema
from multiprocessing import Process, Queue
import multiprocessing
import glob
import math
import time
from category_onboarding import CategoryOnboarding
from product_scores_onboarding import ScoresCalculation
from util.redis_utils import RedisUtil

class BulkCatalogueRefresh:
    def __init__(self, retailer_info):
        self.retailer_info = retailer_info
        self.is_image_sim_enabled = 'no'
        self.image_faiss_index_filename = ''
        if self.retailer_info['create_img_embeddings']:
            self.is_image_sim_enabled = 'yes'
            self.image_faiss_index_filename = self.retailer_info['name'] + '_image_faiss.index'
        self.text_faiss_index_filename = self.retailer_info['name'] + '_text_faiss.index'
        self.file_name = "data_" + self.retailer_info['name'] + ".pkl"
        self.full_file_name = "full_data_" + self.retailer_info['name'] + ".pkl"
        self.data_path = '../data/' + self.retailer_info['id'] + '/'
        self.old_data_path = '../data/' + self.retailer_info['id'] + '_old/'
        os.makedirs(self.old_data_path, exist_ok=True)
        Context.download_blob(self.full_file_name, self.old_data_path)
        self.old_data = pd.read_pickle(self.old_data_path + self.full_file_name)
        self.images_data_path = '../data/' + self.retailer_info['id'] + '/' + 'raw_images/'
        os.makedirs(self.images_data_path, exist_ok=True)
        self.retailer_data = {
                            '_id': int(self.retailer_info['id']),
                            'retailer_name': self.retailer_info['name'],
                            'data_file': self.file_name,
                            'image_faiss' : self.image_faiss_index_filename,
                            'text_faiss': self.text_faiss_index_filename,
                            'is_image_sim_enabled': self.is_image_sim_enabled,
                            'retailer_container': self.retailer_info['container'],
                        }
        self.mongo_client = MetaDataExtractor.initialize_mongo_client(
            Config.AzureConfig.COSMOS_URI,
            Config.AzureConfig.COSMOS_DATABASE_NAME,
            Config.AzureConfig.COSMOS_META_DATA_TABLE
        )
        self.blob_service_client = BlobServiceClient.from_connection_string( 
                                    Config.AzureConfig.ICC_DS_STORAGE_CONNECTION_STRING)
        self.container_name = 'model-artifacts'
        self.raw_image_container_name = 'model-artifacts/image_' + self.retailer_info['id'] + '/' + 'raw_images'
        self.k_nearest = 200
        self.batch_size = max(128*len(tf.config.list_physical_devices('GPU')), 128)
        self.chunk_size = max(2*(multiprocessing.cpu_count() - 4), 10)
        self.lemmatizer = nltk.stem.WordNetLemmatizer()
        self.w_tokenizer = nltk.tokenize.WhitespaceTokenizer()
        if self.retailer_info['retrain_relevance_model']:
            self.rft = RelevanceFineTuning()
        if self.retailer_info['retrain_ner']:
            self.nft = NERFineTuning()
        self.ROBERTA_BERT_MODEL = None
        self.config_path = '../data/config.cfg'
        self.headers = {'User-Agent': "Mozilla/5.0 (X11; Linux x86_64) \
                       AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36"}
        self.image_model = DenseNet121(weights='imagenet', include_top=False)
        self.endpoint = AzureCognitiveSearchConfig.ENDPOINT
        self.admin_key = AzureCognitiveSearchConfig.ADMIN_KEY
        self.schema = AzureCognitiveSearchSchema.SCHEMA

    def __fetch_data_from_container(self):
        Context.init_sql_client()
        fetched_data = Context.azure_sql_client.QueryItems(
            "dbs/" + Config.AzureConfig.COSMOS_SQL_DATABASE_NAME + "/colls/" + self.retailer_info["container"],
            {'query': 'SELECT * FROM root'}, {'enableCrossPartitionQuery': True}
            )
        return fetched_data

    def __preprocess_catalogue_data(self, data):
        #data['_ts'] = pd.to_datetime('now')
        data = data.rename(columns={'productId': 'sku', 'title': 'name', 
                                    'imageUrl': 'imageUrl',
                                    'subCategory': 'productType',
                                    'productUrl': 'link',
                                    '_ts': 'timestamp'})
        if 'category_path' in data.columns:
            data = data[['sku', 'name', 'description', 'category', 'productType',
                         'category_path', 'brand', 'price', 'link', 'imageUrl', 'timestamp']]
        else:
            data = data[['sku', 'name', 'description', 'category', 'productType',
                        'brand', 'price', 'link', 'imageUrl', 'timestamp']]

        data['sku'] = data['sku'].str.lower()
        data.drop_duplicates(subset='sku', inplace=True)
        data = data[~data['name'].isnull()]
        data = data.reset_index()
        data['FID'] = data.index

        data['description'].fillna('', inplace=True)
        data['productType'].fillna('', inplace=True)
        data['category'].fillna('', inplace=True)
        data['category'] = data['category'].str.replace('cat-', '')

        if 'category_path' in data.columns:
            #checking whether we have a place holder category_path
            #In such case all the entries will be na
            if data['category_path'].isna().sum() == data.shape[0] or sum(
                    data['category_path'] == '') == data.shape[0]:
                data['category_path'] = data['category'] + '>' + data['productType']
                category_path_col = None
            else:
                data['category_path'].fillna('', inplace=True)
                data['category_path'] = data.apply(
                    lambda x: (
                            x['category'] + '>' + x['productType']
                    ) if x['category_path'] == '' else x['category_path'], axis=1
                )
                category_path_col = 'Broad_Category'

            data.rename(
                columns={'category_path': 'Broad_Category'}, inplace=True
            )

        else:
            data['Broad_Category'] = data['category'] + '>' + data['productType']
            category_path_col = None

        #incase pt is also empty
        data['Broad_Category'] = data['Broad_Category'].str.strip(">")
        data['brand'] = data['brand'].str.lower()

        data['price'] = data['price'].apply(self.__fill_missing_price)

        return data, category_path_col

    def __fill_missing_price(self, price):
        if price is None or price == '':
            return float(random.randint(1, 50))
        else:
            return float(price)

    def __update_meta_data_mongo(self, client, data):
        if client.find_one({'_id': data['_id']}):
            updated_dictionary = {key: data[key] for key in data.keys() if key != '_id'}
            client.update_one({'_id': data['_id']}, {'$set': updated_dictionary})
            return True
        return False

    def __push_meta_data_to_cosmos(self):
        try:
            update_counter = self.__update_meta_data_mongo(self.mongo_client, self.retailer_data)
            if not update_counter:
                self.mongo_client.insert_one(self.retailer_data) 
        except Exception as e:
            print(traceback.print_exc())
            return "Exception"
        return "Add/Update Successful"

    def __lemmatize_title(self, row):
        return [self.lemmatizer.lemmatize(w) for w in self.w_tokenizer.tokenize(row)]

    def __preprocess_titles(self, data):
        data['name'] = data['name'].str.lower()
        data['name'] = data['name'].apply(self.__lemmatize_title)
        data['name'] = data['name'].str.join(' ')
        data['description'] = data['description'].str.lower()
        data['description'] = data['description'].apply(self.__lemmatize_title)
        data['description'] = data['description'].str.join(' ')
        return data

    def __load_model(self):
        self.ROBERTA_BERT_MODEL = SentenceTransformer(LocalConfig.MODEL_PATH, device='cpu')
    
    def __change_dimensionality(self, embedding):
        return embedding.reshape(1, -1)

    def __insert_embeddings(self, data):
        data = self.__preprocess_titles(data)
        self.__load_model()
        embeddings = self.ROBERTA_BERT_MODEL.encode(data['name'].to_list(), show_progress_bar=False)
        embeddings = embeddings / np.expand_dims(np.linalg.norm(embeddings, axis=1), axis=1)
        data['embedding'] = list(embeddings)
        data['embedding'] = data['embedding'].apply(self.__change_dimensionality)
        return data

    def __push_data_to_blob(self, data_path, file_name, container_name):
        blob_client = self.blob_service_client.get_blob_client(
                      container = container_name, blob = file_name)
        print("\nUploading to Azure Storage as blob:\n\t" + file_name)
        with open(data_path + file_name, "rb") as data:
            blob_client.upload_blob(data, overwrite = True)
            return "File added/updated to Blob"
        return "Exception"

    def __get_image_array(self, image_content):
        """
        Convert image into an array

        """
        img_array = np.asarray(bytearray(image_content), dtype="uint8")
        img_array = cv2.imdecode(img_array, cv2.IMREAD_COLOR)
        img_array = cv2.resize(img_array, tuple([224,224])).astype(np.float32)
        # Normalize pixels
        img_array[:,:,0] = (img_array[:,:,0] - 103.94) * 0.017
        img_array[:,:,1] = (img_array[:,:,1] - 116.78) * 0.017
        img_array[:,:,2] = (img_array[:,:,2] - 123.68) * 0.017

        img_array = np.expand_dims(img_array, axis=0)

        return img_array

    def _bytes_feature(self, value):
       return tf.train.Feature(bytes_list=tf.train.BytesList(value=[value])) 

    def decode_fn(self, record_bytes):
        a = tf.io.parse_single_example(
            record_bytes,
            {"input_img": tf.io.FixedLenFeature([], dtype=tf.string),
            "input_img_url": tf.io.FixedLenFeature([], dtype=tf.string),
            "sku": tf.io.FixedLenFeature([], dtype=tf.string)})
        return {"input_1":tf.reshape(tf.io.decode_raw(a['input_img'],tf.float32),(224,224,3,)), 
                "input_img_url":a['input_img_url'], "sku":a['sku']}

    def __download_images_in_chunk(self, sku_list, img_list, chunk_id):
        tfr_file_name = str(chunk_id) + ".tfrecords" 
        tfr_file_path = self.images_data_path + tfr_file_name
        with tf.io.TFRecordWriter(tfr_file_path) as file_writer:
            for index, sku_img_url_tuple in enumerate(zip(sku_list, img_list)):
                sku, prod_img_url = sku_img_url_tuple
                if index%1000 == 0:
                    print("*****downloaded %d images in chunk %d*****\n\n" %(index, chunk_id))
                try:
                    prod_img_url = urllib.parse.unquote(prod_img_url)
                    prod_img_url = urllib.parse.urljoin(prod_img_url, 
                                   urllib.parse.urlparse(prod_img_url).path)
                    response = requests.request("GET", prod_img_url, 
                               headers=self.headers)
                    image_array = self.__get_image_array(response.content)
                    record_bytes = tf.train.Example(features=tf.train.Features(feature={
                                   "input_img":self._bytes_feature(image_array.tostring()), 
                                   "sku":self._bytes_feature(str.encode(sku)), 
                                   "input_img_url":self._bytes_feature(str.encode(prod_img_url))})).SerializeToString()
                    file_writer.write(record_bytes)
                except:
                    continue

    def __create_image_faiss_index(self, image_features, image_ids):
        vector_dimension = image_features[0].shape[1]
        #index = faiss.IndexFlatIP(vector_dimension)
        index = faiss.IndexFlatL2(vector_dimension)
        image_features = np.vstack(image_features)
        image_ids = np.hstack(image_ids)
        index2 = faiss.IndexIDMap(index)
        index2.add_with_ids(image_features, image_ids)
        faiss_index_file = self.data_path + \
                               self.image_faiss_index_filename
        faiss.write_index(index2, faiss_index_file)
        blob_push_status = self.__push_data_to_blob(self.data_path, 
                           self.image_faiss_index_filename, 
                           self.container_name)
        print("blob push status for image faiss index: %s" %blob_push_status)
        return index2

    def __create_text_faiss_index(self, data, text_features, text_ids):
        vector_dimension = text_features[0].shape[1]
        nlist = int(data.shape[0]/1000) + 1
        quantizer = faiss.IndexFlatL2(vector_dimension)
        text_features = np.vstack(text_features)
        text_ids = np.hstack(text_ids)
        faiss.normalize_L2(text_features)
        faiss_index = faiss.IndexIVFFlat(quantizer, vector_dimension, nlist)
        faiss_index.train(text_features)
        faiss_index.add_with_ids(text_features, text_ids)
        faiss_index_file = self.data_path + self.text_faiss_index_filename 
        faiss.write_index(faiss_index, faiss_index_file)
        blob_push_status = self.__push_data_to_blob(self.data_path,
                           self.text_faiss_index_filename,
                           self.container_name)
        print("blob push status for text faiss index: %s" %blob_push_status)
        return faiss_index, nlist

    def __calculate_similar_skus_in_chunk(self, faiss_index, sku_list, 
                                           emb_list, sku_map, 
                                           chunk_id):
        similar_df = pd.DataFrame([], 
                            columns=['sku', 
                            'similar_skus', 
                            'similar_scores'])
        distances_list, neighbors_list = faiss_index.search(emb_list, k = self.k_nearest)
        for distances, neighbors, sku in zip(distances_list, neighbors_list, sku_list): 
            neighbor_skus = []
            neighbor_sku_distances = []
            distance_iter = distances.tolist()
            neighbor_iter = neighbors.tolist() 
            for distance, neighbor in zip(distance_iter, neighbor_iter):
                neighbor_sku = sku_map.get(neighbor)
                if sku == neighbor_sku:
                    continue
                neighbor_skus.append(neighbor_sku)
                neighbor_sku_distances.append(distance)
            row_rec = {'sku': sku, 'similar_skus': neighbor_skus, 
                      'similar_scores': neighbor_sku_distances}
            similar_df = similar_df.append(row_rec, ignore_index = True)
        if chunk_id % 100 == 0:
            print("calculated similar skus for skus in %d chunks" %chunk_id)
        return similar_df

    def __initialize_similar_skus_for_empty_sku(self, empty_skus, modality):
        scores_column = 'similar_' + modality + '_scores'
        skus_column = 'similar_' + modality + '_skus'
        empty_chunk_df = pd.DataFrame([],
                         columns=['sku',
                          skus_column,
                          scores_column])
        n_skus = []
        n_dists = [] 
        for sku in empty_skus:
            row_rec = {'sku': sku, skus_column: n_skus,
                      scores_column: n_dists}
            empty_chunk_df = empty_chunk_df.append(row_rec, ignore_index = True)
        return empty_chunk_df

    def __calculate_similar_skus(self, faiss_index, sku_list, emb_list, 
                                  sku_map, modality="image", num_clusters=-1):
        if num_clusters != -1:
            faiss_index.nprobe = num_clusters

        print("chunk size in similarity calculation")
        print(self.chunk_size)
        empty_skus, non_empty_skus, non_empty_embs = [], [], []
        for sku, emb in zip(sku_list, emb_list):
            if type(emb) is np.ndarray:
                non_empty_skus.append(sku)
                non_empty_embs.append(emb[0])
            else:
                empty_skus.append(sku)
        empty_chunk_df = self.__initialize_similar_skus_for_empty_sku(empty_skus, modality)
        num_chunks = math.ceil(len(non_empty_skus) / self.chunk_size)
        print("number of chunks in similarity calculation:%d" %num_chunks)
        df_list = []
        i = 0
        while i < num_chunks:
            st = i * self.chunk_size
            ed = (i+1) * self.chunk_size
            this_emb_list = np.array(non_empty_embs[st:ed])
            this_sku_list = non_empty_skus[st:ed]
            chunk_df = self.__calculate_similar_skus_in_chunk(faiss_index,
                        this_sku_list, this_emb_list, sku_map, i)
            if modality == "image":
                chunk_df = chunk_df.rename(columns={'similar_skus': 'similar_image_skus', 
                                            'similar_scores': 'similar_image_scores'})
            else:
                chunk_df = chunk_df.rename(columns={'similar_skus': 'similar_text_skus',
                                            'similar_scores': 'similar_text_scores'})   
            df_list.append(chunk_df)
            i += 1
        df_list.append(empty_chunk_df)
        print("calculated similar skus for all skus in the catalogue using images\n\n")
        return df_list       
   
    def __download_images_parallely(self, sku_list, img_list):
        num_cores = max(multiprocessing.cpu_count() - 4, 1)
        print("num cores used in image processing")
        print(num_cores)
        chunk_size = int(len(sku_list) / num_cores) + 1
        print("chunk size used in image processing")
        print(chunk_size)
        i = 0
        process_list = []
        while i < num_cores:
            print("processing chunk %d" % i)
            st = i * chunk_size
            ed = (i+1) * chunk_size
            this_img_list = img_list[st:ed]
            this_sku_list = sku_list[st:ed]
            #self.__download_images_in_chunk(this_sku_list, this_img_list, i)
            #break
            p = Process(target=self.__download_images_in_chunk, args=(this_sku_list, this_img_list, i))
            p.start()
            process_list.append(p)
            i += 1
        for p in process_list:
            p.join()
        print("processed all images in the catalogue\n\n")
   
    def __create_image_representations(self):
        cwd = os.getcwd()
        os.chdir(self.images_data_path) 
        tfr_files = sorted(glob.glob("*tfrecords"))
        image_df = pd.DataFrame([], columns=['sku', 'image_embedding'])
        dataset = tf.data.TFRecordDataset(tfr_files).map(self.decode_fn,num_parallel_calls=-1)\
                   .batch(self.batch_size).prefetch(tf.data.experimental.AUTOTUNE) 
        for idx, x in tqdm(enumerate(dataset)):
            dense_embs = self.image_model.predict(x)
            dense_embs = GlobalAveragePooling2D()(dense_embs)
            dense_embs = dense_embs.numpy()
            skus = x['sku'].numpy()
            for i in range(len(dense_embs)):
                dense_emb = dense_embs[i]
                dense_emb = dense_emb / np.linalg.norm(dense_emb)
                dense_emb = np.expand_dims(dense_emb, axis=0)
                sku = skus[i].decode("utf-8")
                row_rec = {'sku': sku, 'image_embedding': dense_emb}
                image_df = image_df.append(row_rec, ignore_index = True)
        for tfr_file in tfr_files:
            os.remove(tfr_file)
        os.chdir(cwd)
        return image_df

    def is_catalogue_data_same(self, data, data_old):
        df1 = data[['sku', 'timestamp']]        
        df2 = data_old[['sku', 'timestamp']]
        df3 = df1.merge(df2)
        if df3.shape[0] == df1.shape[0]:
            return True
        return False

    def __initialize_default_value_for_similar_skus(self, data, modality = "image", image_sim_enabled = True):
        num_rows = data.shape[0]
        default_value = [[] for i in range(num_rows)]
        if modality == "image":
            if not image_sim_enabled:
                data['image_embedding'] = default_value
                data['IMAGE_FID'] = -1
            data['similar_image_skus'] = default_value
            data['similar_image_scores'] = default_value
        else:
            data['similar_text_skus'] = default_value
            data['similar_text_scores'] = default_value
        return data

    def __get_additional_skus_in_chunk(self, emb_hash, skus, sku_emb):
        new_skus_hash = {}
        for new_sku in skus:
            new_sku_emb = emb_hash.get(new_sku, -1)
            if type(new_sku_emb) is np.ndarray:
                new_dist = 2 * (1 - np.dot(sku_emb[0], new_sku_emb[0]))
                new_skus_hash[new_sku] = new_dist

        new_skus_hash_sorted = sorted(new_skus_hash.items(), key=lambda x: x[1])
        new_skus = [ ele[0] for ele in new_skus_hash_sorted ]
        new_scores = [ ele[1] for ele in new_skus_hash_sorted ]
        return new_skus, new_scores

    def __get_exact_scores_for_top_image_text_skus_in_chunk(self, sku_list, 
                                                            img_emb_hash,
                                                            text_emb_hash,
                                                            similar_images_hash,     
                                                            similar_text_hash,
                                                            out_q):
        new_df = pd.DataFrame([], columns=['sku', 'new_image_skus',
                  'new_image_scores', 'new_text_skus',
                  'new_text_scores'])
        for sku in sku_list:
            sku_img_emb = img_emb_hash.get(sku, -1)
            sku_text_emb = text_emb_hash.get(sku, -1) 
            img_nn = set(similar_images_hash.get(sku, []))
            text_nn = set(similar_text_hash.get(sku, []))
       
            img_only_skus = img_nn - text_nn
            text_only_skus = text_nn - img_nn
           
            new_img_skus, new_img_scores = [], [] 
            if type(sku_img_emb) is np.ndarray:
                new_img_skus, new_img_scores = self.__get_additional_skus_in_chunk(
                                                img_emb_hash, text_only_skus,
                                                sku_img_emb)

            new_text_skus, new_text_scores = [], []
            if type(sku_text_emb) is np.ndarray:
                new_text_skus, new_text_scores = self.__get_additional_skus_in_chunk(
                                                  text_emb_hash, img_only_skus,
                                                  sku_text_emb)
            row_rec = {'sku': sku, 'new_image_skus': new_img_skus,
                       'new_image_scores': new_img_scores,
                       'new_text_skus': new_text_skus,
                       'new_text_scores': new_text_scores
                      }
            new_df = new_df.append(row_rec, ignore_index = True)

        out_q.put(new_df)

    def __get_exact_scores_for_top_image_text_skus(self, data):
        sku_list = data['sku'].values.tolist()

        img_emb_list = data['image_embedding'].values.tolist()
        img_emb_hash = dict(zip(sku_list, img_emb_list))

        text_emb_list = data['embedding'].values.tolist()
        text_emb_hash = dict(zip(sku_list, text_emb_list))
     
        similar_images_list = data['similar_image_skus'].values.tolist()
        similar_images_hash = dict(zip(sku_list, similar_images_list))

        similar_text_list = data['similar_text_skus'].values.tolist()
        similar_text_hash = dict(zip(sku_list, similar_text_list))

        num_cores = max(multiprocessing.cpu_count() - 4, 1)
        print("num cores used in score calculation")
        print(num_cores)
        chunk_size = int(len(sku_list) / num_cores) + 1
        print("chunk size used in score calculation for additional skus")
        print(chunk_size)
        i = 0
        process_list = []
        df_list = []
        out_q = Queue()
        while i < num_cores:
            print("processing chunk %d in score calculation" % i)
            st = i * chunk_size
            ed = (i+1) * chunk_size
            this_sku_list = sku_list[st:ed]
            p = Process(target=self.__get_exact_scores_for_top_image_text_skus_in_chunk, 
                 args=(this_sku_list, 
                 img_emb_hash, text_emb_hash,
                 similar_images_hash, similar_text_hash, out_q))
            process_list.append(p)
            p.start()
            i += 1

        for i in range(num_cores):
            df_list.append(out_q.get())

        for p in process_list:
            p.join()

        print("processed all chunks in score calculation\n\n")
        new_df = pd.concat(df_list, ignore_index=True)
        data = data.merge(new_df)
        data['similar_image_skus'] = data.apply(
                                      lambda x: x['similar_image_skus']
                                      + x['new_image_skus'], axis = 1)     
        data['similar_image_scores'] = data.apply(
                                        lambda x: x['similar_image_scores']
                                        + x['new_image_scores'], axis = 1)     
        data['similar_text_skus'] = data.apply(
                                     lambda x: x['similar_text_skus']
                                     + x['new_text_skus'], axis = 1)     
        data['similar_text_scores'] = data.apply(
                                       lambda x: x['similar_text_scores']
                                       + x['new_text_scores'], axis = 1) 
        data = data.drop(['new_image_skus', 'new_image_scores',
                'new_text_skus', 'new_text_scores'], axis = 1)
        return data

    def main(self):
        data = self.__fetch_data_from_container()
        data = pd.DataFrame(data)
        data, category_path_col = self.__preprocess_catalogue_data(data)
        data_old = self.old_data
        print("Shape of the dataframe is ", data.shape)
        print("Columns are ", data.columns)
        print("Shape of the old dataframe is ", data_old.shape)
        print("Columns in old dataframe are ", data_old.columns)
        is_data_same = False
        if data.shape[0] == data_old.shape[0]:
            is_data_same = self.is_catalogue_data_same(data, data_old)
        if is_data_same:
            print("Data for retailer %s not changed. Bulk Refresh not needed\n" 
                  %self.retailer_info['id'])
            return
        data_current = data[['sku', 'timestamp']]
        data_intersection = data_old.merge(data_current)
        data_intersection = data_intersection.drop(['similar_image_skus', 
                             'similar_image_scores', 'IMAGE_FID',
                             'similar_text_skus', 'similar_text_scores',
                             'FID'], axis = 1)
        new_data = pd.merge(data, data_old[['sku', 'timestamp']], 
                    on=['sku', 'timestamp'],
                    how='outer', indicator=True)
        new_data = new_data[new_data['_merge']=='left_only']
        new_data['index'] = new_data.index.astype(int)
        data = new_data.drop(['_merge', 'FID'], axis = 1)

        if self.retailer_info['create_img_embeddings']:  
            st1 = time.time()
            sku_list, img_list = data['sku'].values.tolist(), data['imageUrl'].values.tolist()
            self.__download_images_parallely(sku_list, img_list)
            et1 = time.time()
            print("time taken to download and process images:%s seconds" %(et1-st1))
            st2 = time.time()
            image_data = self.__create_image_representations()
            et2 = time.time()
            print("time taken to create image embeddings:%s seconds" %(et2-st2))
            st3 = time.time()
            data = pd.merge(data, image_data, on ='sku', how ='left')
            data['image_embedding'] = data['image_embedding'].fillna(-1)
            et3 = time.time()
            print("time taken to join image and text dataframes in stage-1:%s seconds" %(et3-st3))
        else:
            data = self.__initialize_default_value_for_similar_skus(data, "image", False)
            data_intersection = self.__initialize_default_value_for_similar_skus(data_intersection, "image", False)

        st4 = time.time()
        data = self.__insert_embeddings(data)
        et4 = time.time()
        print("time taken to calculate text embeddings in bulk refresh:%s seconds" %(et4-st4))
        data = pd.concat([data_intersection, data], ignore_index=True)
        data = data.reset_index(drop=True)
        data['FID'] = data.index
        data['IMAGE_FID'] = data.index

        if self.retailer_info['create_img_embeddings']:
            st5 = time.time()
            image_features = data['image_embedding'].values.tolist()
            image_ids = data['IMAGE_FID'].values.tolist()
            image_faiss_index = self.__create_image_faiss_index(image_features, image_ids)
            et5 = time.time()
            print("time taken to create image faiss index:%s seconds" %(et5-st5))

            st6 = time.time()
            skus = data['sku'].values.tolist()
            image_sku_map = dict(zip(image_ids, skus))
            similar_images_df_list = self.__calculate_similar_skus(image_faiss_index, skus,
                                      image_features, image_sku_map)
            if similar_images_df_list:
                similar_images_df = pd.concat(similar_images_df_list, ignore_index=True)
                data = data.merge(similar_images_df)
            else:
                data = self.__initialize_default_value_for_similar_skus(data)
            et6 = time.time()
            print("time taken to calculate similar image skus for entire catalogue:%s seconds" %(et6-st6))

        st7 = time.time()
        text_features = data['embedding'].values.tolist()
        text_ids = data['FID'].values.tolist()
        text_skus = data['sku'].values.tolist()
        text_faiss_index, num_clusters = self.__create_text_faiss_index(data, text_features, text_ids)
        et7 = time.time()
        print("time taken to create text faiss index:%s seconds" %(et7-st7))

        st8 = time.time() 
        text_sku_map = dict(zip(text_ids, text_skus))
        similar_text_df_list = self.__calculate_similar_skus(text_faiss_index, text_skus,
                                text_features, text_sku_map, "text", num_clusters)
        if similar_text_df_list:
            similar_text_df = pd.concat(similar_text_df_list, ignore_index=True)
            data = pd.merge(data, similar_text_df, on ='sku', how ='inner')
        else:
            data = self.__initialize_default_value_for_similar_skus(data, "text")
        et8 = time.time()
        print("time taken to calculate similar text skus for entire catalogue:%s seconds" %(et8-st8))

        if self.retailer_info['create_img_embeddings'] and not data.empty:
            st9=time.time()
            data = self.__get_exact_scores_for_top_image_text_skus(data)
            et9=time.time()
            print("time taken to add additional skus in nearest neigbors:%s seconds" %(et9-st9))

        print("Shape of the final dataframe is ", data.shape)
        print("Columns are ", data.columns)
        print("data types are", data.dtypes)
        os.makedirs('../data/'+self.retailer_info["id"], exist_ok=True)
        data.to_pickle(self.data_path + self.full_file_name)
        if self.retailer_info['upload']:
            blob_push_status = self.__push_data_to_blob(self.data_path,
                               self.full_file_name,
                               self.container_name)
            print("Blob data push update for full data", blob_push_status)

        # get final scores by combining image and text scores
        sr = ScoresCalculation(self.retailer_info, data)
        sr.main()

        if self.retailer_info['category_onboarding']:
            co = CategoryOnboarding(self.retailer_info, data)
            co.main(category_path_col)
        data = data.drop(['similar_image_skus', 'similar_image_scores',
                          'similar_text_skus', 'similar_text_scores'], axis = 1) 
        data.to_pickle(self.data_path + self.file_name) 
        if self.retailer_info['upload']:
            st10 = time.time()
            blob_push_status = self.__push_data_to_blob(self.data_path, 
                               self.file_name, 
                               self.container_name)
            print("Blob data push update ", blob_push_status)
            mongo_update_status = self.__push_meta_data_to_cosmos()
            print("Mongo data push update ", mongo_update_status)
            et10 = time.time()
            print("time taken to upload final retailer pickle file after bulk refresh:%s seconds" %(et10-st10))

        if self.retailer_info['retrain_ner']:
            st11 = time.time()
            self.nft.main(pd.read_pickle(self.data_path + self.file_name), self.config_path)
            et11 = time.time()
            print("time taken to retrain NER:%s seconds" %(et11-st11))

        if self.retailer_info['retrain_relevance_model']:
            st12 = time.time()
            relevance_training_status = self.rft.main(data)
            et12 = time.time()
            print(relevance_training_status)
            print("time taken to retrain Relevance Model:%s seconds" %(et12-st12))

        if self.retailer_info['create_lex_index']:
            st13 = time.time()
            azure_clients = AzureSearchClients(self.retailer_info['name'], self.endpoint, self.admin_key)
            azure_utils = AzureSearchUtils()
            print("Initializing Search Clients for Azure Cognitive Search")
            admin_client, search_client = azure_clients.CreateIndexClient(), azure_clients.CreateSearchClient()
            print("Clients Established for Azure Cognitive Search")
            azure_utils.create_azure_index(self.retailer_info['name'], data, 
             admin_client, search_client)
            print("Azure Cognitive Search Index Succesfully Created")
            et13 = time.time()
            print("time taken to create Azure Cognitive Search Index:%s seconds" %(et13-st13))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Refresh process of exisitng Retailers')
    parser.add_argument('-i', '--id', help='ID', required=True)
    parser.add_argument('-n', '--name', help='retailer_name', required=True)
    parser.add_argument('-c', '--container', help='retailer_container', required=True)
    parser.add_argument('-u', '--upload', help='upload to blob', action='store_true')
    parser.add_argument('-ner', '--retrain_ner', help='Retrain NER model', action='store_true')
    parser.add_argument('-rel', '--retrain_relevance_model', help='Retrain Relevance model', action='store_true')
    parser.add_argument('-lex', '--create_lex_index', help='Create lexical search index', action='store_true')
    parser.add_argument('-img', '--create_img_embeddings', help='Create image embeddings', action='store_true')
    parser.add_argument('-co', '--category_onboarding', help='Category Onboarding', action='store_true')

    input_args = vars(parser.parse_args())
    meta_data_list = MetaDataExtractor.get_retailer_matadata()
    retailer_onboarded = False
    is_image_sim_enabled_prev = 'no'
    retailer_id = input_args['id']
    for meta_data in meta_data_list:
        if int(input_args['id']) == meta_data['_id']:
            retailer_onboarded = True
            is_image_sim_enabled_prev = meta_data.get('is_image_sim_enabled', 'no').strip().lower()
            break

    if retailer_onboarded:
        is_image_sim_enabled = 'no'
        if input_args['create_img_embeddings']:
            is_image_sim_enabled = 'yes'
        if is_image_sim_enabled == is_image_sim_enabled_prev:
            cr = BulkCatalogueRefresh(input_args)
            cr.main()
        else:
            print("Cannot run bulk refresh for %s because of inconsistency with previous run\n" %retailer_id)
    else:
        print("Please onboard retailer %s before running bulk refresh\n" %retailer_id)
 
