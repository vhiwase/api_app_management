from config import Config
Config.switch_env("prod")
import pandas as pd
from util.read_write_data_azure_blob import ReadAndWriteFromAzureBlob
from datetime import datetime, timedelta
from relevance.keywordtargeting import KeywordTargeting


KT = KeywordTargeting()

sales_data = KT.get_lastn_days_job_data('123456','organic_sales',ndays=2)
print("Downloaded data")
