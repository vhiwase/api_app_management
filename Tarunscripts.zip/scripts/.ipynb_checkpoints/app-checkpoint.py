from flask import Flask, request, jsonify, Response, abort
import flask
from bidding.auto_bidder import AutoBidder
from context.context import Context
from relevance.relevance_engine import RelevanceEngine
from util.feedback_collector import FeedbackCollector
from cache.store_data import Store_In_Redis
import nltk
from unit_test import UnitTest
from relevance.keyword_targetting import keyword_targetting

app = Flask(__name__)
nltk.download('stopwords')
nltk.download('punkt')
nltk.download('wordnet')
print('Initializng Context')
Context.init()
auto_bidder = AutoBidder()
relevance_engine = RelevanceEngine()
keyword_targetter = keyword_targetting()

@app.route('/unit_test')
def run_unit_test():
    UnitTest.run_all_test_cases()
    return "All test cases passed"


@app.route('/keyword_targetting')
def return_keywords():
    retailer_id = int(request.args.get("retailerId"))
    sku = request.args.get('sku')
    retailer = Context.get_retailer(retailer_id)
    keywords = keyword_targetter.get_keywords_from_products(retailer,sku)
    return Response(keywords.to_json(orient='records'), mimetype='application/json')

def return_keywords_v2():
    retailer_id = int(request.args.get("retailerId"))
    sku = request.args.get('sku')
    keywords_list = request.args.get('keywords_list')
    retailer = Context.get_retailer(retailer_id)
    keywords_score = keyword_targetter.get_keywords_by_relevance(retailer,sku)
    return Response(keywords_score.to_json(orient='records'), mimetype='application/json')


@app.route('/count_impressions/retailerId=<retailerId>&sku=<sku>')
def set_impression_count(retailerId, sku):
    storage_status = Store_In_Redis.send_data_to_cache(Context.azure_redis_client, retailerId, sku)
    if storage_status:
        return "Stored"
    else: return "Error"


@app.route('/static/<path>')
def static_files(path):
    return app.send_static_file(path)


@app.route('/test_zone')
def test_zone():
    return app.send_static_file("search.html")


@app.route('/')
def home_feedback():
    return app.send_static_file("table.html")


@app.route('/feedback', methods=['POST'])
def record_feedback():
    if request.method == 'POST':
        data = request.json
        FeedbackCollector.push_batch_data_to_MongoDB(data)
        return 'success', 200
    else:
        abort(400)


@app.route('/query/<query>')
def json_output(query):
    k = 10
    result = __query(query, k)
    result = result[['id', 'name', 'price', 'Broad_Category', 'brand']]
    return Response(
        result.to_json(orient='records'),
        mimetype='application/json'
    )


@app.route('/test_query/<query>')
def pretty_output(query):
    k = 30
    result = __query(query, k)
    return result.to_html(index=False)


def __query(query, k):
    retailer = Context.get_retailer(123456)
    if query.startswith("sku="):
        result = relevance_engine.get_products_by_product(retailer, query.split('=', 1)[1].strip(), k)
        result["bid"] = result["relevance_score"].apply(auto_bidder.gen_dafault_bid)
    else:
        result = relevance_engine.get_products_by_query(retailer, query, k)
        result["bid"] = result["relevance_score"].apply(auto_bidder.gen_dafault_bid)
        result = result[['id', 'name', 'price', 'Broad_Category',
                         'distance', 'category_score',
                         'relevance_score', 'bid', 'brand']]

    return result


@app.route('/search')
def search():
    if "query" in request.args:
        query = request.args.get("query")
        k_nearest = int(request.args.get("k"))
        retailer_id = int(request.args.get("retailerId"))
        retailer = Context.get_retailer(retailer_id)
        result = relevance_engine.get_products_by_query(retailer, query, k_nearest)
    elif "product" in request.args:
        product_id = request.args.get("product").lower()
        k_nearest = int(request.args.get("k"))
        retailer_id = int(request.args.get("retailerId"))
        retailer = Context.get_retailer(retailer_id)
        product_recommendations = relevance_engine.get_products_by_product(retailer, product_id, k_nearest)
        if not product_recommendations.empty:
            result = product_recommendations
        else:
            return jsonify({})
    elif "category" in request.args:
        category = request.args.get("category").strip().lower()
        retailer_id = int(request.args.get("retailerId"))
        retailer = Context.get_retailer(retailer_id)
        return jsonify(
            relevance_engine.get_products_by_category(retailer, category)
        )
    else:
        return "Invalid Request", 400

    result["id"] = result["id"]
    return Response(
        result[['id', 'relevance_score']].to_json(orient='records'),
        mimetype='application/json'
    )


@app.route("/bid", methods=['GET','POST'])
def auto_bidding():
    retailer_id = int(request.args.get("retailerId"))
    retailer = Context.get_retailer(retailer_id)

    json_data = flask.request.json
    if "type" in json_data:
        search_type = json_data['type']
    else:
        search_type = "query"  # just for backward compatibility
    if "term" in json_data:
        search_term = json_data['term']
    else:
        search_term = "dummy query"  # just for backward compatibility
    product_list = json_data['products']  # Extract list of products

    result = []
    for product in product_list:
        id = product['id'].lower()
        if "relevance_score" not in product:
            relevance_score = relevance_engine.get_relevance_score(retailer, search_type, search_term, id)
        else:
            relevance_score = product['relevance_score']
        acos = product['acos']/100
        price = product['price']
        bid_value = auto_bidder.gen_auto_bid(relevance_score, acos, price)

        if "floor_price" in product:
            floor_price = product['floor_price']
        else:
            floor_price = 0.5
        if "max_cut_off" in product:
            max_cut_off = product['max_cut_off']
        else:
            max_cut_off = 10

        if bid_value > max_cut_off:
            bid_value = max_cut_off
        if bid_value < floor_price:
            bid_value = floor_price

        if "ad_id" in product:
            ad_id = product["ad_id"]
        else:
            ad_id = 0

        ecpm = auto_bidder.gen_ecpm(bid_value)
        result.append({'id': id, 'bid_value': bid_value, 'ecpm': ecpm, 'ad_id': ad_id})

    return jsonify(result)


@app.route("/bid_v2", methods=['GET','POST'])
def auto_bidding_v2():
    retailer_id = int(request.args.get("retailerId"))
    retailer = Context.get_retailer(retailer_id)

    json_data = flask.request.json
    if "type" in json_data:
        search_type = json_data['type']
    else:
        search_type = "query"  # just for backward compatibility
    if "term" in json_data:
        search_term = json_data['term']
    else:
        search_term = "dummy query"  # just for backward compatibility

    response = []
    ad_units = json_data['ad_units']
    for ad_unit in ad_units:
        product_list = ad_unit['products']  # Extract list of ad units
        campaign_id = ad_unit['campaign_id']
        budget_used = daily_budget_limit = 0
        if 'daily_budget' in ad_unit:
            daily_budget_limit = ad_unit['daily_budget']
        if 'budget_used' in ad_unit:
            budget_used = ad_unit['budget_used']
        product_response = []
        ecpm = 0
        for product in product_list:
            id = product['id'].lower()
            if "relevance_score" not in product:
                try:
                    relevance_score = relevance_engine.get_relevance_score(retailer, search_type, search_term, id)
                except Exception:
                    continue
            else:
                relevance_score = product['relevance_score']
            acos = product['acos']/100
            price = product['price']
            bid_value = auto_bidder.gen_auto_bid(relevance_score, acos, price)

            if "floor_price" in product:
                floor_price = product['floor_price']
            else:
                floor_price = 0.5
            if "max_cut_off" in product:
                max_cut_off = product['max_cut_off']
            else:
                max_cut_off = 10

            if bid_value > max_cut_off:
                bid_value = max_cut_off
            if bid_value < floor_price:
                bid_value = floor_price

            product_response.append({'id': id, 'bid_value': bid_value})
            ecpm += auto_bidder.gen_ecpm(bid_value)

        response.append({'campaign_id': campaign_id, 'ecpm': ecpm, 'products': product_response})

    return jsonify(response)


@app.route("/active_product", methods=['POST'])
def add_active_products():
    retailer_id = int(request.args.get("retailerId"))
    retailer = Context.get_retailer(retailer_id)
    json_data = flask.request.json
    retailer.add_active_products(json_data["sku"])

    return "Done", 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8082)
