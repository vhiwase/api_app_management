from util.icc_logger import Log
import time
import json
import re
from azure.eventhub import EventHubConsumerClient
from azure.eventhub.extensions.checkpointstoreblob import \
    BlobCheckpointStore
from config import Config, LocalConfig
from util.redis_utils import RedisUtil, RedisKeyGen
from util.mongo_util import MongoUtil
import logging
import nest_asyncio
import threading
nest_asyncio.apply()


class ActiveProducts:
    _ID = '_id'
    _CAMPAIGN_DATA = 'campaign_data'
    _RETAILER_ID = 'retailer_id'
    _CAMPAIGN_MODE = 'campaign_mode'
    _ACTIVE_PRODUCTS = 'active_products'
    _TARGET = 'target'
    _PRODUCTS_TO_PROMOTE = 'products_to_promote'
    _DESIRED_ACOS = 'desired_acos'
    _ACOS = 'acos'
    _ROAS = 'roas'
    _HASH = 'hash'
    _KEYWORD = 'KEYWORD'
    _CATEGORY = 'CATEGORY'
    _PRODUCT = 'PRODUCT'
    _MAX_BID_PRICE = 'max_bid_price'
    _RELEVANCE_SCORE = 'relevance_score'
    _CAMPAIGN_ID = 'campaign_id'
    _VERSION = 'version'
    _AUTOMATIC = 'AUTOMATIC'
    _BUDGET = 'budget'
    _BUDGET_TYPE = 'budget_type'
    _PLACEMENTS = 'placements'

    def __init__(self):
        self.eventhub_client = self.__create_eventhub_client()
        self.redis_client = RedisUtil(Config.AzureConfig.REDIS_HOST_NAME,
                                      Config.AzureConfig.REDIS_PASSWORD)

    @staticmethod
    def __create_eventhub_client():
        checkpoint_store = BlobCheckpointStore.from_connection_string(
            Config.AzureConfig.ICC_DS_STORAGE_CONNECTION_STRING,
            Config.AzureConfig.CONTAINER_NAME)

        return EventHubConsumerClient.from_connection_string(
            conn_str=Config.AzureConfig.CAMPAIGN_EVENTHUB_STRING,
            consumer_group=Config.AzureConfig.CAMPAIGN_CONSUMER_GROUP,
            eventhub_name=Config.AzureConfig.CAMPAIGN_EVENTHUB_NAME,
            checkpoint_store=checkpoint_store,
            load_balancing_interval=60,
            logging_enable=False
        )

    def __update_metadata(self, data):
        if self._ROAS in data[self._CAMPAIGN_DATA]:
            acos = 100.0 / data[self._CAMPAIGN_DATA][self._ROAS]
        else:
            acos = data[self._CAMPAIGN_DATA][self._DESIRED_ACOS]

        retailer_id = str(data[self._CAMPAIGN_DATA][self._RETAILER_ID])
        campaign_id = str(data[self._CAMPAIGN_DATA][self._CAMPAIGN_ID])
        max_bid = data[self._CAMPAIGN_DATA][self._MAX_BID_PRICE]
        products_to_promote = data[self._CAMPAIGN_DATA][
            self._PRODUCTS_TO_PROMOTE]
        budget = data[self._CAMPAIGN_DATA][self._BUDGET]
        budget_type = data[self._CAMPAIGN_DATA][self._BUDGET_TYPE]

        # Adding placement info to campaign meta-data
        placements = []
        if self._PLACEMENTS in data[self._CAMPAIGN_DATA]:
            if self._KEYWORD in data[self._CAMPAIGN_DATA][self._PLACEMENTS]:
                placements.extend(data[self._CAMPAIGN_DATA][self._PLACEMENTS][self._KEYWORD])
            if self._CATEGORY in data[self._CAMPAIGN_DATA][self._PLACEMENTS]:
                placements.extend(data[self._CAMPAIGN_DATA][self._PLACEMENTS][self._CATEGORY])
            if self._PRODUCT in data[self._CAMPAIGN_DATA][self._PLACEMENTS]:
                placements.extend(data[self._CAMPAIGN_DATA][self._PLACEMENTS][self._PRODUCT])
        placements = [int(x) for x in placements]

        meta_data = {
            self._CAMPAIGN_ID: campaign_id,
            self._ACOS: acos,
            self._MAX_BID_PRICE: max_bid,
            self._PRODUCTS_TO_PROMOTE: products_to_promote,
            self._VERSION: time.time(),
            self._BUDGET: budget,
            self._BUDGET_TYPE: budget_type,
            self._PLACEMENTS: placements
        }
        self.redis_client.set_value(
            RedisKeyGen.get_camapaign_meta_key(retailer_id, campaign_id),
            meta_data
        )

    def __get_product_campaign_mapping(self, retailer_id, products_to_promote):
        keys = []
        product_key_map = {}
        product_campaign_map = {}
        for product in products_to_promote:
            key = RedisKeyGen.get_prod_camapaign_map_key(retailer_id, product)
            keys.append(key)
            product_key_map[product] = key

        key_val = self.redis_client.multi_get(keys)
        for product in products_to_promote:
            product_campaign_map[product] = {
                "key": product_key_map[product],
                "campaigns": key_val[product_key_map[product]]
            }

        return product_campaign_map

    @staticmethod
    def __get_products_to_activate(product_campaign_map):
        new_products = []

        for product in product_campaign_map:
            if product_campaign_map[product]["campaigns"] is None:
                new_products.append(product)

        return new_products

    def __update_campaign_id(self, product_campaign_map, campaign_id):

        for key in product_campaign_map:
            product = product_campaign_map[key]
            if product["campaigns"] is not None:
                campaign_list = product["campaigns"]
                if campaign_id not in campaign_list:
                    campaign_list.append(campaign_id)
                    self.redis_client.set_value(
                        product["key"],
                        campaign_list
                    )
            else:
                self.redis_client.set_value(
                    product["key"],
                    [campaign_id]
                )

    def __update_keyword_mapping(self, retailer_id, product):
        mongo_util = MongoUtil(Config.AzureConfig.COSMOS_URI,
                               Config.AzureConfig.COSMOS_KEYWORD_TARGETING_DB,
                               retailer_id)
        targeting_data = mongo_util.get_document(product)

        hash_relevance_map = {}
        if targeting_data:
            for target in targeting_data["target"]:
                key = RedisKeyGen.get_keyword_targeting_key_v2(retailer_id, target["hash"])
                hash_relevance_map[key] = target['relevance_score']

            key_val = self.redis_client.multi_get(list(
                hash_relevance_map.keys()))

            new_key_val = {}
            for key in key_val:
                if key_val[key] is None:
                    new_key_val[key] = str({
                        product: hash_relevance_map[key]
                    })
                else:
                    target_products = key_val[key]
                    if product not in target_products:
                        target_products[product] = hash_relevance_map[key]
                    new_key_val[key] = str(target_products)

            self.redis_client.mass_insert_to_redis(new_key_val)

    def __update_category_mappings(self, retailer_id, product):
        mongo_util = MongoUtil(Config.AzureConfig.COSMOS_URI,
                               Config.AzureConfig.COSMOS_CATEGORY_TARGETING_DB,
                               retailer_id)
        targeting_data = mongo_util.get_document(product)

        sku_relevance_map = {}
        if targeting_data:
            for target in targeting_data["target"]:
                target["category"] = target["category"].lower()
                target["category"] = re.sub('[^0-9a-zA-Z]+', '-',
                                            target["category"])
                key = RedisKeyGen.get_category_targeting_key_v2(retailer_id, target["category"])
                sku_relevance_map[key] = target['relevance_score']

            key_val = self.redis_client.multi_get(list(
                sku_relevance_map.keys()))

            new_key_val = {}
            for key in key_val:
                if key_val[key] is None:
                    new_key_val[key] = str({
                        product: sku_relevance_map[key]
                    })
                else:
                    target_products = key_val[key]
                    if product not in target_products:
                        target_products[product] = sku_relevance_map[key]
                    new_key_val[key] = str(target_products)

            self.redis_client.mass_insert_to_redis(new_key_val)

    def __update_product_mappings(self, retailer_id, product):
        mongo_util = MongoUtil(Config.AzureConfig.COSMOS_URI,
                               Config.AzureConfig.COSMOS_PRODUCT_TARGETING_DB,
                               retailer_id)
        targeting_data = mongo_util.get_document(product)

        sku_relevance_map = {}
        if targeting_data:
            for target in targeting_data["target"]:
                key = RedisKeyGen.get_product_targeting_key_v2(retailer_id, target["sku"])
                sku_relevance_map[key] = target['relevance_score']

            key_val = self.redis_client.multi_get(list(
                sku_relevance_map.keys()))

            new_key_val = {}
            for key in key_val:
                if key_val[key] is None:
                    new_key_val[key] = str({
                        product: sku_relevance_map[key]
                    })
                else:
                    target_products = key_val[key]
                    if product not in target_products:
                        target_products[product] = sku_relevance_map[key]
                    new_key_val[key] = str(target_products)

            self.redis_client.mass_insert_to_redis(new_key_val)

    def process_request(self, data):
        logging.info(
            '{env}: Processing campaign update event: {data}'.format(
                env=Config.AzureConfig.ENV,
                data=data
            )
        )
        retailer_id = str(data[self._CAMPAIGN_DATA][self._RETAILER_ID])
        campaign_id = str(data[self._CAMPAIGN_DATA][self._CAMPAIGN_ID])
        data[self._CAMPAIGN_DATA][self._PRODUCTS_TO_PROMOTE] = [
            x.lower() for x in data[self._CAMPAIGN_DATA][
                self._PRODUCTS_TO_PROMOTE]]
        products_to_promote = data[self._CAMPAIGN_DATA][
            self._PRODUCTS_TO_PROMOTE]

        # update metadata cache
        self.__update_metadata(data)

        # update product-campaign mapping
        product_campaign_map = self.__get_product_campaign_mapping(
            retailer_id, products_to_promote)
        new_products = self.__get_products_to_activate(product_campaign_map)
        self.__update_campaign_id(product_campaign_map, campaign_id)

        # activate new products
        for product in new_products:
            self.__update_keyword_mapping(retailer_id, product)
            self.__update_product_mappings(retailer_id, product)
            self.__update_category_mappings(retailer_id, product)

    def process_request_on_event(self, data):
        print("processing:", data)
        campaign_mode = data[self._CAMPAIGN_DATA][self._CAMPAIGN_MODE]
        products_to_promote = data[self._CAMPAIGN_DATA][
            self._PRODUCTS_TO_PROMOTE]
        if campaign_mode != self._AUTOMATIC or products_to_promote is None or \
                len(products_to_promote) == 0:
            return

        self.process_request(data)

    def on_event(self, partition_context, event):
        partition_context.update_checkpoint(event)
        data = json.loads(next(event.body).decode('UTF-8'))
        print("Received event from {partition}: {data}".format(
            partition=partition_context.partition_id,
            data=data
        ))
        logging.info(
            '{env}: Received event from {partition}: {data}'.format(
                env=Config.AzureConfig.ENV,
                partition=partition_context.partition_id,
                data=data
            )
        )

        campaign_mode = data[self._CAMPAIGN_DATA][self._CAMPAIGN_MODE]
        products_to_promote = data[self._CAMPAIGN_DATA][
            self._PRODUCTS_TO_PROMOTE]
        if campaign_mode != self._AUTOMATIC or products_to_promote is None \
                or len(products_to_promote) == 0:
            return

        self.process_request(data)

    def main(self):
        with self.eventhub_client:
            print('Running campaign listener')
            logging.info(
                '{env}: Running campaign listener'.format(
                    env=Config.AzureConfig.ENV
                )
            )
            self.create_consumer()
            # self.register_consumer()

    def register_consumer(self):
        self.eventhub_client.receive(on_event=self.on_event)

    def start_listener_thread(self):
        thread = threading.Thread(target=self.register_consumer)
        Log.info("Attempting to create consumer")
        thread.daemon = True
        thread.start()

    def create_consumer(self):
        self.start_listener_thread()
        delay = 600
        while True:
            time.sleep(10)
            if len(list(self.eventhub_client._event_processors.values())[0]._consumers.items()) == 0:
                Log.info("Closing consumer")
                self.eventhub_client.close()
                time.sleep(delay)
                self.start_listener_thread()
            else:
                Log.info("Campaign listener active")
                time.sleep(delay)

            delay = min(7200, 2*delay)


if __name__ == '__main__':
    # active_products_fetcher = ActiveProducts()
    # loop = asyncio.get_event_loop()
    # loop.run_until_complete(active_products_fetcher.main())
    logging.basicConfig(filename=LocalConfig.LOGS_PATH + 'log_file.log',
                        filemode='a',
                        format='%(asctime)s %(levelname)s-%(message)s',
                        datefmt='%Y-%m-%d %H:%M:%S',
                        level=logging.INFO
                        )
    ap = ActiveProducts()
    ap.main()
    # json_string = '{"event_time": "2022-02-17T10:03:14.149823Z", ' \
    #               '"campaign_data": {"campaign_id": "test_2", "roas":10,' \
    #               '"retailer_id": 757577, "campaign_name": "a","products_to_promote": ["p14076"], ' \
    #               '"budget": 99.0,"budget_type": "DAILY","ad_type": "VIDEO","is_active": false, "max_bid_price":3,' \
    #               '"campaign_mode":"AUTOMATIC", "placements":{"KEYWORD":["1","2"],"CATEGORY":["3","4"]}}}'
    # json_obj = json.loads(json_string)
    # ap.process_request(json_obj)
