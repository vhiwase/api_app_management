import numpy as np
import time
from relevance.keywordtargeting import KeywordTargeting
from config import Config
import argparse
from util.keyword_targetting_utils import KeywordHash
from numpy import dot
from util.mongo_util import MongoUtil

class PostProcess:
    def __init__(self, retailer_info):
        self.env = retailer_info['env']
        Config.switch_env(self.env)
        self.retailer_id = retailer_info['id']
        self.KT = KeywordTargeting()
        self.KH = KeywordHash()
        self.product_meta_data_mongo_client = MongoUtil(
            Config.AzureConfig.COSMOS_URI,
            Config.AzureConfig.COSMOS_PRODUCT_META_DB,
            self.retailer_id)


    def get_sku_keyword_yake(self, retailer_dict, yake_data, hash_to_embeddings):
        sku_to_keyword_yake = {}
        i = 0
        for sku in list(yake_data.keys()):
            hashes_list = list(set(map(self.KH.get_keyword_hash, yake_data[sku])))
            for hash in hashes_list:
                try:
                    cosine_similarity = (1 + dot(retailer_dict[sku]['embedding'][0], hash_to_embeddings[hash])) / 2
                    try:
                        sku_to_keyword_yake[sku].extend([{'hash': hash, 'relevance_score': cosine_similarity}])
                    except:
                        sku_to_keyword_yake[sku] = [{'hash': hash, 'relevance_score': cosine_similarity}]
                except:
                    pass
            i = i + 1
            if (i % 10000 == 0):
                print("Mapping processed for skus: ", i)
        return sku_to_keyword_yake

    def main(self):
        retailer_id = self.retailer_id
        yake_data = self.KT.get_data_from_blob(str(retailer_id) + '_yake_keywords_dict.pkl')
        retailer_data = self.KT.get_data_from_blob("full_data_KT_" + str(retailer_id) + ".pkl")
        retailer_dict = retailer_data.set_index('sku')[
            ['name', 'description', 'category', 'brand', 'productType', 'embedding']].to_dict('index')


        print("Updating product metadata")
        self.KT.update_product_metadata(retailer_data,self.product_meta_data_mongo_client)

        ######## Getting faiss mapping for keywords ###########
        hash_keyword_dict = self.KT.get_data_from_blob(str(retailer_id) + '_hash_keyword_dict.pkl')
        unique_keywords_list = []
        for hash in hash_keyword_dict:
            unique_keywords_list.append(hash_keyword_dict[hash][0])

        ## Generate and add search mapping ######

        st = time.time()
        keyword_ids = list(range(len(unique_keywords_list)))
        keyword_ids_to_keywords = dict(zip(keyword_ids, unique_keywords_list))
        keywords_embeddings = self.KT.get_embeddings(unique_keywords_list)
        sku_embedding_dict = dict(zip(retailer_data['sku'], retailer_data['embedding']))
        keywords_faiss_index = self.KT.create_faiss_index(keywords_embeddings, keyword_ids)
        distances_list, neighbors_list = keywords_faiss_index.search(np.vstack(sku_embedding_dict.values()), k=100)
        keyword_to_embeddings = dict(zip(unique_keywords_list, keywords_embeddings))
        hash_to_embeddings = {}
        for sentence in keyword_to_embeddings.keys():
            hash_to_embeddings[self.KH.get_keyword_hash(sentence)] = keyword_to_embeddings[sentence]

        sku_to_keyword_faiss = {}
        for i in range(len(sku_embedding_dict)):
            sku_to_keyword_faiss[list(sku_embedding_dict.keys())[i]] = [
                {'hash': self.KH.get_keyword_hash(keyword_ids_to_keywords[x]), 'relevance_score': (4 - y) / 4} for
                x, y in zip(neighbors_list[i], distances_list[i])]

        print("Time taken to get  sku hash faiss map is ", time.time() - st)

        print("Getting sku keyword map yake")
        sku_keyword_yake = PP.get_sku_keyword_yake(retailer_dict, yake_data, hash_to_embeddings)

        print("combining hashes dictionaries")
        st = time.time()
        sku_to_hash_combined = PP.KT.add_mapping(sku_to_keyword_faiss, sku_keyword_yake)
        print("Added both mapping in ", time.time() - st)

        print("Creating broad and exact keywords map")
        st = time.time()
        ###### Creating broad and exact keyword targeting ##########
        sku_keyword_map_exact = {}
        for sku in sku_to_hash_combined.keys():
            combined_hash_pairs = sorted(sku_to_hash_combined[sku], key=lambda d: d['relevance_score'], reverse=True)[
                                  :1000]
            combined_hash_pairs_exact = [x for x in combined_hash_pairs if x['relevance_score'] > .85]
            sku_keyword_map_exact[sku] = combined_hash_pairs_exact
        print("Created broad and exact match pairs in ", time.time() - st)

        ######## Add brand and producttype heuristic keywords ####
        print("Adding heurisitc keywords")
        st = time.time()
        sku_brand_ptype_heuristic = self.KT.get_ptype_brand_key_hashes_heuristic(retailer_dict)
        sku_keyword_map_exact = self.KT.add_mapping(sku_keyword_map_exact,sku_brand_ptype_heuristic)
        print("Added heurisitc keywords in ",time.time()-st)

        print("Adding boosting")
        st = time.time()
        sku_keyword_map_exact = PP.KT.add_boosting(retailer_dict, sku_keyword_map_exact)
        print("Boosting done in: ", time.time() - st)

        ###### Pushing data ############
        print("Pushing data to {env} environment".format(env=PP.env))
        st = time.time()
        PP.KT.push_data_to_blob(sku_keyword_map_exact, str(retailer_id) + '_sku_keyword_map_exact.pkl')
        print("time taken to push to blob ", time.time() - st)

        st = time.time()
        mongo_data_sku_hash_exact = PP.KT.create_mongo_data(sku_keyword_map_exact, 'sku_hash')
        PP.KT.push_data_to_mongo(mongo_data_sku_hash_exact, 'sku_hash_exact', retailer_id)
        print("Time taken to insert exact sku hash dict to mongo is", time.time() - st)
        print("Done")



if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Keyword onboarding process of exisitng Retailers')
    parser.add_argument('-i', '--id', help='ID', required=True)
    parser.add_argument('-e', '--env', help='environment', type=str, default='dev')
    args = vars(parser.parse_args())
    PP = PostProcess(args)
    PP.main()

