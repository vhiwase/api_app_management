var main_data;
async function fetchData(query) {
    var url = `query/${query}`
    fetch(url, {
        method: "GET",
        headers: {
            'content-type': 'application/json'
        }
    }).then(res => res.json()).then(data => generateTable(query, data))
}

function searchBoxKeyPress(event)
{
    if(event.keyCode == 13)
    {
        document.getElementById("search-btn").click();
        return false;
    }
}
/**
 * @param {Array} tableData Data from api after search
 */
 function generateTable(query, tableData) {
    main_data = tableData;
    if (document.getElementById("datarecords") != null) {
        var a = document.getElementById("datarecords");
        a.remove();
    }

    if (document.getElementById("search_query_hidden") != null) {
        var a = document.getElementById("search_query_hidden");
        a.remove();
    }

    var tableContainer = document.getElementById("table-container");
    var table = createElement("table");
    table.id = ("datarecords");
    var headers = Object.keys(tableData[0]);
    generateHeaders(headers, table);
    generateBody(tableData, headers, table);
    tableContainer.appendChild(table);
    var search_query = createElement("input");
    search_query.id = "search_query_hidden";
    search_query.type = "hidden";
    search_query.value = query;
    tableContainer.appendChild(search_query);
    document.getElementById("feedback-btn").style.visibility = "visible";
    document.getElementById("feedback-btn").disabled = false;
    document.getElementById("thank-you-banner").style.visibility = "hidden";
}
/**
 * @param {Array} headers headers for table
 * @param {HTMLTableElement} table table to be generated
 */
function generateHeaders(headers, table) {
    var thead = createElement("thead");
    var tr = createElement("tr");
    var th;
    headers.forEach((header, index) => {
        th = createElement("th");
        th.innerHTML = header.replace(/_/g, ' ');
        th.style.textAlign = "center";
        tr.appendChild(th);
    });
    th = createElement("th");
    th.innerHTML = "Correct / Incorrect";
    tr.style.textTransform = "Capitalize";
    th.style.textAlign = "center";
    tr.appendChild(th);
    thead.appendChild(tr);
    table.appendChild(thead);
    table.classList.add("table");
    table.classList.add("table-bordered");
    table.style.textAlign = "center";
}

/**
 * @param {Array} tableData table data from api
 * @param {Array} headers headers for table
 * @param {HTMLTableElement} table table to be generated
 */
function generateBody(tableData,headers,table) {
    var tbody = createElement("tbody");
    var tr;
    tableData.forEach((dataElement,index) => {
        tr = createElement("tr");
        var td;
        headers.forEach((header) => {
            td = createElement("td");
            td.innerHTML = dataElement[header];
            tr.appendChild(td);
        });
        td = createElement("td");
        var cb = createElement('input');
        cb.type = "checkbox";
        cb.checked = true;
        dataElement.isChecked = true;
        cb.onclick = ()=> {
            checkuncheckdata(dataElement);
        }
        td.appendChild(cb);
        tr.appendChild(td);
        tbody.appendChild(tr);
    })
    table.appendChild(tbody);
}

function createElement(type) {
   return document.createElement(type)
}
/**
 * @param {string} id id of input tag
 * @return {string} value of input-tag
 */
function getInputValue(id) {
    var tag = document.getElementById(id);
    return tag.value
}
function checkuncheckdata(dataElement) {
     
    dataElement.isChecked = dataElement.isChecked === undefined || dataElement.isChecked === false ?   true : false;
 
}

function submitFeedback () {
    var correctData = main_data.filter(x=> x.isChecked);
    var incorrectData = main_data.filter(x=> !x.isChecked);
    var returnObject = {
        "query" : document.getElementById("search_query_hidden").value,
        "correct" : correctData,
        "incorrect": incorrectData
    }
    var url = `feedback`
    const res =  fetch(url, {
        method: "POST",
        headers: {
            'content-type': 'application/json'
        },
        body: JSON.stringify(returnObject)
    })
    // console.log(returnObject)
    document.getElementById("feedback-btn").disabled = true;
    document.getElementById("thank-you-banner").style.visibility = "visible";
}