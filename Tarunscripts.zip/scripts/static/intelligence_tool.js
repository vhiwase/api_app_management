var main_data;
var search_query;
var search_target_type;
var search_bid_type;
var main_retailer_id;
var progressFunction;
async function fetchData() {

    retailer_id = document.getElementById('retailer-combo-box').value;
    query = document.getElementById('search-text-box').value;
    roas = document.getElementById('roas-text-box').value;
    target_type = document.querySelector('input[name="target_type"]:checked').value;
    bid_type = document.querySelector('input[name="bid_type"]:checked').value;
    document.getElementById("download-btn").style.visibility = "hidden";
    document.getElementById("table-container").style.visibility = "hidden";

    main_data = ""
    search_query = query
    search_target_type = target_type
    search_bid_type = bid_type
    debug_flag = new URLSearchParams(window.location.search).has("debug")

    var url = `intelligence_v2?retailer_id=${retailer_id}&sku=${query}&roas=${roas}&target_type=${target_type}`+
               `&bid_type=${bid_type}&page=0`;
    if(debug_flag)
        url =url + `&debug=${debug_flag}`
    fetch(url, {
        method: "GET",
        headers: {
            'content-type': 'application/json'
        }
    })
    .then(res => res.json()).then(data => generateTable(data["suggestions"]))
    .catch((error) => {
        document.getElementById("progressBar").style.visibility = "hidden";
        clearInterval(progressFunction);
        alert("No data found!")
    });
    document.getElementById("progressBar").style.visibility = "visible";
    initProgress();
}

function searchBoxKeyPress(event)
{
    if(event.keyCode == 13)
    {
        document.getElementById("search-btn").click();
        return false;
    }
}
/**
 * @param {Array} tableData Data from api after search
 */
 function generateTable(tableData) {
    main_data = tableData;
    if (document.getElementById("datarecords") != null) {
        var a = document.getElementById("datarecords");
        a.remove();
    }

//    if (document.getElementById("search_query_hidden") != null) {
//        var a = document.getElementById("search_query_hidden");
//        a.remove();
//    }

    var tableContainer = document.getElementById("table-container");
    var table = createElement("table");
    table.id = ("datarecords");
    var headers = Object.keys(tableData[0]);
    generateHeaders(headers, table);
    generateBody(tableData, headers, table);
    tableContainer.appendChild(table);
    document.getElementById("progressBar").style.visibility = "hidden";
    clearInterval(progressFunction);
    document.getElementById("table-container").style.visibility = "visible";
    document.getElementById("download-btn").style.visibility = "visible";

}
/**
 * @param {Array} headers headers for table
 * @param {HTMLTableElement} table table to be generated
 */
function generateHeaders(headers, table) {
    var thead = createElement("thead");
    var tr = createElement("tr");
    var th;
    headers.forEach((header, index) => {
        th = createElement("th");
        th.innerHTML = header;
        th.style.textAlign = "center";
        tr.appendChild(th);
    });
    thead.appendChild(tr);
    table.appendChild(thead);
    table.classList.add("table");
    table.classList.add("table-bordered");
    table.style.textAlign = "center";
}

/**
 * @param {Array} tableData table data from api
 * @param {Array} headers headers for table
 * @param {HTMLTableElement} table table to be generated
 */
function generateBody(tableData,headers,table) {
    var tbody = createElement("tbody");
    var tr;
    tableData.forEach((dataElement,index) => {
        tr = createElement("tr");
        var td;
        headers.forEach((header) => {
            td = createElement("td");
            td.innerHTML = dataElement[header];
            tr.appendChild(td);
        });
        tbody.appendChild(tr);
    })
    table.appendChild(tbody);
}

function createElement(type) {
   return document.createElement(type)
}
/**
 * @param {string} id id of input tag
 * @return {string} value of input-tag
 */
function getInputValue(id) {
    var tag = document.getElementById(id);
    return tag.value
}
function checkuncheckdata(dataElement) {
     
    dataElement.isChecked = dataElement.isChecked === undefined || dataElement.isChecked === false ?   true : false;
 
}

function download_table_as_csv() {
    var rows = document.querySelectorAll('table#datarecords  tr');
    var csv = [];
    for (var i = 0; i < rows.length; i++)
    {
        var row = [];
        var cols = rows[i].querySelectorAll('td, th');
        for (var j = 0; j < cols.length; j++)
            row.push(cols[j].innerText);
        csv.push(row.join(','));
    }
    download_string_as_csv(search_query + '_' + search_target_type + '_' + search_bid_type + '.csv', csv.join('\n'))
}

function download_string_as_csv(fileName, csvString)
{
    var link = document.createElement('a');
    link.style.display = 'none';
    link.setAttribute('target', '_blank');
    link.setAttribute('href', 'data:text/csv;charset=utf-8,' + encodeURIComponent(csvString));
    link.setAttribute('download', fileName);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

function initProgress() {
    var elem = document.getElementById("progressBarMeter");
    elem.style.width = "1%"
    var width = 1;
    progressFunction = setInterval(progress, 500);
    function progress() {
        if (width >= 100) {
            clearInterval(progressFunction);
        } else {
            width++;
            elem.style.width = width + "%";
        }
    }
}


function fill_retailers_data(data)
{
   var retailer_list = document.getElementById("retailer-combo-box");
   for(var i=0; i<data.length; i++)
   {
        var option = document.createElement('option');
        option.text =data[i]["retailer_name"];
        option.value = data[i]["retailer_id"];
        retailer_list.add(option);
   }
   document.getElementById("bodyContent").style.visibility = "visible";
   document.getElementById("progressBar").style.visibility = "hidden";
   clearInterval(progressFunction);
}

function init_retailers()
{
    url = "retailers"
    fetch(url, {method: "GET"})
    .then(res => res.json()).then(data => fill_retailers_data(data))
    .catch((error) => {
        alert("Not able to fetch retailers data!")
        document.getElementById("progressBar").style.visibility = "hidden";
        clearInterval(progressFunction);
    });
    document.getElementById("progressBar").style.visibility = "visible";
    initProgress();
}


