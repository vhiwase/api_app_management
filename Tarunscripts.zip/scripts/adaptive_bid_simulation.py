# Dummy script for simulating adaptive bidding. This can be removed once we are done with all simulations.

from bidding.auto_bidder import AutoBidder
auto_bidder = AutoBidder()

winner = {
    "campaign_id": None,
    "ecpm": 50.0
}
print("Iteration,Bid,Floor price,Competition")
for i in range(1, 151):
    campaign_list = [{
        "campaign_id": "test_campaign",
        "bid": 5.0,
        "ctr": 0.01,
        "ecpm": 50.0
    }]
    result = auto_bidder.apply_adaptive_bidder(campaign_list, winner, 20.0)
    ecpm = result[0]["ecpm"]
    bid = result[0]["bid"]
    campaign_id = result[0]["campaign_id"]
    if 50 < i < 100:
        print("{i},{bid},2.0,3.0".format(i=i, ecpm=ecpm, bid=bid))
    else:
        print("{i},{bid},2.0,0".format(i=i, ecpm=ecpm, bid=bid))
    winner["ecpm"] = ecpm
    winner["campaign_id"] = campaign_id
    if 50 < i < 100 and winner["ecpm"] < 30:
        winner["ecpm"] = 30
        winner["campaign_id"] = "competing campaign"


