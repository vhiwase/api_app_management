import sys
import torch
import pickle
import time
from config import LocalConfig
from sentence_transformers import SentenceTransformer
import numpy as np

if __name__ == "__main__":
    num_cuda_devices = torch.cuda.device_count()
    if num_cuda_devices < 1:
        err_msg = "need gpus to run keyword mapping"
        sys.exit(err_msg)
    cuda_devices = ["cuda:" + str(i) for i in range(0, num_cuda_devices)]

    roberta_model = SentenceTransformer(LocalConfig.MODEL_PATH, device='cpu')
    st = time.time()
    fname = sys.argv[1]
    fp = open(fname, "br")
    sentences = pickle.load(fp)
    fp.close()
    # start the multi-process pool on all available CUDA devices
    pool = roberta_model.start_multi_process_pool(cuda_devices)

    # compute the embeddings using the multi-process pool
    embeddings = roberta_model.encode_multi_process(sentences, pool)
    embeddings = embeddings / np.expand_dims(np.linalg.norm(embeddings, axis=1), axis=1)
    print("Embeddings computed. Shape:", embeddings.shape)

    # stop the proccesses in the pool
    roberta_model.stop_multi_process_pool(pool)

    emb_dict = {}
    for index, sentence in enumerate(sentences):
        emb_dict[sentence] = embeddings[index]

    et = time.time()

    print("time taken to generate embeddings for keywords:")
    print(str(et - st) + " seconds")
    fp = open("sentence_embeddings.pkl", "bw")
    pickle.dump(emb_dict, fp)
    fp.close()

