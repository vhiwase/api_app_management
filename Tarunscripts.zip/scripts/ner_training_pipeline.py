# pylint: disable=all
import pandas as pd
import random
import shutil
import spacy
from spacy.tokens import DocBin
import subprocess
import re
from azure.storage.blob import BlobServiceClient
from config import Config, LocalConfig
import os
import pytz
import signal
import logging

class NERFineTuning:
    price_prefix, config_file, file_name = (None, None, None)
    
    def __init__(self):
        self.file_name = "spacy_v2.zip"
        self.config_file = "../data/config_copy.cfg"
        self.price_prefix = '(?![0-9. ]*(ctw|k|dew|ct|tcw))'
        logging.basicConfig(filename = "../data/spacy_ner.log",
                        format = '%(asctime)s %(message)s',
                        filemode = 'w')
        self.logger = logging.getLogger()
        self.logger.setLevel(logging.DEBUG)
        
    def set_model_name(self):
        blob_service_client = BlobServiceClient.from_connection_string(
            Config.AzureConfig.ICC_DS_STORAGE_CONNECTION_STRING
        )
        container_client = blob_service_client.get_container_client(
            container=Config.AzureConfig.CONTAINER_NAME
        )

        most_recent_date = max([item['last_modified'] for item in container_client.list_blobs()])
        version_name = [item['name'] for item in container_client.list_blobs() if item['last_modified']==most_recent_date]
        next_version = int(re.search(r'[0-9]+', version_name[0], re.IGNORECASE).group()) + 1
        self.file_name = 'spacy_v' + str(next_version) + '.zip'
        
    
    def match_brand_name(self, brand, name):
        '''
        generates a score to compare the match of brand's keywords in title

        arguments: brand, title

        returns: int(score), str(brand_in_query)
        '''
        if brand in name:
            return 1
        return 0
    
   
    
    def parse_indexes(self, span_indexes, start_index, end_index):
        '''adds the span indexes of any regex match to a string on indexes of Entity

        arguments: span, int(start index of entity), int(end_index of entity)

        returns: str(start and end indexes for entities)
        '''
        start_index = ','.join([str(start_index), str(span_indexes[0])])
        end_index = ','.join([str(end_index), str(span_indexes[1])])
        return (start_index, end_index)
    
    def create_query_between(self, val, currency, preposition):
        '''generate a query for "price is between 2 prices" and extract the entity indexes

        arguments: row of dataframe, random currency, preposition

        returns: a list [query, start_indexes, end_indexes, entity_labels], boolean(error_flag)
        '''
        row_data = []
        price = int(val['price'])
        left_range, right_range = map(str, (price, price + 50))

        # this snippet generates 4 types of queries,
        # only 1 is selected randomly and indexes are formatted accordingly
        # 1. nike shoes between 10 and 20 dollars
        # 2. shoes by nike between 10 and 20$
        # 3. nike shoes between 10 dollars and 20 dollars
        # 4. shoes by nike between 10$ and 20$
        
        query_prefix = random.choice([' '.join([val['brand'], val['name']]),
                                      ' '.join([val['name'], preposition, val['brand']])
                                     ])
        
        query_suffix = [
            random.choice([left_range + random.choice([' ', '']) + currency, left_range, currency + random.choice([' ', '']) + left_range]),
            random.choice([right_range+ random.choice([' ', '']) + currency, right_range, currency+ random.choice([' ', '']) + right_range])]
        
        query = ' between '.join([query_prefix, ' and '.join(query_suffix)])
        
        multi_currency = True if query_suffix.count(currency)==2 else False

        
        # add indexes of brand name
        start_index, end_index = ("", "")
        try:
            start_index, end_index = map(str, re.search(val['brand'], query, re.IGNORECASE).span())
        except:
            return (row_data, False)

        # add indexes of "between" relation
        span_indexes = re.search('between', query, re.IGNORECASE).span()
        start_index, end_index = self.parse_indexes(span_indexes, start_index, end_index)
        
        for suffix in query_suffix:
            regex_price = suffix.replace('$', '\$') + self.price_prefix
            # print("\033[93m", suffix, query, end="\n\n")
            span_indexes = re.search(regex_price, query, re.IGNORECASE).span()
            start_index, end_index = self.parse_indexes(span_indexes, start_index, end_index)
        
        
        row_data.extend([query, start_index, end_index])
        row_data.append("BRAND, PRC_REL, PRC, PRC")
        return (row_data, True)
    
    def create_query_general(self, query, brand, price, currency, relationship):

        '''extracts indexs of entities from a query

        arguments: str(query), str(brand), str(price), str(currency), str(relationship)

        returns: a list [query, start_indexes, end_indexes, entity_labels], boolean(error_flag)
        '''

        row_data = []
        try:
            start_index, end_index = map(str, re.search(brand, query, re.IGNORECASE).span())
            if int(end_index) - int(start_index) == 0:
                return row_data, False
        except:
            return row_data, False

        span_indexes = re.search(relationship, query, re.IGNORECASE).span()
        start_index, end_index = self.parse_indexes(span_indexes, start_index, end_index)

        # span_indexes = re.search(price, query, re.IGNORECASE).span()
        regex_price = price + self.price_prefix
        span_indexes = re.search(regex_price, query, re.IGNORECASE).span()

        start_index += ',' + str(span_indexes[0])
        end_index += ',' + str(span_indexes[1] + len(currency) + 1)

        row_data.extend([query, start_index, end_index])
        row_data.append("BRAND, PRC_REL, PRC")
        return row_data, True
    
    
    def create_query_no_brand(self, val, relationship, currency):
        '''generate a query for exclusion of brand

        arguments: row of dataframe, price relationship, currency

        returns: a list [query, start_indexes, end_indexes, entity_labels], boolean(error_flag)
        '''
        row_data = []
        start_index, end_index = ("", "")

        # 1. shoes from 10$
        # 2. shoes between 10 and 20$
        between = random.choice([True, False])

        if between:
            # define the range of price value
            left_range, right_range = str(int(val['price'])), str(int(val['price']) + 50)
            query = ' '.join([val['name'],
                              'between',
                              left_range,
                              'and',
                              right_range,
                              currency])

            try:
                start_index, end_index = map(str, re.search('between', query, re.IGNORECASE).span())
            except:
                return (row_data, False)

            # add index of "from" price
            regex_price = str(left_range) + self.price_prefix
            span_indexes = re.search(regex_price, query, re.IGNORECASE).span()
            start_index, end_index = self.parse_indexes(span_indexes, start_index, end_index)

            # add index of "to" price and currency
            regex_price = str(right_range) + self.price_prefix
            span_indexes = re.search(regex_price, query, re.IGNORECASE).span()
            start_index += ',' + str(span_indexes[0])
            end_index += ',' + str(span_indexes[1] + len(currency) + 1)

            row_data.extend([query, start_index, end_index])
            row_data.append("PRC_REL, PRC, PRC")

        else:
            query = ' '.join([val['name'],
                              relationship,
                              str(val['price']),
                              currency])
            try:
                start_index, end_index = map(str, re.search(relationship, query, re.IGNORECASE).span())
            except:
                return row_data, False
            regex_price = str(int(val['price'])) + self.price_prefix
            span_indexes = re.search(regex_price, query, re.IGNORECASE).span()
            start_index += ',' + str(span_indexes[0])
            end_index += ',' + str(span_indexes[1] + len(currency) + 1)
            row_data.extend([query, start_index, end_index])
            row_data.append("PRC_REL, PRC")

        return row_data, True 
    
    
    def generate_data_brand_only(self, data, df):

        '''generate a query with brand and title only

        arguments: data, output_dataframe

        returns: output_dataframe with a columns [query, start_indexes, end_indexes, entity_labels]
        '''

        data = data[~data['brand'].isnull()]
        data.reset_index(drop=True,inplace=True)
        for i, val in data.iterrows():

            choice = random.randint(1, 2)
            query, brand, row_data, preposition = ("", val['brand'], [], random.choice(['by', 'from']))

            # generate score if partial brand name is in title
            score = self.match_brand_name(brand, val['name'])

            if score:
                query = val['name']
            elif choice == 1:
                query = val['name'] + ' ' + preposition + ' ' + val['brand']
            else:
                query = val['brand'] + ' ' + val['name']

            try:
                span_indexs = re.search(brand, query, re.IGNORECASE).span()
            except:
                continue

            row_data.append(query)
            row_data.extend(map(str, span_indexs))
            row_data.append("BRAND")

            df = df.append([row_data])
        return df
    
    
    def generate_data_brand_price(self, data, df):
        '''driver function for all types of queries 

        arguments: data, output_dataframe

        returns: output_dataframe with a columns [query, start_indexes, end_indexes, entity_labels]
        '''
        data = data[~data['brand'].isnull()]
        data.reset_index(drop=True,inplace=True)
        for i, val in data.iterrows():

            query, brand, row_data = ("", val['brand'], [])

            choice = random.randint(1, 4)
            preposition = random.choice(['by', 'from'])
            currency = random.choice(['$', 'dollar', 'dollars', 'cents', 'usd'])
            relationship = random.choice(['less than', 'more than', 'above', 'under'])

            # generate score if partial brand name is in title
            score = self.match_brand_name(val['brand'], val['name'])

            # check score for partial brand name in title
            if score:
                query = ' '.join([val['name'],
                                  relationship,
                                  str(val['price']),
                                  currency])

            #  shoes by nike above 10 dollars  
            elif choice == 1:
                query = ' '.join([val['name'],
                                  preposition,
                                  val['brand'],
                                  relationship,
                                  str(val['price']),
                                  currency])

            # nike shoes from 10 dollars 
            elif choice == 2:
                query = ' '.join([val['brand'],
                                  val['name'],
                                  relationship,
                                  str(val['price']),
                                  currency])

            # all queries involving "between" price relationship
            elif choice == 3:
                row_data, flag = self.create_query_between(val, currency, preposition)
                # print("\033[92m", flag, row_data, end="\n\n")
                if flag:
                    df = df.append([row_data])
                continue

            # brand name is not to be included in query
            elif choice == 4:
                row_data, flag = self.create_query_no_brand(val, relationship, currency)
                if flag:
                    df = df.append([row_data])
                continue

            # populate the list [query, start_indexes, end_indexes, entity_labels]  
            row_data, flag = self.create_query_general(query, brand, str(int(val['price'])), currency, relationship)
            # print("\033[91m", row_data, end="\n\n")
            if flag:
                df = df.append([row_data])

        return df
    

    def change_to_json(self, df):
        data = []
        for i, val in df.iterrows():
            entities = []
            ent, f_ind, e_ind = df.loc[i, 'entity'].split(','), str(df.loc[i, 'start index']).strip().split(','), str(
                df.loc[i, 'end index']).strip().split(',')
            for index in range(len(ent)):
                entities.append((int(f_ind[index]), int(e_ind[index]), ent[index].strip()))
            tuples = (df.loc[i, 'query'].strip(), {'entities': entities})
            data.append(tuples)
        return data

    def change_to_spacy(self, df):
        nlp = spacy.blank("en")
        db = DocBin()
        for text, annot in df:  # data in previous format
            doc = nlp.make_doc(text)  # create doc object from text
            ents = []
            for start, end, label in annot["entities"]:  # add character indexes
                span = doc.char_span(start, end, label=label, alignment_mode="contract")
                if span is None:
                    print("Skipping entity")
                    print(start, end, label, text)
                else:
                    ents.append(span)
            try:
                doc.ents = ents  # label the text with the ents
                db.add(doc)
            except:
                continue
        return db

    def change_data_format(self, train, test):
        train_json, test_json = self.change_to_json(train), self.change_to_json(test)
        train_spacy, test_spacy = self.change_to_spacy(train_json), self.change_to_spacy(test_json)
        return train_spacy, test_spacy

    def train_and_archive_model(self):

        path_output_check = '../data/spacy_ner/'
        self.set_model_name()

        command = f"python -m spacy train {self.config_file} --output {path_output_check} --paths.train ../data/train.spacy --paths.dev ../data/dev.spacy --training.eval_frequency 10 --training.max_steps 500 --gpu-id 0"

        try:
            process = subprocess.Popen(command.split(" "), stdout=subprocess.PIPE)
            # os.system(command) 
            for line in iter(process.stdout.readline, ''):
                line = line.decode('UTF-8').rstrip()
                self.logger.info(line)
                if line != path_output_check + 'model-last':
                    print(line)
                else:
                    print("terminating process")
                    process.send_signal(signal.SIGTERM)
                    break
            print("training finished.")
        except KeyboardInterrupt:
            print("terminating process")
            process.send_signal(signal.SIGTERM)
        except Exception as e:
            print("ERROR: In executing the train command")

        shutil.make_archive("../data/"+self.file_name.split(".")[0], "zip", path_output_check + "model-best")
        blob_service_client = BlobServiceClient.from_connection_string(
            Config.AzureConfig.ICC_DS_STORAGE_CONNECTION_STRING
        )
        blob_client = blob_service_client.get_blob_client(
            container=Config.AzureConfig.CONTAINER_NAME, blob=self.file_name
        )

        print("\nUploading to Azure Storage as blob:\n\t" + self.file_name)
        with open(LocalConfig.DATA_FOLDER_PATH + self.file_name, "rb") as data:
            blob_client.upload_blob(data, overwrite = True)
            return "File added/updated to Blob"

        return "Exception"
    
    
    def main(self, data, config_file):
        
        self.config_file = config_file
        
        train_data = pd.DataFrame()
        train_data = self.generate_data_brand_only(data, train_data)
        train_data = self.generate_data_brand_price(data, train_data)
        train_data.columns = ['query', 'start index', 'end index', 'entity']
        train_data = train_data.sample(frac = 1)
        train_data = train_data.reset_index(drop = True)
        split_index = int(90/100*train_data.shape[0])
        ner_train_data = train_data.iloc[:split_index, :].copy()
        test_data = train_data.iloc[split_index:, :].copy()
        train_spacy, test_spacy = self.change_data_format(ner_train_data, test_data)
        train_spacy.to_disk("../data/train.spacy")
        test_spacy.to_disk("../data/dev.spacy")
        training_status = self.train_and_archive_model()
        return training_status

if __name__ == "__main__":

    #Populate this list of retailers before training from scratch
    #We have to make sure that it is not trained from scratch

    retailers = ['../data/757577/data_jtv.pkl',
                '../data/123456/data_baldor.pkl'
                ]

    nft = NERFineTuning()

    nft.main(pd.read_pickle(retailers[0]), '../data/config_copy.cfg')

    for retailer in retailers[1:]:
        nft.main(pd.read_pickle(retailer), '../data/config.cfg')
