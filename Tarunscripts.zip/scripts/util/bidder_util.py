class BidderUtil:
    @staticmethod
    def compute_bid_v2(acos, sku_info_list):
        factor = 0.0
        total_value = 0.0
        acos = acos / 100.0

        for sku_info in sku_info_list:
            factor += sku_info["ctr"]
            aov = sku_info["aov"]
            total_value += sku_info["pc_cvr"] * aov * acos * sku_info["ctr"]

        return round(total_value / factor, 2)

    @staticmethod
    def compute_bid(retailer, acos, sku_info_list):
        factor = 0.0
        total_value = 0.0
        acos = acos/100.0

        for sku_info in sku_info_list:
            factor += sku_info["ctr"]
            aov = retailer.get_product_by_sku(sku_info["sku"]).get_price()
            total_value += sku_info["pc_cvr"] * aov * acos * sku_info["ctr"]

        return round(total_value/factor, 2)

    @staticmethod
    def compute_campaign_cvr(sku_info_list):
        probabilities = []
        for sku_info in sku_info_list:
            probabilities.append(sku_info["pc_cvr"])
        prob_union = BidderUtil._prob_union(probabilities)

        return prob_union

    @staticmethod
    def compute_campaign_aov(sku_info_list):
        aov = []
        for sku_info in sku_info_list:
            aov.append(float(sku_info["aov"]))
        return round(sum(aov)/len(aov), 2)

    @staticmethod
    def compute_campaign_ctr(sku_info_list):
        probabilities = []

        for sku_info in sku_info_list:
            probabilities.append(sku_info["ctr"])

        prob_union = BidderUtil._prob_union(probabilities)

        return prob_union

    @staticmethod
    def compute_ecpm(campaign_ctr, bid):
        return round(bid*campaign_ctr*1000, 2)

    @staticmethod
    def _prob_union(probabilities):
        if len(probabilities) == 0:
            return 0

        prob_union = 0
        for i in range(0, len(probabilities)):
            prob_union += probabilities[i]
            for j in range(i + 1, len(probabilities)):
                prob_union -= probabilities[i] * probabilities[j]

        return prob_union

    @staticmethod
    def compute_retailer_revenue(
            bid, campaign_aov, campaign_ctr, campaign_cvr, cost_type,
            retailer_profit
    ):
        revenue = bid
        if cost_type == "CPC":
            revenue = ((campaign_ctr * bid) + (
                    campaign_aov * campaign_ctr * campaign_cvr *
                    retailer_profit
            ))*1000
        if cost_type == "CPM":
            revenue = bid + (
                campaign_aov * campaign_ctr * campaign_cvr *
                retailer_profit
            )*1000
        return round(revenue, 2)
