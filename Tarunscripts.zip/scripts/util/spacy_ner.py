# pylint: disable=all
from context.context import Context

class SpacyNer:
    
    # @staticmethod
    def __init__(self):
        self.__origin_model = Context.NLP_SPACY
        
    # @staticmethod
    def entity_extraction(self, query):
        docs = self.__origin_model(query)
        result = {'PRC' : [], 'PRC_REL' : [], 'BRAND' : ''}
        for ent in docs.ents:
            if ent.label_ == 'PRC':
                result['PRC'].append(ent.text)
            elif ent.label_ == 'BRAND':
                result['BRAND'] = ent.text
            elif ent.label_ == 'PRC_REL':
                result['PRC_REL'].append(ent.text)
        return result
