import logging
import os
from config import Config, LocalConfig

# changes to output to console for loki migration
logging.basicConfig(format='%(asctime)s %(levelname)s-%(message)s',
                    datefmt='%Y-%m-%d %H:%M:%S',
                    level=logging.INFO,
                    handlers=[logging.StreamHandler()]
                    )

class Log:
    @staticmethod
    def info(message):
        logging.info(
            "[{ENV}]:{message}".format(ENV=Config.AzureConfig.ENV, message=message)
        )

    @staticmethod
    def exception(message):
        logging.exception(
            "[{ENV}]:{message}".format(ENV=Config.AzureConfig.ENV, message=message)
        )
