# pylint: disable=all
from config import Config
import requests
from collections import defaultdict
from util.mongo_util import MongoUtil

class FloorPriceExtractor:

    @staticmethod
    def get_placement_meta(retailer_id):
        """
        Use the placement meta in downward modules for floor price
        """
        placements_meta_mongo_client = MongoUtil(
            Config.AzureConfig.COSMOS_URI,
            Config.AzureConfig.COSMOS_DATABASE_NAME,
            Config.AzureConfig.COSMOS_PLACEMENTS_META_TABLE
        )

        placement_meta_data = placements_meta_mongo_client.get_document(str(retailer_id))
        if placement_meta_data:
            return placement_meta_data.get('placement_meta')
        return None

    @staticmethod
    def get_ecpm_floor_price_targeting_type(retailer_id):
        """
        Gets the min,max dicts of ecpm value among all placement ids for targeting type
        """
        placement_data = FloorPriceExtractor.get_placement_meta(
            retailer_id
        )
        min_floor_prices = defaultdict(float)
        max_floor_prices = defaultdict(float)
        if placement_data:
            for placement in placement_data:
                target_type = placement.get('targeting', None).lower()
                floor_price = placement.get('min_floor_price_cpm_value', 0.0)

                if target_type is not None and floor_price is not None:
                    if target_type in min_floor_prices.keys():
                        if min_floor_prices[target_type] > floor_price:
                            min_floor_prices[target_type] = floor_price
                        else:
                            max_floor_prices[target_type] = floor_price
                    else:
                        min_floor_prices[target_type] = floor_price

        return {
            'min_floor_prices': min_floor_prices,
            'max_floor_prices': max_floor_prices
        }

