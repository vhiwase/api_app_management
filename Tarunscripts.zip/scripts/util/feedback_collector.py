# pylint: disable=all
from util.meta_data_extractor import MetaDataExtractor
from config import Config


class FeedbackCollector:
    @staticmethod
    def push_batch_data_to_MongoDB(feedback_dictionary):
        """
        Input: list_of_dictionary : list containing dictionaries to be pushed having primary key _id
        Output: 'Success' if data pushed successfully
                'Failed' if data wasn't pushed
        """
        # Initialize Mongoclient for cosmosdb
        column = MetaDataExtractor.initialize_mongo_client(
            Config.AzureConfig.COSMOS_URI,
            Config.AzureConfig.COSMOS_DATABASE_NAME,
            Config.AzureConfig.COSMOS_FEEDBACK_TABLE
        )
        try:
            column.insert_one(feedback_dictionary) 
        except Exception as e:
            # add ids that haven't been pushed to cosmos
            print("Data Not pushed") 
            print(e)
