from relevance.auto_target import AutoTarget
from bidding.auto_bidder import AutoBidder
from metric_estimation.metric_estimator import MetricsEstimator
from collections import defaultdict


class GetTargetsAndBids:
    def __init__(self):
        self.auto_target = AutoTarget()
        self.auto_bidder = AutoBidder()
        self.metric_estimator = MetricsEstimator()

    def get_bid_data(self, retailer, roas, products_to_promote,
                     target_type, bid_type="CPC", suggestions=False, adhoc_targets=None):

        targeting_type = target_type.lower()
        targets = []
        if targeting_type == "keyword":
            for sku in products_to_promote:
                temp = self.auto_target.get_keywords_for_product(retailer, sku)
                for entry in temp:
                    entry['sku'] = sku
                    targets.append(entry)
        elif targeting_type == "category":
            for sku in products_to_promote:
                temp = self.auto_target.get_category_targets(retailer, sku)
                for entry in temp:
                    entry['sku'] = sku
                    targets.append(entry)
        elif targeting_type == "product":
            for sku in products_to_promote:
                temp = self.auto_target.get_products_by_product(retailer, sku)
                for entry in temp:
                    entry['sku'] = sku
                    targets.append(entry)
        else:
            abort(405, "Unsupported type: " + targeting_type)

        if adhoc_targets:
            targets = self.get_adhoc_targets_relevance_score(adhoc_targets, targets)

        self.metric_estimator.get_metric_for_many(retailer, "ctr", targeting_type,
                                                  targets)
        self.metric_estimator.get_metric_for_many(retailer, "pc_cvr", targeting_type,
                                                  targets)

        target_group_map = {}
        for entry in targets:
            if entry['target_value'] not in target_group_map:
                target_group_map[entry['target_value']] = []

            target_group_map[entry['target_value']].append(
                dict(sku=entry["sku"], pc_cvr=entry["pc_cvr"], ctr=entry["ctr"])
            )

        result = []
        for target_value in target_group_map:
            target_group = target_group_map[target_value]
            bid = self.auto_bidder.compute_bid(retailer, 1.0 / roas * 100, target_group)
            if suggestions:
                cpm_bid_value = self.auto_bidder.compute_ecpm(target_group, bid)
                result.append(
                    dict(target_type=targeting_type.upper(),
                         target_value=target_value,
                         cpc_bid_value=bid,
                         cpm_bid_value=cpm_bid_value,
                         click_through_rate=target_group_map[
                             target_value][0]['ctr'])
                )
            else:
                if bid_type == "CPC":
                    bid_value = bid
                else:
                    ctr = self.auto_bidder.compute_campaign_ctr(target_group)
                    bid_value = self.auto_bidder.compute_ecpm(ctr, bid)
                result.append(
                    dict(target_value=target_value, bid=bid_value)
                )

        if suggestions:
            result = sorted(result, key=lambda x: x["cpc_bid_value"], reverse=True)
        else:
            result = sorted(result, key=lambda x: x["bid"], reverse=True)

        return result

    def get_mean_relevance_at_sku(self, targets):
        relevance_sum = defaultdict(float)
        relevance_count = defaultdict(float)
        for each in targets:
            relevance_sum[each['sku']] = relevance_sum[each['sku']] + each['relevance_score']
            relevance_count[each['sku']] = relevance_count[each['sku']] + 1

        relevance_mean = defaultdict(float)
        for sku in relevance_sum:
            if relevance_count[sku] != 0:
                relevance_mean[sku] = relevance_sum[sku] / relevance_count[sku]

        return relevance_mean

    def get_adhoc_targets_relevance_score(self, adhoc_targets, targets):
        # taking mean relevance score for now incase of adhoc target till we compute the real relevance
        targets_final = []
        relevance_mean = self.get_mean_relevance_at_sku(targets)
        for adhoc_target in adhoc_targets:
            targets_adhoc = []
            for each in targets:
                if adhoc_target == each['target_value']:
                    targets_adhoc.append(each)
            if len(targets_adhoc) == 0:
                if len(relevance_mean) > 0:
                    for sku in relevance_mean:
                        targets_adhoc.append(
                            {
                                'target_value': adhoc_target,
                                relevance_score: relevance_mean[sku],
                                'sku': sku

                            }
                        )

            targets_final = targets_final + targets_adhoc
        return targets_final
