import os
from azure.storage.blob import ContainerClient, BlobServiceClient
from io import StringIO
import pandas as pd
from config import Config, AzureConfigPROD
from datetime import datetime, timedelta
import pickle
import pyarrow as pa
import pyarrow.parquet as pq
from io import BytesIO
import time


class ReadAndWriteFromAzureBlob:
    def push_data_to_blob(self, data_path, file_name, connection_string, container_name):
        file_name = data_path + file_name
        blob_service_client = BlobServiceClient.from_connection_string(connection_string)
        blob_client = blob_service_client.get_blob_client(
                      container = container_name, blob = file_name)
        print("\nUploading to Azure Storage as blob:\n\t" + file_name)
        with open(file_name, "rb") as data:
            blob_client.upload_blob(data, overwrite = True)
            return "File added/updated to Blob"
        return "Exception"

    def read_data_by_stream(
            self,
            connection_string,
            container_name,
            blob_name,
            is_pickle=False
    ):
        input_client = ContainerClient.from_connection_string(
            connection_string,
            container_name
        )

        data_from_blob = input_client.download_blob(
            blob_name
        )
        if  not is_pickle:
            blob_df = pd.read_csv(
                StringIO(data_from_blob.content_as_text())
            )
        else:
            fpw = open(blob_name, "bw")
            data_from_blob.readinto(fpw)
            fpw.close()
            fp = open(blob_name, "br")
            blob_df = pickle.load(fp)
            fp.close()

        return blob_df

    @staticmethod
    def read_pickle_file(
            connection_string, container_name, blob_name
    ):
        blob_service_client = BlobServiceClient.from_connection_string(
            connection_string)
        container_client = blob_service_client.get_container_client(
            container_name)
        blob_client = container_client.get_blob_client(blob_name)

        # Download the content of the blob
        blob_bytes = blob_client.download_blob().readall()

        # Load the pickle file
        pickle_object = pickle.loads(blob_bytes)
        return pickle_object

    def write_to_blob(
            self,
            connection_string,
            container_name,
            blob_name,
            data,
            is_pickle=False
    ):
        output_client = BlobServiceClient.from_connection_string(
            connection_string
        )
        try:
            if not is_pickle:
                output_file_name = 'temp_' + blob_name.split("/")[-1]
                data.to_csv(output_file_name, index=None)
            else:
                output_file_name = blob_name
                fp = open(output_file_name, "bw")
                pickle.dump(data,fp)
                fp.close()

            blob_client = output_client.get_blob_client(
                container_name,
                blob_name
            )
            with open(output_file_name, "rb") as data:
                blob_client.upload_blob(
                    data,
                    overwrite=True
                )
                print("Uploaded data to blob: {container_name} {blob_name}".format(
                    container_name=container_name,
                    blob_name=blob_name
                )
                )
                os.remove(output_file_name)
        except Exception:
            raise Exception(
                "Unable to upload data to blob : {container_name} {blob_name}".format(
                    container_name=container_name,
                    blob_name=blob_name
                )
            )

    def get_list_of_blobs_from_container(
            self,
            connection_string,
            container_name
    ):
        input_client = ContainerClient.from_connection_string(
            connection_string,
            container_name
        )
        blobs_list = list(input_client.list_blobs())
        return blobs_list

    def read_only_csv_stream(
            self,
            blob_paths,
            connection_string,
            container_name
    ):
        df = pd.DataFrame()
        for blob_path in blob_paths:
            try:
                if '.csv' in blob_path:
                    temp_df = self.read_data_by_stream(
                        connection_string,
                        container_name,
                        blob_path
                    )
                    df = pd.concat([temp_df, df], ignore_index=True)
            except Exception as e:
                print("Ignoring Exception: {e}".format(e=e))
                continue

        return df

    def find_blob_name_from_container_and_read_df(
            self,
            connection_string,
            container_name,
            list_of_input_strings,
            do_csv_check=False
    ):

        blobs_list = self.get_list_of_blobs_from_container(
            connection_string,
            container_name
        )

        blob_paths = []
        for blob in blobs_list:
            all_checks = 0
            for path_check in list_of_input_strings:
                if path_check in blob.name:
                    all_checks = all_checks + 1
            if all_checks == len(list_of_input_strings):
                blob_paths.append(blob.name)

        if not blob_paths:
            raise Exception(
                "No matching blob found with input strings list"
            )

        if do_csv_check:
            return self.read_only_csv_stream(
                blob_paths,
                connection_string,
                container_name
            )

        df = pd.DataFrame()
        for blob_path in blob_paths:
            temp_df = self.read_data_by_stream(
                connection_string,
                container_name,
                blob_path
            )
            df = pd.concat([temp_df, df], ignore_index=True)

        return df

    def find_csv_from_container_and_read_df(
            self,
            connection_string,
            container_name,
            list_of_input_strings
    ):

        blobs_list = self.get_list_of_blobs_from_container(
            connection_string,
            container_name
        )

        blob_paths = []
        for blob in blobs_list:
            all_checks = 0
            for path_check in list_of_input_strings:
                if path_check in blob.name:
                    all_checks = all_checks + 1
            if all_checks == len(list_of_input_strings):
                blob_paths.append(blob.name)

        blob_paths = filter(lambda k: '.csv' in k, blob_paths)

        if not blob_paths:
            raise Exception(
                "No matching blob found with input strings list"
            )

        df = pd.DataFrame()
        for blob_path in blob_paths:
            temp_df = self.read_data_by_stream(
                connection_string,
                container_name,
                blob_path
            )
            df = pd.concat([temp_df, df], ignore_index=True)

        return df

    def get_input_df_from_datascience_container(
            self, retailer_id, job_name, blob_path, days_from_current_day=1, do_csv_check=False,
            data_source_config=None
    ):

        date_string = datetime.strftime(
            datetime.now() - timedelta(days_from_current_day), '%Y/%m/%d'
        )
        year, month, day = date_string.split("/")
        blob_path = blob_path.format(
            retailer_id=retailer_id,
            year=year,
            month=month,
            day=day,
            job_name=job_name
        )
        # Usually prod data containers are updated in prod hence giving flexibility of reading from prod
        if data_source_config == 'prod':
            return self.find_blob_name_from_container_and_read_df(
                AzureConfigPROD.SUGGESTIONS_INPUT_CONNECTION_STRING,
                AzureConfigPROD.SUGGESTION_INPUT_CONTAINER,
                [blob_path],
                do_csv_check
            )

        return self.find_blob_name_from_container_and_read_df(
            Config.AzureConfig.SUGGESTIONS_INPUT_CONNECTION_STRING,
            Config.AzureConfig.SUGGESTION_INPUT_CONTAINER,
            [blob_path],
            do_csv_check
        )

    def get_input_df_for_suggestions(self, retailer_id, job_name, days_from_current_day=1):
        return self.get_input_df_from_datascience_container(
            retailer_id,
            job_name,
            Config.AzureConfig.SUGGESTION_INPUT_STRING,
            days_from_current_day
        )

    def get_input_df_from_csv(self, retailer_id, job_name,
                              days_from_current_day=1):
        date_string = datetime.strftime(
            datetime.now() - timedelta(days_from_current_day), '%Y/%m/%d')
        year, month, day = date_string.split("/")
        blob_path = Config.AzureConfig.SUGGESTION_INPUT_STRING.format(
            retailer_id=retailer_id,
            year=year,
            month=month,
            day=day,
            job_name=job_name
        )

        return self.find_csv_from_container_and_read_df(
            Config.AzureConfig.SUGGESTIONS_INPUT_CONNECTION_STRING,
            Config.AzureConfig.SUGGESTION_INPUT_CONTAINER,
            [blob_path]
        )

    @staticmethod
    def write_log_to_blob(connection_string, container_name, blob_name):
        output_client = BlobServiceClient.from_connection_string(
            connection_string)
        try:
            blob_client = output_client.get_blob_client(
                container_name,
                blob_name
            )
            with open('log_file.log', "rb") as data:
                blob_client.upload_blob(
                    data,
                    overwrite=True
                )
                print("Uploaded log to blob: {container_name} "
                      "{blob_name}".format(
                    container_name=container_name,
                    blob_name=blob_name)
                )
        except Exception:
            raise Exception(
                "Unable to upload log to blob : {container_name} "
                "{blob_name}".format(
                    container_name=container_name,
                    blob_name=blob_name
                )
            )

    @staticmethod
    def write_target_logs_to_azure(retailer_id, campaign_id, data):
        today = datetime.now()
        try:
            if not data.empty:
                data = data.drop_duplicates()
                data.reset_index(inplace=True, drop=True)
                data.insert(0, "timestamp", round(time.time()))
                table = pa.Table.from_pandas(df=data)
                buf = BytesIO()
                pq.write_table(table, buf)
                buf.seek(0)
                blob_service_client = BlobServiceClient.from_connection_string(
                    Config.AzureConfig.ICC_DS_STORAGE_CONNECTION_STRING
                )
                blob_client = blob_service_client.get_blob_client(
                    Config.AzureConfig.TARGETING_LOGS_CONTAINER,
                    Config.AzureConfig.TARGET_LOGS_BLOB_FORMAT.format(
                        today.year, '{:02d}'.format(today.month),
                        '{:02d}'.format(today.day), retailer_id,
                        campaign_id, round(time.time())
                    )
                )
                blob_client.upload_blob(buf.getvalue(), overwrite=True)
                print(
                    "Target logs for campaign id {} in retailer {} is "
                    "uploaded".format(campaign_id, retailer_id)
                )
            else:
                print(
                    "No target logs for campaign id {} in retailer {} is "
                    "uploaded".format(campaign_id, retailer_id)
                )
        except Exception as e:
            print(e)
