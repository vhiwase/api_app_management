# pylint: disable=all
from pymongo import MongoClient
import certifi
from config import Config


class MetaDataExtractor:
    @staticmethod
    def get_retailer_matadata(retailer_id=None):
        meta_data = []

        # initializing connection
        mongo_client = MetaDataExtractor.initialize_mongo_client(
            Config.AzureConfig.COSMOS_URI,
            Config.AzureConfig.COSMOS_DATABASE_NAME,
            Config.AzureConfig.COSMOS_META_DATA_TABLE
        )
        if retailer_id:
            meta_data = mongo_client.find_one({"_id": int(retailer_id)})
        else:
            records = mongo_client.find()
            for row in records:
                meta_data.append(row)

        return meta_data

    @staticmethod
    def get_product_metadata(retailer_id, sku):
        # initializing connection
        mongo_client = MetaDataExtractor.initialize_mongo_client(
            Config.AzureConfig.COSMOS_URI,
            Config.AzureConfig.COSMOS_PRODUCT_META_DB,
            str(retailer_id)
        )
        meta_data = mongo_client.find_one({"_id": sku})

        return meta_data

    @staticmethod
    def get_active_targets_v2(
            retailer_id, campaign_id, uid
    ):
        mongo_client = MetaDataExtractor.initialize_mongo_client(
            Config.AzureConfig.COSMOS_URI,
            Config.AzureConfig.COSMOS_ACTIVE_TARGETS_DB,
            str(retailer_id)
        )

        _id = campaign_id + "_" + uid
        meta_data = mongo_client.find_one({"_id": _id})
        if meta_data:
            return meta_data["target_keys"]
        return None

    @staticmethod
    def set_active_targets_v2(
            retailer_id, campaign_id, uid, target_keys
    ):
        # initializing connection
        mongo_client = MetaDataExtractor.initialize_mongo_client(
            Config.AzureConfig.COSMOS_URI,
            Config.AzureConfig.COSMOS_ACTIVE_TARGETS_DB,
            str(retailer_id)
        )
        _id = campaign_id + "_" + uid
        mongo_client.update_one(
            {"_id": _id},
            {"$set": {"target_keys": target_keys}},
            upsert=True
        )

    @staticmethod
    def remove_active_targets_v2(retailer_id, campaign_id, uid):
        mongo_client = MetaDataExtractor.initialize_mongo_client(
            Config.AzureConfig.COSMOS_URI,
            Config.AzureConfig.COSMOS_ACTIVE_TARGETS_DB,
            str(retailer_id)
        )
        _id = campaign_id + "_" + uid
        mongo_client.delete_one({"_id": _id})

    # This function initializes Mongoclient for cosmosdb
    @staticmethod
    def initialize_mongo_client(uri, database_name, table_name):
        try:
            # initialize MongoClient using connection uri
            ca = certifi.where()
            client = MongoClient(uri, tlsCAFile=ca)
            # specify the database name in MongoDB
            database = client[database_name]
            # specify the table name in database
            column = database[table_name]
            return column
        except Exception as e:
                print("Error while connecting to Cosmos", e)
                return None

    @staticmethod
    def get_retailer_list_for_suggestions():
        retailer_ids = list()
        meta_data_list = MetaDataExtractor.get_retailer_matadata()
        for meta_data in meta_data_list:
            if meta_data.get("auto_suggestion"):
                retailer_ids.append(meta_data["_id"])
        return retailer_ids

    @staticmethod
    def get_retailer_list_for_job(job_name):
        retailer_ids = list()
        meta_data_list = MetaDataExtractor.get_retailer_matadata()
        for meta_data in meta_data_list:
            if meta_data.get(job_name):
                retailer_ids.append(meta_data['_id'])
        return retailer_ids

    @staticmethod
    def get_all_retailer_ids_in_env():
        retailer_ids = list()
        meta_data_list = MetaDataExtractor.get_retailer_matadata()
        for meta_data in meta_data_list:
            retailer_ids.append(meta_data['_id'])
        return retailer_ids

    def get_retailer_list():
        retailers = list()
        meta_data_list = MetaDataExtractor.get_retailer_matadata()
        for meta_data in meta_data_list:
            retailers.append(
                {
                    "retailer_id": meta_data["_id"],
                    "retailer_name": meta_data["retailer_name"],
                }
            )
        return retailers
        
