from flask import request
import time
from prometheus_client import Counter, Summary, Histogram
import numpy as np

class PrometheusMetrics:

    __APP_NAME = 'DS_SERVICE'
    # more the no of buckets give sharper percentiles without much interpolation
    # https://prometheus.io/docs/practices/histograms/
    # making list till 1s with each millisecond as step
    buk_list = list(np.arange(0, 1, 0.001))
    __REQUEST_LATENCY = Histogram('request_latency_seconds', 'Request latency',
                              ['app_name', 'endpoint', 'http_status'],
                              buckets=buk_list
                              )

    __REDIS_LATENCY = Histogram('redis_client_latency_seconds', 'Redis latency',
                                ['app_name', 'endpoint'],
                                buckets=buk_list
                                )

    @staticmethod
    def start_timer():
        request.start_time = time.time()

    def stop_timer(self, response):
        resp_time = time.time() - request.start_time
        self.__REQUEST_LATENCY.labels(self.__APP_NAME, request.path, response.status_code).observe(resp_time)
        return response

    def setup_metrics(self, app):
        app.before_request(self.start_timer)
        app.after_request(self.stop_timer)

    def redis_latency(self, start_time, path):
        self.__REDIS_LATENCY.labels(self.__APP_NAME, path).observe(time.time() - start_time)
