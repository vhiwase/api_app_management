from datetime import datetime, timedelta
from io import BytesIO
import functools
import pandas as pd
from azure.storage.blob import ContainerClient
from config import Config
from util.read_write_data_azure_blob import ReadAndWriteFromAzureBlob


class CampaignDataAggregator:
    def __init__(self):
        self.input_client = ContainerClient.from_connection_string(
            conn_str=Config.AzureConfig.AGGREGATION_INPUT_STRING,
            container_name=Config.AzureConfig.AGGREGATION_INPUT_CONTAINER
        )
        self.read_write_azure = ReadAndWriteFromAzureBlob()

    @staticmethod
    def __get_parquets(path, input_folder_string, input_file_type):
        if input_folder_string in path.name and input_file_type in path.name:
            return path.name

    def __create_blob_index(self, input_folder_string, input_file_type):
        all_files = list(
            self.input_client.list_blobs(name_starts_with=input_folder_string)
        )
        blobs_ = list(
            set(list(map(functools.partial(self.__get_parquets,
                input_folder_string=input_folder_string,
                input_file_type=input_file_type),
                all_files)))
        )
        blobs_ = list(filter(None, blobs_))
        return blobs_

    def aggregate_campaign_data(
            self, time_delta, flush_mode=False
    ):
        campaign_data = []
        dataframe = pd.DataFrame()

        year, month, day = datetime.strftime(
            datetime.now() - timedelta(time_delta), "%Y/%m/%d"
        ).split('/')

        blobs_list = self.__create_blob_index(
            "campaign-logs/year={}/month={}/day={}".format(year, month, day),
            ".parquet"
        )

        if blobs_list:
            for parquet in blobs_list:
                stream_downloader = self.input_client.download_blob(parquet)
                stream = BytesIO()
                stream_downloader.readinto(stream)
                processed_df = pd.read_parquet(stream, engine="pyarrow")
                dataframe = dataframe.append(processed_df)
            dataframe.reset_index(inplace=True, drop=True)
            dataframe = dataframe["campaign_data"].apply(pd.Series)
            dataframe = dataframe[dataframe["id"].notnull()]
            dataframe = dataframe
            dataframe = dataframe[
                ["id", "mode", "budget", "budget_type", "retailer_id",
                 "status", "ad_groups"]
            ]
            dataframe = dataframe[dataframe["budget"].notnull()]
            dataframe['budget'] = dataframe['budget'].apply(
                lambda x: int(float(x))
            )

        if flush_mode:
            return dataframe.to_dict("records")

        dataframe = dataframe[dataframe["mode"] == "MANUAL"]
        data = dataframe.to_dict("records")

        # Removing ad group and targets that are not active for suggestions
        for record in data:
            campaign_id = record["id"]
            if record["status"] == "INACTIVE":
                continue
            for ad_group in record["ad_groups"]:
                if ad_group["status"] == "INACTIVE":
                    continue
                products_to_promote = []
                for product in ad_group["products_to_promote"]:
                    if product["status"] == "ACTIVE":
                        products_to_promote.append(
                            str(product["sku_id"]).lower()
                        )
                for target in ad_group["targets"]:
                    campaign_data.append(
                        {
                            "retailer_id": record["retailer_id"],
                            "campaignId": campaign_id,
                            "ad_group_id": ad_group["id"],
                            "target_type": target["targeting_type"],
                            "target_value": target["target_value"],
                            "bid": target["bid"],
                            "cost_type": target["bid_type"],
                            "budget": record["budget"],
                            "budget_type": record["budget_type"],
                            "products_to_promote": products_to_promote,
                            "is_negative": target["is_negative"]
                        }
                    )

        return pd.DataFrame(campaign_data)
