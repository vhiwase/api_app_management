from util.redis_utils import RedisUtil, RedisCache, RedisKeyGen
from config import Config
import math
import nltk
nltk.download('stopwords')


class MetricsUtil:
    _RELEVANCE_RANGE = 0.1
    _RELEVANCE_MEAN = 0.6
    _SKU = 'sku'
    _ID = 'id'
    _RELEVANCE_SCORE = 'relevance_score'
    _SIMILAR_CATEGORIES = 'similar_categories'
    _DEFAULT_RELEVANCE_SCORE = _RELEVANCE_MEAN
    _CTR = 'ctr'
    _PC_CVR = 'pc_cvr'
    _KEYWORD_TARGETING = 'keyword'
    _CATEGORY_TARGETING = 'category'
    _PRODUCT_TARGETING = 'product'

    def __init__(self):
        self.redis_client = RedisCache(Config.AzureConfig.REDIS_HOST_NAME,
                                      Config.AzureConfig.REDIS_PASSWORD)

    def __calculate_calibrated_metric(self, relevance_score, lower_, upper_):
        if relevance_score is None:
            relevance_score = self._DEFAULT_RELEVANCE_SCORE
        scaled_score = (relevance_score - self._RELEVANCE_MEAN) / self._RELEVANCE_RANGE
        calibrated_score = 1 / (1 + math.exp(-scaled_score))
        metric_range = upper_ - lower_
        calibrated_metric = (lower_ + (calibrated_score * metric_range))
        return calibrated_metric

    def get_metric_for_one(self, retailer_id, retailer_meta_data, metric, target_type,
                           target_value, sku, relevance_score=None):
        sku = str(sku).lower()
        target_value = str(target_value).lower()

        lb = retailer_meta_data[metric + "_lb"]
        ub = retailer_meta_data[metric + "_ub"]

        keys = self.get_metric_keys(retailer_id, sku, metric, target_type, target_value)
        key_val = self.redis_client.multi_get(keys)

        for key in keys:
            if key_val[key] is None:
                continue
            vals = key_val[key]
            lb, ub = vals[0], vals[1]
            break

        return self.__calculate_calibrated_metric(relevance_score, lb, ub)

    def get_metric_keys(self, retailer_id, sku, metric, target_type, target_value):
        sku = str(sku).lower()
        target_value = str(target_value).lower()

        if metric == self._PC_CVR:
            return self.__get_pc_cvr_keys(retailer_id, sku, target_type, target_value)
        else:
            return self.__get_ctr_keys(retailer_id, sku, target_type, target_value)

    def __get_ctr_keys(self, retailer_id, sku, target_type, target_value):
        keys = []
        if target_type == self._KEYWORD_TARGETING:
            keys.append(RedisKeyGen.get_ctr_sku_keyword_key(retailer_id, sku, target_value))
        elif target_type == self._CATEGORY_TARGETING:
            keys.append(RedisKeyGen.get_ctr_sku_category_key(retailer_id, sku, target_value))
        elif target_type == self._PRODUCT_TARGETING:
            keys.append(RedisKeyGen.get_ctr_sku_sku_key(retailer_id, sku, target_value))

        keys.append(RedisKeyGen.get_ctr_sku_key(retailer_id, sku))
        # if retailer.get_product_by_sku(sku):
        #     keys.append(
        #         RedisKeyGen.get_ctr_catg_key(
        #             retailer.retailer_id,
        #             str(retailer.get_product_by_sku(sku).get_category()).lower()
        #         )
        #     )
        keys.append(RedisKeyGen.get_ctr_retailer_key(retailer_id))

        return keys

    def __get_pc_cvr_keys(self, retailer_id, sku, target_type, target_value):
        keys = []
        if target_type == self._KEYWORD_TARGETING:
            keys.append(RedisKeyGen.get_pc_cvr_sku_keyword_key(retailer_id, sku, target_value))
        elif target_type == self._CATEGORY_TARGETING:
            keys.append(RedisKeyGen.get_pc_cvr_sku_category_key(retailer_id, sku, target_value))
        elif target_type == self._PRODUCT_TARGETING:
            keys.append(RedisKeyGen.get_pc_cvr_sku_sku_key(retailer_id, sku, target_value))

        keys.append(RedisKeyGen.get_pc_cvr_sku_key(retailer_id, sku))
        # if retailer.get_product_by_sku(sku):
        #     keys.append(
        #         RedisKeyGen.get_pc_cvr_category_key(
        #             retailer.retailer_id,
        #             str(retailer.get_product_by_sku(sku).get_category()).lower()
        #         )
        #     )
        keys.append(RedisKeyGen.get_pc_cvr_retailer_key(retailer_id))

        return keys

    def add_metric_for_many_request(
            self, retailer_id, retailer_meta_data, metric_type, request_list):

        meta_data_lb = retailer_meta_data[metric_type + "_lb"]
        meta_data_ub = retailer_meta_data[metric_type + "_ub"]

        all_keys = []
        entry_key_map = {}
        for request in request_list:
            keys = self.get_metric_keys(
                retailer_id, request["sku"], metric_type, request["target_type"], request["target_value"]
            )
            all_keys.extend(keys)
            entry_key_map[request["sku"]+"_"+request["target_type"]+"_"+request["target_value"]] = keys

        key_val = self.redis_client.multi_get(all_keys)

        for request in request_list:
            lb = meta_data_lb
            ub = meta_data_ub
            for key in entry_key_map[request["sku"]+"_"+request["target_type"]+"_"+request["target_value"]]:
                if key_val[key] is None:
                    continue
                vals = key_val[key]
                lb, ub = vals[0], vals[1]
                break
            request[metric_type] = self.__calculate_calibrated_metric(
                request.get('relevance_score'), lb, ub
            )

        return request_list
