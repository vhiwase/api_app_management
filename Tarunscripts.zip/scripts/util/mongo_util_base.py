from pymongo import MongoClient
from pymongo import UpdateOne
import certifi


class MongoUtilBase:
    def __init__(self, uri):
        ca = certifi.where()
        self.client = MongoClient(uri, tlsCAFile=ca)

    def get_document(self, database_name, table_name, document_id):
        return self.client[database_name][table_name].find_one({"_id": document_id})

    def get_documents(self, database_name, table_name, document_id_list):
        return self.client[database_name][table_name].find({"_id": {"$in": document_id_list}})

    def get_all_documents(self, database_name, table_name):
        return self.client[database_name][table_name].find()

    def upsert(self, database_name, table_name, data):
        self.client[database_name][table_name].update({"_id": data["_id"]}, data, True)

    def upsert_bulk(self, database_name, table_name, data):
        n = 500
        upserts = [UpdateOne({'_id':x['_id']}, {'$set':x}, upsert=True) for x in data]
        upserts_chunks = [upserts[i:i + n] for i in range(0, len(upserts), n)]
        for ind, upserts_chunk in enumerate(upserts_chunks):
            if ind % 10 == 0:
                print("processed %d upserts_chunks" %ind)
            result = self.client[database_name][table_name].bulk_write(upserts_chunk, ordered=False)

    def insert(self, database_name, table_name, data):
        self.client[database_name][table_name].insert_one(data)

    def update(self, database_name, table_name, data):
        self.client[database_name][table_name].update({"_id": data["_id"]}, data)

    def insert_many(self, database_name, table_name, data_list, ordered=True):
        self.client[database_name][table_name].insert_many(data_list, ordered)

    def delete_all_from_collection(self, database_name, table_name):
        self.client[database_name][table_name].delete_many(filter={})

    def flush_all_keys(self, database_name, table_name):
        self.client[database_name][table_name].drop()

    def delete_one(self, database_name, table_name, key):
        self.client[database_name][table_name].delete_one({"_id": key})
