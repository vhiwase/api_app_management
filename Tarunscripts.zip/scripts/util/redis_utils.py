import redis
import json
import time
import threading
from cachetools import TTLCache
from .prometheus_metrics import PrometheusMetrics
from config import Config
# DO NOT REMOVE THE BELOW LINE
from numpy import NaN


class RedisUtil:
    def __init__(self, redis_host_name, redis_password):
        self.client = redis.StrictRedis(
            host=redis_host_name, port=6379, db=0,
            password=redis_password, ssl=False)
        self.__prom_metrics = PrometheusMetrics()

    def get_value(self, key):
        start_time = time.time()
        val = self.client.get(key)
        if val:
            val = eval(val)
            self.__prom_metrics.redis_latency(start_time, self.get_value.__qualname__)
            return val
        
        self.__prom_metrics.redis_latency(start_time, self.get_value.__qualname__)
        return None

    def get_all_keys(self):
        return self.client.keys()

    def set_value(self, key, value):
        try:
            self.client.set(key, str(value))
            print("Setting {} : {}".format(key, value))
        except Exception as e:
            print(e)

    def mass_insert_to_redis(self, dict_obj):
        batch_size = min(100000, len(dict_obj))
        cnt = 0
        dict_obj_chunk = {}
        for k, v in dict_obj.items():
            if cnt == batch_size:
                self.client.mset(dict_obj_chunk)
                dict_obj_chunk = {}
                cnt = 0
            dict_obj_chunk[k] = v
            cnt += 1
        self.client.mset(dict_obj_chunk)
        print("Setting :", dict_obj)

    def delete_keys_with_pattern(self, pattern):
        start_time = time.time()
        item_count = 0
        batch_size = 10000
        keys = []

        print("Start scanning keys...")
        for k in self.client.scan_iter(pattern, count=batch_size):
            keys.append(k)
            if len(keys) >= batch_size:
                item_count += len(keys)
                print("batch delete to {} ...".format(item_count))
                self.client.delete(*keys)
                keys = []

        if len(keys) > 0:
            item_count += len(keys)
            print("batch delete to {}".format(item_count))
            self.client.delete(*keys)

        end_time = time.time()
        print("deleted {0} keys in {1:0.3f} ms.".format(item_count, (
                end_time - start_time) / 1000.0))

    def get_items_with_pattern(self, pattern):
        pattern_items = {}
        for k in self.client.scan_iter(pattern):
            pattern_items[k] = json.loads(self.get_value(k))
        return pattern_items

    def get_keys_with_pattern(self, pattern):
        return self.client.scan_iter(pattern)

    def check_exists(self, key):
        self.client.exists(key)

    def multi_get(self, keys):
        start_time = time.time()
        vals = self.client.mget(keys)
        key_val = {}
        for i in range(0, len(keys)):
            if vals[i] is None:
                key_val[keys[i]] = None
            else:
                key_val[keys[i]] = eval(vals[i])

        self.__prom_metrics.redis_latency(start_time, self.multi_get.__qualname__)
        return key_val

    def multi_hash_get(self, name, keys):
        start_time = time.time()
        vals = self.client.hmget(name, keys)
        key_val = {}
        for i in range(0, len(keys)):
            if vals[i] is None:
                key_val[keys[i]] = None
            else:
                val = vals[i][12:]
                key_val[keys[i]] = json.loads(val.decode())

        self.__prom_metrics.redis_latency(start_time, self.multi_hash_get.__qualname__)
        return key_val

    def delete_key(self, key):
        self.client.delete(key)

    def delete_multiple_keys(self, keys_list):
        self.client.delete(*keys_list)

    def get_keys_with_pattern_batch(self, pattern, count):
        mid_results = []
        cur, results = self.client.scan(cursor=0, match=pattern, count=count)
        mid_results += results
        while cur != 0:
            cur, results = self.client.scan(cursor=cur, match=pattern,
                                            count=count)
            mid_results += results

        return list(set(mid_results))


class RedisCache(RedisUtil):
    def __init__(self, redis_host_name, redis_password):
        super().__init__(redis_host_name, redis_password)
        self.max_size = 10000
        self.ttl = 300
        self.cache = TTLCache(maxsize=self.max_size, ttl=self.ttl)
        self.__prom_metrics = PrometheusMetrics()
        self._lock = threading.Lock()
        # self.cahce = {}

    def get_value(self, key):
        start_time = time.time()
        if '_6446977_' not in key:
            with self._lock:
                val = self.cache.get(key, '')
            if val == '':
                val = super().get_value(key)
                with self._lock:
                    self.cache[key] = val
        else:
            val = super().get_value(key)
        self.__prom_metrics.redis_latency(start_time, self.get_value.__qualname__)
        return val

    def set_value(self, key, val):
        super().set_value(key, val)
        with self._lock:
            self.cache[key] = val

    def multi_get(self, keys):
        start_time = time.time()
        is_cache = True
        for key in keys:
            if '_6446977_' in key:
                is_cache = False
                break

        if is_cache:
            key_val = {}
            miss_key_val = {}
            miss_keys = []
            with self._lock:
                for key in keys:
                    val = self.cache.get(key, '')
                    if val != '':
                        key_val[key] = val
                    else:
                        miss_keys.append(key)
            if miss_keys:
                miss_key_val = super().multi_get(miss_keys)
                with self._lock:
                    self.cache.update(miss_key_val)
            key_val.update(miss_key_val)
        else:
            key_val = super().multi_get(keys)
        self.__prom_metrics.redis_latency(start_time, self.multi_get.__qualname__)
        return key_val


class RedisKeyGen:

    @staticmethod
    def get_prod_camapaign_map_key(retailer_id, sku):
        return "{env}_prod_campaign_map_{retailer_id}_{sku}".format(
            env=Config.AzureConfig.ENV,
            retailer_id=retailer_id,
            sku=sku
        )

    @staticmethod
    def get_camapaign_meta_key(retailer_id, campaign_id):
        return "{env}_campaign_{retailer_id}_{campaign_id}".format(
            env=Config.AzureConfig.ENV,
            retailer_id=retailer_id,
            campaign_id=campaign_id
        )

    @staticmethod
    def get_ctr_sku_keyword_key(retailer_id, sku, keyword):
        return "{env}_ctr_{retailer_id}_sku_{sku}_key_{keyword}".format(
            env=Config.AzureConfig.ENV,
            retailer_id=retailer_id,
            sku=sku,
            keyword=keyword
        )

    @staticmethod
    def get_ctr_sku_category_key(retailer_id, sku, category):
        return "{env}_ctr_{retailer_id}_sku_{sku}_catg_{category}".format(
            env=Config.AzureConfig.ENV,
            retailer_id=retailer_id,
            sku=sku,
            category=category
        )

    @staticmethod
    def get_ctr_sku_sku_key(retailer_id, sku, target_sku):
        return "{env}_ctr_{retailer_id}_sku_{sku}_prod_{target_sku}".format(
            env=Config.AzureConfig.ENV,
            retailer_id=retailer_id,
            sku=sku,
            target_sku=target_sku
        )

    @staticmethod
    def get_ctr_sku_key(retailer_id, sku):
        return "{env}_ctr_{retailer_id}_sku_{sku}".format(
            env=Config.AzureConfig.ENV,
            retailer_id=retailer_id,
            sku=sku
        )

    @staticmethod
    def get_ctr_catg_key(retailer_id, category):
        return "{env}_ctr_{retailer_id}_catg_{category}".format(
            env=Config.AzureConfig.ENV,
            retailer_id=retailer_id,
            category=category
        )

    @staticmethod
    def get_ctr_retailer_key(retailer_id):
        return "{env}_ctr_{retailer_id}".format(
            env=Config.AzureConfig.ENV,
            retailer_id=retailer_id
        )

    @staticmethod
    def get_pc_cvr_sku_keyword_key(retailer_id, sku, keyword):
        return "{env}_pc_cvr_{retailer_id}_sku_{sku}_key_{keyword}".format(
            env=Config.AzureConfig.ENV,
            retailer_id=retailer_id,
            sku=sku,
            keyword=keyword
        )

    @staticmethod
    def get_pc_cvr_sku_category_key(retailer_id, sku, category):
        return "{env}_pc_cvr_{retailer_id}_sku_{sku}_catg_{category}".format(
            env=Config.AzureConfig.ENV,
            retailer_id=retailer_id,
            sku=sku,
            category=category
        )

    @staticmethod
    def get_pc_cvr_sku_sku_key(retailer_id, sku, target_sku):
        return "{env}_pc_cvr_{retailer_id}_sku_{sku}_prod_{target_sku}".format(
            env=Config.AzureConfig.ENV,
            retailer_id=retailer_id,
            sku=sku,
            target_sku=target_sku
        )

    @staticmethod
    def get_pc_cvr_sku_key(retailer_id, sku):
        return "{env}_pc_cvr_{retailer_id}_sku_{sku}".format(
            env=Config.AzureConfig.ENV,
            retailer_id=retailer_id,
            sku=sku
        )

    @staticmethod
    def get_pc_cvr_category_key(retailer_id, category):
        return "{env}_pc_cvr_{retailer_id}_catg_{category}".format(
            env=Config.AzureConfig.ENV,
            retailer_id=retailer_id,
            category=category
        )

    @staticmethod
    def get_pc_cvr_retailer_key(retailer_id):
        return "{env}_pc_cvr_{retailer_id}".format(
            env=Config.AzureConfig.ENV,
            retailer_id=retailer_id
        )

    @staticmethod
    def get_winner_ecpm_key(retailer_id, target_type, target_value, placement_id):
        return "{env}_wecpm_{retailer_id}_{target_type}_{target_value}_{placement_id}".format(
            env=Config.AzureConfig.ENV,
            retailer_id=retailer_id,
            target_type=target_type,
            target_value=target_value,
            placement_id=placement_id
        )

    @staticmethod
    def get_targeting_key_v2(retailer_id, target_type, target_value):
        if target_type == "category":
            return RedisKeyGen.get_category_targeting_key_v2(retailer_id, target_value)
        if target_type == "product":
            return RedisKeyGen.get_product_targeting_key_v2(retailer_id, target_value)
        if target_type == "keyword":
            return RedisKeyGen.get_keyword_targeting_key_v2(retailer_id, target_value)
        if target_type == "audience":
            return RedisKeyGen.get_audience_targeting_key_v2(
                retailer_id, target_value
            )
        if target_type == "placement" or target_type == "page":
            return RedisKeyGen.get_other_targeting_key_v2(
                retailer_id, target_type, target_value
            )
        return ""

    @staticmethod
    def get_audience_targeting_key_v2(retailer_id, audience_id):
        return "{env}_v2_{retailer_id}_ut_{audience_id}".format(
            env=Config.AzureConfig.ENV,
            retailer_id=retailer_id,
            audience_id=audience_id
        )

    @staticmethod
    def get_category_targeting_key_v2(retailer_id, category):
        return "{env}_v2_{retailer_id}_ct_{category}".format(
            env=Config.AzureConfig.ENV,
            retailer_id=retailer_id,
            category=category
        )

    @staticmethod
    def get_keyword_targeting_key_v2(retailer_id, keyword):
        return "{env}_v2_{retailer_id}_kt_{keyword}".format(
            env=Config.AzureConfig.ENV,
            retailer_id=retailer_id,
            keyword=keyword
        )

    @staticmethod
    def get_exact_keyword_targeting_key_v2(retailer_id, keyword):
        return "{env}_v2_{retailer_id}_ekt_{keyword}".format(
            env=Config.AzureConfig.ENV,
            retailer_id=retailer_id,
            keyword=keyword
        )

    @staticmethod
    def get_product_targeting_key_v2(retailer_id, sku):
        return "{env}_v2_{retailer_id}_pt_{sku}".format(
            env=Config.AzureConfig.ENV,
            retailer_id=retailer_id,
            sku=sku
        )

    @staticmethod
    def get_other_targeting_key_v2(retailer_id, target_type, target_value):
        return "{env}_v2_{retailer_id}_ot_{target_type}_{target_value}".format(
            env=Config.AzureConfig.ENV,
            retailer_id=retailer_id,
            target_type=target_type,
            target_value=target_value
        )

    @staticmethod
    def get_other_targeting_key_v2(retailer_id, target_type, target_value):
        return "{env}_v2_{retailer_id}_ot_{target_type}_{target_value}".format(
            env=Config.AzureConfig.ENV,
            retailer_id=retailer_id,
            target_type=target_type,
            target_value=target_value
        )

    @staticmethod
    def get_ab_test_user_flag_key(retailer_id, user_key):
        return "{env}_ab_test_{retailer_id}_{user_key}".format(
            env=Config.AzureConfig.ENV,
            retailer_id=retailer_id,
            user_key=user_key
        )

    @staticmethod
    def get_ab_test_campaign_flag_key(retailer_id, campaign_id):
        return "{env}_ab_test_campaign_{retailer_id}_{campaign_id}".format(
            env=Config.AzureConfig.ENV,
            retailer_id=retailer_id,
            campaign_id=campaign_id
        )
