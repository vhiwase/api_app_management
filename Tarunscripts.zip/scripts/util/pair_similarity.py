# pylint: disable=all
import numpy as np
import pandas as pd
from numpy import dot
from numpy.linalg import norm
from context.retailer import Retailer

class PairWiseCosineSimilarity:

    def __init__(self):
        self.results = []
        self.ids = []


    # @staticmethod
    def pair_wise_similarity(self, query_vector, target_sku, retailer):
        try:
            fid_ref = retailer.data[retailer.data['sku'] == target_sku].FID.tolist()[0]
        except Exception as e:
            print("EXCEPTION IN PAIR WISE SIMILARITY")
            return [1], [target_sku]
        product_vector = retailer.faiss_index.reconstruct(fid_ref)
        cosine_similarity = dot(query_vector, product_vector)/(norm(query_vector)*norm(product_vector))
        return [1 - cosine_similarity], [target_sku]
