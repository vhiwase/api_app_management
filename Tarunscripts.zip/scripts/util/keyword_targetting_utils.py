import re
from nltk.stem import PorterStemmer


class KeywordHash:
    def __init__(self):
        self.porter = PorterStemmer()

    def get_keyword_hash(self, string):
        string = self.preprocess_text_lite(string)
        words = string.split(" ")
        words_stemmed = [self.porter.stem(i) for i in words]
        words_stemmed.sort()
        return " ".join(words_stemmed)

    def preprocess_text_lite(self, string):
        regex = re.compile('[^A-Za-z0-9]+')
        string = string.lower()
        string = regex.sub(r' ', string)
        preprocessed_string = string.strip()
        return preprocessed_string

