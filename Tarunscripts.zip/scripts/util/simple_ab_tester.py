from util.redis_utils import RedisCache, RedisKeyGen
from config import Config
import random


class SimpleABTest:
    def __init__(self):
        self.redis_client = RedisCache(Config.AzureConfig.REDIS_HOST_NAME, Config.AzureConfig.REDIS_PASSWORD)

    def is_user_in_control_set(self, retailer, user_id, guest_id):
        if not retailer.get_meta_data().get("ab_test_flag"):
            return False

        if user_id:
            user_key = user_id
        elif guest_id:
            user_key = guest_id
        else:
            return False

        redis_key = RedisKeyGen.get_ab_test_user_flag_key(retailer.retailer_id, user_key)
        ab_test_flag = self.redis_client.get_value(redis_key)
        if ab_test_flag is not None:
            return ab_test_flag

        control_percent = retailer.get_meta_data().get("control_percentage")
        if control_percent is None:
            control_percent = 50

        if random.random()*100 <= control_percent:
            self.redis_client.set_value(redis_key, True)
            return True

        self.redis_client.set_value(redis_key, False)
        return False

    def apply_ab_test_filter_at_campaign_level(self, retailer, user_id, guest_id, ad_units):
        filtered_ad_units = dict()
        if not self.is_user_in_control_set(retailer, user_id, guest_id):
            return ad_units

        campaign_keys = set()
        for uid, ad_unit_list in ad_units.items():
            for meta_data in ad_unit_list:
                campaign_key = RedisKeyGen.get_ab_test_campaign_flag_key(retailer.retailer_id, meta_data["campaign_id"])
                meta_data["ab_test_campaign_key"] = campaign_key
                campaign_keys.add(campaign_key)

        campaign_ab_test_flags = self.redis_client.multi_get(list(campaign_keys))
        for uid, ad_unit_list in ad_units.items():
            for meta_data in ad_unit_list:
                if campaign_ab_test_flags[meta_data["ab_test_campaign_key"]]:
                    continue
                if filtered_ad_units.get(uid) is None:
                    filtered_ad_units[uid] = list()
                filtered_ad_units[uid].append(meta_data)

        return filtered_ad_units
