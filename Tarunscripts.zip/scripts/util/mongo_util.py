from pymongo import MongoClient
from pymongo import UpdateOne
from util.mongo_util_base import MongoUtilBase


class MongoUtil:
    def __init__(self, uri, database_name, table_name):
        self.mongo_base_util = MongoUtilBase(uri)
        self.database_name = database_name
        self.table_name = table_name

    def get_document(self, document_id):
        return self.mongo_base_util.get_document(self.database_name, self.table_name, document_id)

    def get_documents(self, document_id_list):
        return self.mongo_base_util.get_documents(self.database_name, self.table_name, document_id_list)

    def get_all_documents(self):
        return self.mongo_base_util.get_all_documents(self.database_name, self.table_name)

    def upsert(self, data):
        self.mongo_base_util.upsert(self.database_name, self.table_name, data)

    def upsert_bulk(self, data):
        self.mongo_base_util.upsert_bulk(self.database_name, self.table_name, data)

    def insert(self, data):
        self.mongo_base_util.insert(self.database_name, self.table_name, data)

    def update(self, data):
        self.mongo_base_util.update(self.database_name, self.table_name, data)

    def insert_many(self, data_list, ordered=True):
        self.mongo_base_util.insert_many(self.database_name, self.table_name, data_list, ordered)

    def delete_all_from_collection(self):
        self.mongo_base_util.delete_all_from_collection(self.database_name, self.table_name)

    def flush_all_keys(self):
        self.mongo_base_util.flush_all_keys(self.database_name, self.table_name)

