import os
import logging
from config import Config
from util.read_write_data_azure_blob import ReadAndWriteFromAzureBlob
import datetime
from datetime import timedelta

log_path = 'log_file.log'

try:
    os.remove(log_path)
    print('Deleting existing Log file')
except OSError:
    pass

with open(log_path, 'w') as fp:
    pass

logging.basicConfig(filename=log_path,
                    filemode='w',
                    format='%(asctime)s %(levelname)s-%(message)s',
                    datefmt='%Y-%m-%d %H:%M:%S',
                    level=logging.INFO
                    )


class BatchLog:
    @staticmethod
    def info(message):
        logging.info(
            "[{ENV}]:{message}".format(ENV=Config.AzureConfig.ENV,
                                       message=message)
        )

    @staticmethod
    def exception(message):
        logging.exception(
            "[{ENV}]:{message}".format(ENV=Config.AzureConfig.ENV,
                                       message=message)
        )

    @staticmethod
    def write_log_to_azure(log_file_name):
        read_write_blob = ReadAndWriteFromAzureBlob()
        date_string_split = datetime.datetime.strftime(
            datetime.datetime.now() - timedelta(1),
            '%Y/%m/%d').split('/')

        # Write logs to Blob
        log_file = "BatchJobLogs/year={}/month={}/day={}/" \
                   "{log_name}.log".format(
            date_string_split[0],
            date_string_split[1],
            date_string_split[2],
            log_name=log_file_name
        )

        read_write_blob.write_log_to_blob(
            Config.AzureConfig.RECOMMENDATION_OUT_STRING,
            Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME,
            log_file
        )
