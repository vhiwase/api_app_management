# suggestion_util
import pandas as pd
from util.redis_utils import RedisUtil
from config import Config
from relevance.auto_target import AutoTarget
from bidding.auto_bidder import AutoBidder
from metric_estimation.metric_estimator import MetricsEstimator
from util.read_write_data_azure_blob import ReadAndWriteFromAzureBlob
from util.mongo_util import MongoUtil
from util.target_indexer import TargetIndexer
from util.metric_util import MetricsUtil
from util.bidder_util import BidderUtil
from util.mongo_util_base import MongoUtilBase
from util.campaign_data_aggregator import CampaignDataAggregator
from util.keyword_targetting_utils import KeywordHash
from azure.storage.blob import BlobServiceClient
from azure.eventhub import EventHubProducerClient, EventData
import datetime
from io import BytesIO
import statistics
import random
import numpy as np
import json


class SuggestionsUtil:
    def __init__(self):
        self.redis_client = RedisUtil(Config.AzureConfig.REDIS_HOST_NAME,
                                      Config.AzureConfig.REDIS_PASSWORD)
        self.auto_target = AutoTarget()
        self.auto_bidder = AutoBidder()
        self.metric_estimator = MetricsEstimator()
        self.read_write_blob = ReadAndWriteFromAzureBlob()

    def get_campaign_aggregation(self, retailer, time_delta):
        # Campaign aggregation data
        retailer_id = retailer.retailer_id

        try:
            campaign_aggregation = \
                self.read_write_blob.get_input_df_from_csv(
                    retailer_id, 'campaign_aggregation',
                    days_from_current_day=time_delta)
            campaign_aggregation.fillna(0, inplace=True)
            campaign_aggregation['targeting_value'] = \
                campaign_aggregation['targeting_value'].apply(
                    lambda x: str(x).lower())
            campaign_aggregation = campaign_aggregation.groupby(
                ['targeting_type', 'targeting_value', 'campaignId']
            ).sum().reset_index()

            if not campaign_aggregation.empty:
                campaign_aggregation['retailer_id'] = retailer_id
                return campaign_aggregation
            else:
                return pd.DataFrame()
        except KeyError:
            return pd.DataFrame()

    def get_search_count(self, retailer, time_delta, infer_retailer_id=True):
        # Search count data
        if infer_retailer_id:
            retailer_id = retailer.retailer_id
        else:
            retailer_id = retailer

        try:
            count = self.read_write_blob.get_input_df_from_csv(
                retailer_id,
                'keyword_count',
                days_from_current_day=time_delta)
            count.fillna(0, inplace=True)
            count['targeting_value'] = count['targeting_value'].apply(
                lambda x: str(x).lower())
            count = count.groupby(['targeting_type', 'targeting_value']
                                  ).sum().reset_index()
            if not count.empty:
                count['retailer_id'] = retailer_id
                return count
            else:
                return pd.DataFrame()
        except KeyError:
            return pd.DataFrame()

    def get_winner_ecpm(self, retailer, time_delta, infer_retailer_id=True):

        if infer_retailer_id:
            retailer_id = retailer.retailer_id
        else:
            retailer_id = retailer

        try:
            winner_ecpm = self.read_write_blob.get_input_df_from_csv(
                retailer_id, 'winner_aggregation',
                days_from_current_day=time_delta)
            winner_ecpm['targeting_value'] = \
                winner_ecpm['targeting_value'].apply(lambda x: str(x).lower())
            winner_ecpm.fillna(0, inplace=True)

            if not winner_ecpm.empty:
                winner_ecpm['retailer_id'] = retailer_id
                return winner_ecpm
            else:
                return pd.DataFrame()
        except KeyError:
            return pd.DataFrame()

    def create_targeting(self, retailer, df, target_type, get_pc_cvr=None):
        # Creates targeting data
        base_df = df[['retailer_id', 'campaignId', 'acos',
                      'products_to_promote']].copy()
        base_df = base_df.loc[base_df.astype(str).drop_duplicates().index]
        if get_pc_cvr:
            base_df[target_type] = base_df.apply(
                lambda x: self.get_bid_data(
                    retailer, x.acos, x.products_to_promote,
                    target_type.upper(), get_pc_cvr),
                axis=1)
        else:
            base_df[target_type] = base_df.apply(
                lambda x: self.get_bid_data(
                    retailer, x.acos, x.products_to_promote,
                    target_type.upper()),
                axis=1)
        base_df = base_df.explode(target_type)
        base_df = base_df.join(
            base_df[target_type].apply(pd.Series))
        base_df.drop(columns=[target_type], inplace=True)
        base_df.reset_index(inplace=True, drop=True)
        return base_df

    def __get_metadata(
            self, retailer, campaign_aggregation_data, budget_type=None
    ):
        # Get list of campaigns for the retailer
        retailer_id = retailer.retailer_id
        campaigns = list(set(campaign_aggregation_data['campaignId'].values))

        # Getting campaign metadata from cache
        campaign_dict = self.redis_client.multi_get(
            ["{}_campaign_{}_{}".format(Config.AzureConfig.ENV, retailer_id,
                                        campaign) for campaign in
             campaigns])

        # Getting campaign metadata
        campaign_dict = dict(
            filter(lambda item: item[1] is not None, campaign_dict.items())
        )

        # Filtering by budget filter
        if budget_type:
            filtered_campaigns = [v for k, v in campaign_dict.items() if
                                  v['budget_type'] == budget_type]
        else:
            filtered_campaigns = [v for k, v in campaign_dict.items()]

        return filtered_campaigns

    def get_budget_data(
            self, retailer, campaign_aggregation, exhausted, budget_type=None
    ):
        # Get metadata for campaigns
        retailer_id = retailer.retailer_id
        filtered_campaigns = self.__get_metadata(
            retailer, campaign_aggregation, budget_type
        )

        if filtered_campaigns:
            retailer_data = campaign_aggregation.merge(
                pd.DataFrame(filtered_campaigns),
                left_on=['campaignId'], right_on=['campaign_id']).drop(
                columns=['campaign_id'])
            retailer_data.reset_index(inplace=True, drop=True)

            # Calculating total budget spent
            spend_df = retailer_data.groupby('campaignId').agg(
                'adSpent').sum().reset_index()

            # Mapping exhausted budget to create budget_left
            retailer_data['retailer_id'] = retailer_id
            retailer_data['budget_spent'] = retailer_data['campaignId'].map(
                dict(zip(spend_df.campaignId, spend_df.adSpent)))
            retailer_data['budget_left'] = retailer_data['budget'] - \
                retailer_data['budget_spent']

            if exhausted:
                retailer_data = retailer_data[retailer_data[
                                                  'budget_left'] == 0]
                retailer_data.reset_index(inplace=True, drop=True)
                return retailer_data

            else:
                # retailer_data = retailer_data[retailer_data[
                #                                   'budget_left'] > 0.2 * (
                #                                   retailer_data['budget'])]
                retailer_data.reset_index(inplace=True, drop=True)
                return retailer_data

        else:
            return pd.DataFrame()

    def get_targets(
            self, retailer, campaign_aggregation_data, get_pc_cvr=None
    ):
        # Extracting campaign meta data from cache
        retailer_id = retailer.retailer_id
        filtered_campaigns = self.__get_metadata(retailer,
                                                 campaign_aggregation_data)
        dataframe = pd.DataFrame(filtered_campaigns)

        if not dataframe.empty:
            dataframe['retailer_id'] = retailer_id

            # Creating product targeting data
            product_data = self.create_targeting(retailer, dataframe,
                                                 'product', get_pc_cvr)

            # Creating category targeting data
            category_data = self.create_targeting(retailer, dataframe,
                                                  'category', get_pc_cvr)

            # Creating keyword targeting data
            keyword_data = self.create_targeting(retailer, dataframe,
                                                 'keyword', get_pc_cvr)

            consolidated_data = product_data.append(category_data).append(
                keyword_data)
            consolidated_data.rename(columns={
                'target_type': 'targeting_type',
                'target_value': 'targeting_value',
                'campaign_id': 'campaignId',
                'cpc_bid_value': 'current_bid'},
                inplace=True)
            consolidated_data = consolidated_data.merge(
                dataframe, on=['campaignId', 'targeting_type',
                               'targeting_value'])

            # Merging the targeting data with campaign aggregation
            campaign_aggregation = campaign_aggregation_data.merge(
                consolidated_data,
                on=['campaignId', 'targeting_type', 'targeting_value']
            )
            campaign_aggregation['targeting_value'] = \
                campaign_aggregation['targeting_value'].apply(
                    lambda x: str(x).lower())
            campaign_aggregation = campaign_aggregation.loc[
                campaign_aggregation.astype(str).drop_duplicates().index]
            campaign_aggregation.reset_index(inplace=True, drop=True)

            return campaign_aggregation

        else:
            return pd.DataFrame()

    def get_bid_data(
            self, retailer, acos, products_to_promote, target_type,
            get_pc_cvr=None
    ):
        # Calculates bids for the targets
        targeting_type = target_type.lower()

        targets = []
        if targeting_type == "keyword":
            for sku in products_to_promote:
                temp = self.auto_target.get_keywords_for_product(retailer, sku)
                for entry in temp:
                    entry['sku'] = sku
                    targets.append(entry)
        if targeting_type == "category":
            for sku in products_to_promote:
                temp = self.auto_target.get_similar_categories(retailer, sku)
                for entry in temp:
                    entry['sku'] = sku
                    targets.append(entry)
        if targeting_type == "product":
            for sku in products_to_promote:
                temp = self.auto_target.get_products_by_product(retailer, sku)
                for entry in temp:
                    entry['sku'] = sku
                    targets.append(entry)

        self.metric_estimator.get_metric_for_many(retailer, "ctr",
                                                  targeting_type, targets)
        self.metric_estimator.get_metric_for_many(retailer, "pc_cvr",
                                                  targeting_type, targets)

        target_group_map = {}
        for entry in targets:
            if entry['target_value'] not in target_group_map:
                target_group_map[entry['target_value']] = []

            target_group_map[entry['target_value']].append(
                dict(sku=entry["sku"], pc_cvr=entry["pc_cvr"],
                     ctr=entry["ctr"])
            )

        result = []
        for target_value in target_group_map:
            target_group = target_group_map[target_value]
            bid = self.auto_bidder.compute_bid(retailer, acos, target_group)
            cpm_bid_value = self.auto_bidder.compute_ecpm(
                target_group[0]['ctr'], bid)
            if get_pc_cvr:
                result.append(
                    dict(target_type=targeting_type.upper(),
                         target_value=target_value,
                         cpc_bid_value=bid,
                         cpm_bid_value=cpm_bid_value,
                         click_through_rate=target_group_map[
                             target_value][0]['ctr'],
                         pc_cvr=target_group_map[
                             target_value][0]['pc_cvr'])
                )
            else:
                result.append(
                    dict(target_type=targeting_type.upper(),
                         target_value=target_value,
                         cpc_bid_value=bid,
                         cpm_bid_value=cpm_bid_value,
                         click_through_rate=target_group_map[
                             target_value][0]['ctr'])
                )
        result = sorted(result, key=lambda x: x["cpc_bid_value"], reverse=True)
        return result

    @staticmethod
    def get_rejections(retailer, campaign_list):
        mongo_client = MongoUtil(Config.AzureConfig.COSMOS_URI,
                                 Config.AzureConfig.REJECTED_SUGGESTIONS_DB,
                                 str(retailer.retailer_id))
        rejection_metadata = list(mongo_client.get_documents(campaign_list))
        if rejection_metadata:
            df = pd.DataFrame(rejection_metadata)
            df = df.explode('rejected_suggestions_type')
            df['rejected_values'] = df.apply(
                lambda row:
                row['rejected_suggestions'][row['rejected_suggestions_type']],
                axis=1)
            df = df[['_id', 'rejected_suggestions_type', 'rejected_values']]
            return df
        else:
            return pd.DataFrame()

    @staticmethod
    def create_meta_rejections(data, rejection_type):
        if not data.empty:
            if rejection_type == 'budget_rejection':
                data = data[data['rejected_suggestions_type'] ==
                            'increase_budget']
                data.reset_index(inplace=True, drop=True)
            if rejection_type == 'decrease_roas':
                data = data[data['rejected_suggestions_type'] ==
                            'decrease_roas']
                data.reset_index(inplace=True, drop=True)
            if rejection_type == 'increase_max_cutoff':
                data = data[data['rejected_suggestions_type'] ==
                            'increase_max_cutoff']
                data.reset_index(inplace=True, drop=True)
            if rejection_type == 'add_keyword':
                data = data[data['rejected_suggestions_type'] ==
                            'add_keyword']
                data = data[['_id', 'rejected_values']]
                data.reset_index(inplace=True, drop=True)
            if rejection_type == 'add_product':
                data = data[data['rejected_suggestions_type'] ==
                            'add_product']
                data = data[['_id', 'rejected_values']]
                data.reset_index(inplace=True, drop=True)
            if rejection_type == 'add_category':
                data = data[data['rejected_suggestions_type'] ==
                            'add_category']
                data = data[['_id', 'rejected_values']]
                data.reset_index(inplace=True, drop=True)
            if rejection_type == 'bid_rejections':
                bid_rejections = [
                    'increase_keyword_bid', 'decrease_keyword_bid',
                    'increase_category_bid', 'decrease_category_bid',
                    'increase_product_bid', 'decrease_product_bid']
                data = data[data['rejected_suggestions_type'].isin(
                    bid_rejections
                )]
                data['targeting_type'] = \
                    data['rejected_suggestions_type'].apply(
                        lambda x: x.split('_')[1]
                    )
                data['action'] = data['rejected_suggestions_type'].apply(
                    lambda x: x.split('_')[0]
                )
                data = data[
                    ['_id', 'action', 'targeting_type', 'rejected_values']
                ]
                data.reset_index(inplace=True, drop=True)
            if not data.empty:
                return data
            else:
                return pd.DataFrame()
        else:
            return pd.DataFrame()


class PostCampaignSuggestionsUtil:
    def __init__(self, time_delta):
        self.time_delta = time_delta
        self.latest = (
                datetime.date.today() - datetime.timedelta(self.time_delta)
        ).strftime("%Y-%m-%d")
        self.target_indexer = TargetIndexer()
        self.metric_util = MetricsUtil()
        self.keyword_hash = KeywordHash()
        self.read_write_blob = ReadAndWriteFromAzureBlob()
        self.redis_client = RedisUtil(
            Config.AzureConfig.REDIS_HOST_NAME,
            Config.AzureConfig.REDIS_PASSWORD
        )

    def campaign_metadata_extractor(self):
        aggregator = CampaignDataAggregator()
        metadata = aggregator.aggregate_campaign_data(
            self.time_delta
        )
        if not metadata.empty:
            metadata['bid_map'] = metadata.apply(
                lambda x: {x['target_value']: x['bid']}, axis=1
            )
            return metadata
        else:
            return pd.DataFrame()

    @staticmethod
    def get_campaign_data(
            meta_data, retailer_id, target_type
    ):
        if target_type == 'other':
            df = meta_data[meta_data['retailer_id'] == str(retailer_id)]
            df = df[~df.is_negative]
            df.reset_index(inplace=True, drop=True)
            if not df.empty:
                df['target_type'] = df['target_type'].apply(
                    lambda x: str(x).lower()
                )
                df['targets'] = df.apply(lambda x: {
                    'target_type': x['target_type'],
                    'target_value': x['target_value'],
                    'products_to_promote': [{'sku': sku} for sku in
                                            x['products_to_promote']]
                }, axis=1)
                df['products_to_promote'] = df['products_to_promote'].apply(
                    tuple
                )
                df['bid_map'] = df.apply(
                    lambda x: {x['target_value']: x['bid']}, axis=1)
                df['cost_map'] = df.apply(
                    lambda x: {x['target_value']: x['cost_type']}, axis=1)
                df = df.groupby(
                    ['retailer_id', 'campaignId', 'ad_group_id',
                     'products_to_promote', 'budget', 'budget_type']
                ).agg({'targets': lambda x: list(x),
                       'bid_map': lambda x: list(x),
                       'cost_map': lambda x: list(x)}).reset_index()
                df['products_to_promote'] = df['products_to_promote'].apply(
                    list
                )
                df['bid_map'] = df['bid_map'].apply(
                    lambda x: {k: v for d in x for k, v in d.items()}
                )
                df['cost_map'] = df['cost_map'].apply(
                    lambda x: {k: v for d in x for k, v in d.items()}
                )
                return df.to_dict('records')
            else:
                return []

        else:
            df = meta_data[
                (meta_data['retailer_id'] == str(retailer_id)) &
                (meta_data['target_type'] == target_type.upper())
                ]

            if not df.empty:
                df['products_to_promote'] = df['products_to_promote'].apply(
                    tuple
                )
                negative_targets = df.loc[df.is_negative]
                negative_targets = negative_targets.groupby(
                    ['ad_group_id']
                )['target_value'].apply(list).reset_index()
                negative_targets = negative_targets.set_index(
                    'ad_group_id'
                )['target_value'].to_dict()
                df = df.groupby(
                    ['retailer_id', 'campaignId', 'ad_group_id',
                     'products_to_promote', 'cost_type']
                ).agg({'bid_map': lambda x: list(x)})
                df.reset_index(inplace=True)
                df['products_to_promote'] = df['products_to_promote'].apply(
                    list
                )
                df['negative_targets'] = df['ad_group_id'].map(
                    negative_targets
                )
                df['negative_targets'] = df['negative_targets'].apply(
                    lambda d: d if isinstance(d, list) else []
                )
                return df.to_dict('records')
            else:
                return []

    @staticmethod
    def get_mongo_keys(targets):
        for target in targets:
            if target['target_type'] == "keyword":
                target['mongo_key'] = "kt_{}".format(
                    target['target_value'].lower()
                )
            elif target['target_type'] == "product":
                target['mongo_key'] = "pt_{}".format(
                    target['target_value'].lower()
                )
            elif target['target_type'] == "category":
                target['mongo_key'] = "ct_{}".format(
                    target['target_value'].lower()
                )
            else:
                target['mongo_key'] = "None"

    def hash_keywords(self, target_type, target_value):
        if target_type.lower() == "keyword":
            return self.keyword_hash.get_keyword_hash(target_value)
        else:
            return target_value

    @staticmethod
    def get_request_list(campaign, product_meta_data_map):
        request_list = []
        for target in campaign['targets']:
            for entry in target["products_to_promote"]:
                entry["target_type"] = target["target_type"]
                entry["target_value"] = target["target_value"]
                request_list.append(entry)
                entry["aov"] = product_meta_data_map[
                    entry["sku"]
                ]["aov"]
        return request_list

    @staticmethod
    def update_relevance_score(all_targets, current_targets):
        try:
            df1 = pd.DataFrame(current_targets)
            df2 = pd.DataFrame(all_targets)
            df = df1.merge(df2, on=['target_type', 'target_value'], how='left')
            df['products_to_promote'] = df[
                'products_to_promote_y'
            ].combine_first(df['products_to_promote_x'])
            df = df[['target_type', 'target_value', 'products_to_promote']]
            return df.to_dict('records')
        except Exception as e:
            print(e)
            return current_targets

    @staticmethod
    def get_aov(products_to_promote, product_meta_data_map):
        aov = []
        for product in products_to_promote:
            aov.append(
               product_meta_data_map.get(product).get('aov')
            )
        return sum(aov) / len(aov)

    def update_targets_using_indexer(
            self, campaign, retailer_meta_data, product_meta_data_map
    ):
        # Get all targets for the products to promote
        targets = self.target_indexer.get_targets(
            str(campaign['retailer_id']),
            campaign['products_to_promote']
        )

        # Creating payload_difference mapping between keywords and hash for
        # downstream processing
        hash_keyword = {}
        for target in campaign['targets']:
            if target['target_type'] == "keyword":
                hashed_keyword = self.keyword_hash.get_keyword_hash(
                    target['target_value'].lower()
                )
                hash_keyword[hashed_keyword] = target[
                    'target_value'
                ]
                target['target_value'] = hashed_keyword

        # Updating relevance score if available from targets
        campaign['targets'] = self.update_relevance_score(
            targets, campaign['targets']
        )

        # Creating request list to get CTR
        request_list = self.get_request_list(
            campaign, product_meta_data_map
        )

        # Getting CTR at target value level
        self.metric_util.add_metric_for_many_request(
            retailer_meta_data['_id'], retailer_meta_data, "ctr",
            request_list
        )

        # Computing CTR at campaign level
        for target in campaign['targets']:
            target["ctr"] = BidderUtil.compute_campaign_ctr(
                target["products_to_promote"]
            )
            target['keyword'] = hash_keyword.get(target['target_value'])
            if target['target_type'] == "keyword":
                target['bid'] = campaign['bid_map'][
                    hash_keyword[target['target_value']]
                ]
                target['cost_type'] = campaign['cost_map'][
                    hash_keyword[target['target_value']]
                ]
            else:
                target['bid'] = campaign['bid_map'][
                    target['target_value']
                ]
                target['cost_type'] = campaign['cost_map'][
                    target['target_value']
                ]

        # Getting bids from bid landscape, if available
        self.get_mongo_keys(campaign['targets'])

    def get_rejections(self, campaign_id, negations, suggestion_type):
        rejections = negations.get(campaign_id)
        negation_list = []
        if rejections:
            if suggestion_type in ["keyword", "product", "category"]:
                negations = []
                negations.extend(
                    rejections['rejected_suggestions'].get(
                        "add_{}".format(suggestion_type)
                    )
                )
                if suggestion_type == "keyword":
                    for keyword in negation_list:
                        negation_list.append(
                            self.keyword_hash.get_keyword_hash(
                                keyword
                            )
                        )
                else:
                    negation_list = negations

            elif suggestion_type == "budget_suggestion":
                if "increase_budget" in negations[
                    'rejected_suggestions_type'
                ]:
                    negation_list = [campaign_id]

            elif suggestion_type == 'bid_suggestion':
                negation_list.extend(
                    rejections['rejected_suggestions'].get(
                        'increase_keyword_bid') +
                    rejections['rejected_suggestions'].get(
                        'increase_product_bid') +
                    rejections['rejected_suggestions'].get(
                        'increase_category_bid')
                )

            elif suggestion_type == "roas_suggestion":
                if "decrease_roas" in negations[
                    "rejected_suggestions_type"
                ]:
                    negation_list = [campaign_id]

            elif suggestion_type == "max_bid_suggestion":
                if "increase_max_cutoff" in negations[
                    "rejected_suggestions_type"
                ]:
                    negation_list = [campaign_id]

            else:
                negation_list = []

        return negation_list

    def get_impression_data(self, retailer_id, autonomous_suggestion=False):
        df = self.read_write_blob.get_input_df_from_csv(
                str(retailer_id),
                "campaign_aggregation",
                days_from_current_day=self.time_delta
            )
        if not df.empty:
            df.rename(columns={"adGroupId": "ad_group_id"}, inplace=True)
            df["ad_group_id"] = df["ad_group_id"].apply(
                lambda x: x.encode("ascii", "ignore")
            )
            df['ad_group_id'] = df['ad_group_id'].str.decode('utf-8')
            df = df[
                ['campaignId', 'ad_group_id', 'targeting_type',
                 'targeting_value', 'impressions', 'adSpent']
            ]
            df['targeting_type'] = df['targeting_type'].apply(
                lambda x: str(x).lower()
            )
            df['targeting_value'] = df['targeting_value'].apply(
                lambda x: str(x).lower()
            )

            # Hashing keywords for autonomous suggestions
            if autonomous_suggestion:
                df['targeting_value'] = df.apply(
                    lambda x: self.hash_keywords(
                        x['targeting_type'], x['targeting_value']
                    ), axis=1
                )

            df['impression_map'] = df.apply(
                lambda x: {
                    x['ad_group_id']: {x['targeting_value']: x['impressions']}
                }, axis=1
            )
            ad_spent = df.groupby("campaignId")['adSpent'].sum().to_dict()
            df = df.groupby('campaignId').agg(
                {"impression_map": lambda x: list(x)}
            ).reset_index()
            df['ad_spent'] = df['campaignId'].map(ad_spent)
            df['impression_map'] = df['impression_map'].apply(
                lambda x: {k: v for d in x for k, v in d.items()}
            )
            df['mapping'] = df.apply(
                lambda x: {
                    "impression_map": x["impression_map"],
                    "ad_spent": x["ad_spent"]
                }, axis=1
            )
            return df.set_index('campaignId')['mapping'].to_dict()
        else:
            return {}

    @staticmethod
    def get_retailer_metadata(retailer_metadata, retailer_id):
        for metadata in retailer_metadata:
            if str(metadata['_id']) == str(retailer_id):
                return metadata

    @staticmethod
    def get_negations_for_retailer(retailer_id):
        mongo_client = MongoUtilBase(Config.AzureConfig.COSMOS_URI)
        rejection_documents = list(
            mongo_client.get_all_documents(
                Config.AzureConfig.REJECTED_SUGGESTIONS_DB,
                str(retailer_id)
            )
        )
        rejections = {}
        for rejection in rejection_documents:
            rejections[rejection['_id']] = rejection
        return rejections

    @staticmethod
    def get_retailer_prod_map(retailer_id):
        mongo_client = MongoUtilBase(Config.AzureConfig.COSMOS_URI)
        documents = list(
            mongo_client.get_all_documents(
                Config.AzureConfig.COSMOS_PRODUCT_META_DB,
                str(retailer_id)
            )
        )
        metadata_map = {}
        for document in documents:
            metadata_map[document['_id']] = document
        return metadata_map

    @staticmethod
    def get_bid_landscape(retailer_id, budget_suggestion=False):
        mongo_client = MongoUtilBase(Config.AzureConfig.COSMOS_URI)
        documents = list(
            mongo_client.get_all_documents(
                Config.AzureConfig.COSMOS_BID_LANDSCAPE_DB,
                str(retailer_id)
            )
        )
        bid_landscape = {}
        if budget_suggestion:
            for document in documents:
                bid_landscape[document['_id']] = document['target']
        else:
            for document in documents:
                if float(list(document['target'])[-1]) != 0:
                    min_bid, max_bid = float(list(document['target'])[0]), \
                                       float(list(document['target'])[-1])
                    bid = np.round((min_bid + max_bid) / 2, 4)
                    bid_landscape[document['_id']] = {
                        'bid': bid,
                        'min_bid': min_bid,
                        'max_bid': max_bid,
                        'median_bid': statistics.median(
                            [float(bid) for bid in list(document['target'])]
                        )
                    }

        return bid_landscape

    @staticmethod
    def __create_container_client():
        blob_service_client = BlobServiceClient.from_connection_string(
            Config.AzureConfig.AD_SPEND_CONNECTION)
        container_client = blob_service_client.get_container_client(
            Config.AzureConfig.AD_SPEND_CONTAINER)
        return container_client

    def get_latest_ad_spent(self):
        campaign_spend = {}
        container_client = self.__create_container_client()
        look_back_directory = \
            "facts/hourly-summaries/campaign-ad-spent/process_time={} " \
            "{}%3A00%3A00/"
        ad_spent_files = []
        for i in reversed(range(24)):
            if i == 0:
                i = str("00")
            directory_check = look_back_directory.format(
                self.latest, i
            )
            try:
                ad_spent_files.extend(
                    list(
                        container_client.list_blobs(
                            name_starts_with=directory_check
                        )
                    )
                )
            except Exception as e:
                print(e)
                continue
            ad_spent_files = [
                file['name'] for file in ad_spent_files if '.parquet' in
                                                           file['name']
            ]
            if ad_spent_files:
                break

        dataframe = pd.DataFrame()
        for file in ad_spent_files:
            blob_client = container_client.get_blob_client(
                blob=file
            )
            stream_downloader = blob_client.download_blob()
            stream = BytesIO()
            stream_downloader.readinto(stream)
            df = pd.read_parquet(stream, engine='pyarrow')
            if not df.empty:
                dataframe = dataframe.append(df)

        if not dataframe.empty:
            campaign_spend = \
                dataframe.set_index('campaignId')['totalAdSpent'].to_dict()

        return campaign_spend

    @staticmethod
    def send_suggestion_events(
            retailer_id, event_type, list_of_suggestions, logger
    ):
        producer = EventHubProducerClient.from_connection_string(
            conn_str=Config.AzureConfig.AI_EVENTHUB_STRING,
            eventhub_name=Config.AzureConfig.SUGGESTIONS_EVENTHUB_NAME
        )

        if list_of_suggestions:
            for suggestion in list_of_suggestions:
                try:
                    payload = {
                        "event_id": '-'.join(
                            [str(random.randint(0, 999)).zfill(4) for _ in
                             range(4)]
                        ),
                        "event_type": "post_campaign_suggestion",
                        "event_payload": suggestion
                    }
                    event_data_batch = producer.create_batch(
                        partition_id=str(random.choice(range(0, 10)))
                    )
                    event_data_batch.add(EventData(json.dumps(payload)))
                    producer.send_batch(event_data_batch)
                    message = "Pushed {} events for retailer {}".format(
                        event_type, retailer_id
                    )
                    logger.info(message)
                    print(message)
                except Exception as e:
                    logger.info(e)
                    continue
        else:
            message = "No suggestion events for retailer {}".format(
                retailer_id
            )
            logger.info(message)
            print(message)
        producer.close()

    def send_data_to_azure(self, retailer_id, event_type, suggestions, logger):
        # Converting suggestions to dataframe for uploading to AI container
        suggestions_df = pd.DataFrame(suggestions)
        year, month, day = datetime.datetime.strftime(
            datetime.datetime.now() - datetime.timedelta(1), '%Y/%m/%d'
        ).split('/')
        blob_name = "retailer_id={}/year={}/month={}/day={}/{}.csv".format(
            retailer_id, year, month, day, event_type
        )
        # Writing to BLOB storage
        self.read_write_blob.write_to_blob(
            Config.AzureConfig.RECOMMENDATION_OUT_STRING,
            Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME,
            blob_name,
            suggestions_df
        )
        message = "Uploaded suggestions log as csv to AI container"
        logger.info(message)
        print(message)

        # Push suggestions to AI eventhub
        self.send_suggestion_events(
            retailer_id, event_type, suggestions, logger
        )

    def send_logs_to_azure(self, event_type):
        # Write logs to Blob
        year, month, day = datetime.datetime.strftime(
            datetime.datetime.now() - datetime.timedelta(1), '%Y/%m/%d'
        ).split('/')
        log_file = "BatchJobLogs/year={}/month={}/day={}/{} Job.log".format(
            year, month, day, event_type
        )
        self.read_write_blob.write_log_to_blob(
            Config.AzureConfig.RECOMMENDATION_OUT_STRING,
            Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME,
            log_file)

    def get_autonomous_campaign_data(self, retailer_id):
        documents = self.redis_client.multi_get(
            self.redis_client.get_keys_with_pattern_batch(
                "{}_campaign_{}_*".format(
                    Config.AzureConfig.ENV,
                    retailer_id
                ), 1000
            )
        )
        return list(documents.values())
