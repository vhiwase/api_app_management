import pandas as pd

from util.meta_data_extractor import MetaDataExtractor
from util.bidder_util import BidderUtil
from config import Config
from util.redis_utils import RedisUtil, RedisKeyGen
from util.metric_util import MetricsUtil
from util.mongo_util_base import MongoUtilBase
import json
from context.context import Context
from util.keyword_targetting_utils import KeywordHash
import numpy as np
import statistics
from cachetools import TTLCache
from util.read_write_data_azure_blob import ReadAndWriteFromAzureBlob


class TargetIndexer:
    RETAILER_AUDIENCE_CACHE = TTLCache(maxsize=50, ttl=3600)

    def __init__(self, mode=None):
        self.redis_client = RedisUtil(Config.AzureConfig.REDIS_HOST_NAME,
                                      Config.AzureConfig.REDIS_PASSWORD)
        self.metric_util = MetricsUtil()
        self.mongo_util_base = MongoUtilBase(Config.AzureConfig.COSMOS_URI)
        self.keyword_hash = KeywordHash()
        self.read_write_azure = ReadAndWriteFromAzureBlob()
        self.mode = mode

    def reset_cache(self):
        # Used in campaign reconciliation
        self.RETAILER_AUDIENCE_CACHE = TTLCache(maxsize=20, ttl=3600)

    @staticmethod
    def __construct_target_meta_data(
            target_type, target_value, sku, relevance_score
    ):
        target = {
            "target_value": target_value,
            "target_type": target_type,
            "products_to_promote": [
                {
                    "sku": sku,
                    "relevance_score": relevance_score
                }
            ]
        }
        return target

    @staticmethod
    def __add_sku_to_target_meta_data(target, sku, relevance_score):
        target["products_to_promote"].append(
            {
                "sku": sku,
                "relevance_score": relevance_score
            }
        )
        return target

    def get_keywords_from_hash(self, retailer_id, hash_list):
        document = self.mongo_util_base.get_document(
            Config.AzureConfig.COSMOS_HASH_TO_KEYWORD_DB,
            str(retailer_id),
            hash_list
        )

        if document:
            return document["keywords"]

        return []

    def get_keyword_targets(
            self, retailer_id, product_id_list, negations=None
    ):
        documents = self.mongo_util_base.get_documents(
            Config.AzureConfig.COSMOS_KEYWORD_TARGETING_DB,
            retailer_id,
            product_id_list
        )

        targets_map = {}
        for document in documents:
            sku = document["_id"]
            for row in document["target"]:
                key = row["hash"]
                if negations and key in negations:
                    continue
                target = targets_map.get(key)
                if target:
                    self.__add_sku_to_target_meta_data(
                        target, sku, row["relevance_score"]
                    )
                else:
                    targets_map[key] = self.__construct_target_meta_data(
                        "keyword", key, sku, row["relevance_score"]
                    )

        return list(targets_map.values())

    def get_keywords(self, retailer_id, product_id_list, negations=None):
        target_hashes = self.get_keyword_targets(
            retailer_id, product_id_list, negations
        )

        keyword_hash_list = list()
        hash_to_meta_data_map = dict()
        for target_hash in target_hashes:
            keyword_hash_list.append(target_hash["target_value"])
            hash_to_meta_data_map[target_hash["target_value"]] = target_hash

        documents = self.mongo_util_base.get_documents(
            Config.AzureConfig.COSMOS_HASH_TO_KEYWORD_DB,
            retailer_id,
            keyword_hash_list
        )
        keywords = list()
        for document in documents:
            hash_meta_data = hash_to_meta_data_map.get(document["_id"])
            hash_meta_data["keywords"] = document["keywords"]
            keywords.append(hash_meta_data)
        return keywords

    def get_category_targets(
            self, retailer_id, products_to_promote, negations=None
    ):
        documents = self.mongo_util_base.get_documents(
            Config.AzureConfig.COSMOS_CATEGORY_TARGETING_DB,
            retailer_id,
            products_to_promote
        )

        targets_map = {}
        for document in documents:
            sku = document["_id"]
            for row in document["target"]:
                key = row["category"]
                if negations and key in negations:
                    continue
                target = targets_map.get(key)
                if target:
                    self.__add_sku_to_target_meta_data(
                        target, sku, row["relevance_score"]
                    )
                else:
                    targets_map[key] = self.__construct_target_meta_data(
                        "category", key, sku, row["relevance_score"]
                    )

        return list(targets_map.values())

    def get_product_targets(self, retailer_id, products_to_promote,
                            negations=None):
        documents = self.mongo_util_base.get_documents(
            Config.AzureConfig.COSMOS_PRODUCT_TARGETING_DB,
            retailer_id,
            products_to_promote
        )

        targets_map = {}
        for document in documents:
            sku = document["_id"]
            for row in document["target"]:
                key = row["sku"]
                if negations and key in negations:
                    continue
                target = targets_map.get(key)
                if target:
                    self.__add_sku_to_target_meta_data(
                        target, sku, row["relevance_score"]
                    )
                else:
                    targets_map[key] = self.__construct_target_meta_data(
                        "product", key, sku, row["relevance_score"]
                    )

        return list(targets_map.values())

    def get_audience_targets(self, retailer_id, products_to_promote):
        audience_targets = {}
        for product in products_to_promote:
            try:
                cat_data = self.mongo_util_base.get_document(
                    Config.AzureConfig.COSMOS_PRODUCT_META_DB,
                    str(retailer_id),
                    product
                )
                category = cat_data["Broad_Category"]
                cat_key = "{}_{}".format(retailer_id, category)
                if self.RETAILER_AUDIENCE_CACHE.get(cat_key):
                    targets = self.RETAILER_AUDIENCE_CACHE[cat_key]
                else:
                    targets = self.read_write_azure.read_pickle_file(
                        Config.AzureConfig.ICC_DS_STORAGE_CONNECTION_STRING,
                        Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME,
                        Config.AzureConfig.AUDIENCE_BLOB_NAME.format(
                            retailer_id, category
                        )
                    )
                if targets:
                    self.RETAILER_AUDIENCE_CACHE[cat_key] = targets
                    for key, value in targets.items():
                        if audience_targets.get(key):
                            audience_targets[
                                key
                            ]["products_to_promote"].append(
                                {
                                    "sku": product,
                                    "relevance_score": value
                                }
                            )

                        else:
                            audience_targets[key] = {
                                "target_value": key,
                                "target_type": "audience",
                                "products_to_promote": [
                                    {
                                        "sku": product,
                                        "relevance_score": value
                                    }
                                ]
                            }

            except Exception as e:
                print(e)
                continue

        return list(audience_targets.values())

    def __get_negative_targets(self, negative_targets):
        negative_keywords = []
        negative_products = []
        negative_categories = []
        if negative_targets:
            for i in negative_targets:
                if i['target_type'] == 'keyword':
                    negative_keywords.append(i["target_value"].lower())
                    negative_keywords.append(
                        self.keyword_hash.get_keyword_hash(i['target_value'])
                    )
                if i['target_type'] == 'product':
                    negative_products.append(i['target_value'])
                if i['target_type'] == 'category':
                    negative_categories.append(i['target_value'])
        return negative_keywords, negative_products, negative_categories

    def get_targets(
            self, retailer_id, products_to_promote, negative_targets=None,
            ad_group_objective="ROAS"
    ):
        targets = []

        negative_keywords, negative_products, negative_categories = \
            self.__get_negative_targets(
                negative_targets
            )

        targets.extend(
            self.get_keyword_targets(
                retailer_id, products_to_promote, negative_keywords
            )
        )
        targets.extend(
            self.get_category_targets(
                retailer_id, products_to_promote, negative_categories
            )
        )
        targets.extend(
            self.get_product_targets(
                retailer_id, products_to_promote, negative_products
            )
        )

        if (
                ad_group_objective == "ECPM" and
                self.mode == "reconciliation"
        ):
            retailer_metadata = MetaDataExtractor.get_retailer_matadata(
                retailer_id
            )
            if retailer_metadata.get("audience_targeting") is True:
                targets.extend(
                    self.get_audience_targets(retailer_id, products_to_promote)
                )

        return targets

    def fill_target_metrics(
            self, retailer_id, products_to_promote, targets, acos,
            max_bid=None, campaign_mode="AUTOMATIC"
    ):
        if Context.get_retailer(retailer_id) is None:
            retailer_meta_data = MetaDataExtractor.get_retailer_matadata(
                retailer_id)
        else:
            retailer_meta_data = Context.get_retailer(
                retailer_id).get_meta_data()
        product_meta_data_map = self.__get_product_meta_data(
            retailer_id, products_to_promote
        )

        retailer_profit = retailer_meta_data.get(
            "retailer_profit_percent", 0.1
        ) if retailer_meta_data.get(
            "revenue_strategy", ""
        ) == "total_revenue" else 0.0

        request_list = []
        for target in targets:
            for entry in target["products_to_promote"]:
                entry["target_type"] = target["target_type"]
                entry["target_value"] = target["target_value"]
                request_list.append(entry)
                entry["aov"] = product_meta_data_map[entry["sku"]]["aov"]

        self.metric_util.add_metric_for_many_request(retailer_id,
                                                     retailer_meta_data, "ctr",
                                                     request_list)
        self.metric_util.add_metric_for_many_request(retailer_id,
                                                     retailer_meta_data,
                                                     "pc_cvr", request_list)

        for target in targets[:]:
            target["ctr"] = BidderUtil.compute_campaign_ctr(
                target["products_to_promote"]
            )
            target["pc_cvr"] = BidderUtil.compute_campaign_cvr(
                target["products_to_promote"]
            )
            if (
                    target["ctr"] == 0.0 or
                    target["pc_cvr"] == 0.0
            ):
                targets.remove(target)
            else:

                target["aov"] = BidderUtil.compute_campaign_aov(
                    target["products_to_promote"]
                )

                if campaign_mode == "MANUAL":
                    if target["target_type"] not in [
                        "keyword", "product", "category"
                    ]:
                        target["ctr"] = 1.0
                    if target["bid_type"] != "CPC":
                        target["ecpm"] = target["bid"]
                    else:
                        target["ecpm"] = BidderUtil.compute_ecpm(
                            target["ctr"], target["bid"]
                        )

                else:
                    target["bid"] = BidderUtil.compute_bid_v2(acos, target[
                        "products_to_promote"])
                    if max_bid:
                        target["bid"] = min(target["bid"], max_bid)
                    target["ecpm"] = BidderUtil.compute_ecpm(target["ctr"],
                                                             target["bid"])

                if retailer_profit > 0:
                    target["ecpm"] = BidderUtil.compute_retailer_revenue(
                        target["bid"], target["aov"], target["ctr"],
                        target["pc_cvr"], target.get("bid_type"),
                        retailer_profit
                    )

    @staticmethod
    def __get_cost_match_type(campaign_metadata, ad_group_id):
        type_dict = {
            "keyword": "CPC",
            "product": "CPC",
            "category": "CPC",
            "audience": "CPC"
        }
        for ad_group in campaign_metadata["ad_groups"]:
            if ad_group.get(ad_group_id):
                for target in ad_group[ad_group_id]["active_targets"]:
                    type_dict[
                        target["target_type"].lower()
                    ] = target["bid_type"]

        return type_dict

    @staticmethod
    def fill_target_metrics_for_reach_optimization(
            reach_max_ecpm,
            targets
    ):
        for target in targets:
            target["ctr"] = 1.0
            target["bid"] = round(reach_max_ecpm/1000, 2)
            target['ecpm'] = reach_max_ecpm

    def __refresh_targets_in_cache_v2(
            self, retailer_id, campaign_id, ad_group_id, ad_format,
            products_to_promote, targets, placements, campaign_metadata
    ):
        target_keys = self.__get_targets_key_set(retailer_id, targets)
        cache_entries = self.redis_client.multi_get(target_keys)
        cost_dict = self.__get_cost_match_type(campaign_metadata, ad_group_id)
        campaign_type = campaign_metadata["campaign_type"]

        if ad_format == "NATIVE":
            uid = "{}_{}".format(ad_group_id, products_to_promote)
            for target in targets:
                target_value = target["target_value"]
                match_type = target.get("match_type", "BROAD")
                value = cache_entries.get(target["key"])
                if value is None:
                    value = []
                data = {
                        "campaign_id": campaign_id,
                        "ad_group_id": ad_group_id,
                        "uid": uid,
                        "bid": target["bid"],
                        "ctr": target["ctr"],
                        "ecpm": target["ecpm"],
                        "products_to_promote": [products_to_promote],
                        "placements": placements,
                        "cost_type": cost_dict[target["target_type"]],
                        "match_type": match_type,
                        "campaign_type": campaign_type,
                        "target_value": target_value
                    }
                if campaign_type == "MANUAL" and match_type == "BROAD":
                    data["target_value"] = target["exact_value"]
                value.append(data)
                cache_entries[target["key"]] = value

            for key, value in cache_entries.items():
                cache_entries[key] = json.dumps(value)

            old_target_keys = MetaDataExtractor.get_active_targets_v2(
                retailer_id, campaign_id, uid
            )

            if old_target_keys:
                targets_to_be_flushed = list(
                    set(old_target_keys) - set(target_keys)
                )
                self.remove_campaigns_from_target_keys_v2(
                    targets_to_be_flushed, retailer_id, campaign_id, uid
                )

            MetaDataExtractor.set_active_targets_v2(
                retailer_id, campaign_id, uid, target_keys
            )
            self.redis_client.mass_insert_to_redis(cache_entries)

        else:
            uid = ad_group_id
            for target in targets:
                target_value = target["target_value"]
                match_type = target.get("match_type", "BROAD")
                value = cache_entries.get(target["key"])
                if value is None:
                    value = []
                data = {
                        "campaign_id": campaign_id,
                        "ad_group_id": ad_group_id,
                        "uid": uid,
                        "bid": target["bid"],
                        "ctr": target["ctr"],
                        "ecpm": target["ecpm"],
                        "products_to_promote": products_to_promote,
                        "placements": placements,
                        "cost_type": cost_dict[target["target_type"]],
                        "match_type": match_type,
                        "campaign_type": campaign_type,
                        "target_value": target_value
                    }
                if campaign_type == "MANUAL" and match_type == "BROAD":
                    data["target_value"] = target["exact_value"]
                value.append(data)
                cache_entries[target["key"]] = value

            for key, value in cache_entries.items():
                cache_entries[key] = json.dumps(value)

            old_target_keys = MetaDataExtractor.get_active_targets_v2(
                retailer_id, campaign_id, ad_group_id
            )

            if old_target_keys:
                targets_to_be_flushed = list(
                    set(old_target_keys) - set(target_keys)
                )
                self.remove_campaigns_from_target_keys_v2(
                    targets_to_be_flushed, retailer_id, campaign_id, uid
                )

            MetaDataExtractor.set_active_targets_v2(
                retailer_id, campaign_id, ad_group_id, target_keys
            )
            self.redis_client.mass_insert_to_redis(cache_entries)

    @staticmethod
    def __get_product_meta_data(retailer_id, products_to_promote):
        product_meta_data_map = {}

        for sku in products_to_promote:
            product_meta_data_map[
                sku
            ] = MetaDataExtractor.get_product_metadata(retailer_id, sku)

        return product_meta_data_map

    def remove_campaigns_from_target_keys_v2(
            self, target_keys, retailer_id, campaign_id, uid
    ):
        if target_keys:
            key_set_for_deletion = []
            updated_cache_entries = {}
            cache_entries = self.redis_client.multi_get(target_keys)

            for key in target_keys:
                value = cache_entries.get(key)
                if value:
                    for campaign in value[:]:
                        if (
                                campaign["campaign_id"] == campaign_id and
                                campaign["uid"] == uid
                        ):
                            value.remove(campaign)
                            if value:
                                updated_cache_entries[key] = value
                            else:
                                key_set_for_deletion.append(key)

            for key, value in updated_cache_entries.items():
                updated_cache_entries[key] = json.dumps(value)
            if updated_cache_entries:
                self.redis_client.mass_insert_to_redis(updated_cache_entries)
            if key_set_for_deletion:
                self.redis_client.delete_multiple_keys(key_set_for_deletion)
            MetaDataExtractor.remove_active_targets_v2(
                retailer_id, campaign_id, uid
            )

    @staticmethod
    def __get_targets_key_set(retailer_id, targets):
        key_set = []
        for target in targets:
            if (
                    target.get("match_type") == "EXACT" and
                    target["target_type"] == "keyword"
            ):
                key = RedisKeyGen.get_targeting_key_v2(
                    retailer_id, "exact_keyword",
                    target["target_value"].lower().strip()
                )
            else:
                key = RedisKeyGen.get_targeting_key_v2(
                    retailer_id, target["target_type"],
                    target["target_value"].lower().strip()
                )
            target["key"] = key
            key_set.append(key)
        return key_set

    def remove_stale_ad_group(
            self, retailer_id, campaign_id, deactivated_ad_groups
    ):
        for ad_group in deactivated_ad_groups:
            if ad_group["ad_format"] == "NATIVE":
                for product in ad_group["products_to_promote"]:
                    uid = ad_group["ad_group_id"] + "_" + product
                    target_keys = MetaDataExtractor.get_active_targets_v2(
                        retailer_id, campaign_id, uid
                    )
                    self.remove_campaigns_from_target_keys_v2(
                        target_keys, retailer_id, campaign_id, uid
                    )
            else:
                uid = ad_group["ad_group_id"]
                target_keys = MetaDataExtractor.get_active_targets_v2(
                    retailer_id, campaign_id, uid
                )
                self.remove_campaigns_from_target_keys_v2(
                    target_keys, retailer_id, campaign_id, uid
                )

    @staticmethod
    def get_placements(ad_group_data):
        placements = []
        for target in ad_group_data["targets"]:
            if target["status"] == "ACTIVE":
                if target.get("placements"):
                    placements.extend(target["placements"])
        placements = [int(x) for x in placements]
        return list(set(placements))

    def __create_target_data(
            self, retailer_id, products_to_promote, manual_targets,
            negative_targets, ad_format
    ):
        targets = []
        for product in products_to_promote:
            db_targets = self.get_targets(
                retailer_id, [product],
                negative_targets=negative_targets
            )

            for target in manual_targets:
                all_dict = dict()
                all_dict["exact_value"] = target["exact_value"]
                all_dict["target_type"] = target["target_type"].lower()
                all_dict["target_value"] = target["target_value"]
                all_dict["products_to_promote"] = [
                    {"sku": str(product).lower()}
                ]
                all_dict["bid_type"] = target["bid_type"]
                all_dict["bid"] = target["bid"]
                all_dict["match_type"] = target["match_type"]

                for db_target in db_targets:
                    if (
                            all_dict["target_value"] ==
                            db_target["target_value"]
                            and
                            all_dict["target_type"] ==
                            db_target["target_type"]
                    ):
                        all_dict["products_to_promote"] = db_target[
                            "products_to_promote"
                        ]
                        break
                targets.append(all_dict)

        if ad_format == "NATIVE":
            return targets
        else:
            all_dict = {}
            for target in targets:
                if all_dict.get(target["target_value"]):
                    if (
                            all_dict[target["target_value"]]["target_type"] ==
                            target["target_type"]
                    ):
                        all_dict[
                            target["target_value"]
                        ][
                            "products_to_promote"
                        ].extend(
                            target["products_to_promote"]
                        )
                    else:
                        all_dict[target["target_value"]] = target
                else:
                    all_dict[target["target_value"]] = target
            return list(all_dict.values())

    def refresh_manual_targets(self, retailer_id, campaign_id):
        campaign_metadata = self.mongo_util_base.get_document(
            Config.AzureConfig.COSMOS_ACTIVE_CAMPAIGNS_DB,
            str(retailer_id),
            str(campaign_id)
        )

        for ad_group in campaign_metadata["ad_groups"]:
            for key, value in ad_group.items():
                ad_group_id = str(key)
                products_to_promote = value["products_to_promote"]
                acos = value.get("acos")
                placements = value["placements"]
                manual_targets = value["active_targets"]
                negative_targets = value.get("negative_targets")
                ad_format = value["ad_format"]

                if ad_format == "NATIVE":
                    for sku in products_to_promote:
                        uid = ad_group_id + "_" + sku
                        self.remove_targets_v2(retailer_id, campaign_id, uid)

                        targets = self.__create_target_data(
                            retailer_id, [sku],
                            manual_targets,
                            negative_targets,
                            ad_format
                        )

                        if not targets:
                            continue

                        self.fill_target_metrics(
                            retailer_id, [sku], targets, acos,
                            campaign_mode="MANUAL"
                        )

                        self.__refresh_targets_in_cache_v2(
                            retailer_id, campaign_id, ad_group_id, ad_format,
                            sku, targets, placements,
                            campaign_metadata
                        )

                else:
                    uid = ad_group_id
                    self.remove_targets_v2(retailer_id, campaign_id, uid)
                    targets = self.__create_target_data(
                        retailer_id, products_to_promote, manual_targets,
                        negative_targets, ad_format
                    )

                    if not targets:
                        continue

                    self.fill_target_metrics(
                        retailer_id, products_to_promote, targets, acos,
                        campaign_mode="MANUAL"
                    )

                    self.__refresh_targets_in_cache_v2(
                        retailer_id, campaign_id, ad_group_id, ad_format,
                        products_to_promote, targets, placements,
                        campaign_metadata
                    )

    @staticmethod
    def __process_targets_for_logs(ad_group_id, targets):
        df = pd.DataFrame()
        if targets:
            df = pd.DataFrame(targets)
            df.insert(0, "ad_group_id", ad_group_id)
            df = df[["ad_group_id", "target_type", "target_value"]]
        return df

    def refresh_targets_v2(self, retailer_id, campaign_id):
        campaign_metadata = self.mongo_util_base.get_document(
            Config.AzureConfig.COSMOS_ACTIVE_CAMPAIGNS_DB,
            str(retailer_id),
            str(campaign_id)
        )
        all_campaign_targets = pd.DataFrame()
        for ad_group in campaign_metadata["ad_groups"]:
            for key, value in ad_group.items():
                ad_group_id = str(key)
                products_to_promote = value["products_to_promote"]
                acos = value["acos"]
                placements = value["placements"]
                max_bid = value["max_bid_price"]
                negative_targets = value.get("negative_targets")
                ad_format = value["ad_format"]
                adgroup_objective = value.get('adgroup_objective')
                reach_max_ecpm = value.get("reach_optimizer_max_ecpm")

                if ad_format == "NATIVE":
                    for product in products_to_promote:
                        uid = ad_group_id + "_" + product
                        self.remove_targets_v2(
                            retailer_id, campaign_id, uid
                        )

                        targets = self.get_targets(
                            retailer_id, [product], negative_targets,
                            adgroup_objective
                        )

                        all_campaign_targets = all_campaign_targets.append(
                            self.__process_targets_for_logs(
                                ad_group_id, targets
                            )
                        )

                        if adgroup_objective == 'ROAS':
                            self.fill_target_metrics(
                                retailer_id, [product], targets, acos, max_bid
                            )
                        elif adgroup_objective == 'ECPM':
                            self.fill_target_metrics_for_reach_optimization(
                                reach_max_ecpm,
                                targets
                            )

                        self.__refresh_targets_in_cache_v2(
                            retailer_id, campaign_id, ad_group_id, ad_format,
                            product, targets, placements, campaign_metadata
                        )
                else:
                    uid = ad_group_id
                    self.remove_targets_v2(
                        retailer_id, campaign_id, uid
                    )

                    targets = self.get_targets(
                        retailer_id, products_to_promote, negative_targets,
                        adgroup_objective
                    )

                    all_campaign_targets = all_campaign_targets.append(
                        self.__process_targets_for_logs(
                            ad_group_id, targets
                        )
                    )

                    if adgroup_objective == 'ROAS':
                        self.fill_target_metrics(
                            retailer_id, products_to_promote, targets, acos,
                            max_bid
                        )
                    elif adgroup_objective == 'ECPM':
                        self.fill_target_metrics_for_reach_optimization(
                            reach_max_ecpm,
                            targets
                        )

                    self.__refresh_targets_in_cache_v2(
                        retailer_id, campaign_id, ad_group_id, ad_format,
                        products_to_promote, targets, placements,
                        campaign_metadata
                    )

        self.read_write_azure.write_target_logs_to_azure(
            retailer_id, campaign_id, all_campaign_targets
        )

    def remove_targets_v2(
            self, retailer_id, campaign_id, uid
    ):
        target_keys = MetaDataExtractor.get_active_targets_v2(
            retailer_id, campaign_id, uid
        )
        if target_keys:
            self.remove_campaigns_from_target_keys_v2(
                target_keys, retailer_id, campaign_id, uid
            )

    @staticmethod
    def get_bid_landscape_keys(targets):
        for target in targets:
            if target['target_type'] == "keyword":
                target['mongo_key'] = "kt_{}".format(target['target_value'])
            if target['target_type'] == "product":
                target['mongo_key'] = "pt_{}".format(target['target_value'])
            if target['target_type'] == "category":
                target['mongo_key'] = "ct_{}".format(target['target_value'])
        return targets

    def update_bids_with_landscape(
            self, retailer_id, targets, cost_type
    ):
        self.get_bid_landscape_keys(targets)
        mongo_targets = list(map(lambda d: d['mongo_key'], targets))
        bid_landscape = list(
            self.mongo_util_base.get_documents(
                Config.AzureConfig.COSMOS_BID_LANDSCAPE_DB,
                retailer_id,
                mongo_targets
            )
        )
        bid_map = {}
        for doc in bid_landscape:
            if float(list(doc['target'])[-1]) != 0:
                min_bid, max_bid = float(list(doc['target'])[0]), float(
                    list(doc['target'])[-1])
                bid = np.round((min_bid + max_bid) / 2, 4)
                bid_map[doc['_id']] = {
                    'bid': bid,
                    'min_bid': min_bid,
                    'max_bid': max_bid,
                    'median_bid': statistics.median(
                        [float(bid) for bid in list(doc['target'])]
                    )
                }

        if cost_type == "cpc":
            for i in targets:
                if bid_map.get(i['mongo_key']):
                    i['ecpm'] = bid_map.get(i['mongo_key']).get('bid')
                    i['bid'] = i['ecpm'] / i['ctr'] / 1000
                    i['min_bid'] = bid_map.get(
                        i['mongo_key']
                    ).get('min_bid') / i['ctr'] / 1000
                    i['max_bid'] = bid_map.get(
                        i['mongo_key']
                    ).get('max_bid') / i['ctr'] / 1000
                    i['median_bid'] = bid_map.get(
                        i['mongo_key']
                    ).get('median_bid') / i['ctr'] / 1000
                else:
                    i['min_bid'] = round(i['bid'] - (i['bid'] * 0.1), 4)
                    i['max_bid'] = round(i['bid'] + (i['bid'] * 0.1), 4)
                    i['median_bid'] = round(
                        (i['min_bid'] + i['max_bid']) / 2, 4
                    )

        else:
            for i in targets:
                if bid_map.get(i['mongo_key']):
                    i['bid'] = bid_map.get(i['mongo_key']).get('bid')
                    i['min_bid'] = bid_map.get(
                        i['mongo_key']
                    ).get('min_bid')
                    i['max_bid'] = bid_map.get(
                        i['mongo_key']
                    ).get('max_bid')
                    i['median_bid'] = bid_map.get(
                        i['mongo_key']
                    ).get('median_bid')
                else:
                    i['bid'] = i['ecpm']
                    i['min_bid'] = round(i['bid'] - (i['bid'] * 0.1), 4)
                    i['max_bid'] = round(i['bid'] + (i['bid'] * 0.1), 4)
                    i['median_bid'] = round(
                        (i['min_bid'] + i['max_bid']) / 2, 4
                    )

    def fill_target_metrics_for_suggestion(
            self, retailer_metadata, product_meta_data_map,
            products_to_promote, targets, acos, max_bid=None
    ):
        product_meta_data = {}
        for product in products_to_promote:
            product_meta_data[product] = product_meta_data_map[product]

        request_list = []
        for target in targets:
            for entry in target["products_to_promote"]:
                entry["target_type"] = target["target_type"]
                entry["target_value"] = target["target_value"]
                request_list.append(entry)
                entry["aov"] = product_meta_data[entry["sku"]]["aov"]

        self.metric_util.add_metric_for_many_request(
            retailer_metadata['_id'], retailer_metadata, "ctr", request_list
        )
        self.metric_util.add_metric_for_many_request(
            retailer_metadata['_id'], retailer_metadata, "pc_cvr", request_list
        )
        for target in targets[:]:
            target["ctr"] = BidderUtil.compute_campaign_ctr(
                target["products_to_promote"])
            if target["ctr"] == 0.0:
                targets.remove(target)
            else:
                target["bid"] = BidderUtil.compute_bid_v2(acos, target[
                    "products_to_promote"])
                if max_bid:
                    target["bid"] = min(target["bid"], max_bid)
                target["ecpm"] = BidderUtil.compute_ecpm(target["ctr"],
                                                         target["bid"])

    def update_bid_landscape_for_suggestion(
            self, targets, bid_map, cost_type
    ):
        self.get_bid_landscape_keys(targets)
        if cost_type == "cpc":
            for i in targets:
                if bid_map.get(i['mongo_key']):
                    i['ecpm'] = bid_map.get(i['mongo_key']).get('bid')
                    i['bid'] = i['ecpm'] / i['ctr'] / 1000
                    i['min_bid'] = bid_map.get(
                        i['mongo_key']
                    ).get('min_bid') / i['ctr'] / 1000
                    i['max_bid'] = bid_map.get(
                        i['mongo_key']
                    ).get('max_bid') / i['ctr'] / 1000
                    i['median_bid'] = bid_map.get(
                        i['mongo_key']
                    ).get('median_bid') / i['ctr'] / 1000
                else:
                    i['min_bid'] = round(i['bid'] - (i['bid'] * 0.1), 4)
                    i['max_bid'] = round(i['bid'] + (i['bid'] * 0.1), 4)
                    i['median_bid'] = round(
                        (i['min_bid'] + i['max_bid']) / 2, 4
                    )
        else:
            for i in targets:
                if bid_map.get(i['mongo_key']):
                    i['bid'] = bid_map.get(i['mongo_key']).get('bid')
                    i['min_bid'] = bid_map.get(
                        i['mongo_key']
                    ).get('min_bid')
                    i['max_bid'] = bid_map.get(
                        i['mongo_key']
                    ).get('max_bid')
                    i['median_bid'] = bid_map.get(
                        i['mongo_key']
                    ).get('median_bid')
                else:
                    i['bid'] = i['ecpm']
                    i['min_bid'] = round(i['bid'] - (i['bid'] * 0.1), 4)
                    i['max_bid'] = round(i['bid'] + (i['bid'] * 0.1), 4)
                    i['median_bid'] = round(
                        (i['min_bid'] + i['max_bid']) / 2, 4
                    )
