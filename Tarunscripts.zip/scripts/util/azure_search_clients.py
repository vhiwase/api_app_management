# pylint: disable=all
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents import SearchClient
from azure.core.credentials import AzureKeyCredential
from azure.search.documents.indexes.models import (
    ComplexField, CorsOptions, SearchIndex, SimpleField, SearchableField)
import json


class AzureSearchClients:
    def __init__(self, index_name, endpoint, admin_key):
        self.index_name = index_name
        self.endpoint = endpoint
        self.admin_key = admin_key

    def CreateIndexClient(self):
        admin_client = SearchIndexClient(
            endpoint=self.endpoint,
            index_name=self.index_name,
            credential=AzureKeyCredential(self.admin_key))
        return admin_client

    def CreateSearchClient(self):
        search_client = SearchClient(
            endpoint=self.endpoint,
            index_name=self.index_name,
            credential=AzureKeyCredential(self.admin_key))
        return search_client


class AzureSearchUtils:
    SCHEMA = [
            {"fieldtype": "SimpleField", "name": "index", "type": "Edm.String",
             "key": "True", "sortable": "False", "facetable": "False",
             "filterable": "False"},
            {"fieldtype": "SearchableField", "name": "sku",
             "type": "Edm.String", "sortable": "False", "facetable": "False",
             "filterable": "False"},
            {"fieldtype": "SearchableField", "name": "name",
             "type": "Edm.String", "sortable": "True", "facetable": "True",
             "filterable": "True"},
            {"fieldtype": "SearchableField", "name": "productType",
             "type": "Edm.String", "sortable": "True",
             "facetable": "True", "filterable": "True"},
            {"fieldtype": "SearchableField", "name": "brand",
             "type": "Edm.String", "sortable": "True",
             "facetable": "True", "filterable": "True"},
            {"fieldtype": "SearchableField", "name": "normalized_brand",
             "type": "Edm.String", "sortable": "True",
             "facetable": "True", "filterable": "True"}
        ]

    def infer_schema(self):
        schema, columns = [], []
        try:
            for i in self.SCHEMA:
                columns.append(i['name'])
                if 'key' in i.keys() and i['fieldtype'] == 'SimpleField':
                    schema.append(SimpleField(
                        name=i['name'], key=i['key'], type=i['type'],
                        sortable=i['sortable'], facetable=i['facetable'],
                        filterable=i['filterable']))
                if 'key' not in i.keys() and i['fieldtype'] == 'SimpleField':
                    schema.append(
                        SimpleField(
                            name=i['name'], type=i['type'],
                            sortable=i['sortable'], facetable=i['facetable'],
                            filterable=i['filterable']))
                if 'key' not in i.keys() and i['fieldtype'] == \
                        'SearchableField':
                    schema.append(SearchableField(
                        name=i['name'], type=i['type'], sortable=i['sortable'],
                        facetable=i['facetable'], filterable=i['filterable']))
                if 'key' not in i.keys() and i['fieldtype'] == 'ComplexField':
                    schema.append(
                        ComplexField(
                            name=i['name'], type=i['type'],
                            sortable=i['sortable'], facetable=i['facetable'],
                            filterable=i['filterable']))
        except Exception as e:
            print(e)
        return schema, columns

    @staticmethod
    def default_settings():
        cors_options = CorsOptions(
            allowed_origins=["*"], max_age_in_seconds=60)
        scoring_profiles = []
        suggester = []
        return cors_options, scoring_profiles, suggester

    def process_data(self, data):
        _, columns = self.infer_schema()
        if 'index' not in data.columns:
            data = data.reset_index()
        dataframe = data[columns]
        dataframe.insert(loc=0, column='@search.action', value='upload')
        dataframe['index'] = dataframe['index'].apply(str)
        return json.loads(dataframe.to_json(orient='records'))

    @staticmethod
    def batch(iterable, n=1):
        l = len(iterable)
        for ndx in range(0, l, n):
            yield iterable[ndx:min(ndx + n, l)]

    def create_azure_index(self, retailer_name, data, admin_client,
                           search_client):
        cors_options, scoring_profiles, suggester = self.default_settings()
        schema, columns = self.infer_schema()
        index = SearchIndex(
            name=retailer_name,
            fields=schema,
            scoring_profiles=scoring_profiles,
            suggesters=suggester,
            cors_options=cors_options)
        documents = self.process_data(data)
        try:
            result = admin_client.delete_index(index)
            print("Index {} will be deleted, if it exists already".format(
                retailer_name))
        except Exception as ex:
            print(ex)
        try:
            result = admin_client.create_index(index)
            print('Index', result.name, 'created')
        except Exception as ex:
            print('Unable to create Index due to {}'.format(ex))
        try:
            batch_counter = 0
            for document in self.batch(documents, 999):
                result = search_client.upload_documents(documents=document)
                batch_counter += 1
                print(f'Batch sent! - #{batch_counter}')
            print("Documents have been successfully uploaded")
        except Exception as ex:
            print("Unable to upload documents due to {}".format(ex))
