import sys

sys.path.append("../icc-ai-v24/scripts")
import itertools
import random
import nltk
from torch.utils.data import DataLoader
from sentence_transformers import SentenceTransformer, InputExample, losses, models
import torch.nn as nn
import torch
from azure.storage.blob import BlobServiceClient
from config import Config
import pandas as pd
import numpy as np
import time
import pickle
from keyword_reboarding import KeywordMining
import argparse
from relevance.keywordtargeting import KeywordTargeting
from azure.cosmos.cosmos_client import CosmosClient
from retailer_onboarding_lite import RetailerOnboardingLite
import os
import faiss
from sklearn.metrics import auc

random.seed(100)
Config.switch_env('prod')


class ModelFineTuning:

    def __init__(self, retailer_info):
        self.retailer_info = retailer_info
        self.retailer_lite = RetailerOnboardingLite(retailer_info)
        self.KM = KeywordMining()
        self.lemmatizer = nltk.stem.WordNetLemmatizer()
        self.w_tokenizer = nltk.tokenize.WhitespaceTokenizer()
        self.n_gpus = torch.cuda.device_count()
        self.sku_keywords_dict = self.__get_atc_dict()
        self.catalogue_data = self.__get_catalogue_data_filtered()
        self.model = self.__get_model()
        self.parallel_net = nn.DataParallel(self.model, device_ids=[0, 1, 2, 3])
        self.__gen_data_dicts()

    def __get_atc_dict(self):
        atc_data = self.KM.get_lastn_days_job_data(self.retailer_info['id'], 'atc', ndays=10)
        atc_data['keyword_hash'] = atc_data['keywords'].apply(self.KM.KH.get_keyword_hash)
        atc_data.rename(columns={'Product': 'sku'}, inplace=True)
        atc_data1 = atc_data.groupby(['sku', 'keyword_hash'], as_index=False).agg({'Count': sum}).sort_values(
            by='Count', ascending=False)
        atc_data1['cumulative_sum'] = atc_data1['Count'].cumsum()
        atc_data2 = atc_data1[atc_data1.cumulative_sum < int(.9 * atc_data['Count'].sum())]
        sku_keywordhash_dict = atc_data2.groupby('sku')['keyword_hash'].apply(list).to_dict()
        hash_keyword_dict = self.KM.KT.get_hash_keyword_dict(atc_data['keywords'])
        sku_keywords_dict = {}
        for sku in sku_keywordhash_dict.keys():
            sku_keywords_dict[sku] = [hash_keyword_dict[hash][0] for hash in sku_keywordhash_dict[sku]]
        print("No of skus in atc sku-keyword dict ", len(sku_keywords_dict))
        return sku_keywords_dict

    def __get_atc_data(self):
        print("Getting atc data")
        atc_data = self.KM.get_lastn_days_job_data(self.retailer_info['id'], 'atc', ndays=10)
        atc_data['keyword_hash'] = atc_data['keywords'].apply(self.KM.KH.get_keyword_hash)
        atc_data.rename(columns={'Product': 'sku'}, inplace=True)
        atc_data1 = atc_data.groupby(['sku', 'keyword_hash'], as_index=False).agg({'Count': sum}).sort_values(
            by='Count', ascending=False)
        atc_data1['cumulative_sum'] = atc_data1['Count'].cumsum()
        atc_data2 = atc_data1[atc_data1.cumulative_sum < int(.9 * atc_data['Count'].sum())]
        return atc_data2

    def __get_catalogue_data_filtered(self):
        print("Filtering catalogue data")
        catalogue_data = self.retailer_lite._RetailerOnboardingLite__fetch_data_from_container()
        catalogue_data = pd.DataFrame(catalogue_data)
        print("Shape of the dataframe is ", catalogue_data.shape)
        catalogue_data, category_path_col = self.retailer_lite._RetailerOnboardingLite__preprocess_catalogue_data(
            catalogue_data)
        print("Columns are ", catalogue_data.columns)
        catalogue_data_filtered = catalogue_data[catalogue_data.sku.isin(self.sku_keywords_dict.keys())]
        print("Filtered catalogue data shape ", catalogue_data_filtered.shape)
        return catalogue_data_filtered

    def __get_model(self):
        model_arch = self.retailer_info["model"]
        if model_arch == 'tf2':
            model = SentenceTransformer('sentence-transformers/multi-qa-MiniLM-L6-cos-v1')
            for index, (name, param) in enumerate(model._first_module().auto_model.named_parameters()):
                if index > 94:  # Finetune only last encoder's dense layers
                    param.requires_grad = True
                else:
                    param.requires_grad = False

        if model_arch == 'roberta-large':
            model = SentenceTransformer('roberta-large')

        if model_arch == 'current':
            model = SentenceTransformer('../icc-ai-v5/scripts/relevance_products/data/fine_tuned_roberta_cpu.pt')

        if model_arch == 'tf1':
            stage1_model = models.Transformer('sentence-transformers/multi-qa-MiniLM-L6-cos-v1')
            for param in stage1_model.parameters():
                param.requires_grad = False
            pooling_model = models.Pooling(stage1_model.get_word_embedding_dimension())
            dense_model1 = models.Dense(in_features=pooling_model.get_sentence_embedding_dimension(), out_features=256,
                                        activation_function=nn.Tanh())
            dense_model2 = models.Dense(in_features=dense_model1.get_sentence_embedding_dimension(), out_features=1024,
                                        activation_function=nn.Tanh())
            model = SentenceTransformer(modules=[stage1_model, pooling_model, dense_model1, dense_model2])

        return model

    def __gen_data_dicts(self):
        self.sku_category_dict = dict(zip(self.catalogue_data.sku, self.catalogue_data.category))
        self.sku_producttype_dict = dict(zip(self.catalogue_data.sku, self.catalogue_data.productType))
        self.sku_name_dict = dict(zip(self.catalogue_data.sku, self.catalogue_data.name))
        self.category_sku_dict = self.catalogue_data.groupby('category')['sku'].apply(list).to_dict()
        self.producttype_sku_dict = self.catalogue_data.groupby('productType')['sku'].apply(list).to_dict()
        self.all_skus = list(set(self.catalogue_data.sku))

    def __gen_training_pairs_by_sku(self, original_sku, similar_producttype_skus, similar_category_skus, random_skus,
                                    data_type):
        if data_type == 'training':
            data_pairs = []
            for keyword in self.sku_keywords_dict[original_sku]:
                similarity_score = random.uniform(0.9, 1)
                data_pairs.append(
                    InputExample(texts=[self.sku_name_dict[original_sku], keyword], label=similarity_score))

            for sku in similar_producttype_skus:
                for keyword in self.sku_keywords_dict[sku]:
                    similarity_score = random.uniform(0.75, 0.90)
                    data_pairs.append(
                        InputExample(texts=[self.sku_name_dict[original_sku], keyword], label=similarity_score))

            for sku in similar_category_skus:
                for keyword in self.sku_keywords_dict[sku]:
                    similarity_score = random.uniform(0.5, 0.75)
                    data_pairs.append(
                        InputExample(texts=[self.sku_name_dict[original_sku], keyword], label=similarity_score))

            for sku in random_skus:
                for keyword in self.sku_keywords_dict[sku]:
                    similarity_score = random.uniform(0.1, 0.45)
                    data_pairs.append(
                        InputExample(texts=[self.sku_name_dict[original_sku], keyword], label=similarity_score))

        if data_type == 'validation':
            data_pairs = []
            for keyword in self.sku_keywords_dict[original_sku]:
                similarity_score = 1
                data_pairs.append([original_sku, self.sku_name_dict[original_sku], keyword, similarity_score])

            for sku in similar_producttype_skus:
                for keyword in self.sku_keywords_dict[sku]:
                    similarity_score = 0
                    data_pairs.append([original_sku, self.sku_name_dict[original_sku], keyword, similarity_score])

            for sku in similar_category_skus:
                for keyword in self.sku_keywords_dict[sku]:
                    similarity_score = 0
                    data_pairs.append([original_sku, self.sku_name_dict[original_sku], keyword, similarity_score])

            for sku in random_skus:
                for keyword in self.sku_keywords_dict[sku]:
                    similarity_score = 0
                    data_pairs.append([original_sku, self.sku_name_dict[original_sku], keyword, similarity_score])
        return (data_pairs)

    def __gen_modelling_pairs(self, num_pairs=5):
        training_pairs = []
        validation_pairs = []
        i = 0
        j = 0

        train_test_split = .8
        all_skus = (list(self.catalogue_data.sku))
        training_size = int(np.ceil(len(list(self.catalogue_data.sku)) * train_test_split))
        training_skus = random.sample(list(self.catalogue_data.sku), training_size)

        print("Total no of skus", len(all_skus))
        for sku in all_skus:
            category = self.sku_category_dict[sku]
            producttype = self.sku_producttype_dict[sku]
            sim_producttype_skus_list = self.producttype_sku_dict[producttype]
            sim_category_skus_list = set(self.category_sku_dict[category]) - set(
                self.producttype_sku_dict[producttype])
            random_skus_list = set(self.all_skus) - set(self.category_sku_dict[category])
            similar_producttype_skus = random.sample(sim_producttype_skus_list,
                                                     min(len(sim_producttype_skus_list), num_pairs))
            similar_category_skus = random.sample(sim_category_skus_list,
                                                  min(len(sim_category_skus_list), num_pairs))
            random_skus = random.sample(random_skus_list, min(len(random_skus_list), num_pairs))

            if sku in training_skus:
                training_pairs.extend(
                    self.__gen_training_pairs_by_sku(sku, similar_producttype_skus, similar_category_skus, random_skus,
                                                     'training'))
            else:
                validation_pairs.extend(
                    self.__gen_training_pairs_by_sku(sku, similar_producttype_skus, similar_category_skus, random_skus,
                                                     'validation'))
            i = i + 1
            if (i % 1000 == 0):
                print("No of skus pairs generated: ", i)
        return training_pairs, validation_pairs

    def __model_training(self, modelling_pairs):
        train_dataloader = DataLoader(modelling_pairs, shuffle=True, batch_size=256)
        steps_per_epoch = len(train_dataloader)
        print(steps_per_epoch)
        train_loss = losses.CosineSimilarityLoss(self.parallel_net)
        self.parallel_net.module.fit(train_objectives=[(train_dataloader, train_loss)],
                                     optimizer_params={'lr': 4e-4},
                                     # evaluator=val_evaluator,
                                     # evaluation_steps=steps_per_epoch,
                                     output_path="output/{name}-atc-{model}-{epochs}epochs".format(
                                         name=self.retailer_info['name'],
                                         model=self.retailer_info['model'],
                                         epochs=self.retailer_info['epochs']),
                                     epochs=self.retailer_info['epochs'],
                                     warmup_steps=100
                                     )
        return self.parallel_net.module

    @staticmethod
    def create_text_faiss_index(text_features, text_ids):
        vector_dimension = text_features.shape[1]
        nlist = int(len(text_features) / 1000) + 1
        quantizer = faiss.IndexFlatL2(vector_dimension)
        text_features = np.vstack(text_features)
        text_ids = np.hstack(text_ids)
        faiss.normalize_L2(text_features)
        faiss_index = faiss.IndexFlatL2(vector_dimension)
        faiss_index2 = faiss.IndexIDMap(faiss_index)
        faiss_index2.train(text_features)
        faiss_index2.add_with_ids(text_features, text_ids)
        return faiss_index2, nlist

    @staticmethod
    def get_precision_recall_values(actual_mapping, model_mapping, cutoff_score):
        sku_precison_dict = {}
        sku_recall_dict = {}
        atc_missed_dict = {}
        for sku in set(actual_mapping['sku']):
            actual_mapping_sku = actual_mapping[actual_mapping.sku == sku]
            if len(model_mapping[sku]) > 0:
                model_mapping_sku_df = pd.DataFrame(model_mapping[sku])
            else:
                model_mapping_sku_df = pd.DataFrame(columns=['hash', 'relevance_score'])
            model_mapping_sku_df.rename(columns={'hash': 'keyword_hash'}, inplace=True)
            model_mapping_sku_df['sku'] = sku
            model_mapping_sku_df1 = model_mapping_sku_df[model_mapping_sku_df.relevance_score > cutoff_score]
            combined_df = actual_mapping.merge(model_mapping_sku_df1, on=['sku', 'keyword_hash'])

            sku_recall_dict[sku] = combined_df.shape[0] / actual_mapping_sku.shape[0]

            if model_mapping_sku_df1.shape[0] > 0:
                sku_precison_dict[sku] = combined_df.shape[0] / model_mapping_sku_df1.shape[0]
            else:
                sku_precison_dict[sku] = 1
            atc_missed_dict[sku] = 1 - (combined_df['Count'].sum() / actual_mapping_sku['Count'].sum())
        precision = np.mean(list(sku_precison_dict.values()))
        recall = np.mean(list(sku_recall_dict.values()))
        atc_missed = np.mean(list(atc_missed_dict.values()))
        return precision, recall, atc_missed

    def calculate_validation_metrics(self, model):
        train_test_split = .8
        all_skus = (list(self.catalogue_data.sku))
        training_size = int(np.ceil(len(list(self.catalogue_data.sku)) * train_test_split))
        training_skus = random.sample(list(self.catalogue_data.sku), training_size)
        validation_skus = list(set(all_skus) - set(training_skus))
        atc_data = self.__get_atc_data()
        validation_atc_data = atc_data[atc_data['sku'].isin(validation_skus)].set_index('sku')
        validation_atc_dict = validation_atc_data.T.to_dict('list')
        print("Generating embeddings ")
        num_cuda_devices = torch.cuda.device_count()
        cuda_devices = ["cuda:" + str(i) for i in range(0, num_cuda_devices)]
        pool = model.start_multi_process_pool(cuda_devices)

        search_data = self.KM.get_lastn_days_job_data(self.retailer_info['id'], 'organic_search', ndays=10)
        keywords_list = search_data['keywords'].astype(str)
        hash_keyword_dict = self.KM.KT.get_hash_keyword_dict(keywords_list)
        unique_keywords_list = []
        for key_hash in hash_keyword_dict:
            unique_keywords_list.append(hash_keyword_dict[key_hash][0])
        print("Generating keyword embeddings")
        keywords_embeddings = model.encode_multi_process(unique_keywords_list, pool)
        keywords_embeddings = keywords_embeddings / np.expand_dims(np.linalg.norm(keywords_embeddings, axis=1), axis=1)
        keywords_to_embedding_dict = dict(zip(unique_keywords_list, keywords_embeddings))

        keyword_hash_embeddings = {}
        for keyword in list(keywords_to_embedding_dict.keys()):
            keyword_hash_embeddings[self.KM.KH.get_keyword_hash(keyword)] = keywords_to_embedding_dict[keyword]

        product_names = list(self.catalogue_data.name)
        skus_list = list(self.catalogue_data.sku)
        fids_list = self.catalogue_data['FID'].values.tolist()
        producttype_list = self.catalogue_data['productType'].values.tolist()
        print("Geenrating product embeddings ")
        product_names_embeddings = model.encode_multi_process(product_names, pool)
        product_names_embeddings = product_names_embeddings / np.expand_dims(
            np.linalg.norm(product_names_embeddings, axis=1), axis=1)
        product_ids_to_embedding_dict = dict(zip(skus_list, product_names_embeddings))
        fid_sku_map = dict(zip(fids_list, skus_list))
        fid_producttype_map = dict(zip(fids_list, producttype_list))
        sku_producttype_map = dict(zip(skus_list, producttype_list))
        self.catalogue_data['embedding'] = list(product_names_embeddings)
        self.catalogue_data['embedding'] = self.catalogue_data['embedding'].apply(lambda x: x.reshape(1, -1))

        retailer_dict = self.catalogue_data.set_index('sku')[
            ['name', 'description', 'category', 'brand', 'productType', 'embedding']].to_dict('index')
        print("Creating faiss index")
        product_faiss_index, num_clusters = self.create_text_faiss_index(product_names_embeddings, fids_list)
        distances_list, neighbors_list = product_faiss_index.search(np.vstack(keywords_embeddings), k=100)

        keyword_nn_skus_map = {}
        for distances, neighbors, kwd in zip(distances_list, neighbors_list, keywords_list):
            neighbor_skus_obj = {}
            distance_iter = distances.tolist()
            neighbor_iter = neighbors.tolist()
            for distance, neighbor in zip(distance_iter, neighbor_iter):
                neighbor_sku = fid_sku_map.get(neighbor)
                neighbor_skus_obj[neighbor_sku] = distance
            keyword_nn_skus_map[kwd] = neighbor_skus_obj
        print("Creating mappings")
        sku_keyword_map = self.KM.PP.get_sku_keyword_faiss(keyword_nn_skus_map)
        emptymap = {}
        final_mapping1 = self.KM.KT.add_mapping(retailer_dict, emptymap, sku_keyword_map)

        producttype_map = self.KM.get_producttype_mapping(self.catalogue_data, retailer_dict, hash_keyword_dict.keys(),
                                                          keyword_hash_embeddings)
        final_mapping2 = self.KM.KT.add_mapping(retailer_dict, final_mapping1, producttype_map)

        final_map_validation_products = {}
        for sku in validation_skus:
            if sku in sku_keyword_map:
                final_map_validation_products[sku] = final_mapping2[sku]
            else:
                final_map_validation_products[sku] = []

        print("Calculating precision recall metrics")
        cutoff_list = []
        precision_list = []
        recall_list = []
        atc_missed_list = []
        for cutoff in np.arange(0, 1.00, .01):
            cutoff_list.append(cutoff)
            precision, recall, atc_missed = self.get_precision_recall_values(validation_atc_data,
                                                                             final_map_validation_products, cutoff)
            precision_list.append(precision)
            recall_list.append(recall)
            atc_missed_list.append(atc_missed)
        metrics_dataframe = pd.DataFrame({'cutoff': cutoff_list,
                                          'precision': precision_list,
                                          'recall': recall_list,
                                          'atc_missed_percent': atc_missed_list})
        return metrics_dataframe

    def main(self):

        training_data_path = '../data/model_finetune_data/{retailer_id}_training_pairs.pkl'.format(
            retailer_id=self.retailer_info["id"])
        validation_data_path = '../data/model_finetune_data/{retailer_id}_validation_pairs.pkl'.format(
            retailer_id=self.retailer_info["id"])
        atc_mapping_dict_path = '../data/model_finetune_data/{retailer_id}_atc_keyword_sku_map.pkl'.format(
            retailer_id=self.retailer_info["id"])
        if os.path.exists(training_data_path):
            print("training pairs data exist, so not generating again")
            with open(training_data_path, 'rb') as f:
                training_pairs = pickle.load(f)
        else:
            print("Generating modelling pairs")
            st = time.time()
            training_pairs, validation_pairs = self.__gen_modelling_pairs()
            print("No of training pairs={training_pairs}, validation pairs={validation_pairs}".format(
                training_pairs=len(training_pairs),
                validation_pairs=len(validation_pairs)))
            print("time taken to generate pairs for finetuning ", time.time() - st)

            if not os.path.exists('../data/model_finetune_data'):
                os.mkdir('../data/model_finetune_data')

            with open(training_data_path, 'wb') as handle:
                pickle.dump(training_pairs, handle)
            with open(validation_data_path, 'wb') as handle:
                pickle.dump(validation_pairs, handle)
            with open(atc_mapping_dict_path, 'wb') as handle:
                pickle.dump(self.sku_keywords_dict, handle)

        if self.retailer_info['train']:
            model = self.__model_training(training_pairs)

        if self.retailer_info['validation']:
            print("Calculating validation metrics")
            model_path = "output/{name}-atc-{model}-{epochs}epochs".format(
                name=self.retailer_info['name'],
                model=self.retailer_info['model'],
                epochs=self.retailer_info['epochs'])
            model = SentenceTransformer(model_path, device='cuda')

            precision_recall_df = self.calculate_validation_metrics(model)
            auc_pr_roc = auc(precision_recall_df['recall'], precision_recall_df['precision'])
            print(precision_recall_df)
            print("AUC-PR is ", auc_pr_roc)
            precision_recall_df.to_csv(model_path + '_pr_df.csv')
            with open("output/keyword_targeting_valuation_metrics.txt", "a") as myfile:
                myfile.write("\n model {model_path} metrics : auc-pr = {auc_pr_roc}".format(model_path=model_path,
                                                                                            auc_pr_roc=auc_pr_roc))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Model finetuning')
    parser.add_argument('-i', '--id', help='ID', required=True)
    parser.add_argument('-n', '--name', help='retailer_name', required=True)
    parser.add_argument('-c', '--container', help='retailer_container', required=True)
    parser.add_argument('-m', '--model', help='model', required=True)
    parser.add_argument('-e', '--epochs', help='model', nargs='?', const=5, type=int, default=5)
    parser.add_argument('-t', '--train', help='train model', action='store_true')
    parser.add_argument('-v', '--validation', help='validate model', action='store_true')
    args = vars(parser.parse_args())
    FT = ModelFineTuning(args)
    FT.main()

