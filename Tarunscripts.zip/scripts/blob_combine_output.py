# pylint: disable=all
import pandas as pd
from azure.storage.blob import ContainerClient, BlobServiceClient
from io import StringIO
from config import Config
from datetime import datetime, timedelta, date
import json
from util.meta_data_extractor import MetaDataExtractor

today = date.today().strftime("%d_%m_%Y")
OUTPUT_FILENAME = 'CombinedOutput-{}.csv'.format(today)
date_string = datetime.strftime(datetime.now() - timedelta(1), '%Y/%m/%d/')
final_columns = ['retailer_id','campaignId','suggestion_id','suggestion_type','message','json']


class CombineBlobOutput:
    def __init__(self):
        self.InputClient = ContainerClient.from_connection_string(
            conn_str=Config.AzureConfig.RECOMMENDATION_OUT_STRING,
            container_name=Config.AzureConfig.RECOMMENDATION_OUTPUT_CONTAINERNAME)

        self.OutputClient = BlobServiceClient.from_connection_string(Config.AzureConfig.RECOMMENDATION_OUT_STRING)

        self.InputClient1 = ContainerClient.from_connection_string(
            conn_str=Config.AzureConfig.RECOMMENDATION_INP_STRING,
            container_name=Config.AzureConfig.RECOMMENDATION_INPUT_CONTAINERNAME)

    def get_blobs_retailers(self):
        blobs_list = list(self.InputClient1.list_blobs())
        retailers_ = list(set([blob.name.split('/')[0] for blob in blobs_list if date_string in blob.name]))
        return retailers_

    def combine_to_excel(self, keyword_suggestion, budget_recommendation, bid_suggestion,output_container_name,output_file_name):

        files_list = []
        try:
            blobstring1 = self.InputClient.download_blob(keyword_suggestion)
            keyword_suggestion_df = pd.read_csv(StringIO(blobstring1.content_as_text()))
            keyword_suggestion_df['suggestion_id'] = 'K1'
            keyword_suggestion_df['suggestion_type'] = 'keyword_suggestion'
            keyword_suggestion_df['message'] = keyword_suggestion_df.apply(lambda x: (
                    'Please add keyword: [' + x['keyword_suggestions'] + '] for bid value: ' + str(
                x['recommended_cpc_bid'])), axis=1)

            keyword_suggestion_df['json'] = keyword_suggestion_df.apply(
                lambda x: '"{}"'.format(json.dumps({'suggestion_id': x['suggestion_id'],
                                                    'keyword': x['keyword_suggestions'],
                                                    'recommended_bid': x['recommended_cpc_bid']})), axis=1)
            keyword_suggestion_df = keyword_suggestion_df[final_columns]
            files_list.append(keyword_suggestion_df)
            print('Keyword suggestion file created successfully')
        except Exception as error:
            print("Unable to create keyword suggestion output file due to {}".format(error))

        try:
            blobstring2 = self.InputClient.download_blob(budget_recommendation)
            budget_recommendation_df = pd.read_csv(StringIO(blobstring2.content_as_text()))
            budget_recommendation_df['suggestion_type'] = 'budget_suggestion'
            budget_recommendation_df['message'] = budget_recommendation_df.apply(lambda x: (
                    "Please consider revising your campaign {} budget to {} to".format(x['campaignId'], x['final_budget'])), axis=1)

            budget_recommendation_df['json'] = budget_recommendation_df.apply(
                lambda x: '"{}"'.format(json.dumps({'suggestion_id': x['suggestion_id'],
                                                   'campaignId': x['campaignId'],
                                                    'final_budget': x['final_budget']})), axis=1)
            budget_recommendation_df = budget_recommendation_df[final_columns]
            files_list.append(budget_recommendation_df)
            print('Budget suggestion file created successfully')
        except Exception as error:
            print("Unable to create budget recommendation output file due to {}".format(error))

        try:
            blobstring3 = self.InputClient.download_blob(bid_suggestion)
            bid_suggestion_df = pd.read_csv(StringIO(blobstring3.content_as_text()))
            bid_suggestion_df['suggestion_type'] = 'bid_suggestion'
            bid_suggestion_df['message'] = bid_suggestion_df.apply(lambda x: (
                    "Please consider revising your bid value for [{}] to {}".format(x['keyword'], x['revised_bid'])), axis=1)

            bid_suggestion_df['json'] = bid_suggestion_df.apply(
                lambda x: '"{}"'.format(json.dumps({'suggestion_id': x['suggestion_id'],
                                                    'keyword': x['keyword'],
                                                    'revised_bid_value': x['revised_bid']})), axis=1)
            bid_suggestion_df = bid_suggestion_df[final_columns]
            files_list.append(bid_suggestion_df)
            print('Bid suggestion file created successfully')
        except Exception as error:
            print("Unable to create bid suggestion output file due to: {}".format(error))

            df_combined = pd.concat(files_list)
            df_combined.to_csv(output_file_name)

        try:
            blob_client = self.OutputClient.get_blob_client(container=output_container_name, blob=output_file_name)
            with open(output_file_name, "rb") as output_data:
                blob_client.upload_blob(output_data, overwrite=True)
        except Exception:
            raise Exception("Unable to write file to the output destination")
    


if __name__ == "__main__":
    print('Running code for combine output')
    CBO = CombineBlobOutput()
    retailers = MetaDataExtractor.get_retailer_list_for_suggestions()
    if retailers:
        for retailer in retailers:
            try:
                KEYWORD_INPUT_FILENAME = str(retailer) + "_" + 'KeywordSuggestions-{}.csv'.format(today)
                BUDGET_INPUT_FILENAME = str(retailer) + "_" + 'BudgetRecommendation-{}.csv'.format(today)
                BID_INPUT_FILENAME = str(retailer) + "_" + 'BidRecommendation-{}.csv'.format(today)
                CBO.combine_to_excel(KEYWORD_INPUT_FILENAME,BUDGET_INPUT_FILENAME,BID_INPUT_FILENAME,
                                     Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME,
                                     str(retailer) + "_" + OUTPUT_FILENAME)
                print("Successfully created combine file for retailer - {}".format(retailer))

            except Exception as error:
                print("Unable to create combined output file for retailer {} due to {}".format(retailer, error))
                continue
