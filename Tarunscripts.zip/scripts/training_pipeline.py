# pylint: disable=all
import itertools
import random
import nltk
from torch.utils.data import DataLoader
from sentence_transformers import SentenceTransformer, InputExample, losses, evaluation
import torch.nn as nn
import torch
from azure.storage.blob import BlobServiceClient
from config import Config


class RelevanceFineTuning:
    
    def __init__(self):
        self.lemmatizer = nltk.stem.WordNetLemmatizer()
        self.w_tokenizer = nltk.tokenize.WhitespaceTokenizer()
        self.n_gpus = torch.cuda.device_count()
        self.model = SentenceTransformer('../data/fine_tuned_roberta_cpu.pt', device = 'cpu')
        self.parallel_net = nn.DataParallel(self.model, device_ids = [0,1])
        
    
    def __lemmatize_title(self, row):
        return [self.lemmatizer.lemmatize(w) for w in self.w_tokenizer.tokenize(row)]
    
    def __preprocess_titles(self, data):
        data['name'] = data['name'].str.lower()
        data['name'] = data['name'].apply(self.__lemmatize_title)
        data['name'] = data['name'].str.join(' ')
        return data
    
    def __generate_high_similarity_pairs(self, data):
        training_data = []
        data_group = data.groupby('Broad_Category')
        for cat, df in data_group:
            if df.shape[0] == 1:
                continue
            list_of_cat = random.sample(list(itertools.combinations(df.name, 2)), int(df.shape[0]/3)+1)
            training_data.extend(list_of_cat)
        return training_data
    
    def __generate_low_similarity_pairs(self, data):
        training_data = []
        for key, val in data.iterrows():
            low_similar = data[data['Broad_Category'] != val['Broad_Category']].name
            random_element = random.choice(list(low_similar))[0]
            training_data.append((val['name'], random_element))
        return training_data
    
    def __generate_similarity_score_training(self, high_similarity_list, low_similarity_list):
        training_set = []
        for index in range(len(high_similarity_list)):
            training_set.append(InputExample(texts = [high_similarity_list[index][0], high_similarity_list[index][1]], 
                                                        label = random.uniform(0.7, 1)))
        for index in range(len(low_similarity_list)):
            training_set.append(InputExample(texts = [low_similarity_list[index][0], low_similarity_list[index][1]], 
                                                        label = random.uniform(0.1, 0.5)))
        return training_set
    
    def __generate_similarity_score_evaluation(self, high_similarity_list, low_similarity_list):
        first_text_list, second_text_list, score = [], [], []
        for item in high_similarity_list:
            first_text_list.append(item[0])
            second_text_list.append(item[1])
            score.append(random.uniform(0.7, 1))
        
        for item in low_similarity_list:
            first_text_list.append(item[0])
            second_text_list.append(item[1])
            score.append(random.uniform(0.1, 0.5))    
            
        return evaluation.EmbeddingSimilarityEvaluator(first_text_list, second_text_list, score)
    

    def __model_training(self, train_data, evaluator):

        train_dataloader = DataLoader(train_data, shuffle=True, batch_size=64)
        train_loss = losses.CosineSimilarityLoss(self.parallel_net)
        self.parallel_net.module.fit(train_objectives=[(train_dataloader, train_loss)], epochs=15, evaluator=evaluator, 
                                evaluation_steps = 500, warmup_steps=100)
        return self.parallel_net.module
        
    def __upload_model(self, model):
        self.parallel_net.module.save('../data/test_model.pt') # TODO: Change it to the actual name after discussing acceptance criteria
        # TODO : Don't push to blob. Register on Azure ML instead.
        blob_service_client = BlobServiceClient.from_connection_string(
            Config.AzureConfig.ICC_DS_STORAGE_CONNECTION_STRING
        )
        blob_client = blob_service_client.get_blob_client(container = self.container_name, blob = '../data/test_model.pt')
        print("\nUploading to Azure Storage as blob:\n\t" + self.file_name)
        with open(self.data_path + self.file_name, "rb") as data:
            blob_client.upload_blob(data, overwrite = True)
            return "File added/updated to Blob"
        return "Exception"


    def main(self, data):
        data = self.__preprocess_titles(data)
        high_similarity_pairs = self.__generate_high_similarity_pairs(data)
        low_similarity_pairs = self.__generate_low_similarity_pairs(data)
        high_sim_cutoff_index = int(10/100*len(high_similarity_pairs))
        low_sim_cutoff_index = int(10/100*len(low_similarity_pairs))
        train_data = self.__generate_similarity_score_training(high_similarity_pairs[:-high_sim_cutoff_index], 
                                                               low_similarity_pairs[:-low_sim_cutoff_index])
        evaluator = self.__generate_similarity_score_evaluation(high_similarity_pairs[-high_sim_cutoff_index:], 
                                                               low_similarity_pairs[-low_sim_cutoff_index:])
        model = self.__model_training(train_data, evaluator)
        upload_status = self.__upload_model(model)
        return upload_status
        
