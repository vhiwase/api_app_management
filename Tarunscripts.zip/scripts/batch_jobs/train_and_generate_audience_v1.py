import argparse
import numpy as np
import pickle
import pandas as pd
import random
import joblib
import copy
import os
from util.read_write_data_azure_blob import ReadAndWriteFromAzureBlob
from numpy.linalg import norm
from sklearn.model_selection import train_test_split
#from imblearn.over_sampling import SMOTE, ADASYN
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report
from sklearn.metrics import precision_recall_curve, auc, roc_auc_score, precision_recall_fscore_support
#from tabulate import tabulate
from datetime import datetime, timedelta
from config import Config
from multiprocessing import Process, Queue, Manager
import multiprocessing
import math

class TrainAudienceV1:
    def __init__(self, today_date, env, retailer_id):
        Config.switch_env(env)
        print(
            "Running for environment - {}".format(
                Config.AzureConfig.ENV)
        )
        self.base_dir = "audience_features/"
        self.con_features_file = "user_semantic_unit_emb_hash.pkl"
        self.catg_features_file = "user_purchase_catg_unit_features_hash.pkl"
        self.catg_labels_file = "category_labels.pkl"
        self.catg_emb_file = "catg_emb_hash.pkl"
        self.meta_audience_file = "meta_audience.pkl"
        self.data_path = self.base_dir + retailer_id
        os.makedirs(self.data_path, exist_ok=True)
        self.aud_data_path = "audience_targeting_v1/" + retailer_id
        os.makedirs(self.aud_data_path, exist_ok=True)
        self.val_metrics_file = "val_metrics.csv"
        self.val_metrics_heuristic_file = "val_metrics_heuristic.csv"
        self.aud_metrics_path = "audience_metrics_v1/" + retailer_id
        os.makedirs(self.aud_metrics_path, exist_ok=True)
        self.read_write_blob = ReadAndWriteFromAzureBlob()
        self.retailer_id = retailer_id
        self.today_date = today_date
        self.env = env

        self.catg_emb_hash = self.download_catg_embeddings() 

    def generate_labels(self, target_category, catg_users_hash):
        pos_catg_users = catg_users_hash.get(target_category, set())
        all_users = list(catg_users_hash.values())
        neg_catg_users = set().union(*all_users) - pos_catg_users
        return pos_catg_users

    def calculate_metrics(self, y_actual, y_pred, y_prob, data_type, catg):
        if data_type == "future":
                return []
        p_obj, r_obj, f_obj, s_obj = precision_recall_fscore_support(y_actual, y_pred, labels=[1])
        p_score, r_score, f1_score, support = p_obj[0], r_obj[0], f_obj[0], s_obj[0]
        # Data to plot precision - recall curve
        try:
            precision, recall, thresholds = precision_recall_curve(y_actual.to_numpy(), y_prob)
        except:
            precision, recall, thresholds = "undefined", "undefined", "undefined"
        # Use AUC function to calculate the area under the curve of precision recall curve
        try:
            pr_auc = auc(recall, precision)
        except:
            pr_auc = "undefined"
        try:
            roc_auc = roc_auc_score(y_actual.to_numpy(), y_prob)
        except:
            roc_auc = "undefined"
        return [catg, p_score, r_score, f1_score, support, len(y_actual), pr_auc, roc_auc]

    def infer_category_chunk(self, catg_chunk, catg_users_hash, con_user_embs, data_type, out_q):
        metrics = []
        blob_names = []
        catgs = []
        for catg, catg_emb in catg_chunk:
            if catg_users_hash:
                pos_users = self.generate_labels(catg, catg_users_hash)
            else:
                pos_users = set()
            y_acts = []
            y_preds = []
            y_probs = []
            users = []
            for k, v in con_user_embs.items():
                y_act = 0
                if k in pos_users:
                    y_act = 1
                v = np.array(v)
                v = v / np.linalg.norm(v)
                score = (1 + np.dot(v,catg_emb[0])/(norm(v)*norm(catg_emb[0])))/2
                y_pred = 0
                if score >= 0.75:
                    y_pred = 1
                y_acts.append(y_act)
                y_preds.append(y_pred)
                y_probs.append(score)
                users.append(k)

            y_acts = pd.Series(y_acts)
            y_preds = np.array(y_preds)
            y_probs = np.array(y_probs)

            metric = []
            if data_type == "val":
                metric = self.calculate_metrics(y_acts, y_preds, y_probs, data_type, catg)
            metrics.append(metric)

            blob_name = self.aud_data_path + "/" + catg + "_" + "audience.pkl"
            catgs.append(catg)
            blob_names.append(blob_name)
            if data_type == "future":
                catg_audience_dict = dict(zip(users, y_probs))
                for _env in ("dev", "qa", "uat", "prod"):
                    Config.switch_env(_env)
                    self.read_write_blob.write_to_blob(Config.AzureConfig.RECOMMENDATION_OUT_STRING, Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME, blob_name, catg_audience_dict, True)

        out_q.put((catgs, blob_names, metrics))

    def infer_using_heuristic(self, data_type, val_users, true_catg_users_hash):
        metrics = []
        pred_catg_users_hash = self.download_labels("train")
        for catg, pos_users in true_catg_users_hash.items():
            pred_pos_users = pred_catg_users_hash.get(catg, set())
            y_acts = []
            y_preds = []
            for val_user in val_users:
                y_act = 0
                y_pred = 0
                if val_user in pos_users:
                    y_act = 1
                if val_user in pred_pos_users:
                    y_pred = 1
                y_acts.append(y_act)
                y_preds.append(y_pred)
            y_acts = pd.Series(y_acts)
            y_preds = np.array(y_preds)
            metric = self.calculate_metrics(y_acts, y_preds, [], data_type, catg)
            metrics.append(metric)

        metrics_df = pd.DataFrame(metrics, columns = ['Broad_Category', 'Precision', 'Recall', 'F1', 'Support', 'Total', 'PR-AUC', 'ROC-AUC'])
        metrics_df = metrics_df.sort_values('Support', ascending=False)
        blob_name = self.aud_metrics_path + "/" + self.today_date + "_" + self.val_metrics_heuristic_file
        for _env in ("dev", "qa", "uat", "prod"):
            Config.switch_env(_env)
            self.read_write_blob.write_to_blob(Config.AzureConfig.RECOMMENDATION_OUT_STRING, Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME, blob_name, metrics_df)
        fp = open(blob_name, "w")
        metrics_df.to_csv(fp)
        fp.close()

    def infer_using_avg_sku_emb_as_user_emb(self, data_type):
        if data_type == "val":
            con_user_embs_train = self.download_features("train")
            # this logic is to get same val data to compare emb based and DL model
            users = list(con_user_embs_train.keys())
            users.sort()
            random.Random(8).shuffle(users)
            # get validation set users
            val_users = users[int(len(users)*0.8):]
            con_user_embs = {uid:con_user_embs_train.get(uid) for uid in val_users}
            catg_users_hash = self.download_labels("test")
        else:
            con_user_embs = self.download_features("test")
            catg_users_hash = {}
        #num_cores = max(multiprocessing.cpu_count() - 4, 1)
        num_cores = min(multiprocessing.cpu_count() - 4, 10)
        chunk_size = math.ceil((len(self.catg_emb_hash) / num_cores))
        catg_list = list(self.catg_emb_hash.items())
        i = 0
        meta_audience = []
        full_metrics = []
        process_list = []
        out_q = Queue()
        while i < num_cores:
            st = i * chunk_size
            ed = (i+1) * chunk_size
            catg_chunk = catg_list[st:ed]
            p = Process(target=self.infer_category_chunk, args=(catg_chunk, catg_users_hash, con_user_embs, data_type, out_q))
            p.start()
            process_list.append(p)
            i += 1

        for i in range(num_cores):
            catgs, blob_names, metrics = out_q.get()
            for catg, blob_name in zip(catgs, blob_names):
                meta_audience.append((catg, blob_name))
            for metric in metrics:
                full_metrics.append(metric)

        for p in process_list:
            p.join()

        out_str = "processed all categories of retailer %s for %s audience targeting\n" %(retailer_id, data_type)
        print(out_str)

        # write meta audience file if data type is future
        if data_type == "future":
            audience = dict(meta_audience)
            blob_name = self.aud_data_path + "/" + self.meta_audience_file
            for _env in ("dev", "qa", "uat", "prod"):
                Config.switch_env(_env)
                self.read_write_blob.write_to_blob(Config.AzureConfig.RECOMMENDATION_OUT_STRING, Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME, blob_name, audience, True)
        #write validation metrics if data type is val
        if data_type == "val":
            metrics_df = pd.DataFrame(full_metrics, columns = ['Broad_Category', 'Precision', 'Recall', 'F1', 'Support', 'Total', 'PR-AUC', 'ROC-AUC'])
            metrics_df = metrics_df.sort_values('Support', ascending=False)
            blob_name = self.aud_metrics_path + "/" + self.today_date + "_" + self.val_metrics_file
            for _env in ("dev", "qa", "uat", "prod"):
                Config.switch_env(_env)
                self.read_write_blob.write_to_blob(Config.AzureConfig.RECOMMENDATION_OUT_STRING, Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME, blob_name, metrics_df)
            return val_users, catg_users_hash
        return

    def download_catg_embeddings(self):
        Config.switch_env(self.env)
        blob_name = self.base_dir + self.retailer_id + "/" + self.today_date + "_" + self.catg_emb_file
        catg_emb_hash = self.read_write_blob.read_data_by_stream(
                    Config.AzureConfig.RECOMMENDATION_OUT_STRING,
                    Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME,
                    blob_name, True)
        return catg_emb_hash 

    def download_features(self, data_type):
        Config.switch_env(self.env)
        blob_name = self.base_dir + self.retailer_id + "/" + self.today_date + "_" + data_type + "_" + self.con_features_file
        con_user_embs = self.read_write_blob.read_data_by_stream(
                Config.AzureConfig.RECOMMENDATION_OUT_STRING,   
                Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME,   
                blob_name, True)

        #blob_name = self.base_dir + self.retailer_id + "/" + self.today_date + "_" + data_type + "_" + self.catg_features_file
        #user_catg_features = self.read_write_blob.read_data_by_stream(
                     #Config.AzureConfig.RECOMMENDATION_OUT_STRING,   
                     #Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME,   
                     #blob_name, True)

        return con_user_embs

    def download_labels(self, data_type):
        Config.switch_env(self.env)
        blob_name = self.base_dir + self.retailer_id + "/" + self.today_date + "_" + data_type + "_" + self.catg_labels_file
        catg_users_hash_test = self.read_write_blob.read_data_by_stream(
                    Config.AzureConfig.RECOMMENDATION_OUT_STRING,
                    Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME,
                    blob_name, True)
        return catg_users_hash_test 

if __name__=="__main__":
    parser = argparse.ArgumentParser(description="Batch job for audience targeting at category level")
    parser.add_argument('-env', '--environment', type=str,
                        default='prod',
                        help='List of environments to run products purchase to user map')
    parser.add_argument('-i', '--id', help='retialer id', required=True)

    input_args = vars(parser.parse_args())
    retailer_id = str(input_args['id'])
    env = input_args['environment']
    today_date = datetime.strftime(datetime.now(), "%Y-%m-%d")
    print(today_date)

    train_obj = TrainAudienceV1(today_date, env, retailer_id)


    print("*** Val Data Inference using avg. sku emb as user emb ***")
    val_users, catg_user_hash_test = train_obj.infer_using_avg_sku_emb_as_user_emb("val")


    print("*** Val Data Inference using heuristic ***")
    train_obj.infer_using_heuristic("val", val_users, catg_user_hash_test)


    print("*** Future Data Inference using avg. sku emb as user emb ***")
    train_obj.infer_using_avg_sku_emb_as_user_emb("future")
