import os

def get_training_config(model_name, train_path_tfr_files, val_path_tfr_files, dump_dir, retailer_obj):

    config = {
        "model":{
            "name":model_name,
            "type":"audience"
        },

        "retailer":retailer_obj,

        "training": {
            "train_path_tfr_files":train_path_tfr_files,
            "val_path_tfr_files":val_path_tfr_files,
            "dump_directory" : dump_dir,
            "params":{
                "lr": 0.0004,
                "batch_size": 64,
                "epochs": 50
            }
        }
    }

    return config
