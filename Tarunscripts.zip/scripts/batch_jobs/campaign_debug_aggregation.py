import argparse
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from azure.storage.blob import ContainerClient
from pyspark.sql.types import *
from datetime import datetime, timedelta
import json
from pyspark.sql import functions as f
from config import Config
from util.meta_data_extractor import MetaDataExtractor


class CampaignDebugger:
    def __init__(self, time_delta, environment):
        Config.switch_env(environment)
        print(
            "Running for environment - {}".format(
                Config.AzureConfig.ENV)
        )
        self.current_run = datetime.strftime(
            datetime.now() - timedelta(time_delta),
            "year=%Y/month=%m/day=%d/"
        )

    @staticmethod
    def __get_retailers():
        retailers = MetaDataExtractor.get_retailer_list_for_job(
            "debug_campaigns"
        )
        retailers = [str(i) for i in retailers]
        return retailers

    @staticmethod
    def __get_container_client(connection_string, container_name):
        return ContainerClient.from_connection_string(
            connection_string, container_name
        )

    def __list_rr_blobs(self):
        # Lists the latest RR log blobs
        input_client = self.__get_container_client(
            Config.AzureConfig.ENGG_ACCOUNT_CONNECTION_STRING,
            Config.AzureConfig.RR_CONTAINER
        )
        latest_blobs = []
        i = 0
        while True:
            master_list = list(
                input_client.list_blobs(
                    name_starts_with=Config.AzureConfig.RR_PATTERN.format(
                        i, self.current_run
                    )
                )
            )
            i += 1
            if master_list:
                latest_blobs.extend(master_list)
            else:
                break
        latest_rr = [blob.name for blob in latest_blobs if blob.size > 508]
        latest_rr = [Config.AzureConfig.RR_PATH + blob for blob in latest_rr]
        print("Got the latest list of RR logs")
        return latest_rr

    @staticmethod
    def __get_data(json_string):
        data_map = {}
        all_ads = []
        campaign_details = {}
        retailer_id = []
        data = json.loads(json_string)['event_payload']
        data_map['request_id'] = data['request_id']
        data_map['targeting_type'] = data['ad_request']['request_payload'][
            'filter']['targeting_type']
        data_map['targeting_value'] = data['ad_request']['request_payload'][
            'filter']['targeting_value']
        data_map['placement_id'] = data['ad_request']['request_payload'][
            'filter']['placement_id']
        data_map['platform_type'] = data['ad_request']['request_payload'][
            'user']['platform']['device_type']
        data_map['timestamp'] = data['ad_request']['request_time']

        all_ads.extend(data['meta_data']['loosing_ads'])
        all_ads.extend(data['meta_data']['winning_ads'])

        for ads in all_ads:
            retailer_id.append(ads['campaign_details']['retailer_id'])
            campaign_details[ads['campaign_details']['campaign_id']] = {
                'ecpm': ads['pricing_data']['eCPM'],
                'campaign_mode': ads['campaign_details']['campaign_mode']}
        if retailer_id:
            data_map['retailer_id'] = retailer_id[0]
        else:
            data_map['retailer_id'] = 0
        data_map['campaign_details'] = campaign_details
        return json.dumps(data_map)

    @staticmethod
    def __get_campaign_details(contentions, winner_id):
        contentions = json.loads(contentions)
        return json.dumps({winner_id: contentions[winner_id]})

    def read_rr_avro(self, spark):
        # Reads the latest RR log files
        spark.conf.set(
            "fs.azure.account.key." +
            Config.AzureConfig.ENGG_ACCOUNT_NAME +
            ".dfs.core.windows.net",
            Config.AzureConfig.ENGG_ACCOUNT_KEY)

        # Listing the latest RR logs blobs
        latest_rr = self.__list_rr_blobs()

        # Reading the latest RR log blobs
        rr_logs = spark.read.option(
            "basepath",
            Config.AzureConfig.RR_PATH +
            Config.AzureConfig.RR_PATTERN.split('/partition')[0]
        ).format("avro").load(latest_rr)

        # Creating UDF to decode bytes object
        decode_elements = udf(lambda a: a.decode('utf-8'))
        rr_logs = rr_logs.select(
            decode_elements(rr_logs['Body']).alias("Json")
        )

        # Creating UDF to parse the JSON string and get data
        my_parse_string_udf = spark.udf.register(
            "my_parse_string", self.__get_data
        )
        rr_logs = rr_logs.select(my_parse_string_udf(col("Json")))

        # Selecting only columns that are required and renaming them
        rr_logs = rr_logs.select(
            'my_parse_string(Json)', f.json_tuple(
                'my_parse_string(Json)', 'campaign_details', 'platform_type',
                'timestamp', 'targeting_value', 'targeting_type',
                'retailer_id', 'request_id', 'placement_id'
            ).alias(
                'campaign_details', 'platform_type', 'timestamp',
                'targeting_value', 'targeting_type', 'retailer_id',
                'request_id', 'placement_id'
            )
        )
        print("Completed parsing the RR Logs")
        return rr_logs

    def __read_ad_rendered(self, retailer_id, spark):
        # Reads the ad render data
        spark.conf.set(
            "fs.azure.account.key." +
            Config.AzureConfig.ENGG_ACCOUNT_NAME +
            ".dfs.core.windows.net",
            Config.AzureConfig.ENGG_ACCOUNT_KEY
        )

        # Getting the latest AD Render data
        input_client = ContainerClient.from_connection_string(
            conn_str=Config.AzureConfig.ENGG_ACCOUNT_CONNECTION_STRING,
            container_name=Config.AzureConfig.AD_RENDER_CONTAINER
        )
        pattern = Config.AzureConfig.AD_RENDER_PATTERN.format(
            retailer_id, self.current_run
        )

        master_list = list(
            input_client.list_blobs(
                name_starts_with=pattern
            )
        )
        latest_render = [blob.name for blob in master_list if blob.size > 508
                         and 'eventType=1' in blob.name]
        latest_render = [Config.AzureConfig.AD_RENDER_PATH + blob for blob
                         in latest_render]
        print(
            "Got the latest ad render blobs for retailer - {}, "
            "now parsing the data".format(retailer_id)
        )

        # Reading & parsing the Ad Render data
        ad_render = spark.read.option(
            "basepath",
            Config.AzureConfig.AD_RENDER_PATH +
            Config.AzureConfig.AD_RENDER_PATTERN.split('/retailerId')[0]
        ).format("parquet").load(latest_render)
        print(
            "Completed parsing the available ad render data for the "
            "retailer - {}".format(retailer_id)
        )
        return ad_render

    def __combine_data(self, retailer, rr_log, ad_render):
        print(
            "Combining rr log and ad render data for retailer - {}".format(
                retailer)
        )

        # Combining rr logs data and ad render data
        combined_df = rr_log.join(
            ad_render,
            (rr_log.request_id == ad_render.requestId) &
            (rr_log.retailer_id == ad_render.retailerId),
            "inner"
        )

        # Selecting only needed columns
        combined_df = combined_df.select(
            'campaign_details', 'platform_type', 'timestamp',
            'targeting_value', 'targeting_type', 'retailer_id', 'request_id',
            'placement_id', 'campaignId'
        )

        # Creating udf to get winner campaign's details
        get_campaign_detail_udf = udf(
            self.__get_campaign_details, StringType()
        )

        # Getting winner campaign details
        combined_df = combined_df.withColumn(
            "winner_details", get_campaign_detail_udf(
                combined_df.campaign_details, combined_df.campaignId
            )
        )

        # Adding Year, Month and Day for partitioning
        combined_df = combined_df.withColumn(
            'year', lit(str(
                self.current_run.split('/')[0].split('=')[1]
            ))
        )
        combined_df = combined_df.withColumn(
            'month', lit(str(
                self.current_run.split('/')[1].split('=')[1]
            ))
        )
        combined_df = combined_df.withColumn(
            'day', lit(str(
                self.current_run.split('/')[2].split('=')[1]
                           ))
        )

        # Renaming columns
        columns = ['contention_details', 'platform_type', 'timestamp',
                   'targeting_value', 'targeting_type', 'retailer_id',
                   'request_id', 'placement_id', 'winning_campaign_id',
                   'winning_campaign_details', 'year', 'month', 'day']
        combined_df = combined_df.toDF(*columns)
        return combined_df

    @staticmethod
    def __get_campaigns(json_string):
        return list(json.loads(json_string).keys())

    def __create_campaign_data(self, combined_df):
        # Creating UDFs for aggregating campaign ids & winner details
        get_campaigns_udf = udf(self.__get_campaigns, ArrayType(StringType()))
        get_campaign_detail_udf = udf(
            self.__get_campaign_details, StringType()
        )

        # Getting campaigns list out of all the contending campaigns
        combined_df = combined_df.withColumn(
            "contending_campaigns_list", get_campaigns_udf(
                combined_df['contention_details']
            )
        )

        # Exploding the campaigns to individual rows
        combined_df = combined_df.select(
            combined_df.contention_details, combined_df.platform_type,
            combined_df.timestamp, combined_df.targeting_value,
            combined_df.targeting_type, combined_df.retailer_id,
            combined_df.request_id, combined_df.placement_id,
            combined_df.winning_campaign_id,
            combined_df.winning_campaign_details, combined_df.year,
            combined_df.month, combined_df.day,
            explode(combined_df['contending_campaigns_list'])
        )

        # Getting contending campaign's details
        combined_df = combined_df.withColumn(
            "contending_campaign_details", get_campaign_detail_udf(
                combined_df['contention_details'], combined_df['col'])
        )

        # Filtering only those columns that are required
        combined_df = combined_df.select(
            combined_df.platform_type, combined_df.timestamp,
            combined_df.targeting_value, combined_df.targeting_type,
            combined_df.retailer_id, combined_df.request_id,
            combined_df.placement_id, combined_df.winning_campaign_id,
            combined_df.winning_campaign_details, combined_df.year,
            combined_df.month, combined_df.day, combined_df.col,
            combined_df.contending_campaign_details
        )

        # Renaming columns
        columns = ['platform_type', 'timestamp', 'targeting_value',
                   'targeting_type', 'retailer_id', 'request_id',
                   'placement_id', 'winning_campaign_id',
                   'winning_campaign_details', 'year', 'month', 'day',
                   'contending_campaign_id', 'contending_campaign_details']
        combined_df = combined_df.toDF(*columns)
        return combined_df

    @staticmethod
    def __write_parquet(
            df, spark, output_location, retailer, consolidate=False
    ):
        # Method that writes the aggregated data to AI containers
        spark.conf.set(
            "fs.azure.account.key." +
            Config.AzureConfig.ACCOUNT_NAME +
            ".dfs.core.windows.net",
            Config.AzureConfig.ACCOUNT_KEY
        )

        if consolidate:
            df.coalesce(1).write.option("header", True).partitionBy(
                "retailer_id", "year", "month", "day"
            ).mode("overwrite").parquet(output_location)
            print(
                "Successfully written consolidated data to AI containers "
                "for retailer - {}".format(
                    retailer
                )
            )
        else:
            df.write.option("header", True).partitionBy(
                "retailer_id", "year", "month", "day"
            ).mode("overwrite").parquet(output_location)
            print(
                "Successfully written data to AI containers {}".format(
                    retailer
                )
            )

    def main(self):
        spark = SparkSession.builder.enableHiveSupport().getOrCreate()
        spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
        spark.conf.set("spark.sql.execution.arrow.pyspark.enabled", "true")

        # Get list of retailers to aggregate for campaign debugging
        retailers = self.__get_retailers()

        if retailers:
            # Get RR Logs
            rr_logs = self.read_rr_avro(spark)
            for retailer in retailers:
                try:
                    print("Processing data for retailer - {}".format(retailer))

                    # Get Ad render data for the retailer
                    retailer_data = self.__read_ad_rendered(retailer, spark)

                    # Filter RR logs for the retailer
                    rr_log_filtered = rr_logs.filter(
                        rr_logs.retailer_id == retailer
                        )

                    # Merging RR logs with Ad render data
                    requests_df = self.__combine_data(
                        retailer, rr_log_filtered, retailer_data
                    )

                    # Writing to AI container
                    self.__write_parquet(
                        requests_df,
                        spark,
                        Config.AzureConfig.AI_REQUEST_OUTPUT_PATH,
                        retailer
                    )

                    # Creating campaign level aggregation
                    campaign_df = self.__create_campaign_data(requests_df)

                    # Writing aggregated campaign level data to AI container
                    self.__write_parquet(
                        campaign_df,
                        spark,
                        Config.AzureConfig.AI_CAMPAIGN_OUTPUT_PATH,
                        retailer
                    )

                    # Writing to AI containers as single file
                    self.__write_parquet(
                        campaign_df,
                        spark,
                        Config.AzureConfig.AI_CAMPAIGN_CONSOLIDATED_PATH,
                        retailer,
                        consolidate=True
                    )
                except Exception as e:
                    print(e)
                    continue

        else:
            print("No retailers available for debugging, closing the app")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Auto suggestions master job')
    parser.add_argument('-d', '--day_count', type=int, default=1,
                        help='Number of days to look backward from current '
                             'date for suggestions')
    parser.add_argument('-env', '--environment', type=str,
                        default='prod',
                        help='List of environments to run debug aggregation')
    input_args = vars(parser.parse_args())
    for env in input_args['environment'].strip().split(','):
        try:
            cd = CampaignDebugger(
                time_delta=input_args['day_count'],
                environment=env
            )
            cd.main()
        except Exception as exception:
            print(exception)
            continue
