from util.azure_batch_logger import BatchLog
import os
from config import Config
from context.context import Context
from datetime import datetime, timedelta
from azure.storage.blob import ContainerClient
from multiprocessing import Process, Queue
import multiprocessing
from fastavro import reader
import pandas as pd
from util.meta_data_extractor import MetaDataExtractor
from util.read_write_data_azure_blob import ReadAndWriteFromAzureBlob
import argparse
import swifter
import numpy as np
import faiss

class OrganicPurchaseFeatures:
    def __init__(self, time_delta, environment, retailer_id):
        Config.switch_env(environment)
        print(
            "Running for environment - {}".format(
                Config.AzureConfig.ENV)
        )
        self.data_path = "audience_features/%s" %(retailer_id)
        os.makedirs(self.data_path, exist_ok=True)
        self.input_client = ContainerClient.from_connection_string(
            conn_str=Config.AzureConfig.ORGANIC_CONNECTION,
            container_name=Config.AzureConfig.ORGANIC_CONTAINER
        )
        self.current_date = datetime.strftime(
            datetime.now() - timedelta(time_delta), "%Y-%m-%d"
        )
        self.read_write_blob = ReadAndWriteFromAzureBlob()

    @staticmethod
    def _get_retailer_name(retailer_ids):
        retailer_ids = [int(retailer_id) for retailer_id in retailer_ids]
        retailer_names = []
        all_meta = MetaDataExtractor.get_retailer_matadata()
        for retailer in all_meta:
            if retailer['_id'] in retailer_ids:
                retailer_names.append(retailer['retailer_name'])
        return retailer_names

    @staticmethod
    def generate_user_features(df, data_type, prod_emb_hash, prod_catg_hash, catg_ind_hash, prod_catalog_catg_hash, catalog_catg_index_hash, retailer_id, today_date, env):
        df = df[df['user_id']!='']
        df['product_list'] = df['product_list'].apply(lambda x: [item for sublist in x for item in eval(str(sublist))])
        products_purchased_list  = df['product_list'].tolist()
        products_purchased = set([item for sublist in products_purchased_list for item in sublist])
        products_in_catalog = set(prod_emb_hash.keys())
        print(len(products_purchased.intersection(products_in_catalog)))
        df['quantity_list'] = df['quantity_list'].apply(lambda x: [item for sublist in x for item in eval(str(sublist))])
        con_user_embs = {}
        user_catg_features = {}
        u_list = df['user_id'].values.tolist()
        p_lists = df['product_list'].values.tolist()
        q_lists = df['quantity_list'].values.tolist()
        pq_lists = list(zip(p_lists, q_lists))
        u2p_dict = dict(zip(u_list, pq_lists))
        labels_dict = {}
        catalog_catg_labels_dict = {}
        for k, v in u2p_dict.items():
            emb = [0.0]*1024
            cnt = 0
            catg_features = [0]*(len(catg_ind_hash))
            for prod, qt in zip(v[0], v[1]):
                qt = int(qt)
                con_emb = prod_emb_hash.get(prod)
                catg = prod_catg_hash.get(prod, '')
                catg_ind = catg_ind_hash.get(catg)
                if not catg_ind:
                    continue
                ccatg = prod_catalog_catg_hash.get(prod, '')
                labels_dict.setdefault(catg, set()).add(k)
                catalog_catg_labels_dict.setdefault(ccatg, set()).add(k)
                try:
                    con_emb = con_emb / np.linalg.norm(con_emb)
                    this_emb = [x * qt for x in con_emb.tolist()[0]]
                    cur_emb = [sum(x) for x in zip(emb, this_emb)]
                    emb = cur_emb
                    cnt += qt
                    catg_features[catg_ind] = catg_features[catg_ind] + qt
                except:
                    continue
            if emb != [0.0]*1024:
                final_emb = [x/cnt for x in emb]
                con_user_embs[k] = final_emb
                catg_features = np.array(catg_features)
                unit_catg_features = catg_features / np.linalg.norm(catg_features)
                unit_catg_features_list = unit_catg_features.tolist()
                user_catg_features[k] = unit_catg_features_list

        Config.switch_env(env)
        read_write_blob = ReadAndWriteFromAzureBlob()
        #if data_type == "test":
        blob_name = "audience_features/" + retailer_id + "/" + today_date + "_" + data_type + "_" + "category_labels.pkl"
        read_write_blob.write_to_blob(Config.AzureConfig.RECOMMENDATION_OUT_STRING, Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME, blob_name, labels_dict, True)
        blob_name = "audience_features/" + retailer_id + "/" + today_date + "_" + data_type + "_" + "catalog_category_labels.pkl"
        read_write_blob.write_to_blob(Config.AzureConfig.RECOMMENDATION_OUT_STRING, Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME, blob_name, catalog_catg_labels_dict, True)

        blob_name = "audience_features/" + retailer_id + "/" + today_date + "_" + data_type + "_" + "user_semantic_unit_emb_hash.pkl"
        read_write_blob.write_to_blob(Config.AzureConfig.RECOMMENDATION_OUT_STRING, Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME, blob_name, con_user_embs, True)

        blob_name = "audience_features/" + retailer_id + "/" + today_date + "_" + data_type + "_" + "user_purchase_catg_unit_features_hash.pkl"
        read_write_blob.write_to_blob(Config.AzureConfig.RECOMMENDATION_OUT_STRING, Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME, blob_name, user_catg_features, True)


    @staticmethod
    def get_product_embeddings_from_catalog(retailer_id, retailer_name, env):
        full_file_name = "full_data_" + retailer_name + ".pkl"
        data_path =  "audience_features/%s/" %(retailer_id)
        os.makedirs(data_path, exist_ok=True)
        Context.download_blob(full_file_name, data_path)
        df = pd.read_pickle(data_path + full_file_name)
        category_embeddings = {}
        for category, embedding in df.groupby('Broad_Category')['embedding'].apply(np.mean).items():
            faiss.normalize_L2(embedding)
            category_embeddings[category] = embedding
        prod_emb_hash = dict(zip(df['sku'].values.tolist(), df['embedding'].values.tolist()))
        prod_catg_hash = dict(zip(df['sku'].values.tolist(), df['Broad_Category'].values.tolist()))
        categories = list(set(df['Broad_Category'].values.tolist()))
        catg_index_hash = {catg:ind for ind, catg in enumerate(categories)}
        blob_name = "audience_features/" + retailer_id + "/" + today_date + "_" + "catg_emb_hash.pkl"
        Config.switch_env(env)
        read_write_blob = ReadAndWriteFromAzureBlob()
        read_write_blob.write_to_blob(Config.AzureConfig.RECOMMENDATION_OUT_STRING, Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME, blob_name, category_embeddings, True)
        blob_name = "audience_features/" + retailer_id + "/" + today_date + "_" + "catg_index_hash.pkl"
        read_write_blob.write_to_blob(Config.AzureConfig.RECOMMENDATION_OUT_STRING, Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME, blob_name, catg_index_hash, True)
        prod_catalog_catg_hash = dict(zip(df['sku'].values.tolist(), df['category'].values.tolist()))
        catalog_categories = list(set(df['category'].values.tolist()))
        catalog_catg_index_hash = {catg:ind for ind, catg in enumerate(catalog_categories)}
        blob_name = "audience_features/" + retailer_id + "/" + today_date + "_" + "catalog_catg_index_hash.pkl"
        read_write_blob.write_to_blob(Config.AzureConfig.RECOMMENDATION_OUT_STRING, Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME, blob_name, catalog_catg_index_hash, True)
        return prod_emb_hash, prod_catg_hash, catg_index_hash, prod_catalog_catg_hash, catalog_catg_index_hash


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Batch job that maps organic products purchase to users"
    )
    parser.add_argument('-m', '--month_count', type=int, default=2,
                        help='Number of months to look backward from current '
                             'date')
    parser.add_argument('-env', '--environment', type=str,
                        default='prod',
                        help='List of environments to run products purchase to user map')
    parser.add_argument('-i', '--id', help='retialer id', required=True)
    input_args = vars(parser.parse_args())
    today_date = datetime.strftime(datetime.now(), "%Y-%m-%d")
    env = input_args['environment']
    retailer_ids = [input_args['id']]
    retailer_names = OrganicPurchaseFeatures._get_retailer_name(retailer_ids)
    for retailer_id, retailer_name in zip(retailer_ids, retailer_names):
        print("*****processing retailer %s*****" %retailer_name)
        prod_emb_hash, prod_catg_hash, catg_ind_hash, prod_catalog_catg_hash, catalog_catg_index_hash = OrganicPurchaseFeatures.get_product_embeddings_from_catalog(retailer_id, retailer_name, env)
        for month in range(input_args['month_count']):
            i = 1 + 30*(month)
            ed = 30 * (1+month)
            full_data = pd.DataFrame()
            while i <= ed:
                print("processing day %s data" %i)
                try:
                    keyword_mapper = OrganicPurchaseFeatures(
                        time_delta=i,
                        environment=env,
                        retailer_id=retailer_id
                    )
                    blob_file = "organic_purchase_features/%s/%s.csv" %(retailer_id, keyword_mapper.current_date)
                    data = keyword_mapper.read_write_blob.read_data_by_stream(
                            Config.AzureConfig.RECOMMENDATION_OUT_STRING,
                            Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME,
                            blob_file)
                    df_list = [full_data, data]
                    full_data = pd.concat(df_list, ignore_index=True)
                    i += 1
                except Exception as exception:
                    print(exception)
                    print("Exception in processing day %s data" %i)
                    i += 1
                    continue

            final_data = full_data.groupby('user_id')[['product_list','quantity_list']].agg(list).reset_index()
            if month == 0:
                OrganicPurchaseFeatures.generate_user_features(final_data, "train", prod_emb_hash, prod_catg_hash, catg_ind_hash, prod_catalog_catg_hash, catalog_catg_index_hash, retailer_id, today_date, env)
            if month == 1:
                OrganicPurchaseFeatures.generate_user_features(final_data, "test", prod_emb_hash, prod_catg_hash, catg_ind_hash, prod_catalog_catg_hash, catalog_catg_index_hash, retailer_id, today_date, env)
