import argparse
import numpy as np
import pickle
import pandas as pd
import random
import os
from util.read_write_data_azure_blob import ReadAndWriteFromAzureBlob
from numpy.linalg import norm
from datetime import datetime, timedelta
from config import Config
import math
import tensorflow as tf
import logging

os.environ['CUDA_DEVICE_ORDER'] = "PCI_BUS_ID"
logging.disable(logging.WARNING)
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3" 
import tensorflow as tf
print("GPU detected:", tf.test.is_gpu_available())

class PrepareData:
    def __init__(self, today_date, env, retailer_id, feature_type):
        Config.switch_env(env)
        print(
            "Running for environment - {}".format(
                Config.AzureConfig.ENV)
        )
        self.data_path = "audience_features/%s" %(retailer_id)
        os.makedirs(self.data_path, exist_ok=True)
        self.con_features_file = "user_semantic_unit_emb_hash.pkl"
        self.catg_features_file = "user_purchase_catg_unit_features_hash.pkl"
        self.catg_emb_file = "catg_emb_hash.pkl"
        self.catg_labels_file = "category_labels.pkl"
        self.catg_index_file = "catg_index_hash.pkl"
        self.catalog_catg_labels_file = "catalog_category_labels.pkl"
        self.catalog_catg_index_file = "catalog_catg_index_hash.pkl"
        self.read_write_blob = ReadAndWriteFromAzureBlob()
        self.retailer_id = retailer_id
        self.today_date = today_date
        self.env = env
        self.feature_type = feature_type
        self.catg_labels, self.num_catgs = self.download_and_generate_label_vectors("bcatg", "test")
        self.catalog_catg_labels, self.num_catalog_catgs = self.download_and_generate_label_vectors("catg", "test")
        self.train_val_features = self.download_features("train")
        self.users = list(self.train_val_features.keys())
        self.users.sort()
        random.Random(8).shuffle(self.users)
        self.train_users = self.users[0:int(len(self.users)*0.8)]
        self.train_features = {uid:self.train_val_features.get(uid) for uid in self.train_users}
        self.val_users = self.users[int(len(self.users)*0.8):]
        self.val_features = {uid:self.train_val_features.get(uid) for uid in self.val_users}
        self.test_features = self.download_features("test")
        #self.catg_emb_hash = self.download_catg_embeddings()


    def decode_fn(self, record_bytes):
        a =  tf.io.parse_single_example(
         record_bytes,
         {"input_uid": tf.io.FixedLenFeature([], dtype=tf.string),
            "input_num_bcatg": tf.io.FixedLenFeature([], dtype=tf.string),
            "input_num_catg": tf.io.FixedLenFeature([], dtype=tf.string),
            "input_user": tf.io.FixedLenFeature([], dtype=tf.string),
            "input_bin_user": tf.io.FixedLenFeature([], dtype=tf.string),
            "output_bcatg":tf.io.FixedLenFeature([], dtype=tf.string),
            "output_catg":tf.io.FixedLenFeature([], dtype=tf.string)} )
        return {"input_user":tf.reshape(tf.io.decode_raw(a['input_user'],tf.float64),(self.num_catgs,)), "input_bin_user":tf.reshape(tf.io.decode_raw(a['input_bin_user'],tf.float64),(self.num_catgs,)), "input_uid": a['input_uid'], "input_num_catg": a["input_num_catg"], "input_num_bcatg": a["input_num_bcatg"]}, {'output_catg': tf.reshape(tf.io.decode_raw(a['output_catg'],tf.int64),(self.num_catalog_catgs,)), 'output_bcatg': tf.reshape(tf.io.decode_raw(a['output_bcatg'],tf.int64),(self.num_catgs,))}

    def _bytes_feature(self, value):
        return tf.train.Feature(bytes_list=tf.train.BytesList(value=[value]))


    def prepare_train_and_test_data(self, data_type):
        if data_type == "train":
            features_dict = self.train_features
        elif data_type == "val":
            features_dict = self.val_features
        else:
            features_dict = self.test_features
        out_dir = self.data_path + "/"
        file_name = "aud_model_" + data_type + "_data.tfrecords"
        out_file = out_dir + file_name
        cnt = 0
        with tf.io.TFRecordWriter(out_file) as file_writer:
            for uid, _feature in features_dict.items():
                if cnt%1000 == 0:
                    print("processed %s records in %s dataset" %(cnt,data_type))
                if data_type == "test":
                    out_bcatg = np.array([-1] * self.num_catgs)
                    out_catg = np.array([-1] * self.num_catalog_catgs)
                elif data_type == "val":
                    out_bcatg = self.catg_labels.get(uid, np.array([0] * self.num_catgs))
                    out_catg = self.catalog_catg_labels.get(uid, np.array([0] * self.num_catalog_catgs))
                else:
                    out_bcatg = self.catg_labels.get(uid, np.array([]))
                    out_catg = self.catalog_catg_labels.get(uid, np.array([]))
                    if out_bcatg.size == 0:
                        continue
                bin_feature = []
                for feat in _feature:
                    if feat > 0.0:
                        bin_feature.append(1.0)
                    else:
                        bin_feature.append(0.0)
                _feature = np.array(_feature)
                bin_feature = np.array(bin_feature)
                try:
                    record_bytes = tf.train.Example(features=tf.train.Features(feature={"input_user": self._bytes_feature(_feature.tostring()), "input_bin_user": self._bytes_feature(bin_feature.tostring()), "output_catg": self._bytes_feature(out_catg.tostring()), "output_bcatg": self._bytes_feature(out_bcatg.tostring()), "input_uid": self._bytes_feature(str.encode(uid)), "input_num_catg": self._bytes_feature(str.encode(str(self.num_catalog_catgs))), "input_num_bcatg": self._bytes_feature(str.encode(str(self.num_catgs)))})).SerializeToString()
                    file_writer.write(record_bytes)
                    cnt += 1
                    #ret = self.decode_fn(record_bytes)
                except:
                    continue
        print("number of records in %s set:%s" %(data_type, cnt))

    def download_catg_embeddings(self):
        Config.switch_env(self.env)
        blob_name = self.data_path + "/" + self.today_date + "_" + self.catg_emb_file
        catg_emb_hash = self.read_write_blob.read_data_by_stream(
                    Config.AzureConfig.RECOMMENDATION_OUT_STRING,
                    Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME,
                    blob_name, True)
        return catg_emb_hash 

    def download_features(self, data_type):
        Config.switch_env(self.env)
        # if user is represented as avg. emb of purchased products 
        if self.feature_type == "emb":
            blob_name = self.data_path + "/" + self.today_date + "_" + data_type + "_" + self.con_features_file
            user_catg_features = self.read_write_blob.read_data_by_stream(
                    Config.AzureConfig.RECOMMENDATION_OUT_STRING,   
                    Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME,   
                    blob_name, True)
        else:
            blob_name = self.data_path + "/" + self.today_date + "_" + data_type + "_" + self.catg_features_file
            user_catg_features = self.read_write_blob.read_data_by_stream(
                         Config.AzureConfig.RECOMMENDATION_OUT_STRING,   
                         Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME,   
                         blob_name, True)

        return user_catg_features

    def download_and_generate_label_vectors(self, category_level, data_type):
        Config.switch_env(self.env)
        if category_level == "bcatg":
            blob_name = self.data_path + "/" + self.today_date + "_" + data_type + "_" + self.catg_labels_file
            catg_users_hash_test = self.read_write_blob.read_data_by_stream(
                        Config.AzureConfig.RECOMMENDATION_OUT_STRING,
                        Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME,
                        blob_name, True)
            blob_name = self.data_path + "/" + self.today_date + "_" + self.catg_index_file
            catg_index_hash = self.read_write_blob.read_data_by_stream(
                        Config.AzureConfig.RECOMMENDATION_OUT_STRING,
                        Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME,
                        blob_name, True)
        else:
            blob_name = self.data_path + "/" + self.today_date + "_" + data_type + "_" + self.catalog_catg_labels_file
            catg_users_hash_test = self.read_write_blob.read_data_by_stream(
                        Config.AzureConfig.RECOMMENDATION_OUT_STRING,
                        Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME,
                        blob_name, True)
            blob_name = self.data_path + "/" + self.today_date + "_" + self.catalog_catg_index_file
            catg_index_hash = self.read_write_blob.read_data_by_stream(
                        Config.AzureConfig.RECOMMENDATION_OUT_STRING,
                        Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME,
                        blob_name, True)

        user_catg_hash = {}
        for ctg, users in catg_users_hash_test.items():
            for user in users:
                user_catg_hash.setdefault(user, set()).add(ctg)

        user_labels = {}
        for user, ctgs in user_catg_hash.items():
            out_catg = np.array([0]*len(catg_index_hash))
            for ctg in ctgs:
                index = catg_index_hash.get(ctg, -1)
                if index == -1 or out_catg[index] == 1:
                    continue
                out_catg[index] = 1
            user_labels[user] = out_catg
                
        return user_labels, len(catg_index_hash)

if __name__=="__main__":
    parser = argparse.ArgumentParser(description="Batch job to prepare data in tfr format for  audience targeting")
    parser.add_argument('-env', '--environment', type=str,
                        default='prod',
                        help='List of environments to run products purchase to user map')
    parser.add_argument('-i', '--id', help='retialer id', required=True)
    # cboc stands for purchase count in bag of categroies, emb stands for representing user in product space using embedding
    parser.add_argument('-ft', '--featuretype', type=str, default='cboc',help='feature type using which model is built')

    input_args = vars(parser.parse_args())
    retailer_id = str(input_args['id'])
    env = input_args['environment']
    today_date = datetime.strftime(datetime.now()-timedelta(0), "%Y-%m-%d")
    print(today_date)
    feature_type = input_args['featuretype']

    data_obj = PrepareData(today_date, env, retailer_id, feature_type)
    data_obj.prepare_train_and_test_data("train")
    data_obj.prepare_train_and_test_data("val")
    data_obj.prepare_train_and_test_data("test")

