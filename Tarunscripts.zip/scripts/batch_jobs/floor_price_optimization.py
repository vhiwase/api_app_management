from config import Config
from util.mongo_util_base import MongoUtilBase
import numpy as np
import argparse
from datetime import datetime, timedelta
from util.meta_data_extractor import MetaDataExtractor
from pyspark.sql import SparkSession
import pyspark.sql.functions as f
from pyspark.sql.types import StringType, MapType, DoubleType
import pandas as pd
from util.read_write_data_azure_blob import ReadAndWriteFromAzureBlob
from nltk.stem import PorterStemmer
from collections import defaultdict
from io import BytesIO
import base64
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import (
    Mail, Attachment, FileContent, FileName, FileType, Disposition
)


class FloorPriceSuggestion:
    def __init__(self, environment, look_back):
        Config.switch_env(environment)
        print(
            "Running Floor Price Suggestion for environment - {}".format(
                Config.AzureConfig.ENV
            )
        )
        self.impression_threshold = 1000
        self.fill_rate_threshold = 0.8
        self.retailers = self.__get_retailers()
        self.mongo_client = MongoUtilBase(
            Config.AzureConfig.COSMOS_URI
        )
        self.start = datetime.strftime(
            datetime.now() - timedelta(1), "%Y-%m-%d"
        )
        self.end = datetime.strftime(
            datetime.now() - timedelta(look_back + 1), "%Y-%m-%d"
        )
        self.read_write_azure = ReadAndWriteFromAzureBlob()
        self.run = datetime.strftime(
            datetime.now() - timedelta(1), "year=%Y/month=%m/day=%d"
        )

    @staticmethod
    def __get_retailers():
        all_retailers = MetaDataExtractor.get_retailer_matadata()
        retailers = [
            str(retailer["_id"]) for retailer in all_retailers if retailer.get(
                "floor_price_recipients"
            )
        ]
        return retailers

    @staticmethod
    def create_spark_session():
        spark = SparkSession.builder.enableHiveSupport().getOrCreate()
        spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
        spark.conf.set("spark.sql.execution.arrow.pyspark.enabled", "true")
        spark.conf.set(
            "fs.azure.account.key." +
            Config.AzureConfig.ENGG_ACCOUNT_NAME +
            ".dfs.core.windows.net",
            Config.AzureConfig.ENGG_ACCOUNT_KEY
        )
        return spark

    def get_aov_data(self, retailer_id):
        aov_dict = defaultdict(list)
        sku_aov = []

        documents = list(
            self.mongo_client.get_all_documents(
                Config.AzureConfig.COSMOS_PRODUCT_META_DB,
                str(retailer_id)
            )
        )

        for doc in documents:
            sku_aov.append(doc["aov"])
            if doc.get("Broad_Category"):
                aov_dict[doc["Broad_Category"]].append(doc["aov"])

        aov_dict["Retailer"] = sku_aov
        return aov_dict

    def get_metadata_for_computation(self, retailer_id):
        metadata = self.mongo_client.get_document(
            Config.AzureConfig.COSMOS_DATABASE_NAME,
            Config.AzureConfig.COSMOS_META_DATA_TABLE,
            int(retailer_id)
        )

        metadata["ctr"] = round(
            (metadata["ctr_lb"] + metadata["ctr_ub"]) / 2, 4
        )
        metadata["pc_cvr"] = round(
            (metadata["pc_cvr_lb"] + metadata["pc_cvr_ub"]) / 2, 4
        )
        metadata["acos"] = metadata.get("retailer_acos", 0.2)
        metadata["cutoff"] = metadata.get("sku_promotion_percent", 20)

        return metadata

    def write_to_azure(self, retailer_id, floor_price_df):
        self.read_write_azure.write_to_blob(
            Config.AzureConfig.RECOMMENDATION_OUT_STRING,
            Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME,
            "retailer_id={}/{}/FloorPriceSuggestion.csv".format(
                retailer_id, self.run
            ),
            floor_price_df
        )

    def process_daily_summary(self, retailer_id, daily_summary):
        target_mapping = {
            "1": "KEYWORD",
            "2": "CATEGORY",
            "3": "PRODUCT"
        }
        get_value = f.udf(
            lambda name: target_mapping.get(str(name), 0), StringType()
        )
        df = daily_summary.filter(
            "retailerId = {} and event_time>='{} 00:00:00' and "
            "event_time<'{} 00:00:00'".format(
                str(retailer_id), self.end, self.start
            )
        )
        df = df.groupBy(
            ["targetingType", "targetingValue", "impressionCount"]
        ).sum(
            "pdpVisitCount", "addToCartCount", "addToCartInstancesViaPdp",
            "organicSalesTransactionCount"
        )
        df = df.withColumn(
            "clicks", (f.col("sum(pdpVisitCount)") +
                       f.col("sum(addToCartCount)") -
                       f.col("sum(addToCartInstancesViaPdp)"))
        )
        df = df.select(
            "targetingType", "targetingValue", "impressionCount",
            "clicks", "sum(organicSalesTransactionCount)"
        )
        df = df.withColumn("targetingType", get_value(df["targetingType"]))
        df = df.groupBy(
            "targetingType", "targetingValue"
        ).sum("impressionCount", "clicks",
              "sum(organicSalesTransactionCount)")
        df = df.toDF(
            *["targetingType", "targetingValue", "impressions", "clicks",
              "conversions"]
        )
        df = df.filter(f.col("impressions") >= self.impression_threshold)

        return df

    @staticmethod
    def get_retailer_floor_price(filtered_daily_summary, metadata, aov_dict):
        retailer_aov = np.percentile(
            aov_dict["Retailer"], metadata["cutoff"]
        )
        pc_cvr = metadata["pc_cvr"]
        ctr = metadata["ctr"]
        acos = metadata["acos"]

        if filtered_daily_summary.head(1):
            impressions = filtered_daily_summary.agg(
                f.sum("impressions")
            ).collect()[0][0]
            clicks = filtered_daily_summary.agg(
                f.sum("clicks")
            ).collect()[0][0]
            conversions = filtered_daily_summary.agg(
                f.sum("conversions")
            ).collect()[0][0]

            ctr = round(clicks / impressions, 4)
            pc_cvr = round(conversions / clicks, 4)

            retailer_price_values = [
                {
                    "targeting_type": "RETAILER",
                    "targeting_value": "RETAILER",
                    "CPC": round(
                        pc_cvr * retailer_aov * metadata["acos"], 2
                    ),
                    "CPM": round(
                        pc_cvr * retailer_aov * metadata["acos"] * ctr * 1000,
                        2
                    ),
                    "CTR": ctr,
                    "PC_CVR": pc_cvr,
                    "AOV": retailer_aov
                }
            ]

        else:
            retailer_price_values = [
                {
                    "targeting_type": "RETAILER",
                    "targeting_value": "RETAILER",
                    "CPC": round(pc_cvr * retailer_aov * acos, 2),
                    "CPM": round(pc_cvr * retailer_aov * acos * ctr * 1000, 2),
                    "CTR": ctr,
                    "PC_CVR": pc_cvr,
                    "AOV": retailer_aov
                }
            ]

        for category, aov_list in aov_dict.items():
            if category != "RETAILER":
                category_aov = np.percentile(aov_list, metadata["cutoff"])
                retailer_price_values.append({
                    "targeting_type": "Category",
                    "targeting_value": category,
                    "CPC": round(category_aov * pc_cvr * acos, 2),
                    "CPM": round(category_aov * pc_cvr * acos * ctr * 1000, 2),
                    "CTR": ctr,
                    "PC_CVR": pc_cvr,
                    "AOV": category_aov
                })
        return retailer_price_values

    def process_hourly_summary(self, retailer_id, hourly_summary):
        target_mapping = {
            "1": "KEYWORD",
            "2": "CATEGORY",
            "3": "PRODUCT"
        }

        get_value = f.udf(
            lambda name: target_mapping.get(str(name), 0), StringType()
        )
        df = hourly_summary.filter(
            "retailerId = {} and event_time>='{} 00:00:00' and "
            "event_time<'{} 00:00:00'".format(
                str(retailer_id), self.end, self.start
            )
        )
        df = df.groupby("targetingType", "targetingValue").sum(
            'adResponseServerCount', 'opportunityPotentialCount'
        )
        df = df.toDF(
            *["targetingType", "targetingValue", "serve_rate", "opportunity"])

        df = df.groupBy("targetingType", "targetingValue").agg(
            f.sum("serve_rate").alias("serve_rate"),
            f.sum("opportunity").alias("opportunity")
        ).filter((f.col("opportunity") >= self.impression_threshold))

        df = df.withColumn("fill_rate", df["serve_rate"] / df["opportunity"])
        df = df.filter((f.col("fill_rate") >= self.fill_rate_threshold))
        df = df.withColumn("targetingType", get_value(df["targetingType"]))
        return df

    def getKeywordHashes(self, retailer_id):
        keyword_hash = {}
        documents = list(
            self.mongo_client.get_all_documents(
                Config.AzureConfig.COSMOS_HASH_TO_KEYWORD_DB,
                str(retailer_id)
            )
        )
        for doc in documents:
            keyword_hash[doc["_id"]] = doc["keywords"]

        return keyword_hash

    @staticmethod
    def getTargetingTypeFloorPrice(daily_summary, metadata, aov_dict):
        target_type_floor_prices = []
        try:
            # Calculations at targeting type level
            target_type_df = daily_summary.groupBy("targetingType").agg(
                f.sum("impressions").alias("impressions"),
                f.sum("clicks").alias("clicks"),
                f.sum("conversions").alias("conversions")
            )
            target_type_df = target_type_df.withColumn(
                "ctr", f.col("clicks") / f.col("impressions")
            ).withColumn(
                "pc_cvr", f.col("conversions") / f.col("clicks")
            )
            aov = np.percentile(aov_dict["Retailer"], metadata["cutoff"])
            target_type_df = target_type_df.withColumn(
                "CPC", f.round(aov * f.col("pc_cvr") * metadata["acos"], 2)
            ).withColumn(
                "CPM", f.round(f.col("CPC") * f.col("ctr") * 1000, 2)
            ).withColumn(
                "targeting_type", f.lit("Retailer")
            )
            target_type_df = target_type_df.select(
                "targetingType", "targeting_type", "CPC", "CPM", "ctr",
                "pc_cvr"
            )
            target_type_df = target_type_df.toDF(
                *["targeting_value", "targeting_type", "CPC", "CPM", "CTR",
                  "PC_CVR"]
            )

            # Convert the PySpark DataFrame to a dictionary using a UDF
            to_dict_udf = f.udf(lambda x: {
                "targeting_type": x["targeting_type"],
                "targeting_value": x["targeting_value"],
                "CPC": x["CPC"],
                "CPM": x["CPM"],
                "CTR": x["CTR"],
                "PC_CVR": x["PC_CVR"]
            }, MapType(StringType(), StringType()))

            z = target_type_df.withColumn(
                "targeting_type_dict", to_dict_udf(f.struct(
                    f.col("targeting_type"),
                    f.col("targeting_value"),
                    f.col("CPC"), f.col("CPM"), f.col("CTR"), f.col("PC_CVR")
                ))
            )
            z = z.withColumn(
                "CPC", f.col("CPC").cast('double')
            ).withColumn(
                "CPM", f.col("CPM").cast('double')
            ).withColumn(
                "CTR", f.col("CTR").cast('double')
            ).withColumn(
                "PC_CVR", f.col("PC_CVR").cast('double')
            ).select("targeting_type_dict").collect()
            target_type_floor_prices = [x["targeting_type_dict"] for x in z]

        except Exception as e:
            print(e)

        return target_type_floor_prices

    def get_bid_landscape_dict(self, retailer_id):
        bid_landscape_dict = {}
        bid_landscape = list(
            self.mongo_client.get_all_documents(
                Config.AzureConfig.COSMOS_BID_LANDSCAPE_DB,
                str(retailer_id)
            )
        )
        for i in bid_landscape:
            bid_landscape_dict[i["_id"]] = float(
                next(iter(i['target']))
            )

        return bid_landscape_dict

    @staticmethod
    def get_keyword_hash(string):
        string = str(string).lower()
        porter = PorterStemmer()
        words = string.split(" ")
        words_stemmed = [porter.stem(i) for i in words]
        words_stemmed.sort()
        return " ".join(words_stemmed)

    def getTargetingValueFloorPrice(
            self, hourly_summary, daily_summary, keyword_hashes, bid_landscape
    ):

        target_value_floor_prices = []
        try:
            stem_udf = f.udf(self.get_keyword_hash, StringType())
            result = daily_summary.join(
                hourly_summary, ["targetingType", "targetingValue"]
            )

            result = result.withColumn(
                "ctr", f.col("clicks") / f.col("impressions")
            )

            result = result.filter(~f.isnan(f.col("ctr")))

            result = result.withColumn(
                "hash_val",
                f.when(
                    f.col("targetingType") == "KEYWORD",
                    stem_udf(f.col("targetingValue"))
                ).otherwise(None)
            )

            result = result.withColumn(
                "key",
                f.when(f.col("targetingType") == "KEYWORD",
                       f.concat(f.lit("kt_"), f.col("hash_val"))).when(
                    f.col("targetingType") == "PRODUCT",
                    f.concat(f.lit("pt_"),
                             f.lower(f.col("targetingValue")))).when(
                    f.col("targetingType") == "CATEGORY",
                    f.concat(f.lit("ct_"),
                             f.lower(f.col("targetingValue")))))

            result = result.withColumn('hash_val', f.coalesce(
                f.lower(f.col('targetingValue'))))
            result = result.filter(
                f.col("key").isin(list(bid_landscape.keys())))
            result = result.withColumn(
                "cpm",
                f.udf(lambda key: bid_landscape.get(key), DoubleType())(
                    f.col("key"))
            )
            result = result.withColumn(
                "cpc",
                f.round(f.col("cpm") / f.col("ctr") / 1000, 2))
            result = result.select(
                f.col("targetingType").alias("targeting_type"),
                f.col("hash_val").alias("targeting_value"),
                f.col("cpm"),
                f.col("cpc"),
                f.col("ctr")
            )

            target_value_floor_prices = result.collect()

            target_value_floor_prices = [{
                "targeting_type": row["targeting_type"],
                "targeting_value": value
                if row["targeting_type"] == "KEYWORD"
                else row["targeting_value"],
                "CPM": row["cpm"],
                "CPC": row["cpc"],
                "CTR": row["ctr"]
                } for row in target_value_floor_prices for value in
                    keyword_hashes.get(row["targeting_value"], [])
                    if row["targeting_type"] == "KEYWORD"
            ] + [
                {
                    "targeting_type": row["targeting_type"],
                    "targeting_value": row["targeting_value"],
                    "CPM": row["cpm"],
                    "CPC": row["cpc"],
                    "CTR": row["ctr"]
                } for row in target_value_floor_prices
                if row["targeting_type"] != "KEYWORD"
            ]

        except Exception as e:
            print(e)

        return target_value_floor_prices

    @staticmethod
    def process_suggestions(suggestions):
        df = pd.DataFrame(suggestions)
        df['targeting_type'] = df['targeting_type'].str.upper()
        df['CPC'] = df['CPC'].astype('float')
        df['CPM'] = df['CPM'].astype('float')
        df['CTR'] = round(df['CTR'].astype('float'), 4)
        df['PC_CVR'] = round(df['PC_CVR'].astype('float'), 4)
        df = df.groupby(['targeting_type', 'targeting_value'],
                        group_keys=False).apply(
            lambda x: x.loc[x.CPC.idxmax()]).reset_index(drop=True)
        df = df.sort_values("targeting_type", ascending=False)
        df.reset_index(inplace=True, drop=True)
        return df

    @staticmethod
    def send_floor_price_email(retailer_id, suggestion_df):
        metadata = MetaDataExtractor.get_retailer_matadata(retailer_id)
        recipient_mail = metadata.get(
            "floor_price_recipients", Config.AzureConfig.SENDER_MAIL
        )

        suggestion_df = suggestion_df[
            ["targeting_type", "targeting_value", "CPC", "CPM"]
        ]
        suggestion_df.insert(0, "retailer_id", retailer_id)

        meta_df = suggestion_df[
            suggestion_df["targeting_value"].isin(
                ["RETAILER", "KEYWORD", "PRODUCT", "CATEGORY"]
            )
        ]
        meta_df = meta_df[["retailer_id", "targeting_value", "CPC", "CPM"]]
        meta_df.columns = ["Retailer ID", "Level", "CPC", "CPM"]
        meta_df.reset_index(inplace=True, drop=True)
        table_html = meta_df.to_html(index=False)

        csv_message = Mail(
            from_email=Config.AzureConfig.SENDER_MAIL,
            to_emails=recipient_mail,
            subject="Floor Price Recommendations for Retailer - "
                    "{}".format(retailer_id),
            html_content=table_html
        )

        target_df = suggestion_df[~suggestion_df["targeting_value"].isin(
            ["RETAILER", "KEYWORD", "PRODUCT", "CATEGORY"])]

        if not target_df.empty:
            target_df.columns = [
                "Retailer ID", "Targeting Type", "Targeting Value", "CPC",
                "CPM"
            ]
            target_df.reset_index(inplace=True, drop=True)

            # Create buffered csv
            buffer = BytesIO()
            target_df.to_csv(buffer)
            buffer.seek(0)
            data = buffer.read()
            encoded = base64.b64encode(data).decode()

            attachment = Attachment()
            attachment.file_content = FileContent(encoded)
            attachment.file_type = FileType("text/csv")
            attachment.file_name = FileName(
                "FloorPriceRecommendation_{}".format(retailer_id)
            )
            attachment.disposition = Disposition("attachment")
            csv_message.attachment = attachment

        try:
            sendgrid_client = SendGridAPIClient(
                Config.AzureConfig.SENDGRID_API
            )
            sendgrid_client.send(csv_message)
            print("Successfully sent floor price recommendations to "
                  "recipient emails for retailer - {}".format(retailer_id))

        except Exception as e:
            print(e)

    def main(self):
        spark = self.create_spark_session()

        # Getting ads tracking summary
        hourly_summary = spark.read.format(
            "delta"
        ).load(Config.AzureConfig.ORGANIC_AD_REQUEST_SUMMARY)

        # Getting daily ads summary
        daily_summary = spark.read.format(
            "delta"
        ).load(Config.AzureConfig.ORGANIC_DAILY_SUMMARY)

        for retailer_id in self.retailers:
            suggestions = []
            print(
                "Creating floor price suggestions for retailer - {}".format(
                    retailer_id
                )
            )

            try:
                aov_data = self.get_aov_data(retailer_id)
                metadata = self.get_metadata_for_computation(retailer_id)

                # Creating floor price suggestions at targeting type level
                filtered_daily_summary = self.process_daily_summary(
                    retailer_id, daily_summary
                )

                # Creating floor price suggestion at retailer level
                retailer_suggestions = self.get_retailer_floor_price(
                    filtered_daily_summary, metadata, aov_data)
                if retailer_suggestions:
                    print(
                        "Created suggestions at retailer level for {}".format(
                            retailer_id
                        )
                    )
                    suggestions.extend(retailer_suggestions)

                target_type_suggestions = self.getTargetingTypeFloorPrice(
                    filtered_daily_summary, metadata, aov_data
                )
                if target_type_suggestions:
                    print(
                        "Created suggestions at target type level for "
                        "{}".format(retailer_id)
                    )
                    suggestions.extend(target_type_suggestions)

                # Creating floor price suggestions at target value level
                filtered_hourly_summary = self.process_hourly_summary(
                    retailer_id, hourly_summary
                )
                keyword_hashes = self.getKeywordHashes(retailer_id)
                bid_landscape = self.get_bid_landscape_dict(retailer_id)
                target_value_suggestions = self.getTargetingValueFloorPrice(
                    filtered_hourly_summary, filtered_daily_summary,
                    keyword_hashes, bid_landscape
                )
                if target_value_suggestions:
                    print(
                        "Created suggestions at target value level for "
                        "{}".format(retailer_id)
                    )
                    suggestions.extend(target_value_suggestions)

                if suggestions:
                    output = self.process_suggestions(suggestions)
                    self.write_to_azure(retailer_id, output)
                    self.send_floor_price_email(retailer_id, output)

            except Exception as e:
                print(
                    "Unable to create floor price suggestions for retailer "
                    "- {} as {}".format(retailer_id, e)
                )


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Floor Price Suggestion')
    parser.add_argument('-env', '--environment', type=str,
                        default='prod',
                        help='List of environments to run suggestions')
    parser.add_argument('-d', '--day_count', type=int, default=14,
                        help='Number of days to look backward from current '
                             'date for suggestions')
    parser.add_argument('-databricks', '--databricks', type=bool,
                        default=False,
                        help="The script can run only in Databricks")
    input_args = vars(parser.parse_args())
    if input_args['databricks']:
        for env in input_args['environment'].strip().split(','):
            try:
                FPS = FloorPriceSuggestion(
                    environment=env, look_back=input_args["day_count"]
                )
                FPS.main()
            except Exception as exception:
                print(exception)
                continue
    else:
        print("The script will not run outside of Databricks environment")
