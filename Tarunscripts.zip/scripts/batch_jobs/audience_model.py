import logging, os

os.environ['CUDA_DEVICE_ORDER'] = "PCI_BUS_ID"

logging.disable(logging.WARNING)
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"
import tensorflow as tf
print("GPU detected:", tf.test.is_gpu_available())

import numpy as np
import pickle, glob
from random import shuffle
import matplotlib.pyplot as plt
from tqdm import tqdm

from tensorflow.keras.layers import Input,GlobalAveragePooling2D, Dense, concatenate, BatchNormalization, Reshape, Softmax, Flatten, Concatenate
from tensorflow.keras.models import Model
import tensorflow.keras.backend as K
import pickle
import glob
#from tensorflow_addons.optimizers import AdamW
#import tensorflow_addons as tfa
#from tfa.optimizers import AdamW

def load_model(config, num_bcatgs, num_catgs):
    input_ = Input(shape=(num_bcatgs,), name="input_user")
    input_b = Input(shape=(num_bcatgs,), name="input_bin_user")
    #input_ = Input(shape=(1024,), name="input_user")
    input_2 = Dense(num_bcatgs, activation='sigmoid', name="input_2")(input_)
    input_2b = Dense(num_bcatgs, activation='sigmoid', name="input_2b")(input_b)
    merged = concatenate([input_2, input_2b])
    #input_3 = Dense(num_bcatgs, activation='sigmoid', name="input_3")(input_2)
    out = Dense(num_bcatgs, activation='sigmoid', name="output_bcatg")(merged)
    model = Model(inputs=[input_,input_b], outputs=out)
    print(model.summary())
    return model


def decode_fn(record_bytes):
    a =  tf.io.parse_single_example(
     record_bytes,
     {"input_uid": tf.io.FixedLenFeature([], dtype=tf.string),
        "input_num_bcatg": tf.io.FixedLenFeature([], dtype=tf.string),
        "input_num_catg": tf.io.FixedLenFeature([], dtype=tf.string),
        "input_user": tf.io.FixedLenFeature([], dtype=tf.string),
        "input_bin_user": tf.io.FixedLenFeature([], dtype=tf.string),
        "output_bcatg":tf.io.FixedLenFeature([], dtype=tf.string),
        "output_catg":tf.io.FixedLenFeature([], dtype=tf.string)} )
    return {"input_user":tf.reshape(tf.io.decode_raw(a['input_user'],tf.float64),(int(a['input_num_bcatg']),)), "input_bin_user":tf.reshape(tf.io.decode_raw(a['input_bin_user'],tf.float64),(int(a['input_num_bcatg']),)), "input_uid": a['input_uid'], "input_num_catg": a["input_num_catg"], "input_num_bcatg": a["input_num_bcatg"]}, {'output_bcatg': tf.reshape(tf.io.decode_raw(a['output_bcatg'],tf.int64),(int(a['input_num_bcatg']),))}


def _bytes_feature(value):
    return tf.train.Feature(bytes_list=tf.train.BytesList(value=[value]))

def get_num_records(tf_records_filenames):
    c = 0
    for fn in tf_records_filenames:
        for record in tf.compat.v1.io.tf_record_iterator(fn):
            c += 1
    return c

def train(config, num_bcatgs, num_catgs):
    batch_size = config["training"]["params"]["batch_size"]
    train_tfr_files = sorted(glob.glob(config['training']['train_path_tfr_files']))
    num_train_recs = get_num_records(train_tfr_files)
    print(num_train_recs)
    val_tfr_files = sorted(glob.glob(config['training']['val_path_tfr_files']))
    num_val_recs = get_num_records(val_tfr_files)
    print(num_val_recs)
    train_dataset = tf.data.TFRecordDataset(train_tfr_files).map(decode_fn,num_parallel_calls=-1).batch(batch_size).prefetch(tf.data.experimental.AUTOTUNE).repeat()

    val_dataset  = tf.data.TFRecordDataset(val_tfr_files).map(decode_fn,num_parallel_calls=-1).batch(batch_size).prefetch(tf.data.experimental.AUTOTUNE).repeat()
   
    #DISTRIBUTE STRATEGY
    strategy = tf.distribute.MirroredStrategy()
    print('Number of devices: {}'.format(strategy.num_replicas_in_sync))
    with strategy.scope():

        #MODEL
        model = load_model(config, num_bcatgs, num_catgs)
   
        #TRAINING
        dump_path = config["training"]["dump_directory"]
        if not os.path.exists(dump_path):
            os.makedirs(dump_path)
   
        filepath = config["model"]["name"] + "-" + "epoch{epoch:01d}.hdf5"
        cp_callback = tf.keras.callbacks.ModelCheckpoint(filepath=dump_path+filepath, verbose=1, save_best_only=True, monitor='val_loss', mode='min', save_freq='epoch')
        reduce_lr = tf.keras.callbacks.ReduceLROnPlateau(monitor='val_loss', factor=0.2, patience=3, min_lr=0.0000001)

        #TRAINING
        # define optimisers, losses and metrics
   
        lr = config["training"]["params"]["lr"]
        model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=lr, amsgrad=True),
                loss=tf.keras.losses.BinaryCrossentropy(),
                #loss=tf.keras.losses.CategoricalCrossentropy(),
                metrics=['categorical_accuracy', tf.keras.metrics.BinaryAccuracy()]
                )
    print("Starting training")
    #dump histories
    history = model.fit(train_dataset, epochs=config["training"]["params"]["epochs"],
                        validation_data=val_dataset,
                        steps_per_epoch=num_train_recs/batch_size,
                        validation_steps=num_val_recs/batch_size,
                        shuffle=True,
                        verbose=1,
                        #max_queue_size=50, 
                        #workers=25,
                        use_multiprocessing=True,
                        callbacks=[cp_callback, reduce_lr])

    print(history.history.keys())
    print(history.history)
    fpw = open(dump_path + config["model"]["name"] + "_history.pkl", "wb")
    pickle.dump(history.history, fpw)
    fpw.close()
