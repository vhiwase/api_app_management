import argparse, os
import tensorflow as tf
import numpy as np
import pickle
from tensorflow.keras.layers import Input, Dense, concatenate
from tensorflow.keras.models import Model
from datetime import datetime, timedelta
import time
import glob
from config import Config
from util.read_write_data_azure_blob import ReadAndWriteFromAzureBlob
from sklearn.metrics import precision_recall_fscore_support, precision_recall_curve, auc, roc_auc_score
import pandas as pd

def decode_fn(record_bytes):
    a =  tf.io.parse_single_example(
     record_bytes,
     {"input_uid": tf.io.FixedLenFeature([], dtype=tf.string),
        "input_num_bcatg": tf.io.FixedLenFeature([], dtype=tf.string),
        "input_num_catg": tf.io.FixedLenFeature([], dtype=tf.string),
        "input_user": tf.io.FixedLenFeature([], dtype=tf.string),
        "input_bin_user": tf.io.FixedLenFeature([], dtype=tf.string),
        "output_bcatg":tf.io.FixedLenFeature([], dtype=tf.string),
        "output_catg":tf.io.FixedLenFeature([], dtype=tf.string)} )
    return {"input_user":tf.reshape(tf.io.decode_raw(a['input_user'],tf.float64),(int(a['input_num_bcatg']),)), "input_bin_user":tf.reshape(tf.io.decode_raw(a['input_bin_user'],tf.float64),(int(a['input_num_bcatg']),)), "input_uid": a['input_uid'], "input_num_catg": a["input_num_catg"], "input_num_bcatg": a["input_num_bcatg"]}, {'output_bcatg': tf.reshape(tf.io.decode_raw(a['output_bcatg'],tf.int64),(int(a['input_num_bcatg']),))}

def infer(test_tfr_files, aud_model, inv_catg_index_map, aud_path):
    read_write_blob = ReadAndWriteFromAzureBlob()
    y_pred_list = []
    users_list = []
    test_dataset = tf.data.TFRecordDataset(test_tfr_files).map(decode_fn,num_parallel_calls=-1).batch(512).prefetch(tf.data.experimental.AUTOTUNE)
    for idx,(x,y) in enumerate(test_dataset):
        if idx%10 == 0:
            print("processed %d batches" %idx)
        users_list.append(x['input_uid'].numpy().tolist())
        y_pred = aud_model.predict(x)
        y_pred_list.append(y_pred)
    y_preds = np.vstack(y_pred_list)
    users = [user.decode() for user_list in users_list for user in user_list]
    meta_audience = {}
    for col in range(y_preds.shape[1]):
        catg = inv_catg_index_map[col]
        aud_scores = y_preds[:, col]
        auds_dict = dict(zip(users, aud_scores))
        blob_name = aud_path + "/" + catg + "_" + "audience.pkl"
        meta_audience[catg] = blob_name
        for _env in ("dev", "qa", "uat", "prod"):
            Config.switch_env(_env)
            read_write_blob.write_to_blob(Config.AzureConfig.RECOMMENDATION_OUT_STRING, Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME, blob_name, auds_dict, True)

    # write meta audience file
    blob_name = aud_path + "/" + "meta_audience.pkl"
    for _env in ("dev", "qa", "uat", "prod"):
        Config.switch_env(_env)
        read_write_blob.write_to_blob(Config.AzureConfig.RECOMMENDATION_OUT_STRING, Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME, blob_name, meta_audience, True)

def get_validation_metrics(val_tfr_files, aud_model, inv_catg_index_map, val_path):
    read_write_blob = ReadAndWriteFromAzureBlob()
    correct = 0
    total = 0
    y_pred_list = []
    y_actual_list = []
    users_list = []
    val_metrics = []
    st2=time.time()
    val_dataset = tf.data.TFRecordDataset(val_tfr_files).map(decode_fn,num_parallel_calls=-1).batch(512).prefetch(tf.data.experimental.AUTOTUNE)
    for idx,(x,y) in enumerate(val_dataset):
        if idx%10 == 0:
            print("processed %d batches" %idx)
        users_list.append(x['input_uid'].numpy().tolist())
        y_pred = aud_model.predict(x)
        y_pred_list.append(y_pred)
        y_actual = y["output_bcatg"].numpy()
        y_actual_list.append(y_actual)

    y_preds = np.vstack(y_pred_list)
    y_actuals = np.vstack(y_actual_list)
    users = [user.decode() for user_list in users_list for user in user_list]
    for col in range(y_preds.shape[1]):
        catg = inv_catg_index_map[col]
        aud_scores = y_preds[:, col]
        aud_preds = [1 if prob >= 0.25 else 0 for prob in aud_scores]
        aud_actuals = y_actuals[:, col]
        p_obj, r_obj, f_obj, s_obj = precision_recall_fscore_support(aud_actuals, aud_preds, labels=[1])
        p_score, r_score, f1_score, support = p_obj[0], r_obj[0], f_obj[0], s_obj[0]
        precision, recall, thresholds = precision_recall_curve(aud_actuals, aud_scores)
        try:
            pr_auc = auc(recall, precision)
        except:
            pr_auc = "undefined"
        try:
            roc_auc = roc_auc_score(aud_actuals, aud_scores)
        except:
            roc_auc = "undefined"
        val_metrics.append([catg, p_score, r_score, f1_score, support, len(aud_actuals), pr_auc, roc_auc])
    val_df = pd.DataFrame(val_metrics, columns = ['Broad_Category', 'Precision', 'Recall', 'F1', 'Support', 'Total', 'PR-AUC', 'ROC-AUC'])
    val_df = val_df.sort_values('Support', ascending=False)
    print(val_df)
    today_date = datetime.strftime(datetime.now(), "%Y-%m-%d")
    blob_name = val_path + "/" + today_date + "_" + "val_metrics.csv"
    for _env in ("dev", "qa", "uat", "prod"):
        Config.switch_env(_env)
        read_write_blob.write_to_blob(Config.AzureConfig.RECOMMENDATION_OUT_STRING, Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME, blob_name, val_df)

    et2=time.time()
    print("time taken to infer:%s" %(et2-st2))
    fp = open(blob_name, "w")
    val_df.to_csv(fp)
    fp.close()


if __name__=="__main__":
    parser = argparse.ArgumentParser(description='Generate Future Audience')
    parser.add_argument('-i', '--id', help='ID', required=True)
    args = vars(parser.parse_args())
    retailer_id = args["id"]
    data_path = "audience_features/%s" %retailer_id
    model_path = "audience_model/%s/" %retailer_id
    os.makedirs(model_path, exist_ok=True)
    models = glob.glob(model_path + "*")
    best_epoch = -1
    for model in models:
        if "epoch" not in model:
            continue
        epoch=int(model.split("epoch")[1].split(".hdf5")[0])
        if epoch > best_epoch:
            best_epoch = epoch
            aud_model_path = model
    aud_model = tf.keras.models.load_model(aud_model_path)
    test_tfr_files = sorted(glob.glob(data_path + "/*test*tfrecords"))
    val_tfr_files = sorted(glob.glob(data_path + "/*val*tfrecords"))
    today_date = datetime.strftime(datetime.now()-timedelta(0), "%Y-%m-%d")
    catg_index_file = "audience_features/" + retailer_id + "/" + today_date + "_" + "catg_index_hash.pkl"
    fp = open(catg_index_file, "br")
    catg_index_map = pickle.load(fp)
    fp.close()
    inv_catg_index_map = {v:k for k, v in catg_index_map.items()}
    val_path = "audience_metrics_v2/%s" %retailer_id
    os.makedirs(val_path, exist_ok=True)
    get_validation_metrics(val_tfr_files, aud_model,inv_catg_index_map, val_path)
    aud_path = "audience_targeting_v2/%s" %retailer_id
    os.makedirs(aud_path, exist_ok=True)
    infer(test_tfr_files, aud_model, inv_catg_index_map, aud_path)
