import logging
import os, sys
import argparse
import glob
import pickle
from datetime import datetime, timedelta
from audience_config import get_training_config
from audience_model import train

def main(args):
    model_name = "aud_model_v2"
    retailer_id = args["id"]
    data_path = "audience_features/%s" %retailer_id
    os.makedirs(data_path, exist_ok=True)
    # Train & Val data paths
    train_path_tfr_files = data_path + "/*train*tfrecords"
    val_path_tfr_files = data_path + "/*val*tfrecords"
    model_path = "audience_model/" + retailer_id + "/"
    os.makedirs(model_path, exist_ok=True)
    existing_models = glob.glob(model_path+"*")
    for existing_model in existing_models:
        os.remove(existing_model)
    config = get_training_config(model_name, train_path_tfr_files, val_path_tfr_files, model_path, args)
    today_date = datetime.strftime(datetime.now()-timedelta(0), "%Y-%m-%d")
    bcatg_file = data_path + "/" + today_date + "_" + "catg_index_hash.pkl"
    fp = open(bcatg_file, "br")
    bcatg_ind_map = pickle.load(fp)
    num_bcatgs = len(bcatg_ind_map)
    fp.close()
    catg_file = data_path + "/" + today_date + "_" + "catalog_catg_index_hash.pkl"
    fp = open(catg_file, "br")
    catg_ind_map = pickle.load(fp)
    num_catgs = len(catg_ind_map)
    fp.close()
    train(config, num_bcatgs, num_catgs)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Train Retailer Audience Model')
    parser.add_argument('-i', '--id', help='ID', required=True)
    args = vars(parser.parse_args())
    main(args)
