from util.azure_batch_logger import BatchLog
import os
from config import Config
from datetime import datetime, timedelta
from azure.storage.blob import ContainerClient
from multiprocessing import Process, Queue
import multiprocessing
from fastavro import reader
import pandas as pd
from util.meta_data_extractor import MetaDataExtractor
from util.read_write_data_azure_blob import ReadAndWriteFromAzureBlob
import argparse
import swifter
import numpy as np

class OrganicPurchaseData:
    def __init__(self, time_delta, environment, retailer_id):
        Config.switch_env(environment)
        print(
            "Running for environment - {}".format(
                Config.AzureConfig.ENV)
        )
        self.data_path = "organic_purchase_features/%s" %(retailer_id)
        os.makedirs(self.data_path, exist_ok=True)
        self.input_client = ContainerClient.from_connection_string(
            conn_str=Config.AzureConfig.ORGANIC_CONNECTION,
            container_name=Config.AzureConfig.ORGANIC_CONTAINER
        )
        self.current_date = datetime.strftime(
            datetime.now() - timedelta(time_delta), "%Y-%m-%d"
        )
        self.current_run = datetime.strftime(
            datetime.now() - timedelta(time_delta), "year=%Y/month=%m/day=%d"
        )
        self.read_write_blob = ReadAndWriteFromAzureBlob()
        self.num_cores = max(multiprocessing.cpu_count() - 4, 1)
        print(
            "Total number of cores that will be used during multiprocessing "
            "will be {}".format(self.num_cores)
        )

    @staticmethod
    def _get_retailers_for_aggregation():
        retailer_ids = []
        retailer_names = []
        all_meta = MetaDataExtractor.get_retailer_matadata()
        for retailer in all_meta:
            retailer_ids.append(retailer['_id'])
            retailer_names.append(retailer['retailer_name'])
        return retailer_ids, retailer_names

    def __list_data_files(self, retailer_id, event_type):
        pattern = Config.AzureConfig.ORGANIC_CONTAINER_PATTERN.format(
            retailer_id, event_type, self.current_run
        )
        master_list = list(
            self.input_client.list_blobs(
                name_starts_with=pattern
            )
        )
        latest_blobs = [blob for blob in master_list if blob.size > 508]
        return latest_blobs

    def consolidate_data(self, latest_blobs, output_queue):
        local_files = []
        for blob in latest_blobs:
            blob_client = ContainerClient.get_blob_client(
                self.input_client, blob=blob
            )
            blob_name = str.replace(blob.name, '/', '_').replace('-', '_')
            try:
                with open(blob_name, "wb+") as my_file:
                    my_file.write(blob_client.download_blob(connection_timeout=300).readall())
                    my_file.close()
                local_files.append(blob_name)
            except:
                print("CAUTION: download failed for %s !!!" %blob_name)
                continue
        consolidated_data = []
        for file in local_files:
            try:
                with open(file, 'rb') as fo:
                    avro_reader = reader(fo)
                    for emp in avro_reader:
                        consolidated_data.append(emp)
                        os.remove(file)
            except Exception as e:
                BatchLog.info(e)
                continue
        output_queue.put(consolidated_data)

    def consolidate_data_parallel(self, latest_blobs):
        if latest_blobs:
            chunk_size = int(len(latest_blobs) / self.num_cores) + 1
            message = "Chunk size that will be used to process files in " \
                      "parallel - {}".format(chunk_size)
            print(message)

            i = 0
            process_list = []
            file_list = []
            output_queue = Queue()
            while i < self.num_cores:
                print("processing chunk %d" % i)
                start_index = i * chunk_size
                end_index = (i + 1) * chunk_size
                chunked_blob_list = latest_blobs[start_index:end_index]
                p = Process(
                    target=self.consolidate_data,
                    args=(chunked_blob_list, output_queue)
                )
                process_list.append(p)
                p.start()
                i += 1

            for i in range(self.num_cores):
                file_list.extend(output_queue.get())

            for p in process_list:
                p.join()

            message = "Downloaded & processed all files"
            print(message)

            # Converting the data into a dataframe
            df = pd.DataFrame(file_list)
            df = df.loc[df.astype(str).drop_duplicates().index]
            df.reset_index(inplace=True, drop=True)
            return df

        else:
            return pd.DataFrame()

    @staticmethod
    def __get_user_data(dict_object):
        user_id = dict_object.get('user_id')
        guest_id = dict_object.get('guest_id')
        return user_id, guest_id

    def main(self, retailer):
        try:
            message = "Processing retailer - {} on day {}".format(retailer, self.current_date)
            print(message)
            BatchLog.info(message)
            # Download and consolidate search data
            blobs = self.__list_data_files(retailer, 'place-order')
            data = self.consolidate_data_parallel(blobs)
            data['user_id'] = data['user'].apply(lambda x: x.get('user_id', ''))
            data['guest_id'] = data['user'].apply(lambda x: x.get('guest_id', ''))
            data['items'] = data['order'].apply(lambda x: x.get('items', []))
            data['timestamp'] = data['event_timestamp']
            data['product_list'] = data['items'].apply(lambda x: [i.get("product_id", "") for i in x])
            data['quantity_list'] = data['items'].apply(lambda x: [i.get("quantity", 0) for i in x])
            data = data[['user_id', 'guest_id', 'product_list', 'quantity_list', 'timestamp']]
            out_file = self.data_path + "/" + self.current_date + ".csv"
            self.read_write_blob.write_to_blob(
                Config.AzureConfig.RECOMMENDATION_OUT_STRING,
                Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME,
                out_file,
                data
            )
        except Exception as e:
            BatchLog.info(e)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Batch job that maps organic products purchase to users"
    )
    parser.add_argument('-d', '--day_count', type=int, default=60,
                        help='Number of months to look backward from current '
                             'date')
    parser.add_argument('-env', '--environment', type=str,
                        default='prod',
                        help='List of environments to run products purchase to user map')
    input_args = vars(parser.parse_args())
    ed = input_args['day_count']
    env = input_args['environment']
    retailer_ids, retailer_names = OrganicPurchaseData._get_retailers_for_aggregation()
    retailer_ids, retailer_names = ['123456', '4987041', '70891516'], ['baldor', 'staples', 'lordandtaylor']
    today_date = datetime.strftime(datetime.now(), "%Y-%m-%d")
    for retailer_id, retailer_name in zip(retailer_ids, retailer_names):
        print("*****processing retailer %s*****" %retailer_name)
        i = 1
        while i <= ed:
            try:
                keyword_mapper = OrganicPurchaseData(
                    time_delta=i,
                    environment=env,
                    retailer_id=retailer_id
                )
                keyword_mapper.main(retailer_id)
                i += 1
            except Exception as exception:
                print(exception)
                print("Exception in processing day %s data" %i)
                i += 1
                continue
