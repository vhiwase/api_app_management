from util.azure_batch_logger import BatchLog
import os
from config import Config
from datetime import datetime, timedelta
from azure.storage.blob import ContainerClient
from multiprocessing import Process, Queue
import multiprocessing
from fastavro import reader
import pandas as pd
from util.meta_data_extractor import MetaDataExtractor
from util.read_write_data_azure_blob import ReadAndWriteFromAzureBlob
import argparse
import swifter


class OrganicKeywordProductMapper:
    def __init__(self, time_delta, environment):
        Config.switch_env(environment)
        print(
            "Running for environment - {}".format(
                Config.AzureConfig.ENV)
        )
        self.input_client = ContainerClient.from_connection_string(
            conn_str=Config.AzureConfig.ORGANIC_CONNECTION,
            container_name=Config.AzureConfig.ORGANIC_CONTAINER
        )
        self.current_run = datetime.strftime(
            datetime.now() - timedelta(time_delta), "year=%Y/month=%m/day=%d"
        )
        self.retailers = self._get_retailers_for_aggregation()
        self.read_write_blob = ReadAndWriteFromAzureBlob()
        self.num_cores = max(multiprocessing.cpu_count() - 4, 1)
        print(
            "Total number of cores that will be used during multiprocessing "
            "will be {}".format(self.num_cores)
        )

    @staticmethod
    def _get_retailers_for_aggregation():
        retailer_ids = []
        all_meta = MetaDataExtractor.get_retailer_matadata()
        for retailer in all_meta:
            retailer_ids.append(retailer['_id'])
        return retailer_ids

    def __list_data_files(self, retailer_id, event_type):
        pattern = Config.AzureConfig.ORGANIC_CONTAINER_PATTERN.format(
            retailer_id, event_type, self.current_run
        )
        master_list = list(
            self.input_client.list_blobs(
                name_starts_with=pattern
            )
        )
        latest_blobs = [blob for blob in master_list if blob.size > 508]
        return latest_blobs

    def consolidate_data(self, latest_blobs, output_queue):
        local_files = []
        for blob in latest_blobs:
            blob_client = ContainerClient.get_blob_client(
                self.input_client, blob=blob
            )
            blob_name = str.replace(blob.name, '/', '_').replace('-', '_')
            local_files.append(blob_name)
            with open(blob_name, "wb+") as my_file:
                my_file.write(blob_client.download_blob().readall())
                my_file.close()

        consolidated_data = []
        for file in local_files:
            with open(file, 'rb') as fo:
                avro_reader = reader(fo)
                for emp in avro_reader:
                    try:
                        consolidated_data.append(emp)
                        os.remove(file)
                    except Exception as e:
                        BatchLog.info(e)
                        continue
        output_queue.put(consolidated_data)

    def consolidate_data_parallel(self, latest_blobs):
        if latest_blobs:
            chunk_size = int(len(latest_blobs) / self.num_cores) + 1
            message = "Chunk size that will be used to process files in " \
                      "parallel - {}".format(chunk_size)
            print(message)

            i = 0
            process_list = []
            file_list = []
            output_queue = Queue()
            while i < self.num_cores:
                print("processing chunk %d" % i)
                start_index = i * chunk_size
                end_index = (i + 1) * chunk_size
                chunked_blob_list = latest_blobs[start_index:end_index]
                p = Process(
                    target=self.consolidate_data,
                    args=(chunked_blob_list, output_queue)
                )
                process_list.append(p)
                p.start()
                i += 1

            for i in range(self.num_cores):
                file_list.extend(output_queue.get())

            for p in process_list:
                p.join()

            message = "Downloaded & processed all files"
            print(message)

            # Converting the data into a dataframe
            df = pd.DataFrame(file_list)
            df = df.loc[df.astype(str).drop_duplicates().index]
            df.reset_index(inplace=True, drop=True)
            return df

        else:
            return pd.DataFrame()

    @staticmethod
    def __get_user_data(dict_object):
        user_id = dict_object.get('user_id')
        guest_id = dict_object.get('guest_id')
        return user_id, guest_id

    @staticmethod
    def get_product_keyword_map(combined_df, guest_list, output_queue):
        product_keyword_map = {}
        for guest in guest_list:
            filtered_df = combined_df[
                combined_df['guest_id'] == guest
                ]
            for index in filtered_df.index:
                try:
                    if filtered_df['event_type'][index] == 'ADD_TO_CART':
                        if filtered_df['event_type'][index - 1] == 'SEARCH':
                            if int(
                                    filtered_df['event_timestamp'][index - 1]
                            ) - int(
                                filtered_df['event_timestamp'][index]
                            ) <= 300:
                                product = filtered_df['products'][index]
                                keyword = filtered_df['keyword'][index - 1]
                                if product_keyword_map.get(product):
                                    product_keyword_map[product].append(
                                        keyword
                                    )
                                else:
                                    product_keyword_map[product] = [
                                        keyword
                                    ]
                except KeyError:
                    continue
        output_queue.put(product_keyword_map)

    @staticmethod
    def __flatten_dictionary(list_of_dictionary):
        product_keyword_map = {}
        for dictionary in list_of_dictionary:
            for key, value in dictionary.items():
                if product_keyword_map.get(key):
                    product_keyword_map[key].extend(value)
                else:
                    product_keyword_map[key] = value
        return product_keyword_map

    def __get_product_keyword_map_parallel(self, guest_list, combined_df):
        if guest_list:
            print("Total guest ids to process: {}".format(len(guest_list)))
            chunk_size = int(len(guest_list) / self.num_cores) + 1
            message = "Chunk size that will be used to process parallel - " \
                      "{}".format(chunk_size)
            print(message)

            i = 0
            process_list = []
            keyword_list = []
            output_queue = Queue()
            while i < self.num_cores:
                start_index = i * chunk_size
                end_index = (i + 1) * chunk_size
                chunked_list = guest_list[start_index:end_index]
                p = Process(
                    target=self.get_product_keyword_map,
                    args=(combined_df, chunked_list, output_queue)
                )
                process_list.append(p)
                p.start()
                i += 1

            for i in range(self.num_cores):
                keyword_list.append(output_queue.get())

            for p in process_list:
                p.join()

            message = "Processed data from all Guest IDs"
            print(message)

            # Converting the data into a dataframe
            flattened_dict = self.__flatten_dictionary(keyword_list)
            df = pd.DataFrame(
                flattened_dict.values(),
                flattened_dict.keys()
            )
            df = df.stack().reset_index()
            df.columns = ["Product", "KeyNum", "Keyword"]
            df = df[["Product", "Keyword"]]
            df = df.groupby(
                ["Product", "Keyword"]
            )["Keyword"].count().reset_index(name="Count")
            df.columns = ["Product", "Keyword", "Count"]
            return df
        else:
            return pd.DataFrame()

    def create_atc_mapping(self, retailer_id, search_data, atc_data):
        if not search_data.empty and not atc_data.empty:
            message = "Got non empty search and add to cart data, " \
                      "proceeding with aggregations for retailer - {}".format(
                        retailer_id
                        )
            print(message)
            BatchLog.info(message)

            # Processing the search and atc data
            search_data['user_id'], search_data['guest_id'] = zip(
                *search_data['user'].map(self.__get_user_data)
            )
            atc_data['user_id'], atc_data['guest_id'] = zip(
                *atc_data['user'].map(self.__get_user_data)
            )

            # Filtering search data by guest id, only if they have an
            # event type of add to cart
            search_data = search_data[
                search_data['guest_id'].isin(atc_data['guest_id'].unique())
            ]
            search_data.reset_index(inplace=True, drop=True)

            # Getting products the user have interacted with
            atc_data['products'] = atc_data['items'].swifter.apply(
                lambda x: x[0]['product_id']
            )

            # Combining search and atc data
            combined_df = pd.concat([search_data, atc_data])
            combined_df = combined_df[
                ['guest_id', 'event_type', 'event_timestamp', 'products',
                 'keyword']
            ]
            combined_df = combined_df.dropna(subset=['guest_id'])
            combined_df.reset_index(inplace=True, drop=True)

            # Sorting the data by userid and event timestamp to make the
            # events sequential
            combined_df = combined_df.sort_values(
                ['guest_id', 'event_timestamp']
            )
            combined_df.reset_index(inplace=True, drop=True)

            # Creating list of unique guest sessions by IDs
            unique_guests = list(
                set(
                    combined_df['guest_id'].to_list()
                )
            )
            product_keyword_df = self.__get_product_keyword_map_parallel(
                unique_guests, combined_df
            )
            return product_keyword_df
        else:
            return pd.DataFrame()

    def main(self):
        for retailer in self.retailers:
            try:
                message = "Processing retailer - {}".format(retailer)
                print(message)
                BatchLog.info(message)

                # Download and consolidate search data
                search_blobs = self.__list_data_files(retailer, 'search')
                search_data = self.consolidate_data_parallel(search_blobs)

                # Download and consolidate add to cart data
                atc_blobs = self.__list_data_files(retailer, 'add-to-cart')
                atc_data = self.consolidate_data_parallel(atc_blobs)

                # Combining data and creating product keyword maps
                product_keyword_df = self.create_atc_mapping(
                    retailer, search_data, atc_data
                )

                # Writing the data to storage containers
                if not product_keyword_df.empty:
                    message = "Mapped product to keywords for retailer " \
                              "- {}".format(retailer)
                    print(message)
                    BatchLog.info(message)

                    blob_name = "retailer_id={}/{}/{}".format(
                        retailer, self.current_run,
                        'OrganicProductKeywordMap.csv'
                    )
                    self.read_write_blob.write_to_blob(
                        Config.AzureConfig.RECOMMENDATION_OUT_STRING,
                        Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME,
                        blob_name,
                        product_keyword_df
                    )
                else:
                    message = "No product to keyword data available for " \
                              "retailer- {}".format(retailer)
                    print(message)
                    BatchLog.info(message)

            except Exception as e:
                BatchLog.info(e)
                continue

        # Write logs to Azure container
        log_file = "{}/{}/{}".format(
            'BatchJobLogs', self.current_run, 'OrganicProductKeywordMap.log'
        )
        self.read_write_blob.write_log_to_blob(
            Config.AzureConfig.RECOMMENDATION_OUT_STRING,
            Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME,
            log_file
        )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Batch job that maps organic search keyword to products"
    )
    parser.add_argument('-d', '--day_count', type=int, default=1,
                        help='Number of days to look backward from current '
                             'date for suggestions')
    parser.add_argument('-env', '--environment', type=str,
                        default='prod',
                        help='List of environments to run keyword product map')
    input_args = vars(parser.parse_args())
    for env in input_args['environment'].strip().split(','):
        try:
            keyword_mapper = OrganicKeywordProductMapper(
                time_delta=input_args['day_count'],
                environment=env
            )
            keyword_mapper.main()
        except Exception as exception:
            print(exception)
            continue
