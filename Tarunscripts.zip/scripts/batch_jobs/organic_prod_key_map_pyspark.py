# This job can run only on DataBricks
from config import Config
from datetime import datetime, timedelta
from util.meta_data_extractor import MetaDataExtractor
import argparse
import pyspark.sql.functions as f
from pyspark.sql.window import Window
from util.read_write_data_azure_blob import ReadAndWriteFromAzureBlob
from pyspark.sql import SparkSession


class OrganicKeywordProductMapper:
    def __init__(self, time_delta, environment):
        Config.switch_env(environment)
        print(
            "Running for environment - {}".format(
                Config.AzureConfig.ENV
            )
        )
        self.current_run = datetime.strftime(
            datetime.now() - timedelta(time_delta), "year=%Y/month=%m/day=%d"
        )
        self.retailers = self._get_retailers_for_aggregation()
        self.read_write_azure = ReadAndWriteFromAzureBlob()

    @staticmethod
    def _get_retailers_for_aggregation():
        retailer_ids = []
        all_meta = MetaDataExtractor.get_retailer_matadata()
        for retailer in all_meta:
            retailer_ids.append(retailer['_id'])
        return retailer_ids

    def _get_organic_data(self, spark, retailer_id, event_type):
        spark.conf.set(
            "fs.azure.account.key." +
            Config.AzureConfig.ENGG_ACCOUNT_NAME +
            ".dfs.core.windows.net",
            Config.AzureConfig.ENGG_ACCOUNT_KEY
        )
        df = spark.read.format(
            "com.databricks.spark.avro"
        ).load(
            Config.AzureConfig.ORGANIC_DATABRICKS_PATH.format(
                retailer_id, event_type, self.current_run
            )
        )
        return df

    def _write_to_azure(self, retailer_id, count_df):
        count_df = count_df.toPandas()
        self.read_write_azure.write_to_blob(
            Config.AzureConfig.RECOMMENDATION_OUT_STRING,
            Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME,
            "retailer_id={}/{}/OrganicProductKeywordMap.csv".format(
                retailer_id, self.current_run
            ),
            count_df
        )

    def main(self):
        spark = SparkSession.builder.enableHiveSupport().getOrCreate()
        spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
        spark.conf.set("spark.sql.execution.arrow.pyspark.enabled", "true")

        for retailer in self.retailers:
            try:
                message = "Processing retailer - {}".format(retailer)
                print(message)

                # Getting Search data
                search_data = self._get_organic_data(
                    spark, retailer, "search"
                )
                search_df = search_data.withColumn(
                    "guest_id", f.col("user.guest_id")
                )
                search_df = search_df.select(
                    "guest_id", "keyword", "event_timestamp"
                )

                # Getting ATC data
                atc_data = self._get_organic_data(
                    spark, retailer, "add-to-cart"
                )
                atc_df = atc_data.withColumn(
                    "guest_id", f.col("user.guest_id")
                )

                # Extracting products that were added to cart
                atc_df = atc_df.withColumn(
                    "product_id", f.col("items.product_id")[0]
                )
                atc_df = atc_df.select(
                    "guest_id", "product_id", "event_timestamp"
                )

                # Adding event type as columns
                search_df = search_df.withColumn("event_type", f.lit("search"))
                atc_df = atc_df.withColumn("event_type", f.lit("atc"))

                # Concatenating the dataframes and sorting them
                n_df = search_df.union(atc_df)
                n_df = n_df.orderBy(["guest_id", "event_timestamp"])

                # Creating window for partitioning
                w = Window().partitionBy().orderBy(
                    ['guest_id', 'event_timestamp']
                )

                # Adding n+1 row as new columns for filtering
                df = n_df.select(
                    "*",
                    f.lag("event_type").over(w).alias("event_type_2"),
                    f.lag("guest_id").over(w).alias("guest_id_2"),
                    f.lag("keyword").over(w).alias("keyword_2"),
                    f.lag("event_timestamp").over(w).alias("event_timestamp_2")
                )

                # Filtering only add to carts that are done after search
                df = df.filter(
                    (df.guest_id == df.guest_id_2) &
                    (df.event_type == "atc") &
                    (df.event_type_2 == "search") &
                    ((df.event_timestamp_2 - df.event_timestamp) <= 300)
                )
                df = df.select("keyword_2", "keyword")
                df = df.toDF(*["keyword", "product"])

                # Getting count of keyword <> product mapping
                count_df = df.groupBy(["keyword", "product"]).count()
                count_df = count_df.toDF(*["Keyword", "Product", "Count"])

                # Writing to Azure Container
                self._write_to_azure(retailer, count_df)

            except Exception as e:
                print(e)
                continue


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description='Organic Product Keyword Mapper'
    )
    parser.add_argument('-d', '--day_count', type=int, default=1,
                        help='Number of days to look backward from current '
                             'date for suggestions')
    parser.add_argument('-env', '--environment', type=str,
                        default='prod',
                        help='List of environments to run debug aggregation')
    parser.add_argument('-databricks', '--databricks', type=bool,
                        default=False,
                        help="The script can run only in Databricks")
    input_args = vars(parser.parse_args())
    if input_args['databricks']:
        print(input_args)
        for env in input_args['environment'].strip().split(','):
            try:
                OrganicMapper = OrganicKeywordProductMapper(
                    time_delta=input_args['day_count'],
                    environment=env
                )
                OrganicMapper.main()
            except Exception as exception:
                print(exception)
                continue
    else:
        print("The script will not run outside of Databricks environment")
