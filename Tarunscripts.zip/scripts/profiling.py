# pylint: disable=all
import cProfile, pstats, io
from pstats import SortKey
from context.context import Context
from relevance.relevance_engine import RelevanceEngine
from bidding.auto_bidder import AutoBidder


Context.init()
relevance_engine = RelevanceEngine()
auto_bidder = AutoBidder()

def __query():
    queries = ['apples from usa', "apples under $40", "carrots by grimmway",
    ]
    pr = cProfile.Profile()
    pr.enable()
    for query in queries:
        retailer = Context.get_retailer(123456)
        if query.startswith("sku="):
            result = relevance_engine.get_products_by_product(retailer, 
                                        query.split('=', 1)[1].strip())
        else:
            result = relevance_engine.get_products_by_query(retailer, query, 10)
      
    pr.disable()
    s = io.StringIO()
    sortby = SortKey.CUMULATIVE
    ps = pstats.Stats(pr, stream=s).sort_stats(sortby)
    ps.print_stats()
    print(type(s.getvalue()))

__query()
