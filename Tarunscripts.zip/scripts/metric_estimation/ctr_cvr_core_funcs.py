from util.azure_batch_logger import BatchLog
import pandas as pd
from io import BytesIO
from datetime import date, timedelta
from azure.storage.blob import BlobServiceClient
from config import Config
from util.keyword_targetting_utils import KeywordHash
from metric_estimation.metric_estimator import MetricsEstimator


class GetCTRCVRData:
    _DATE_TIME = 'date_time'
    _RETAILER_ID = 'retailer_id'
    _PROD_ID = 'prodId'
    _SKU = 'sku'
    _AD_TYPE = 'adType'
    _TARGETING_TYPE = 'targetingType'
    _TARGETING_VALUE = 'targetingValue'
    _COLS_TO_SELECT = ['prodId', 'campaignId', 'targetingType',
                       'targetingValue', 'adType',
                       'placementId', 'sales',
                       'impressionCount', 'clickCount',
                       'conversionCount', 'date_time',
                       'retailer_id']

    def __init__(self, time_delta, environment):
        Config.switch_env(environment)
        self.time_delta = time_delta
        self.container_client = self.__container_client()

    @staticmethod
    def __container_client():
        blob_service_client = BlobServiceClient.from_connection_string(
            Config.AzureConfig.CTR_CVR_INPUT_CONNECTION_STRING)
        container_client = blob_service_client.get_container_client(
            Config.AzureConfig.CTR_CVR_INPUT_CONTAINER)
        return container_client

    def get_past_days_files(self, retailer_id):
        look_back_directory = "facts/daily-summaries/" \
                              "daily_product_tracking_summary/retailerId={}/" \
                              "event_time={} 00%3A00%3A00/"
        today = date.today()
        look_back = today - timedelta(days=self.time_delta)
        delta = today - look_back
        meta_files = []

        print("clickstream data look back window", self.time_delta)
        print("clickstream data start date", look_back)
        print(
            "clickstream data end date", (look_back + timedelta(delta.days-1))
        )

        for i in range(delta.days):
            meta_files.extend(list(self.container_client.list_blobs(
                name_starts_with=look_back_directory.format(retailer_id, (
                        look_back + timedelta(days=i)).strftime(
                    '%Y-%m-%d')))))
        meta_files = [
            file['name'] for file in meta_files if '.parquet' in file['name']
        ]

        return meta_files

    def get_raw_data(self, retailer_id, metric_type, attribution_window=None):
        ad_type_to_code = {1: "NATIVE", 2: "VIDEO", 3: "SHOPPABLE_VIDEO",
                           4: "REELS"}
        targeting_type_to_code = {1: "KEYWORD", 2: "CATEGORY", 3: "PRODUCT"}

        files = self.get_past_days_files(retailer_id)
        dataframe = pd.DataFrame()

        if files:
            message = "Files for retailer - {retailer_id} are available for {log_str} " \
                      "estimation, proceeding with calculations".format(
                retailer_id=retailer_id,
                log_str=metric_type
            )

            BatchLog.info(message)
            print(message)

            for file in files:
                current_file_date = file.split('event_time=')[1].split()[0]
                blob_client = self.container_client.get_blob_client(blob=file)
                stream_downloader = blob_client.download_blob()
                stream = BytesIO()
                stream_downloader.readinto(stream)
                temp_df = pd.read_parquet(stream, engine='pyarrow')
                temp_df[self._DATE_TIME] = current_file_date
                dataframe = pd.concat([dataframe, temp_df],
                                      ignore_index=True)

            if not dataframe.empty:
                message = "Raw data for retailer - {retailer_id} are available for {log_str} " \
                          "estimation, proceeding with calculations".format(
                    retailer_id=retailer_id,
                    log_str=metric_type
                )
                BatchLog.info(message)
                print(message)

                dataframe[self._DATE_TIME] = pd.to_datetime(
                    dataframe[self._DATE_TIME], infer_datetime_format=True)
                dataframe[self._RETAILER_ID] = retailer_id

                dataframe = dataframe[self._COLS_TO_SELECT]
                dataframe[self._PROD_ID] = dataframe[self._PROD_ID].apply(
                    lambda x: str(x).lower())
                dataframe = dataframe[dataframe[self._PROD_ID].str.len() > 0]
                dataframe.reset_index(inplace=True, drop=True)
                dataframe.rename(columns={self._PROD_ID: self._SKU},
                                 inplace=True)
                dataframe[self._AD_TYPE] = dataframe[self._AD_TYPE].map(
                    ad_type_to_code)
                dataframe[self._TARGETING_TYPE] = dataframe[
                    self._TARGETING_TYPE].map(targeting_type_to_code)
                dataframe[self._TARGETING_TYPE] = dataframe[self._TARGETING_TYPE].str.lower()
                dataframe[self._TARGETING_VALUE] = dataframe[self._TARGETING_VALUE].str.lower()
            else:
                message = "Raw data for retailer - {retailer_id} is not available for " \
                          "{log_str} estimation, not proceeding with " \
                          "calculations".format(retailer_id=retailer_id,
                                                log_str=metric_type)
                BatchLog.info(message)
                print(message)
        else:
            message = "Files for retailer - {retailer_id} are not available for {log_str} " \
                      "estimation, not proceeding with calculations".format(
                retailer_id=retailer_id,
                log_str=metric_type
            )
            BatchLog.info(message)
            print(message)

        return dataframe


class SoftAdpation:
    __CLICKS_THRESHOLD = 100
    __CLICKS_THRESHOLD_STR = 'cvr_prior_clicks_threshold'
    __IMPRESSION_THRESHOLD = 1000
    __IMPRESION_THESHOLD_STR = 'ctr_prior_impressions_threshold'
    # TODO check if default cvr is required
    __DEFAULT_CVR = 0
    __DEFAULT_CTR = 0

    def __init__(self):
        self.metric_estimator = MetricsEstimator()

    def soft_adapted_metric(self, prior_metric_bias, sample_size_bias,
                            metric_current_count, current_sample_size
                            ):
        return (metric_current_count + prior_metric_bias * sample_size_bias) / (
                current_sample_size + sample_size_bias)

    def estimated_probablility(self, prior_metric_bias, sample_size_bias,
                               metric_current_count, current_sample_size,
                               default_metric_value
                               ):
        # bounding metric by 1
        if current_sample_size > sample_size_bias:
            return min(max(
                metric_current_count / current_sample_size,
                default_metric_value
            ), 1)
        else:
            return min(
                self.soft_adapted_metric(
                    prior_metric_bias,
                    sample_size_bias,
                    metric_current_count,
                    current_sample_size
                ),
                1
            )

    def calculate_cvr(
            self, clicks, conversions, retailer, target_type,
            target_value, targets, sku
    ):
        clicks_prior = retailer.meta_data.get(
            self.__CLICKS_THRESHOLD_STR,
            self.__CLICKS_THRESHOLD
        )
        prior_cvr = None
        if clicks <= clicks_prior:
            prior_cvr = self.metric_estimator.get_metric_for_multi_sku(
                retailer, "pc_cvr_est_from_data", target_type, target_value.lower(), targets).get(sku)

        return self.estimated_probablility(
            prior_cvr,
            clicks_prior,
            conversions,
            clicks,
            self.__DEFAULT_CVR
        )

    def calculate_ctr(
            self, impressions, clicks, retailer, target_type,
            target_value, targets, sku
    ):
        impressions_prior = retailer.meta_data.get(
            self.__IMPRESION_THESHOLD_STR,
            self.__IMPRESSION_THRESHOLD
        )
        prior_ctr = None
        if impressions <= impressions_prior:
            prior_ctr = self.metric_estimator.get_metric_for_multi_sku(
                retailer, "ctr", target_type, target_value.lower(), targets).get(sku)

        return self.estimated_probablility(
            prior_ctr,
            impressions_prior,
            clicks,
            impressions,
            self.__DEFAULT_CTR
        )

    def get_cvr_at_sku_level(
            self, x, click_threshold, conversion_threshold, clicks_col_name,
            conversions_col_name, sku_cvr_col_name, scale_factor=0.9):
        """
        Returns at cvr sku level if there are enough clicks else if there are atleast conversion_threshold conversions .
        This is used as prior later on at sku_target value level. If both conditions aren't met then
        prior is based on retailer level bias that will be pulled during metric estimation flow
        """
        if x[sku_cvr_col_name]==0:
            x[sku_cvr_col_name] = 0.0001
        if x[clicks_col_name] > click_threshold:
            return [x[sku_cvr_col_name], x[sku_cvr_col_name]]
        else:
            if x[conversions_col_name] >= conversion_threshold:
                return [x[sku_cvr_col_name] * scale_factor, x[sku_cvr_col_name]]
        return None


class GetTargetsForSKU:
    __HASH = 'hash'
    __TARGET = 'target'
    __REL_SCORE = 'relevance_score'
    __SKU = 'sku'
    __CATEGORY = 'category'
    __KEYWORD = 'keyword'
    __TARGET_KEY_MAP = {'keyword': 'hash', 'product': 'sku', 'category': 'category'}
    __TARGETING_VALUE = 'targetingValue'
    __TARGETING_TYPE = 'targetingType'
    __SKU_TARGET_REL_SCORE = 'relevance_score'
    __TARGETS = 'targets'

    def format_targets_nd_relvance_scores(self, rel_mongo_client, sku_list, target_type):
        targets_and_relevance_scores = {}
        target_key_str = self.__TARGET_KEY_MAP[target_type]
        for product_id in sku_list:
            try:
                targets = rel_mongo_client.get_document(product_id)
                for target in targets[self.__TARGET]:
                    targets_and_relevance_scores[
                        str(product_id) + "_" + target[target_key_str].lower()
                        ] = target[self.__REL_SCORE]
            except Exception as e:
                message = "Getting targets failed for {sku},{target_type}, " \
                          "exception: {exception}".format(
                    sku=product_id,
                    exception=e,
                    target_type=target_type
                )
                print(message)
                BatchLog.info(message)

        return targets_and_relevance_scores

    def get_all_keyword_targets_for_sku_list(self, retailer, sku_list):
        return self.format_targets_nd_relvance_scores(
            retailer.product_to_broad_hash_mongo_client,
            sku_list,
            'keyword'
        )

    def get_all_product_targets_for_sku_list(self, retailer, sku_list):
        return self.format_targets_nd_relvance_scores(
            retailer.product_mongo_client,
            sku_list,
            'product'
        )

    def get_all_category_targets_for_sku_list(self, retailer, sku_list):
        return self.format_targets_nd_relvance_scores(
            retailer.category_mongo_client,
            sku_list,
            'category'
        )

    def get_all_targets_for_sku_list(self, retailer, sku_list):
        return {
            'keyword': self.get_all_keyword_targets_for_sku_list(
                retailer, sku_list.get('keyword', [])
            ),
            'product': self.get_all_product_targets_for_sku_list(
                retailer, sku_list.get('product', [])
            ),
            'category': self.get_all_category_targets_for_sku_list(
                retailer, sku_list.get('category', [])
            )
        }


class CTRCVRDataAggregations:
    __SKU = 'sku'
    __KEYWORD = 'keyword'
    __PRODUCT = 'product'
    __CATEGORY = 'category'
    __TARGETING_VALUE = 'targetingValue'
    __TARGETING_TYPE = 'targetingType'
    __SKU_TARGET_REL_SCORE = 'relevance_score'
    __TARGETS = 'targets'
    __RETAILER_ID = 'retailer_id'
    __CLICKS = 'clickCount'
    __CONVERSIONS = 'conversionCount'
    __IMPRESSIONS = 'impressionCount'
    __MEAN_STR = "{metric_name}_mean"
    __STD_STR = "{metric_name}_std"
    __MAX_STR = "{metric_name}_max"
    __MIN_STR = "{metric_name}_min"
    __LB = 'lb'
    __UB = 'ub'
    __SKU_LEVEL = 'sku_level'
    __AGG_LEVEL = 'aggregation_level'
    __RETAILER_LEVEL = 'retailer_level'
    __REDIS_FORMAT = 'redis_format_output'
    __CAMPAIGN_ID = 'campaignId'
    __TARGETING_TYPES = ['keyword', 'product', 'category']

    def __init__(self):
        self.get_targets = GetTargetsForSKU()

    def hash_nd_aggregate(self, df):
        keyword_hash = KeywordHash()

        df[self.__TARGETING_VALUE] = df.apply(
            lambda x: keyword_hash.get_keyword_hash(x[self.__TARGETING_VALUE]) if
            x[self.__TARGETING_TYPE] == self.__KEYWORD else
            x[self.__TARGETING_VALUE], axis=1
        )

        df = df.groupby(
            by=[self.__RETAILER_ID,
                self.__CAMPAIGN_ID,
                self.__SKU,
                self.__TARGETING_VALUE,
                self.__TARGETING_TYPE], as_index=False
        )[[self.__IMPRESSIONS, self.__CLICKS, self.__CONVERSIONS]].sum()

        df = df[df[self.__IMPRESSIONS] > 0]

        df = df.groupby(
            by=[self.__RETAILER_ID,
                self.__SKU,
                self.__TARGETING_VALUE,
                self.__TARGETING_TYPE], as_index=False
        )[[self.__IMPRESSIONS, self.__CLICKS, self.__CONVERSIONS]].sum()

        return df

    def get_sku_target_rel_score(self, df, retailer):
        sku_map = {}
        for each in self.__TARGETING_TYPES:
            sku_map[each] = df[df[self.__TARGETING_TYPE] == each][self.__SKU].unique()

        all_sku_rel_score_map = self.get_targets.get_all_targets_for_sku_list(
            retailer,
            sku_map
        )

        df[self.__SKU_TARGET_REL_SCORE] = df.apply(
            lambda x: all_sku_rel_score_map.get(
                x[self.__TARGETING_TYPE]).get(x[self.__SKU] + "_" + x[self.__TARGETING_VALUE]),
            axis=1
        )

        # replacing with None as its further taken care in metric estimation
        df[self.__TARGETS] = df.apply(
            lambda x: (
                {x[self.__SKU]: None} if str(x[self.__SKU_TARGET_REL_SCORE]) == 'nan' else
                {x[self.__SKU]: x[self.__SKU_TARGET_REL_SCORE]}), axis=1
        )

        return df

    def run_preprocess_data(self, df, retailer):
        df = self.hash_nd_aggregate(df)
        df = self.get_sku_target_rel_score(df, retailer)
        return df

    def redis_formating(self, redis_key, metric_lb, metric_ub):
        return {redis_key: [metric_lb, metric_ub]}

    def high_level_aggregation(self, data, metric_name, groupby_cols):
        high_level_agg = data.groupby(
            by=groupby_cols).agg(
            {metric_name: ["mean", "std", "min", "max"]}
        ).reset_index()

        self.__MEAN_STR = self.__MEAN_STR.format(metric_name=metric_name)
        self.__STD_STR = self.__STD_STR.format(metric_name=metric_name)
        self.__MAX_STR = self.__MAX_STR.format(metric_name=metric_name)
        self.__MIN_STR = self.__MIN_STR.format(metric_name=metric_name)

        high_level_agg.columns = groupby_cols + [
            self.__MEAN_STR, self.__STD_STR, self.__MIN_STR, self.__MAX_STR
        ]

        # dropping na as we would be overestimating with only one data point
        high_level_agg = high_level_agg[~high_level_agg[self.__STD_STR].isna()]
        high_level_agg[self.__LB] = high_level_agg[self.__MEAN_STR] - high_level_agg[self.__STD_STR]
        high_level_agg[self.__UB] = high_level_agg[self.__MEAN_STR] + high_level_agg[self.__STD_STR]

        # bounding by min and max to keep ranges between real bounds when there is less data
        high_level_agg[self.__LB] = high_level_agg.apply(
            lambda x: round(max(x[self.__LB], x[self.__MIN_STR]), 4), axis=1)
        high_level_agg[self.__UB] = high_level_agg.apply(
            lambda x: round(min(x[self.__UB], x[self.__MAX_STR]), 4), axis=1)

        return high_level_agg

    def create_redis_format_output(self, df, redis_key_map, aggregation_level, aggregation_cols):
        df[self.__AGG_LEVEL] = aggregation_level

        if len(aggregation_cols) == 2:
            df[self.__REDIS_FORMAT] = df.apply(
                lambda x: self.redis_formating(
                    redis_key_map.get(x[self.__AGG_LEVEL])(
                        x[aggregation_cols[0]], x[aggregation_cols[1]]
                    ),
                    x[self.__LB],
                    x[self.__UB]
                ), axis=1
            )
        else:
            df[self.__REDIS_FORMAT] = df.apply(
                lambda x: self.redis_formating(
                    redis_key_map.get(x[self.__AGG_LEVEL])(
                        x[aggregation_cols[0]]
                    ),
                    x[self.__LB],
                    x[self.__UB]
                ), axis=1
            )

        return list(df[self.__REDIS_FORMAT].values)

    def higher_level_metric_estimation(self, data, redis_key_map, metric_type,
                                       aggregation_level, aggregation_cols
                                       ):
        higher_level_estimations = self.high_level_aggregation(
            data,
            metric_type,
            aggregation_cols
        )

        return self.create_redis_format_output(
            higher_level_estimations,
            redis_key_map,
            aggregation_level,
            aggregation_cols
        )

    def aggregate_for_cvr(self, data, groupby_cols, cvr_col_name):
        aggregated_df = data.groupby(
            by=groupby_cols, as_index=False)[
            [self.__IMPRESSIONS, self.__CLICKS, self.__CONVERSIONS]].sum()
        aggregated_df[cvr_col_name] = (aggregated_df[self.__CONVERSIONS] / aggregated_df[self.__CLICKS])
        aggregated_df[cvr_col_name] = aggregated_df[cvr_col_name].apply(lambda x: min(x, 1))

        return aggregated_df
