from util.azure_batch_logger import BatchLog
import argparse
import datetime
from datetime import date, timedelta
from util.redis_utils import RedisUtil, RedisKeyGen
from util.meta_data_extractor import MetaDataExtractor
from util.read_write_data_azure_blob import ReadAndWriteFromAzureBlob
from config import Config
from metric_estimation.ctr_cvr_core_funcs import GetCTRCVRData, SoftAdpation
from metric_estimation.ctr_cvr_core_funcs import GetTargetsForSKU, CTRCVRDataAggregations
from context.context import Context


class CtrAggregator:
    _TARGETING_TYPE = 'targetingType'
    _TARGETING_VALUE = 'targetingValue'
    _CLICKS = 'clickCount'
    _CTR = 'ctr'
    _IMPRESSIONS = 'impressionCount'
    _SKU = 'sku'
    _KEYWORD = 'keyword'
    _CATEGORY = 'category'
    _PRODUCT = 'product'
    _RETAILER_ID = 'retailer_id'
    _LB = 'lb'
    _UB = 'ub'
    _TARGETS = 'targets'
    _REDIS_FORMAT = 'redis_format_output'
    _AGG_LEVEL = 'aggregation_level'
    _SKU_LEVEL = 'sku_level'
    _RETAILER_LEVEL = 'retailer_level'
    _IMPRESSION_NOISE_THRESHOLD = 10

    _REDIS_KEY_MAP = {
        'sku_keyword': RedisKeyGen.get_ctr_sku_keyword_key,
        'sku_product': RedisKeyGen.get_ctr_sku_sku_key,
        'sku_category': RedisKeyGen.get_ctr_sku_category_key,
        'sku_level': RedisKeyGen.get_ctr_sku_key,
        'category_level': RedisKeyGen.get_ctr_catg_key,
        'retailer_level': RedisKeyGen.get_ctr_retailer_key
    }

    def __init__(self, time_delta, environment):
        Config.switch_env(environment)
        print(
            "Running for environment - {}".format(
                Config.AzureConfig.ENV)
        )
        self.redis_client = RedisUtil(Config.AzureConfig.REDIS_HOST_NAME,
                                      Config.AzureConfig.REDIS_PASSWORD)
        self.read_write_blob = ReadAndWriteFromAzureBlob()
        self.get_ctr_cvr_data = GetCTRCVRData(time_delta, environment)
        self.data_aggregations = CTRCVRDataAggregations()
        self.soft_adaption = SoftAdpation()

    def compute_ctr(self, data, retailer_obj):
        ctr_estimation = []
        data = self.data_aggregations.run_preprocess_data(data, retailer_obj)
        # filtering to avoid any data noise
        data = data[(data[self._IMPRESSIONS] > self._IMPRESSION_NOISE_THRESHOLD)]
        data[self._CTR] = data.apply(
            lambda x: self.soft_adaption.calculate_ctr(
                x[self._IMPRESSIONS],
                x[self._CLICKS],
                retailer_obj,
                x[self._TARGETING_TYPE],
                x[self._TARGETING_VALUE],
                x[self._TARGETS],
                x[self._SKU]
            ),
            axis=1
        )

        data[self._AGG_LEVEL] = self._SKU + "_" + data[self._TARGETING_TYPE]

        data[self._REDIS_FORMAT] = data.apply(
            lambda x: self.data_aggregations.redis_formating(
                self._REDIS_KEY_MAP.get(x[self._AGG_LEVEL])(
                    x[self._RETAILER_ID],
                    x[self._SKU],
                    x[self._TARGETING_VALUE]
                ),
                x[self._CTR],
                x[self._CTR]
            ), axis=1
        )
        ctr_estimation = ctr_estimation + list(data[self._REDIS_FORMAT].values)

        # sku level estimation
        sku_level_estimations = self.data_aggregations.higher_level_metric_estimation(
            data,
            self._REDIS_KEY_MAP,
            self._CTR,
            self._SKU_LEVEL,
            [self._RETAILER_ID, self._SKU]
        )

        ctr_estimation = ctr_estimation + sku_level_estimations

        # retailer level estimation
        retailer_level_estimations = self.data_aggregations.higher_level_metric_estimation(
            data,
            self._REDIS_KEY_MAP,
            self._CTR,
            self._RETAILER_LEVEL,
            [self._RETAILER_ID]
        )

        ctr_estimation = ctr_estimation + retailer_level_estimations

        return ctr_estimation

    def push_to_redis(self, estimation_dict):
        if estimation_dict:
            for estimations in estimation_dict:
                for key, value in estimations.items():
                    self.redis_client.set_value(key, value)

    def main(self):
        message = "Starting CTR estimation"
        BatchLog.info(message)
        print(message)
        retailers = MetaDataExtractor.get_retailer_list_for_job(
            "ctr_estimation"
        )
        Context.init(
            list(map(int, retailers)),
            lite_mode=False,
            init_mongo_clients=True,
            download_data=False,
            download_models=False
        )
        if retailers:
            for retailer_id in retailers:
                try:
                    retailer_obj = Context.get_retailer(int(retailer_id))
                    data_input = self.get_ctr_cvr_data.get_raw_data(
                        retailer_id,
                        self._CTR
                    )
                    estimated_ctr = self.compute_ctr(data_input, retailer_obj)
                    if estimated_ctr:
                        self.redis_client.delete_keys_with_pattern(
                            "{}_ctr_{}_*".format(
                                Config.AzureConfig.ENV,
                                str(retailer_id)
                            )
                        )
                        BatchLog.info(
                            "{} - {}".format(retailer_id, estimated_ctr)
                        )
                        self.push_to_redis(estimated_ctr)
                        message = "Successfully estimated CTR for retailer " \
                                  "- {}".format(retailer_id)
                        BatchLog.info(message)
                        print(message)
                    else:
                        message = "No CTR available for retailer - {}".format(
                            retailer_id)
                        BatchLog.info(message)
                        print(message)
                except Exception as e:
                    message = "Unable to estimate CTR for the retailer " \
                              "{} as data may not be available with error " \
                              "message {}".format(retailer_id, e)
                    BatchLog.info(message)
                    print(message)

        message = "CTR Estimation has been completed"
        BatchLog.info(message)
        print(message)

        date_string_split = datetime.datetime.strftime(
            datetime.datetime.now() - timedelta(1),
            '%Y/%m/%d').split('/')

        # Write logs to Blob
        log_file = "BatchJobLogs/year={}/month={}/day={}/" \
                   "CTREstimationJob.log".format(
            date_string_split[0],
            date_string_split[1],
            date_string_split[2])
        self.read_write_blob.write_log_to_blob(
            Config.AzureConfig.RECOMMENDATION_OUT_STRING,
            Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME,
            log_file)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description='Calculates Rolling CTR for All Retailers')
    parser.add_argument('-d', '--day_count', type=int, default=14,
                        help='Number of days to look backward from current '
                             'date for calculating rolling CTR')
    parser.add_argument('-env', '--environment', type=str,
                        default='dev,qa,uat',
                        help='List of environments to run ctr estimation')
    input_args = vars(parser.parse_args())
    for env in input_args['environment'].strip().split(','):
        try:
            CTRCalculator = CtrAggregator(
                time_delta=input_args['day_count'],
                environment=env)
            CTRCalculator.main()
        except Exception as exception:
            print(exception)
            continue
