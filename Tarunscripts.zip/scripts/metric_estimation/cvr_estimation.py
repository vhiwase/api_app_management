from util.azure_batch_logger import BatchLog
import argparse
import datetime
from datetime import timedelta
from util.redis_utils import RedisUtil, RedisKeyGen
from util.meta_data_extractor import MetaDataExtractor
from util.read_write_data_azure_blob import ReadAndWriteFromAzureBlob
from metric_estimation.ctr_cvr_core_funcs import GetCTRCVRData, SoftAdpation
from metric_estimation.ctr_cvr_core_funcs import GetTargetsForSKU, CTRCVRDataAggregations
from config import Config
from context.context import Context


class CvrAggregator:
    _TARGETING_TYPE = 'targetingType'
    _TARGETING_VALUE = 'targetingValue'
    _CLICKS = 'clickCount'
    _CONVERSIONS = 'conversionCount'
    _CVR = 'cvr'
    _IMPRESSIONS = 'impressionCount'
    _SKU = 'sku'
    _RETAILER_ID = 'retailer_id'
    _LB = 'lb'
    _UB = 'ub'

    _SKU_TARGET_REL_SCORE = 'relevance_score'
    _TARGETS = 'targets'
    _REDIS_FORMAT = 'redis_format_output'
    _AGG_LEVEL = 'aggregation_level'
    _SKU_LEVEL = 'sku_level'
    _RETAILER_LEVEL = 'retailer_level'
    _SKU_CVR = 'sku_cvr'
    _CATG_CVR = 'category_cvr'
    _CLICKS_THRESHOLD_STR = 'cvr_prior_clicks_threshold'
    _CONV_THRESHOLD_STR = 'cvr_est_min_conversions'
    _SKU_CVR_RANGE = 'sku_cvr_range'

    _REDIS_KEY_MAP = {
        'sku_keyword': RedisKeyGen.get_pc_cvr_sku_keyword_key,
        'sku_product': RedisKeyGen.get_pc_cvr_sku_sku_key,
        'sku_category': RedisKeyGen.get_pc_cvr_sku_category_key,
        'sku_level': RedisKeyGen.get_pc_cvr_sku_key,
        'category_level': RedisKeyGen.get_pc_cvr_category_key,
        'retailer_level': RedisKeyGen.get_pc_cvr_retailer_key
    }

    _IMPRESSION_NOISE_THRESHOLD = 10
    _CLICKS_THRESHOLD = 100
    _MIN_CONV_FOR_CVR_EST = 10
    _MIN_CONV_EST_SKU_CVR_SCALE_FACTOR = 0.9

    def __init__(self, time_delta, environment):
        Config.switch_env(environment)
        print(
            "Running for environment - {}".format(
                Config.AzureConfig.ENV)
        )
        self.redis_client = RedisUtil(Config.AzureConfig.REDIS_HOST_NAME,
                                      Config.AzureConfig.REDIS_PASSWORD)
        self.retailer_metadata = MetaDataExtractor.get_retailer_matadata()
        self.read_write_blob = ReadAndWriteFromAzureBlob()
        self.get_ctr_cvr_data = GetCTRCVRData(time_delta, environment)
        self.data_aggregations = CTRCVRDataAggregations()
        self.soft_adaption = SoftAdpation()

    def __extract_attribution_window(self, retailer_id):
        for retailer in self.retailer_metadata:
            if retailer['_id'] == retailer_id:
                if retailer.get('attribution_window'):
                    return retailer['attribution_window']
                else:
                    return 14

    def estimate_cvr_at_sku_level(self, retailer_obj, data):
        # sku level aggregation
        sku_level_aggregation = self.data_aggregations.aggregate_for_cvr(
            data, [self._RETAILER_ID, self._SKU], self._SKU_CVR
        )

        # threshold of estimating cvr
        clicks_threshold = retailer_obj.meta_data.get(
            self._CLICKS_THRESHOLD_STR,
            self._CLICKS_THRESHOLD
        )

        # threshold of estimating cvr
        conversion_threshold = retailer_obj.meta_data.get(
            self._CONV_THRESHOLD_STR,
            self._MIN_CONV_FOR_CVR_EST
        )

        sku_level_aggregation[self._SKU_CVR_RANGE] = sku_level_aggregation.apply(
            lambda x: self.soft_adaption.get_cvr_at_sku_level(
                x, clicks_threshold, conversion_threshold, self._CLICKS,
                self._CONVERSIONS, self._SKU_CVR, self._MIN_CONV_EST_SKU_CVR_SCALE_FACTOR
            ), axis=1
        )

        # removing rows without any prior range estimation
        sku_level_aggregation = sku_level_aggregation[~sku_level_aggregation[self._SKU_CVR_RANGE].isna()]
        sku_level_aggregation[self._LB] = sku_level_aggregation[self._SKU_CVR_RANGE].apply(lambda x: x[0])
        sku_level_aggregation[self._UB] = sku_level_aggregation[self._SKU_CVR_RANGE].apply(lambda x: x[1])
        sku_level_estimates = self.data_aggregations.create_redis_format_output(
            sku_level_aggregation,
            self._REDIS_KEY_MAP,
            self._SKU_LEVEL,
            [self._RETAILER_ID, self._SKU]
        )

        return sku_level_estimates

    def compute_pc_cvr(self, data, retailer_obj, retailer_id):
        cvr_estimations = []
        data = self.data_aggregations.run_preprocess_data(data, retailer_obj)

        # filtering to avoid any data discrepancies
        data = data[(data[self._CLICKS] > 0) & (data[self._IMPRESSIONS] > 0)]

        # sku level estimation
        sku_level_estimations = self.estimate_cvr_at_sku_level(
            retailer_obj, data.copy(deep=True)
        )

        # pushing sku level estimation so that it can be used as prior for sku_target_value level further
        if len(sku_level_estimations) > 0:
            self.push_to_redis(sku_level_estimations)
            message = "Estimated SKU LEVEL CVR for retailer " \
                      "- {}".format(retailer_id)

            BatchLog.info(message)
            print(message)


        # Estimating CVR of sku target value level by taking sku level estimates as prior
        data[self._CVR] = data.apply(
            lambda x: self.soft_adaption.calculate_cvr(
                x[self._CLICKS],
                x[self._CONVERSIONS],
                retailer_obj,
                x[self._TARGETING_TYPE],
                x[self._TARGETING_VALUE],
                x[self._TARGETS],
                x[self._SKU]
            ),
            axis=1
        )

        data[self._AGG_LEVEL] = self._SKU + "_" + data[self._TARGETING_TYPE]

        data[self._REDIS_FORMAT] = data.apply(
            lambda x: self.data_aggregations.redis_formating(
                self._REDIS_KEY_MAP.get(x[self._AGG_LEVEL])(
                    x[self._RETAILER_ID],
                    x[self._SKU],
                    x[self._TARGETING_VALUE]
                ),
                x[self._CVR],
                x[self._CVR]
            ), axis=1
        )
        cvr_estimations = cvr_estimations + list(data[self._REDIS_FORMAT].values)

        return cvr_estimations

    def push_to_redis(self, estimation_dict):
        if estimation_dict:
            for estimations in estimation_dict:
                for key, value in estimations.items():
                    self.redis_client.set_value(key, value)

    def main(self):
        message = "Starting CVR estimation"
        BatchLog.info(message)
        print(message)
        retailers = MetaDataExtractor.get_retailer_list_for_job(
            "cvr_estimation"
        )
        Context.init(
            list(map(int, retailers)),
            lite_mode=False,
            init_mongo_clients=True,
            download_data=False,
            download_models=False
        )
        if retailers:
            for retailer_id in retailers:
                try:
                    retailer_obj = Context.get_retailer(int(retailer_id))
                    data_input = self.get_ctr_cvr_data.get_raw_data(
                        retailer_id,
                        self._CVR
                    )
                    estimated_cvr = self.compute_pc_cvr(data_input,
                                                        retailer_obj,
                                                        retailer_id
                                                        )
                    if estimated_cvr:
                        self.push_to_redis(estimated_cvr)
                        BatchLog.info(
                            "{} - {}".format(retailer_id, estimated_cvr)
                        )
                        message = "Successfully estimated CVR for retailer " \
                                  "- {}".format(retailer_id)
                        BatchLog.info(message)
                        print(message)
                    else:
                        message = "No CVR available for retailer - {}".format(
                            retailer_id)
                        BatchLog.info(message)
                        print(message)
                except Exception as e:
                    message = "Unable to estimate CVR for the retailer " \
                              "{} as data may not be available with error " \
                              "message {}".format(retailer_id, e)
                    BatchLog.info(message)
                    print(message)

        message = "CVR Estimation is complete"
        BatchLog.info(message)
        print(message)

        date_string_split = datetime.datetime.strftime(
            datetime.datetime.now() - timedelta(1),
            '%Y/%m/%d').split('/')

        # Write logs to Blob
        log_file = "BatchJobLogs/year={}/month={}/day={}/" \
                   "CVREstimationJob.log".format(
            date_string_split[0],
            date_string_split[1],
            date_string_split[2]
        )
        self.read_write_blob.write_log_to_blob(
            Config.AzureConfig.RECOMMENDATION_OUT_STRING,
            Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME,
            log_file)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description='Calculates Rolling CVR for All Retailers')
    parser.add_argument('-d', '--day_count', type=int, default=14,
                        help='Number of days to look backward from current '
                             'date for calculating rolling CVR')
    parser.add_argument('-env', '--environment', type=str,
                        default='dev,qa,uat',
                        help='List of environments to run CVR estimation')
    input_args = vars(parser.parse_args())
    for env in input_args['environment'].strip().split(','):
        try:
            CVRCalculator = CvrAggregator(
                time_delta=input_args['day_count'],
                environment=env)
            CVRCalculator.main()
        except Exception as exception:
            print(exception)
            continue
