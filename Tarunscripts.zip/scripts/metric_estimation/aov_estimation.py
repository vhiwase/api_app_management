from util.azure_batch_logger import BatchLog
import argparse
from util.read_write_data_azure_blob import ReadAndWriteFromAzureBlob
from util.mongo_util import MongoUtil
from util.meta_data_extractor import MetaDataExtractor
from config import Config
import pandas as pd
import time


class AOVEstimator:
    __JOB_NAME = 'place_order_data'
    __ORDER_VALUE = 'order_value'
    __PRICE_AFTER_DISCOUNT = 'price_after_discount'
    __QUANTITY = 'quantity'
    __SKU = 'product_id'
    __ID = "_id"
    __AOV = "aov"

    def __init__(self, time_delta, environment, data_source_environment):
        Config.switch_env(environment)
        print(
            "Running for environment - {}".format(
                Config.AzureConfig.ENV)
        )
        self.time_delta = time_delta
        self.read_write_blob = ReadAndWriteFromAzureBlob()
        self.environment = environment
        self.data_source_environment = data_source_environment

    def get_aov_data(self, retailer_id):
        organic_aov_df = pd.DataFrame()

        for days_from_current_day in range(1, self.time_delta + 1):
            # try except since on somedays data may not be found in look back window
            try:
                data_source_config = None
                if self.data_source_environment == 'prod':
                    data_source_config = 'prod'
                temp_df = self.read_write_blob.get_input_df_from_datascience_container(
                    retailer_id,
                    self.__JOB_NAME,
                    Config.AzureConfig.ORGANIC_DS_INPUT_STRING,
                    days_from_current_day,
                    do_csv_check=True,
                    data_source_config=data_source_config
                )
                organic_aov_df = pd.concat([organic_aov_df, temp_df])
            except Exception as e:
                print("Ignoring exception:{e}".format(e=e))
                continue

        if not organic_aov_df.empty:
            organic_aov_df[
                self.__ORDER_VALUE
            ] = organic_aov_df[self.__PRICE_AFTER_DISCOUNT] * organic_aov_df[self.__QUANTITY]

            organic_aov_df = organic_aov_df[[self.__SKU, self.__ORDER_VALUE]]

        return organic_aov_df

    def run_aov_estimator(self, aov_data):
        # taking median since it would be more conservative to achieve roas
        if not aov_data.empty:
            aov_data = aov_data.groupby(by=self.__SKU)[self.__ORDER_VALUE].median()
            aov_data = aov_data.to_dict()
            return aov_data
        return {}

    def update_mongo_aov(self, retailer_id, aov_data):
        if len(aov_data) > 0:
            product_metadata_mongo = MongoUtil(
                Config.AzureConfig.COSMOS_URI,
                Config.AzureConfig.COSMOS_PRODUCT_META_DB,
                retailer_id
            )
            skus_price_aov = product_metadata_mongo.get_all_documents()

            updated_skus_aov = []
            for each in skus_price_aov:
                prod_id = each.get(self.__ID)
                if aov_data.get(prod_id):
                    each[self.__AOV] = round(aov_data.get(prod_id), 2)
                    updated_skus_aov.append(each)

            if updated_skus_aov:
                st1 = time.time()
                product_metadata_mongo.upsert_bulk(updated_skus_aov)
                et1 = time.time()
                print("time taken to ingest documents into mongo:%s" % (et1 - st1))
        else:
            print(
                "AOV data is empty for {retailer_id}, no documents are updated".format(
                    retailer_id=retailer_id
                )
            )

    def main(self):
        message = "Starting AOV estimation"
        print(message)
        BatchLog.info(message)
        retailers = MetaDataExtractor.get_all_retailer_ids_in_env()
        if retailers:
            for retailer_id in retailers:
                aov_data = self.get_aov_data(str(retailer_id))
                aov_data = self.run_aov_estimator(aov_data)
                # update data in mongo
                self.update_mongo_aov(str(retailer_id), aov_data)
                message = "AOV estimation done for retailer {retailer_id}, env:{env}".format(
                    retailer_id=retailer_id,
                    env=self.environment
                )
                print(message)
                BatchLog.info(message)

        message = "AOV estimation done for all retailers"
        print(message)
        BatchLog.info(message)

        BatchLog.write_log_to_azure("AOVEstimation")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description='Calculates AOV for All Retailers in metadata of env')
    parser.add_argument('-d', '--day_count', type=int, default=7,
                        help='Number of days to look backward from current '
                             'date for calculating AOV')
    parser.add_argument('-env', '--environment', type=str,
                        default='dev,qa,uat',
                        help='List of environments to run ctr estimation')
    parser.add_argument('-source_env', '--data_source_environment', type=str,
                        default='prod',
                        help='Source env to get aov data defaults to prod')

    input_args = vars(parser.parse_args())
    for env in input_args['environment'].strip().split(','):
        try:
            aov_estimator = AOVEstimator(
                time_delta=input_args['day_count'],
                environment=env,
                data_source_environment=input_args['data_source_environment']
            )
            aov_estimator.main()
        except Exception as exception:
            print(exception)
            continue
