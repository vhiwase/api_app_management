# pylint: disable=all
from util.icc_logger import Log
import json
from flask import Flask, request, Response, abort
from bidding.auto_bidder import AutoBidder
from context.context import Context
from util.prometheus_metrics import PrometheusMetrics
from werkzeug.middleware.dispatcher import DispatcherMiddleware
from prometheus_client import make_wsgi_app
import argparse
from config import Config
from applicationinsights.flask.ext import AppInsights
from relevance.auto_target import AutoTarget
from metric_estimation.metric_estimator import MetricsEstimator
from apscheduler.schedulers.background import BackgroundScheduler
from util.keyword_targetting_utils import KeywordHash
from util.target_indexer import TargetIndexer
from util.bidder_util import BidderUtil
from util.meta_data_extractor import MetaDataExtractor
from util.mongo_util_base import MongoUtilBase
from util.simple_ab_tester import SimpleABTest


app = Flask(__name__)
relevance_engine = None
auto_bidder = None
app_insights = None
auto_target = None
metric_estimator = None
keyword_hash = None
target_indexer = None
mongo_util_base = None
simple_ab_tester = None
version = "v1.2023.1.1"



def initialize_app(args):
    global auto_bidder, app_insights, metric_estimator, \
        auto_target, keyword_hash, target_indexer, mongo_util_base, simple_ab_tester

    if args.get("env"):
        Config.switch_env(args.get("env"))
    Log.info("Initializing app as {env}".format(env=Config.AzureConfig.ENV))

    app.config['APPINSIGHTS_INSTRUMENTATIONKEY'] = Config.AzureConfig.INSTRUMENTATION_KEY
    app_insights = AppInsights(app)

    Context.init(args['retailer_ids'], lite_mode=True)

    auto_bidder = AutoBidder()
    auto_target = AutoTarget()
    prometheus_metrics = PrometheusMetrics()
    prometheus_metrics.setup_metrics(app)
    metric_estimator = MetricsEstimator()
    keyword_hash = KeywordHash()
    target_indexer = TargetIndexer()
    mongo_util_base = MongoUtilBase(Config.AzureConfig.COSMOS_URI)
    simple_ab_tester = SimpleABTest()

    if not args.get('local'):
        # Plug metrics WSGI app to main app with dispatcher
        app.wsgi_app = DispatcherMiddleware(app.wsgi_app, {"/actuator/prometheus": make_wsgi_app()})
        scheduler = BackgroundScheduler()
        scheduler.add_job(func=Context.refresh_meta_data, trigger="interval", seconds=3600)
        scheduler.start()

    app.run(host='0.0.0.0', port=8082, threaded=True)


@app.after_request
def after_request(response):
    app_insights.flush()
    return response


@app.route('/static/<path>')
def static_files(path):
    return app.send_static_file(path)


@app.route('/health')
@app.route('/')
def health_check():
    return "ICC-AI services "+version+" running as " + Config.AzureConfig.ENV


@app.route('/tool')
def companion_tools_ui():
    return app.send_static_file("intelligence_tool.html")


@app.route('/intelligence')
@app.route('/intelligence_v2')
def intelligence_service_v2():
    try:
        retailer_id = int(request.args.get("retailer_id"))
        sku_raw = request.args.get('sku')
        targeting_type = request.args.get('target_type').lower()
        if 'page' in request.args:
            page = int(request.args.get('page'))
        else:
            page = None
        roas = None
        trace_id = None

        if request.args.get('roas') is not None:
            roas = float(request.args.get('roas'))
        else:
            roas = 5.0
        if "trace_id" in request.args:
            trace_id = request.args.get('trace_id')
        bid_type = request.args.get('bid_type').lower()

        if request.args.get('debug') is not None:
            debug_flag = True
        else:
            debug_flag = False

        try:
            sku_list = [sku.strip().lower() for sku in sku_raw.split(",")]
            targets = []
            acos = 100.0/roas
            if targeting_type == "keyword":
                targets = target_indexer.get_keywords(str(retailer_id), sku_list)
                target_indexer.fill_target_metrics(str(retailer_id), sku_list, targets, acos)
                for target in targets:
                    target["target_value"] = target["keywords"][0]
            elif targeting_type == "category":
                targets = target_indexer.get_category_targets(str(retailer_id), sku_list)
                target_indexer.fill_target_metrics(str(retailer_id), sku_list, targets, acos)
            elif targeting_type == "product":
                targets = target_indexer.get_product_targets(str(retailer_id), sku_list)
                target_indexer.fill_target_metrics(str(retailer_id), sku_list, targets, acos)
            else:
                abort(405, "Unsupported type: " + targeting_type)

            result = []
            if debug_flag:
                for target in targets:
                    if bid_type == "cpm":
                        target["bid"] = target["ecpm"]
                    target.pop("target_type", None)
                    for product in target["products_to_promote"]:
                        product.pop("target_type", None)
                        product.pop("target_value", None)
                    target["products_to_promote"] = str(target["products_to_promote"])
                result = targets
            else:
                for target in targets:
                    if bid_type == "cpm":
                        target["bid"] = target["ecpm"]
                    if targeting_type == "category":
                        result.append(
                            dict(
                                target_value=target["target_value"],
                                bid=target["bid"],
                                category=target["target_value"][target["target_value"].rfind(">")+1:]
                            )
                        )
                    else:
                        result.append(
                            dict(
                                target_value=target["target_value"],
                                bid=target["bid"],
                            )
                        )

            result = sorted(result, key=lambda x: x["bid"], reverse=True)
            if page:
                result = result[(page - 1) * 20:page * 20]
            else:
                if page != 0:
                    result = result[:200]

        except Exception as e:
            Log.exception(
                "[function]:intelligence_service [trace_id]:{trace_id} "
                "[message]:Error in intelligence_service for parameters "
                "retailer_id:{retailer_id},skus:{sku_raw},"
                "targeting_type:{targeting_type},roas:{roas},bid_type:{bid_type}"
                " [exception]:{exception}".format(
                    trace_id=trace_id,
                    retailer_id=retailer_id,
                    sku_raw=sku_raw,
                    targeting_type=targeting_type,
                    roas=roas,
                    bid_type=bid_type,
                    exception=e)
            )
            result = []
    except Exception as e:
        Log.exception("[function]:intelligence_service,"
                      "[exception]:{exception}".format(exception=e)
                      )
        result = []
    total_no_suggestion = result.__len__()
    result = dict(total_no_suggestion=total_no_suggestion, suggestions=result)

    return Response(json.dumps(result), mimetype='application/json')


@app.route('/intelligence_v3', methods=['POST'])
def intelligence_service_v3():
    try:
        request_data = request.get_json()
        retailer_id = int(request_data.get("retailer_id"))
        sku_list = request_data.get("products_to_promote")
        if type(sku_list) == str:
            sku_list = [
                sku.strip().lower() for sku in sku_list.split(",")
            ]
        targeting_type = request_data.get("target_type").lower()
        bid_type = request_data.get("bid_type").lower()

        if 'page' in request_data:
            page = int(request_data.get('page'))
        else:
            page = None
        trace_id = None
        if "trace_id" in request_data:
            trace_id = request_data.get('trace_id')

        roas = 5.0

        try:
            targets = []
            acos = 100.0 / roas
            if targeting_type == "keyword":
                targets = target_indexer.get_keywords(str(retailer_id),
                                                      sku_list)
                target_indexer.fill_target_metrics(str(retailer_id), sku_list,
                                                   targets, acos)
                target_indexer.update_bids_with_landscape(
                    str(retailer_id), targets, bid_type
                )
                for target in targets:
                    target["target_value"] = target["keywords"][0]
            elif targeting_type == "category":
                targets = target_indexer.get_category_targets(str(retailer_id),
                                                              sku_list)
                target_indexer.fill_target_metrics(str(retailer_id), sku_list,
                                                   targets, acos)
                target_indexer.update_bids_with_landscape(
                    str(retailer_id), targets, bid_type
                )
            elif targeting_type == "product":
                targets = target_indexer.get_product_targets(str(retailer_id),
                                                             sku_list)
                target_indexer.fill_target_metrics(str(retailer_id), sku_list,
                                                   targets, acos)
                target_indexer.update_bids_with_landscape(
                    str(retailer_id), targets, bid_type
                )
            else:
                abort(405, "Unsupported type: " + targeting_type)

            result = []

            for target in targets:
                if targeting_type == "category":
                    result.append(
                        dict(
                            target_value=target["target_value"],
                            bid=target["bid"],
                            min_bid=target["min_bid"],
                            max_bid=target["max_bid"],
                            category=target[
                                         "target_value"
                                     ][target["target_value"].rfind(">") + 1:]
                        )
                    )
                elif targeting_type == "keyword":
                    result.append(
                        dict(
                            target_value=target["target_value"],
                            bid=target["bid"],
                            min_bid=target["min_bid"],
                            max_bid=target["max_bid"],
                            broad_keywords=dict(
                                keywords_list=target["keywords"],
                                bid=target["bid"],
                                min_bid=target["min_bid"],
                                max_bid=target["max_bid"]
                            )
                        )
                    )
                else:
                    result.append(
                        dict(
                            target_value=target["target_value"],
                            bid=target["bid"],
                            min_bid=target["min_bid"],
                            max_bid=target["max_bid"]
                        )
                    )
            result = sorted(result, key=lambda x: x["bid"], reverse=True)
            if page:
                result = result[(page - 1) * 20:page * 20]
            else:
                if page != 0:
                    result = result[:200]

        except Exception as e:
            Log.exception(
                "[function]:intelligence_service [trace_id]:{trace_id} "
                "[message]:Error in intelligence_service for parameters "
                "retailer_id:{retailer_id},skus:{sku_raw},"
                "targeting_type:{targeting_type}, roas:{roas}, "
                "bid_type:{bid_type} [exception]:{exception}".format(
                    trace_id=trace_id,
                    retailer_id=retailer_id,
                    sku_raw=sku_list,
                    targeting_type=targeting_type,
                    roas=roas,
                    bid_type=bid_type,
                    exception=e)
            )
            result = []
    except Exception as e:
        Log.exception("[function]:intelligence_service,"
                      "[exception]:{exception}".format(exception=e)
                      )
        result = []
    total_no_suggestion = result.__len__()
    result = dict(total_no_suggestion=total_no_suggestion, suggestions=result)

    return Response(json.dumps(result), mimetype='application/json')


@app.route('/broad_keywords', methods=['GET', 'POST'])
def broad_keywords():
    keyword = request.args.get('keyword')
    retailer_id = int(request.args.get("retailer_id"))
    key_hash = keyword_hash.get_keyword_hash(keyword)
    trace_id = None
    if "trace_id" in request.args:
        trace_id = request.args.get("trace_id")
    try:
        keyword_variations = target_indexer.get_keywords_from_hash(retailer_id, key_hash)
    except Exception as e:
        keyword_variations = []
        Log.exception(
            "[function]:broad_keywords [trace_id]:{trace_id} "
            "[message]:Error in broad_keywords for parameters "
            "retailer_id:{retailer_id},keyword:{keyword}}"
            "[exception]:{exception}".format(
                trace_id=trace_id,
                retailer_id=retailer_id,
                keyword=keyword,
                exception=e)
        )
    return Response(json.dumps(keyword_variations), mimetype='application/json')


@app.route('/ad_search', methods=['POST'])
@app.route('/ad_search_v4', methods=['POST'])
@app.route('/ad_search_v3', methods=['POST'])
def ad_search_v2():
    try:
        placement_id_list = []
        trace_id = None

        request_data = request.get_json()
        retailer_id = int(request_data.get("retailer_id"))
        target_type = request_data.get("target_type").lower()
        user_id = request_data.get("user_id")
        guest_id = request_data.get("guest_id")
        if "placement_id_list" in request_data:
            for placement in request_data["placement_id_list"]:
                placement_id_list.append(int(placement))
        elif "placement_id" in request_data:
            placement_id_list.append(int(request_data.get("placement_id")))
        if "trace_id" in request_data:
            trace_id = request_data.get("trace_id")

        target_value_list = []
        if "target_value_list" in request_data:
            for target_value in request_data.get("target_value_list"):
                target_value = target_value.lower().strip().encode("ascii", "ignore").decode()
                target_value_list.append(target_value)
        else:
            target_value = request_data.get("target_value").lower().strip()
            target_value = target_value.encode("ascii", "ignore").decode()
            target_value_list.append(target_value)

        retailer = Context.get_retailer(retailer_id)
        result = auto_target.get_target_campaigns_v2(
            retailer, target_type, target_value_list, placement_id_list,
            user_id, guest_id, trace_id
        )
        Log.info("/ad_search response : {result}".format(result=result))

    except Exception as e:
        Log.exception(
            "[function]:ad_search [trace_id]:{trace_id} "
            "[message]:Error in ad_search for parameters "
            "retailer_id:{retailer_id},target_type:{target_type},"
            "target_value:{target_value},placement_id:{placement_id} "
            "[exception]:{exception}".format(
                trace_id=trace_id,
                retailer_id=retailer_id,
                target_type=target_type,
                target_value=target_value,
                placement_id=placement_id_list,
                exception=e)
        )
        result = []

    return Response(json.dumps(result), mimetype='application/json')


@app.route('/ad_search_v5', methods=['POST'])
def ad_search_v5():
    try:
        placement_id_list = []
        trace_id = None

        request_data = request.get_json()
        retailer_id = int(request_data.get("retailer_id"))
        target_type = request_data.get("target_type").lower()
        user_id = request_data.get("user_id")
        guest_id = request_data.get("guest_id")
        if "placement_id_list" in request_data:
            for placement in request_data["placement_id_list"]:
                placement_id_list.append(int(placement))
        if "trace_id" in request_data:
            trace_id = request_data.get("trace_id")

        target_value_list = []
        if "target_value_list" in request_data:
            for target_value in request_data.get("target_value_list"):
                target_value = target_value.lower().strip().encode("ascii", "ignore").decode()
                target_value_list.append(target_value)
        else:
            target_value = request_data.get("target_value").lower().strip()
            target_value = target_value.encode("ascii", "ignore").decode()
            target_value_list.append(target_value)

        retailer = Context.get_retailer(retailer_id)
        result = auto_target.get_target_campaigns_v3(
            retailer, target_type, target_value_list, placement_id_list,
            user_id, guest_id, trace_id
        )
        Log.info("/ad_search response : {result}".format(result=result))

    except Exception as e:
        Log.exception(
            "[function]:ad_search [trace_id]:{trace_id} "
            "[message]:Error in ad_search for parameters "
            "retailer_id:{retailer_id},target_type:{target_type},"
            "target_value:{target_value},placement_id:{placement_id} "
            "[exception]:{exception}".format(
                trace_id=trace_id,
                retailer_id=retailer_id,
                target_type=target_type,
                target_value=target_value,
                placement_id=placement_id_list,
                exception=e)
        )
        result = []

    return Response(json.dumps(result), mimetype='application/json')


@app.route('/ecpm', methods=['GET', 'POST'])
def get_ecpm():
    retailer_id = int(request.args.get("retailer_id"))
    sku_raw = request.args.get("sku")
    target_type = request.args.get("target_type").lower()
    target_value = request.args.get("target_value").lower()
    cpc_bid_value = float(request.args.get("cpc_bid_value"))
    trace_id = None
    if "trace_id" in request.args:
        trace_id = request.args.get("trace_id")

    try:
        retailer = Context.get_retailer(retailer_id)
        if target_type == "keyword":
            target_value = keyword_hash.get_keyword_hash(target_value)

        targets = []
        for sku in sku_raw.split(","):
            targets.append(
                dict(sku=sku, target_type=target_type, target_value=target_value)
            )

        metric_estimator.get_metric_for_many(
            retailer, "ctr", target_type, targets
        )

        ctr = BidderUtil.compute_campaign_ctr(targets)
        ecpm = BidderUtil.compute_ecpm(ctr, cpc_bid_value)
        result = {
            "ecpm": ecpm
        }

    except Exception as e:
        Log.exception(
            "[function]:get_ecpm [trace_id]:{trace_id} "
            "[message]:Error in get_ecpm for parameters "
            "retailer_id:{retailer_id},target_type:{target_type},sku:{sku},"
            "target_value:{target_value},cpc_bid_value:{cpc_bid_value} "
            "[exception]:{exception}".format(
                trace_id=trace_id,
                retailer_id=retailer_id,
                target_type=target_type,
                target_value=target_value,
                sku=sku_raw,
                cpc_bid_value=cpc_bid_value,
                exception=e)
        )
        abort(404, 'Data not found')
        result = {}

    return Response(json.dumps(result), mimetype='application/json')


@app.route('/erevenue', methods=['GET', 'POST'])
def erevenue():
    try:
        retailer_id = int(request.args.get("retailer_id"))
        trace_id = None
        if "trace_id" in request.args:
            trace_id = request.args.get("trace_id")
        sku_raw = request.args.get("sku").lower()
        sku = sku_raw.split(",")
        retailer = Context.get_retailer(retailer_id)
        expected_revenue = auto_target.get_expected_revenue(retailer, sku)
        result = {
            'erevenue': expected_revenue
        }
    except Exception as e:
        Log.exception(
            "[function]:erevenue [trace_id]:{trace_id} "
            "[message]:Error in erevenue for parameters "
            "retailer_id:{retailer_id},sku:{sku}"
            "[exception]:{exception}".format(
                trace_id=trace_id,
                retailer_id=retailer_id,
                sku=sku_raw,
                exception=e)
        )

        result = {}

    return Response(json.dumps(result), mimetype='application/json')


@app.route('/bid_suggestion', methods=['POST'])
def get_bid_for_adhoc_targets():
    request_data = request.get_json()
    retailer_id = int(request_data.get("retailer_id"))
    target_type = request_data.get("target_type").lower()
    target_value = request_data.get("target_value").lower()
    products_to_promote = request_data.get("products_to_promote")
    if type(products_to_promote) == str:
        products_to_promote = [
            sku.strip().lower() for sku in products_to_promote.split(",")
        ]
    bid_type = request_data.get("bid_type").lower()

    target_type_map = {"keyword": "kt_{}",
                       "product": "pt_{}",
                       "category": "ct_{}"}
    if (
            retailer_id is None or target_type is None or
            target_value is None or products_to_promote is None
    ):
        result = {}
    else:
        result = {}
        if target_type == "keyword":
            target_value = keyword_hash.get_keyword_hash(target_value)
            broad_keywords = target_indexer.get_keywords_from_hash(
                retailer_id, target_value
            )
        landscape = mongo_util_base.get_document(
            Config.AzureConfig.COSMOS_BID_LANDSCAPE_DB,
            str(retailer_id),
            target_type_map[target_type].format(target_value)
        )
        retailer = Context.get_retailer(retailer_id)
        sku_relevance_map = dict.fromkeys(products_to_promote)
        ctr_metric = metric_estimator.get_metric_for_multi_sku(
            retailer, 'ctr', target_type, target_value,
            sku_relevance_map
        )
        cvr_metric = metric_estimator.get_metric_for_multi_sku(
            retailer, 'pc_cvr', target_type, target_value,
            sku_relevance_map
        )
        sku_info = []
        for i in products_to_promote:
            sku_info.append(
                {"sku": i.lower(),
                 "ctr": ctr_metric[i],
                 "pc_cvr": cvr_metric[i],
                 "aov": MetaDataExtractor.get_product_metadata(
                     retailer_id, i
                 )['aov']
                 }
            )
        if landscape and float(list(landscape['target'])[-1]) != 0:
            min_bid = float(list(landscape['target'])[0])
            max_bid = float(list(landscape['target'])[-1])
            bid = round((min_bid + max_bid) / 2, 4)
            if bid_type == "cpc":
                ctr = BidderUtil.compute_campaign_ctr(sku_info)
                bid = round(bid / ctr / 1000, 4)
        else:
            roas = 5
            acos = 100.0 / roas
            bid = BidderUtil.compute_bid_v2(acos, sku_info)
            if bid_type == "cpm":
                ctr = BidderUtil.compute_campaign_ctr(sku_info)
                bid = BidderUtil.compute_ecpm(ctr, bid)

        result = {
            "min_bid": round(bid - (bid * 0.1), 4),
            "max_bid": round(bid + (bid * 0.1), 4),
            "bid": bid
        }
        if target_type == "keyword":
            result = {
                "min_bid": round(bid - (bid * 0.1), 4),
                "max_bid": round(bid + (bid * 0.1), 4),
                "bid": bid,
                "broad_match":
                    {
                        "keywords_list": broad_keywords,
                        "min_bid": round(bid - (bid * 0.1), 4),
                        "max_bid": round(bid + (bid * 0.1), 4),
                        "bid": bid
                    }
            }
    return Response(json.dumps(result), mimetype='application/json')


@app.route('/retailers', methods=['GET'])
def get_retailers():
    result = MetaDataExtractor.get_retailer_list()
    return Response(json.dumps(result), mimetype='application/json')


# @app.route('/autoshop')
# def autoshop():
#     if "image_url" in request.args:
#         img_url = request.args.get("image_url")
#         k_nearest = int(request.args.get("k"))
#         retailer_id = int(request.args.get("retailerId"))
#         retailer = Context.get_retailer(retailer_id)
#         product_recommendations = relevance_engine.get_similar_images_from_catalog(
#             retailer, img_url, k_nearest)
#         if not product_recommendations.empty:
#             return Response(
#                 product_recommendations[['id', 'relevance_score']].to_json(orient='records'),
#                 mimetype='application/json'
#             )
#
#     return jsonify({})


@app.errorhandler(500)
def handle_500(error):
    return str(error), 500


if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description='Bootstrapping ICC AI services.')
    parser.add_argument('-r', '--retailer_ids', help='List of retailer ids',
                        type=int, nargs="+")
    parser.add_argument('-e', '--env',
                        help='Override environment variable from system',
                        type=str, default=None)
    parser.add_argument('-l', '--local',
                        help='Boolean flag to start the app locally',
                        action='store_true')
    input_args = vars(parser.parse_args())
    initialize_app(input_args)
