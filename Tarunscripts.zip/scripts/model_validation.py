import sys
import itertools
import random
import nltk
from torch.utils.data import DataLoader
from sentence_transformers import SentenceTransformer, InputExample, losses, evaluation, util, models
import torch.nn as nn
import torch
from azure.storage.blob import BlobServiceClient
from config import Config
import pandas as pd
import numpy as np
import time
import pickle
from numpy import dot
from keyword_reboarding import KeywordMining
import argparse
from relevance.keywordtargeting import KeywordTargeting
from azure.cosmos.cosmos_client import CosmosClient
from retailer_onboarding_lite import RetailerOnboardingLite
from sklearn.metrics import precision_recall_curve
import os
import faiss
from sklearn.metrics import auc
random.seed(100)
Config.switch_env('prod')


class ModelValidation:

    def __init__(self, retailer_info):
        self.retailer_info = retailer_info
        self.retailer_lite = RetailerOnboardingLite(retailer_info)
        self.KM = KeywordMining()
        self.model = SentenceTransformer(retailer_info['model_path'])

    #        self.catalogue_data = self.__get_catalogue_data_filtered()

    def __get_atc_data(self):
        print("Getting atc data")
        atc_data = self.KM.get_lastn_days_job_data(self.retailer_info['id'], 'atc')
        atc_data.rename(columns={'Product': 'sku', 'Count': 'add_to_cart_count'}, inplace=True)
        atc_data['keyword_hash'] = atc_data['keywords'].apply(self.KM.KH.get_keyword_hash)
        atc_data1 = atc_data.groupby(['sku', 'keyword_hash'], as_index=False).agg(
            {'add_to_cart_count': sum}).sort_values(by='add_to_cart_count', ascending=False)
        atc_data1['cumulative_sum'] = atc_data1['add_to_cart_count'].cumsum()
        atc_data2 = atc_data1[atc_data1.cumulative_sum < int(.9 * atc_data['add_to_cart_count'].sum())]
        return atc_data2

    def __get_catalogue_data_filtered(self):
        print("Filtering catalogue data")
        catalogue_data = self.retailer_lite._RetailerOnboardingLite__fetch_data_from_container()
        catalogue_data = pd.DataFrame(catalogue_data)
        print("Shape of the dataframe is ", catalogue_data.shape)
        catalogue_data, category_path_col = self.retailer_lite._RetailerOnboardingLite__preprocess_catalogue_data(
            catalogue_data)
        print("Columns are ", catalogue_data.columns)
        # catalogue_data_filtered = catalogue_data[catalogue_data.sku.isin(set(self.atc_data['Product']))]
        # print("Filtered catalogue data shape ", catalogue_data_filtered.shape)
        return catalogue_data

    def calculate_validation_metrics(self, validation_data, keyword_atc):
        num_cuda_devices = torch.cuda.device_count()
        cuda_devices = ["cuda:" + str(i) for i in range(1, num_cuda_devices)]
        pool = self.model.start_multi_process_pool(cuda_devices)

        product_id_to_name_dict = dict(zip(validation_data.sku, validation_data.product_name))
        product_ids = list(product_id_to_name_dict.keys())
        product_names = list(product_id_to_name_dict.values())

        print('Generating embeddings')
        product_names_embeddings = self.model.encode_multi_process(product_names, pool)
        product_names_embeddings = product_names_embeddings / np.expand_dims(
            np.linalg.norm(product_names_embeddings, axis=1), axis=1)
        product_ids_to_embedding_dict = dict(zip(product_ids, product_names_embeddings))

        keywords_list = list(set(validation_data['keyword']))
        keywords_embeddings = self.model.encode_multi_process(keywords_list, pool)
        keywords_embeddings = keywords_embeddings / np.expand_dims(np.linalg.norm(keywords_embeddings, axis=1), axis=1)
        keywords_to_embedding_dict = dict(zip(keywords_list, keywords_embeddings))

        validation_dataframe = validation_data.copy()
        cosine_sim_list = []
        i = 0
        print('computing metrics')
        for index, row in validation_data.iterrows():
            cosine_sim = (1 + dot(keywords_to_embedding_dict[row.keyword], product_ids_to_embedding_dict[row.sku])) / 2
            cosine_sim_list.append(cosine_sim)
        validation_dataframe['cosine_similarity'] = cosine_sim_list
        validation_dataframe1 = validation_dataframe.sort_values(by=['keyword', 'cosine_similarity'],
                                                                 ascending=[True, False])
        validation_dataframe1['rank'] = validation_dataframe1.groupby(['keyword'])['cosine_similarity'].rank(
            ascending=False).astype(int)
        validation_dataframe1['MRR'] = np.where(validation_dataframe1['relevance_score'] == 1,
                                                1 / validation_dataframe1['rank'], 0)
        print(validation_dataframe1.shape)
        keyword_mrr = validation_dataframe1.groupby('keyword_hash', as_index=False).agg(
            {'MRR': lambda x: sum(x) / len(x)})
        weighted_mrr = keyword_mrr.merge(keyword_atc, on='keyword_hash')
        print(keyword_mrr.shape)
        print(weighted_mrr.shape)
        weighted_mrr['weighted_mrr'] = weighted_mrr['MRR'] * weighted_mrr['add_to_cart_count']
        weighted_mrr_value = weighted_mrr['weighted_mrr'].sum() / weighted_mrr['add_to_cart_count'].sum()
        precision, recall, thresholds = precision_recall_curve(list(validation_dataframe1['relevance_score']),
                                                               validation_dataframe1['cosine_similarity'])
        auc_pr = auc(recall, precision)
        return weighted_mrr_value, auc_pr

    def main(self):
        atc_data = self.__get_atc_data()
        keyword_hash_atc_count = atc_data.groupby('keyword_hash', as_index=False).agg({'add_to_cart_count': sum})
        validation_data_path = '../data/model_finetune_data/{retailer_id}_validation_pairs.pkl'.format(
            retailer_id=self.retailer_info["id"])
        with open(validation_data_path, 'rb') as f:
            validation_data = pickle.load(f)
        validation_data = pd.DataFrame(validation_data, columns=['sku', 'product_name', 'keyword', 'relevance_score'])
        validation_data['keyword_hash'] = validation_data['keyword'].apply(self.KM.KH.get_keyword_hash)
        weighted_mrr_value, auc_pr = self.calculate_validation_metrics(validation_data, keyword_hash_atc_count)
        print("weighted MRR :", weighted_mrr_value)
        print("AUC-PR ", auc_pr)

        with open("../data/model_finetune_data/model_finetune_experiments_metrics_v1.txt", "a") as myfile:
            myfile.write("\n model={model_path}, retailer={retailer_id}, "
                         "metrics : auc-pr={auc_pr}, weighted MRR={weighted_mrr_value}".format(
                    model_path=self.retailer_info['model_path'],
                    auc_pr=auc_pr,
                    weighted_mrr_value=weighted_mrr_value,
                    retailer_id = self.retailer_info['id']
                    ))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Model validation')
    parser.add_argument('-i', '--id', help='ID', required=True)
    parser.add_argument('-n', '--name', help='retailer_name', required=True)
    parser.add_argument('-c', '--container', help='retailer_container', required=True)
    parser.add_argument('-mp', '--model_path', help='model', required=True)
    args = vars(parser.parse_args())
    MV = ModelValidation(args)
    MV.main()