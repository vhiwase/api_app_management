from datetime import datetime, timedelta
from util.suggestions_util import PostCampaignSuggestionsUtil


class BudgetSuggestion:
    def __init__(self, time_delta):
        self.time_delta = time_delta
        self.version = datetime.now().strftime('%Y-%m-%dT%H:%M:%SZ')
        self.expiry = (
                datetime.now() + timedelta(1)
        ).strftime('%Y-%m-%dT%H:%M:%SZ')
        self.suggestion_util = PostCampaignSuggestionsUtil(self.time_delta)

    @staticmethod
    def get_potential_impressions(
            current_bid, bid_landscape, current_impressions
    ):
        # Method to calculate potential impressions from bid landscape for
        # the current bid value
        if not current_impressions:
            return 0

        potential_impressions = 0
        if bid_landscape:
            for k, v in bid_landscape.items():
                if float(k) < current_bid:
                    potential_impressions = v
                else:
                    break
            if potential_impressions > current_impressions:
                return potential_impressions
            else:
                return 0
        else:
            return 0

    def get_new_budget(
            self, targets, bid_landscape, search_count, budget
    ):
        if not search_count:
            return 0

        for target in targets:
            current_bid = target['ecpm']
            impressions = search_count.get(target['target_value'].lower())

            if impressions and impressions > 0:
                potential_impressions = self.get_potential_impressions(
                    current_bid, bid_landscape.get(
                        target['mongo_key'].lower()
                    ), impressions
                )
                imp_left = max(0, (potential_impressions - impressions))
                budget += (imp_left * current_bid) / 1000

        return budget

    def get_budget_suggestion(
            self, campaign_list, retailer_meta_data, product_meta_data_map,
            ad_spent, bid_landscape, search_count, negations
    ):
        budget_suggestions = []
        suggestions = {}
        retailer_id = str(retailer_meta_data["_id"])

        for record in campaign_list:
            campaign_id = record['campaign_id']
            for ad_group in record["ad_groups"]:
                for key, value in ad_group.items():
                    ad_group_id = str(key)
                    try:
                        budget_negation = self.suggestion_util.get_rejections(
                            record['campaign_id'], negations,
                            "budget_suggestion"
                        )

                        if record["budget_type"] == "DAILY":
                            try:
                                total_spend = search_count.get(
                                    campaign_id
                                ).get("ad_spent")
                            except AttributeError:
                                continue
                        else:
                            total_spend = ad_spent.get(campaign_id)

                        if (
                                total_spend and
                                total_spend < record['budget']
                        ) or budget_negation:
                            continue

                        search_counter = search_count.get(campaign_id).get(
                            "impression_map"
                        ).get(
                            ad_group_id
                        )

                        # Getting targets for the autonomous campaign
                        targets = self.suggestion_util.target_indexer. \
                            get_targets(
                                retailer_id, value["products_to_promote"]
                            )

                        # Filling with necessary metrics and ecpm values
                        self.suggestion_util.target_indexer. \
                            fill_target_metrics_for_suggestion(
                                retailer_meta_data, product_meta_data_map,
                                value["products_to_promote"], targets,
                                value["acos"]
                            )

                        # Getting mongo keys for the targets
                        targets = self.suggestion_util.target_indexer. \
                            get_bid_landscape_keys(
                                targets
                            )

                        # Computing budget
                        new_budget = self.get_new_budget(
                            targets, bid_landscape, search_counter,
                            record['budget']
                        )

                        if suggestions.get(campaign_id):
                            suggestions[campaign_id][
                                "new_budget"
                            ] += new_budget
                        else:
                            suggestions[campaign_id] = {
                                "current_budget": record["budget"],
                                "new_budget": new_budget
                            }

                    except Exception as e:
                        print(e)
                        continue

        for key, value in suggestions.items():
            try:
                if value["new_budget"] > value["current_budget"]:
                    budget_suggestions.append(
                        {
                            "retailer_id": str(retailer_meta_data["_id"]),
                            "campaign_id": str(key),
                            "suggestion_type": "increase_budget",
                            "suggestion_code": "A101",
                            "campaign_level_suggestion": True,
                            "version": self.version,
                            "expiry": self.expiry,
                            "suggestions": [
                                {
                                    "current_budget": value["current_budget"],
                                    "recommended_budget": min(
                                        2 * value["current_budget"],
                                        value["new_budget"]
                                    )
                                }
                            ]
                        }
                    )
            except Exception as e:
                print(e)
                continue

        return budget_suggestions
