from datetime import datetime, timedelta
import numpy as np
from util.suggestions_util import PostCampaignSuggestionsUtil
from util.bidder_util import BidderUtil
from operator import itemgetter
from math import ceil
import statistics


class RoASMaxBidSuggestion:
    def __init__(self, time_delta):
        self.time_delta = time_delta
        self.version = datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ")
        self.expiry = (
                datetime.now() + timedelta(1)
        ).strftime("%Y-%m-%dT%H:%M:%SZ")
        self.suggestion_util = PostCampaignSuggestionsUtil(self.time_delta)

    @staticmethod
    def create_search_averages(search_count, campaign_id):
        search_counter = search_count.copy()
        search_counter.pop(str(campaign_id), None)
        documents = list(search_counter.values())
        average_dict = {}

        for i in documents:
            try:
                for key, value in i["impression_map"].items():
                    for target, impressions in value.items():
                        if average_dict.get(target):
                            average_dict[target].append(impressions)
                        else:
                            average_dict[target] = [impressions]
            except Exception as e:
                print(e)
                continue

        if average_dict:
            return {k: np.mean(v) for k, v in average_dict.items()}

    @staticmethod
    def is_under_performing(targets, search_count, averages, threshold=0.5):
        if search_count and targets:
            target_cutoff = len(targets)
            current_cutoff = 0

            for target in targets:
                if current_cutoff > threshold * target_cutoff:
                    return True
                try:
                    if search_count[target["target_value"].lower()] < \
                            averages[target["target_value"].lower()]:
                        current_cutoff += 1
                except KeyError:
                    continue

        return False

    @staticmethod
    def __get_aov(product_metadata, products_to_promote):
        aov = []
        for product in products_to_promote:
            aov.append(product_metadata[product]["aov"])
        return statistics.mean(aov)

    @staticmethod
    def get_ordered_targets(targets, bid_landscape):
        target_metrics = []
        for target in targets:
            landscape = bid_landscape.get(target["mongo_key"], {})
            for k, v in landscape.items():
                ad_spent = (float(k) * v) / 1000

                if ad_spent > 0:
                    revenue = np.round(
                        BidderUtil.compute_bid_v2(
                            100, target["products_to_promote"]
                        )
                    )
                    target_metrics.append(
                        {
                            "target_value": target["target_value"],
                            "roas": ceil(
                                (revenue/ad_spent) * 10
                            ) / 10,
                            "ad_spent": ad_spent,
                            "bid": float(k) / min(0.002, target["ctr"]) / 1000
                        }
                    )
        return sorted(
            target_metrics, key=itemgetter('roas'), reverse=True
        )

    def compute_suggestion(self, targets, bid_landscape, budget):
        ordered_targets = self.get_ordered_targets(targets, bid_landscape)
        roas = 100
        max_bid = 0
        try:
            ad_spent = 0
            target_dict = {}
            for target in ordered_targets:
                if ad_spent > budget:
                    break
                ad_spent += target['ad_spent']
                target_dict[target["target_value"]] = {
                    "roas": target["roas"],
                    "bid": target["bid"]
                }
            max_bid = sorted(
                target_dict.values(), key=itemgetter('bid'), reverse=True
            )[0]["bid"]
            roas = sorted(
                target_dict.values(), key=itemgetter('roas'), reverse=False
            )[0]["roas"]
            return roas, max_bid
        except Exception as e:
            print(e)
            return roas, max_bid

    def get_roas_maxbid_suggestion(
            self, campaign_list, retailer_metadata, product_meta_data_map,
            bid_landscape, search_count, negations
    ):
        roas_suggestions = {}
        max_bid_suggestions = {}
        retailer_id = str(retailer_metadata["_id"])
        for campaign in campaign_list:
            campaign_id = campaign["campaign_id"]
            for ad_group in campaign["ad_groups"]:
                for key, value in ad_group.items():
                    ad_group_id = str(key)
                    try:
                        # Get negations
                        roas_negation = self.suggestion_util.get_rejections(
                            campaign_id, negations, "roas_suggestion"
                        )
                        maxbid_negation = self.suggestion_util.get_rejections(
                            campaign_id, negations, "max_bid_suggestion"
                        )

                        # Getting targets from CosmosDB for the  campaign
                        targets = \
                            self.suggestion_util.target_indexer.get_targets(
                                retailer_id, value["products_to_promote"]
                            )

                        # Filtering search count of targets for the campaign
                        try:
                            search_counter = search_count.get(
                                campaign_id
                            ).get(
                                "impression_map"
                            ).get(
                                ad_group_id
                            )
                        except AttributeError:
                            continue

                        # Getting averages of the target values
                        averages = self.create_search_averages(
                            search_count, campaign_id
                        )

                        # Checking if the campaign in under performing
                        if self.is_under_performing(
                                targets, search_counter, averages
                        ):

                            # Filling with necessary metrics and ecpm values
                            self.suggestion_util.target_indexer.\
                                fill_target_metrics_for_suggestion(
                                    retailer_metadata, product_meta_data_map,
                                    value["products_to_promote"], targets,
                                    value["acos"]
                                )

                            # Getting mongo keys for the targets
                            targets = self.suggestion_util.target_indexer.\
                                get_bid_landscape_keys(
                                    targets
                                )

                            # Computing roas and max bid suggestions
                            roas, max_bid = self.compute_suggestion(
                                targets, bid_landscape, campaign["budget"]
                            )

                            current_roas = 100 / value["acos"]
                            current_max_bid = value['max_bid_price']

                            if (
                                roas < current_roas and ad_group_id not in
                                    roas_negation
                            ):
                                suggestion = {
                                    "ad_group_id": ad_group_id,
                                    "suggestions": [
                                        {
                                            "current_roas": current_roas,
                                            "recommended_roas": max(1.1, roas)
                                        }
                                    ]
                                }

                                if roas_suggestions.get(
                                        campaign_id
                                ):
                                    roas_suggestions[
                                        campaign_id
                                    ]["suggestions"].append(suggestion)
                                else:
                                    roas_suggestions[
                                        campaign_id
                                    ] = {
                                        "retailer_id": retailer_id,
                                        "campaign_id": campaign_id,
                                        "campaign_level_suggestion": False,
                                        "suggestion_type": "decrease_roas",
                                        "suggestion_code": "A103",
                                        "suggestions": [
                                            {
                                                "ad_group_id": str(key),
                                                "suggestions": [
                                                    {
                                                        "current_roas":
                                                            current_roas,
                                                        "recommended_roas":
                                                            max(1.1, roas)
                                                    }
                                                ]
                                            }
                                        ]
                                    }

                            if (
                                    max_bid > current_max_bid and
                                    ad_group_id not in maxbid_negation
                            ):
                                max_bid = round(max_bid * 2) / 2
                                aov = self.__get_aov(
                                    product_meta_data_map,
                                    value["products_to_promote"]
                                )
                                max_bid = min(max_bid, 0.5 * aov)
                                suggestion_payload = {
                                    "ad_group_id": ad_group_id,
                                    "suggestions": [
                                        {
                                            "current_max_cutoff":
                                                current_max_bid,
                                            "recommended_roas": max_bid
                                        }
                                    ]
                                }

                                if max_bid_suggestions.get(campaign_id):
                                    max_bid_suggestions[
                                        campaign_id
                                    ]["suggestions"].append(suggestion_payload)
                                else:
                                    max_bid_suggestions[campaign_id] = {
                                        "retailer_id": retailer_id,
                                        "campaign_id": campaign_id,
                                        "suggestion_type":
                                            "increase_max_cutoff",
                                        "suggestion_code": "A102",
                                        "campaign_level_suggestion": False,
                                        "version": self.version,
                                        "expiry": self.expiry,
                                        "suggestions": [suggestion_payload]
                                    }

                    except Exception as e:
                        print(e)
                        continue

        all_suggestions = list(roas_suggestions.values()) + \
            list(max_bid_suggestions.values())

        return all_suggestions
