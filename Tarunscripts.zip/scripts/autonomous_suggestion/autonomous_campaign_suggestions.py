from util.azure_batch_logger import BatchLog
from config import Config
from util.suggestions_util import PostCampaignSuggestionsUtil
from util.meta_data_extractor import MetaDataExtractor
from budget_suggestion import BudgetSuggestion
from roas_max_bid_suggestion import RoASMaxBidSuggestion
import argparse


class AutonomousSuggestions:
    def __init__(self, time_delta, environment):
        Config.switch_env(environment)
        print(
            "Running post campaign suggestions for autonomous campaigns in "
            "environment - {}".format(
                Config.AzureConfig.ENV
            )
        )
        self.time_delta = time_delta
        self.suggestion_util = PostCampaignSuggestionsUtil(self.time_delta)
        self.retailers = MetaDataExtractor.get_retailer_list_for_suggestions()
        self.retailer_metadata = MetaDataExtractor.get_retailer_matadata()
        self.budget_suggestion = BudgetSuggestion(self.time_delta)
        self.roas_max_bid_suggestion = RoASMaxBidSuggestion(self.time_delta)

    def main(self):
        for retailer_id in self.retailers:
            retailer_suggestions = []
            message = "Creating suggestions for the retailer - {}".format(
                retailer_id
            )
            BatchLog.info(message)
            print(message)

            # Getting autonomous campaigns and their metadata
            campaign_list = self.suggestion_util.get_autonomous_campaign_data(
                retailer_id
            )

            # Getting retailer metadata
            retailer_metadata = self.suggestion_util.get_retailer_metadata(
                self.retailer_metadata, str(retailer_id)
            )

            # Getting all negation data for the retailer
            negations = self.suggestion_util.get_negations_for_retailer(
                str(retailer_id)
            )

            # Creating product metadata map for all products in the retailer
            product_meta_data_map = self.suggestion_util.get_retailer_prod_map(
                str(retailer_id)
            )

            # Creating bid landscape mapping for the retailer
            bid_landscape = self.suggestion_util.get_bid_landscape(
                str(retailer_id), budget_suggestion=True
            )

            # Creating budget suggestions
            budget_suggestion = []
            ad_spent = self.suggestion_util.get_latest_ad_spent()
            search_count = self.suggestion_util.get_impression_data(
                retailer_id, autonomous_suggestion=True
            )
            budget_suggestion.extend(
                self.budget_suggestion.get_budget_suggestion(
                    campaign_list, retailer_metadata, product_meta_data_map,
                    ad_spent, bid_landscape, search_count, negations
                )
            )
            if budget_suggestion:
                retailer_suggestions.extend(budget_suggestion)
                message = "Created budget suggestions for retailer - " \
                          "{}".format(retailer_id)
                BatchLog.info(message)
                print(message)
            else:
                message = "No budget suggestions available for retailer - " \
                          "{}".format(retailer_id)
                BatchLog.info(message)
                print(message)

            # Creating RoAS Max Bid suggestions
            roas_max_bid_suggestions = []
            roas_max_bid_suggestions.extend(
                self.roas_max_bid_suggestion.
                get_roas_maxbid_suggestion(
                    campaign_list, retailer_metadata, product_meta_data_map,
                    bid_landscape, search_count, negations
                )
            )

            if roas_max_bid_suggestions:
                retailer_suggestions.extend(roas_max_bid_suggestions)
                message = "Created RoAS/Max Bid suggestions for retailer - " \
                          "{}".format(retailer_id)
                BatchLog.info(message)
                print(message)
            else:
                message = "No RoAS/Max Bid suggestions available for " \
                          "retailer - {}".format(retailer_id)
                BatchLog.info(message)
                print(message)

            # Sending suggestion events and uploading suggestions as CSV to
            # AI containers
            self.suggestion_util.send_data_to_azure(
                retailer_id, "Autonomous Suggestions", retailer_suggestions,
                BatchLog
            )

        # Uploading logs to AI container
        self.suggestion_util.send_logs_to_azure("Autonomous Suggestions")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Post campaign suggestions for autonomous campaigns"
    )
    parser.add_argument('-d', '--day_count', type=int, default=1,
                        help='Number of days to look backward from current '
                             'date for suggestions')
    parser.add_argument('-env', '--environment', type=str,
                        default='dev,qa,uat',
                        help='List of environments to run post campaign '
                             'suggestions for autonomous campaigns')
    input_args = vars(parser.parse_args())
    for env in input_args['environment'].strip().split(','):
        try:
            autonomous_suggestion = AutonomousSuggestions(
                time_delta=input_args['day_count'],
                environment=env
            )
            autonomous_suggestion.main()
        except Exception as exception:
            print(exception)
            continue
