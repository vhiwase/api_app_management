# pylint: disable=all
import os, traceback, argparse
from relevance.keywordtargeting import KeywordTargeting
import keyword_product_map_helper
import pickle
from config import Config, LocalConfig
import os
import faiss

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Mapping keywords to skus')
    parser.add_argument('-i', '--id', help='ID', required=True)
    parser.add_argument('-e', '--env', help='environment', type=str, default='dev')
    args = vars(parser.parse_args())
    Config.switch_env(args['env'])
    retailer_id = args['id']
    KT = KeywordTargeting()
    print("Running semantic keywords to sku map in {env} environment".format(env=args['env']))
    data_path = LocalConfig.DATA_FOLDER_PATH + str(retailer_id) + '/'
    hash_keyword_dict = KT.get_data_from_blob(str(retailer_id)+'_hash_keyword_dict.pkl')
    mined_keywords_list_unique = []
    for k, v in hash_keyword_dict.items():
        mined_keywords_list_unique.append(v[0])
    keyword_list = list(set(mined_keywords_list_unique))
    print("No of keywords to be mapepd ",len(keyword_list))
    retailer_data = KT.get_data_from_blob("full_data_KT_" + str(retailer_id) + ".pkl")
    retailer_faiss_index = faiss.read_index(data_path + str(retailer_id)+'_text_faiss_retailer_lite.index')
    kwds_map=keyword_product_map_helper.main(retailer_data, keyword_list, 100,'keyword_onboarding',retailer_faiss_index)
    fp=open(LocalConfig.DATA_FOLDER_PATH+str(retailer_id)+"_keyword_product_map_faiss.pkl", "bw")
    pickle.dump(kwds_map, fp)
    fp.close()

    fp = open('model_nns.pkl', "br")
    model_nns = pickle.load(fp)
    fp.close()
    KT.push_data_to_blob(model_nns,str(retailer_id)+'_model_nns.pkl')

    fp = open('sentence_embeddings.pkl', "br")
    sentence_embeddings = pickle.load(fp)
    fp.close()
    KT.push_data_to_blob(sentence_embeddings,str(retailer_id)+'_sentence_embeddings.pkl')

    os.rename('model_nns.pkl',LocalConfig.DATA_FOLDER_PATH+str(retailer_id)+'_model_nns.pkl')
    os.rename('sentences.pkl',LocalConfig.DATA_FOLDER_PATH+str(retailer_id)+'_sentences.pkl')
    os.rename('sentence_embeddings.pkl',LocalConfig.DATA_FOLDER_PATH+str(retailer_id)+'_sentence_embeddings.pkl')

    file_name = str(retailer_id) + '_keyword_product_map_faiss.pkl'
    KT.push_data_to_blob(kwds_map,file_name)