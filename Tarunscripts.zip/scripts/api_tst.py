# pylint: disable=all
import requests
import json


url = "http://127.0.0.1:5000/search?query="
query = "yellow plantains"
r = requests.get(url+query)
print(r.json())


url = "http://127.0.0.1:5000/search?product="
id_ = "sfdmfl"
r = requests.get(url+id_)
print(r.json())


url = "http://127.0.0.1:5000/bid"
request_packet={'type': 'product', 'term': 'product id', 'products':[{'id':'zap1', 'relevance_score':0.75, 'default_bid_value':2},{'id':'zap2', 'relevance_score':0.5,'default_bid_value':2}]}
response=requests.get(url, json=request_packet)
print(response.json())


