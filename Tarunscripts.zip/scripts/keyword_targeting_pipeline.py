import sys
import argparse
import subprocess

parser = argparse.ArgumentParser(description='Keyword onboarding process of exisitng Retailers')
parser.add_argument('-i', '--id', help='ID', required=True)
parser.add_argument('-n', '--name', help='retailer_name', required=True)
parser.add_argument('-t', '--type', help='onboarding type',required=True)
parser.add_argument('-c', '--container', help='retailer_container',required=True)
parser.add_argument('-p', '--path', help='search file path',required=False)
parser.add_argument('-e', '--env', help='environment to push data', required=False)
parser.add_argument('-cs', '--cat_src', help='catalog_source', type=str, default='prod')
args = vars(parser.parse_args())

retailer_id = args["id"]
retailer_name = args["name"]
onboarding_type = args["type"]
container_name = args["container"]
environment = args["env"]
catalogue_source = args["cat_src"]

print("Running retailer onboarding lite")
try:
    subprocess.run(
        ["time python3  retailer_onboarding_lite.py --id " + str(retailer_id) +
         " --name " + str(retailer_name) + " --container "+ str(container_name) +
         " --env "+ str(environment) + " --cat_src "+ str(catalogue_source)],
        shell=True)
except subprocess.CalledProcessError as e:
    err_msg = "Retailer onboarding lite could not be completed"
    sys.exit(err_msg)


if onboarding_type == 'yake':

    print("Running yake job")
    try:
        subprocess.run(
            ["time python3 yake_keyword_generation.py --id " + str(retailer_id) + " --name " + str(retailer_name) + " --env "+ str(environment)], shell=True)
    except subprocess.CalledProcessError as e:
        err_msg = "Yake keyword generation could not be completed"
        sys.exit(err_msg)

    print("Running job for post processing")
    try:
        subprocess.run(["time python3  keyword_targeting_post_processing.py --id "  + str(retailer_id) + " --env "+ str(environment)], shell=True)
    except subprocess.CalledProcessError as e:
        err_msg = "Post processing could not be completed"
        sys.exit(err_msg)
    print("Done")

elif onboarding_type == 'search':
    search_file_path = args["path"]
    print("Running keyword onboarding from search keywords")
    try:
        subprocess.run(
            ["time python3  search_day1.py --id " + str(retailer_id) + " --path " + str(search_file_path) + " --env "+ str(environment)+ " --cat_src "+ str(catalogue_source)],shell=True)
    except subprocess.CalledProcessError as e:
        err_msg = "Retailer onboarding lite could not be completed"
        sys.exit(err_msg)

elif onboarding_type == 'reboarding':
    environment = args["env"]
    print("Reboarding retailer {retailer_id} in {env} environment".format(retailer_id=retailer_id, env=environment))
    try:
        subprocess.run(
            ["time python3  keyword_reboarding.py --id " + str(retailer_id) + " --env " + str(environment)], shell=True)
    except subprocess.CalledProcessError as e:
        err_msg = "Retailer onboarding lite could not be completed"
        sys.exit(err_msg)
