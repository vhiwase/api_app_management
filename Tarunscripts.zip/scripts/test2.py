# pylint: disable=all
from context.context import Context
import yake
import pandas as pd
import numpy as np
import nltk
import pickle
from nltk.stem import PorterStemmer, WordNetLemmatizer
import re
from scipy import spatial
from relevance.relevance_engine import RelevanceEngine
from nltk.corpus import stopwords
import os
import itertools
from util.keyword_targetting_utils import KeywordHash
from config import Config, LocalConfig
import time
from azure.storage.blob import BlobServiceClient
from util.mongo_util import MongoUtil
from collections import defaultdict

if not os.path.exists('./nltk_data'):
    os.mkdir("./nltk_data")
nltk.download('stopwords', "./nltk_data/")
nltk.data.path.append("./nltk_data/")


class KeywordTargeting:

    def __init__(self):
        self.yake_model = self.yake_model_initialize()
        self.relevance_engine = RelevanceEngine()
        self.porter = PorterStemmer()
        self.wordnet_lemmatizer = WordNetLemmatizer()
        self.stopwords_set = stopwords.words('english')
        self.KH = KeywordHash()

    def get_similar_products(self, retailer, sku, n):
        return self.relevance_engine.get_products_by_product(retailer, sku)

    def get_keywords_data(self, retailer, sku):
        try:
            product_data = retailer.data.loc[
                retailer.data['sku'] == sku, ['brand', 'category', 'productType', 'name', 'description']]
            if product_data.shape[0] == 0:
                raise Exception()

        except:
            properties = {'sku_id': sku}
            Context.logger_client.track_trace("EK101: ERROR IN RETRIEVING DATA GIVEN SKU ID", properties)
            return None

        product_data['relevance_score'] = 1

        #         sim_products_data = self.get_similar_products(retailer, sku, n)
        #         sim_products_data1 = sim_products_data[['brand', 'category',
        #         'productType', 'name','description', 'relevance_score']]

        final_data = product_data
        #        final_data = product_data.append(sim_products_data1,ignore_index=True).drop_duplicates()
        final_data['brand_category'] = final_data['brand'] + ' ' + final_data['category']
        final_data['brand_productType'] = final_data['brand'] + ' ' + final_data['productType']
        final_data['category_productType'] = final_data['category'] + ' ' + final_data['productType']

        final_data['yake_keywords_name'] = final_data['name'].apply(self.yake_model.extract_keywords)
        final_data['yake_keywords_description'] = final_data['description'].apply(self.yake_model.extract_keywords)
        return final_data

    @staticmethod
    def yake_model_initialize():
        language = "en"
        max_ngram_size = 3
        deduplication_threshold = 0.9
        numofkeywords = 5
        custom_kw_extractor = yake.KeywordExtractor(lan=language, n=max_ngram_size, dedupLim=deduplication_threshold,
                                                    top=numofkeywords, features=None)
        return custom_kw_extractor

    def get_complementary_keywords(self, retailer, sku, keywords_list):
        full_keywords_list = self.get_keywords_with_relevance(retailer, sku)
        return full_keywords_list[~full_keywords_list['keyword'].isin(keywords_list)]

    def get_keyword_combinations(self, retailer, sku, sku_description_hash=None):
        final_keywords_list = []
        final_keywords_list1 = []
        brand = retailer.get_product_by_sku(sku).get_brand()
        product_type = retailer.get_product_by_sku(sku).get_product_type()

        """Splitting the keywords to increase keywords list """
        brand_list = re.split('; |& |, |\*|\n', brand)
        product_type_list = re.split('; |& |, |\*|\n', product_type)
        yake_keywords_name = self.yake_model.extract_keywords(retailer.get_product_by_sku(sku).get_name())
        yake_keywords_description = self.yake_model.extract_keywords(sku_description_hash[sku])
        yake_keywords_name_list = [i[0] for i in yake_keywords_name]
        yake_keywords_description_list = [i[0] for i in yake_keywords_description]
        yake_keywords_list = yake_keywords_name_list + yake_keywords_description_list
        for yake_keyword in yake_keywords_list:
            t = [brand_list, product_type_list, [yake_keyword]]
            combination = [item for sublist in t for item in sublist]
            combinations_list = []
            for L in range(0, len(combination) + 1):
                for subset in itertools.permutations(combination, L):
                    combinations_list.append(list(subset))
            combinations_list_final = [' '.join(words) for words in combinations_list]
            final_keywords_list.extend(combinations_list_final)
            for final_keyword in final_keywords_list:
                final_keyword = self.preprocess_text(final_keyword)
                words = final_keyword.split()
                if len(words) <= 4:
                    final_keywords_list1.append(final_keyword)
                else:
                    final_keywords_list1.extend(self.return_left_right(final_keyword))
            final_keywords_list1 = list(set(final_keywords_list1))
            final_keywords_list1.sort(key=len)
            final_keywords_list1.remove('')
        return final_keywords_list1

    def preprocess_text(self, string):
        stem_tokens_list = []
        regex = re.compile('[^A-Za-z0-9]+')
        string = regex.sub(r' ', string)
        string = string.strip()
        text_tokens = string.split()
        tokens_without_sw = [word for word in text_tokens if not word in self.stopwords_set]
        for word in tokens_without_sw:
            stem_token = self.porter.stem(word)
            stem_tokens_list.append(stem_token)
        indexes = np.sort([stem_tokens_list.index(x) for x in set(stem_tokens_list)])
        preprocessed_string = " ".join(([tokens_without_sw[index] for index in indexes]))
        return preprocessed_string

    def preprocess_text_lite(self, string):
        regex = re.compile('[^A-Za-z0-9]+')
        string = string.lower()
        string = regex.sub(r' ', string)
        preprocessed_string = string.strip()
        return preprocessed_string

    @staticmethod
    def get_string_permutations(string):
        combinations_list = []
        tokens_list = [string.split()]
        combination = [item for sublist in tokens_list for item in sublist]
        for L in range(0, len(combination) + 1):
            for subset in itertools.permutations(combination, L):
                combinations_list.append(list(subset))
        combinations_string = [' '.join(words) for words in combinations_list]
        combinations_string.remove('')
        return (combinations_string)

    def get_hash_to_mined_keywords_dict(self, keywords_list):
        mined_keywords_dict = {}
        for keyword in keywords_list:
            preprocessed_string = self.preprocess_text(keyword)
            string_permutations = self.get_string_permutations(preprocessed_string)
            mined_keywords_dict[self.KH.get_keyword_hash(keyword)] = string_permutations
        return (mined_keywords_dict)

    @staticmethod
    def return_left_right(string):
        left = ' '.join(string.split()[:3])
        right = ' '.join(string.split()[-3:])
        return [left, right]

    def get_embeddings_list(self, keywords_list):
        keyword_embeddings_list = []
        for keyword in keywords_list:
            keyword_embedding = self.relevance_engine.get_query_embedding(keyword)[0]
            keyword_embeddings_list.append(keyword_embedding)
        return keyword_embeddings_list

    def keyword_ranker(self, retailer, keywords_list, sku, keyword_embeddings=None):
        try:
            data = self.get_keywords_data(retailer, sku)
            brand_list = re.split(r'\W+', data['brand'].values[0])
            product_type_list = re.split(r'\W+', data['productType'].values[0])
            product_embedding = retailer.get_product_by_sku(sku).get_embeding()
        except:
            properties = {'sku_id': sku}
            Context.logger_client.track_trace("EK102: ERROR IN RETRIEVING PRODUCT EMBEDDING GIVEN SKU ID",
                                              properties)
            return pd.DataFrame([['None', 0.0]], columns=['keyword', 'similarity_score'])
        cosine_similarity_list = []

        if keyword_embeddings is None:
            keyword_embeddings = self.get_embeddings_list(keywords_list)

        for i in range(len(keyword_embeddings)):
            keyword_embedding = keyword_embeddings[i]
            try:
                embedding_similarity = 1 - spatial.distance.cosine(keyword_embedding, product_embedding)
            except:
                embedding_similarity = 0
            cosine_similarity_list.append(embedding_similarity)
        similarity_frame = pd.DataFrame(data={'keyword': keywords_list,
                                              'similarity_score': cosine_similarity_list})

        similarity_frame["key"] = similarity_frame["keyword"].apply(self.KH.get_keyword_hash)
        avg_score_df = similarity_frame.groupby('key')[['similarity_score']].mean()
        similarity_frame.drop('similarity_score', inplace=True, axis=1)
        similarity_frame = similarity_frame.join(avg_score_df, on=['key'])
        similarity_frame.drop('key', inplace=True, axis=1)

        similarity_frame['brand_ratio'] = similarity_frame['keyword'].apply(self.string_matcher, args=([brand_list]))
        similarity_frame['productType_ratio'] = similarity_frame['keyword'].apply(self.string_matcher,
                                                                                  args=([product_type_list]))
        similarity_frame['similarity_score'] = (0.5 * similarity_frame['similarity_score']) + \
                                               (0.3 * similarity_frame['brand_ratio']) + (
                                                       0.2 * similarity_frame['productType_ratio'])
        similarity_frame.drop(['brand_ratio', 'productType_ratio'], axis=1, inplace=True)
        similarity_frame.sort_values(by='similarity_score', ascending=False, inplace=True)
        return similarity_frame

    def get_keywords_with_relevance(self, retailer, sku):
        keyword_list = self.get_keyword_combinations(retailer, sku)
        if not keyword_list:
            return pd.DataFrame()
        ranked_keywords = self.keyword_ranker(retailer, keyword_list, sku)
        ranked_keywords = ranked_keywords[ranked_keywords['similarity_score'] > 0.3]
        return ranked_keywords

    @staticmethod
    def string_matcher(string, keywords_list):
        keyword_set = set(' '.join(keywords_list).lower().split(' '))
        string_set = set(string.lower().split(' '))
        ratio = len(list(keyword_set & string_set)) / len(list(keyword_set))
        return ratio

    def get_data_from_blob(self, blob_name):
        Context.download_blob(blob_name, LocalConfig.DATA_FOLDER_PATH)
        with open(LocalConfig.DATA_FOLDER_PATH + blob_name, 'rb') as data:
            blob = pickle.load(data)
            return blob

    def push_data_to_blob(self, file, file_name):
        blob_service_client = BlobServiceClient.from_connection_string(
            Config.AzureConfig.ICC_DS_STORAGE_CONNECTION_STRING)
        blob_client = blob_service_client.get_blob_client(container=Config.AzureConfig.CONTAINER_NAME,
                                                          blob=file_name)
        with open(LocalConfig.DATA_FOLDER_PATH + file_name, 'wb') as handle:
            pickle.dump(file, handle, protocol=pickle.HIGHEST_PROTOCOL)

        with open(LocalConfig.DATA_FOLDER_PATH + file_name, 'rb') as data:
            blob_client.upload_blob(data, overwrite=True)

    def get_retailer_keywords_dict_v1(self, retailer):
        retailer_id = retailer.meta_data['_id']
        skus = list(retailer.data.sku.unique())
        st = time.time()
        sku_description_hash = retailer.data.set_index('sku')['description'].to_dict()
        print("time taken to calculate desription hash is ", time.time() - st)
        sku_keywords_dict = {}
        i = 0
        temp_file_name = str(retailer_id) + '_yake_keywords_dict_temp.pkl'
        for sku in skus:
            try:
                st = time.time()
                keyword_list = self.get_keyword_combinations(retailer, sku, sku_description_hash)
                print("time taken to get keyword combintions for single sku ", time.time() - st)
                sku_keywords_dict[sku] = keyword_list
            except:
                pass
            i = i + 1
            if (i % 1000 == 0):
                print("No of Skus processed: ", i)
            if (i % 10000 == 0):
                self.push_data_to_blob(sku_keywords_dict, temp_file_name)
        return sku_keywords_dict

    @staticmethod
    def get_nearest_keywords(retailer, faiss_index, keyword_list, sku):
        """ To change to n nearest based on score cutoff"""
        try:
            product_embedding = retailer.get_product_by_sku(sku).get_embeding()
            distance, index = faiss_index.search(product_embedding, k=50)
            nearest_keywords = [keyword_list[i] for i in index[0]]
        except:
            return ['None']
        return nearest_keywords, distance[0]

    def get_hash_keyword_dict(self, keywords_list):
        keyword_hash = []
        keywords_list = list(set(map(self.preprocess_text_lite, keywords_list)))
        for keyword in keywords_list:
            keyword_hash.append(self.KH.get_keyword_hash(keyword))

        hash_keywords_dict = defaultdict(list)
        for key, value in zip(keyword_hash, keywords_list):
            hash_keywords_dict[key].append(value)
        return hash_keywords_dict

    def create_mongo_data(self, dictionary_data, dict_type):
        final_data = []
        for key in list(dictionary_data.keys()):
            mongo_dict = {}
            mongo_dict['_id'] = key
            if dict_type == 'sku_hash':
                mongo_dict['target'] = dictionary_data[key]
            elif dict_type == 'hash_keyword':
                mongo_dict['keywords'] = dictionary_data[key]
            else:
                print("Wrong dictionary type")
            final_data.append(mongo_dict)
        return final_data

    def push_data_to_mongo(self, mongo_data, dict_type, retailer_id):
        if dict_type == 'sku_hash_exact':
            mongo_client = MongoUtil(Config.AzureConfig.COSMOS_URI, Config.AzureConfig.COSMOS_KEYWORD_TARGETING_DB,
                                     str(retailer_id))
        elif dict_type == 'sku_hash_broad':
            mongo_client = MongoUtil(Config.AzureConfig.COSMOS_URI,
                                     Config.AzureConfig.COSMOS_BROAD_KEYWORD_TARGETING_DB,
                                     str(retailer_id))
        elif dict_type == 'hash_keyword':
            mongo_client = MongoUtil(Config.AzureConfig.COSMOS_URI, Config.AzureConfig.COSMOS_HASH_TO_KEYWORD_DB,
                                     str(retailer_id))
        else:
            print("Wrong dictionary type")

        try:
            mongo_client.upsert_bulk(mongo_data)
        except:
            print("Cannot push data to mongo")

    def add_mapping(self, retailer_dict, existing_map, new_mapping):
        final_map = existing_map.copy()
        for sku in new_mapping.keys():
            try:
                brand = retailer_dict[sku]['brand']
                brand_list_hashes = list(map(self.KH.get_keyword_hash, re.split(r'\W+', brand)))
            except:
                brand_list_hashes = ' '
            try:
                product_type = retailer_dict[sku]['productType']
                product_type_list_hashes = list(map(self.KH.get_keyword_hash, re.split(r'\W+', product_type)))
            except:
                product_type_list_hashes = ' '
            try:
                category = retailer_dict[sku]['category']
                category_list_hashes = list(map(self.KH.get_keyword_hash, re.split(r'\W+', category)))
            except:
                category_list_hashes = ' '

            new_search_hash_pairs = []
            existing_map_hashes_list = []
            if sku in existing_map.keys():
                for hash_dict in existing_map[sku]:
                    existing_map_hashes_list.append(hash_dict['hash'])
            else:
                existing_map_hashes_list = []
            for hash_dict in new_mapping[sku]:
                if hash_dict['hash'] not in existing_map_hashes_list:
                    hash_string = hash_dict['hash'].split(' ')
                    cat_boost = 0.1 * len(list(set(hash_string).intersection(category_list_hashes))) / len(
                        category_list_hashes)
                    brand_boost = 0.2 * len(list(set(hash_string).intersection(brand_list_hashes))) / len(
                        brand_list_hashes)
                    product_type_boost = 0.2 * len(
                        list(set(hash_string).intersection(product_type_list_hashes))) / len(
                        product_type_list_hashes)
                    final_relevance_score = .5 * hash_dict[
                        'relevance_score'] + brand_boost + product_type_boost + cat_boost
                    new_search_hash_pairs.extend(
                        [{'hash': hash_dict['hash'], 'relevance_score': final_relevance_score}])
            try:
                combined_hash_pairs = final_map[sku] + new_search_hash_pairs
            except:
                combined_hash_pairs = new_search_hash_pairs
            combined_hash_pairs1 = sorted(combined_hash_pairs, key=lambda d: d['relevance_score'], reverse=True)[:1000]
            final_map[sku] = combined_hash_pairs1
        return final_map



