# pylint: disable=all
from util.azure_batch_logger import BatchLog
import sys
import os
import pandas as pd
import numpy as np
import re
import time
from util.keyword_targetting_utils import KeywordHash
from util.meta_data_extractor import MetaDataExtractor
from relevance.keywordtargeting import KeywordTargeting
from context.context import Context
from util.read_write_data_azure_blob import ReadAndWriteFromAzureBlob
import keyword_product_map_helper
from keyword_targeting_post_processing import PostProcess
import pickle
from scipy import spatial
import itertools
from datetime import datetime, timedelta
import faiss
import argparse
from numpy import dot
from config import Config, LocalConfig

class KeywordMining:

    def __init__(self):
        self.KT = KeywordTargeting()
        self.KH = KeywordHash()
        self.PP = PostProcess()
        self.read_write_blob = ReadAndWriteFromAzureBlob()
        self.time_delta = 1
        self.date_string_split = datetime.strftime(
            datetime.now() - timedelta(self.time_delta),
            '%Y/%m/%d').split('/')

    def get_search_logs(self, retailer_id):
        count = self.read_write_blob.get_input_df_from_csv(
            retailer_id,
            'keyword_count',
            days_from_current_day=self.time_delta)
        count.fillna(0, inplace=True)
        count['targeting_value'] = count['targeting_value'].apply(
            lambda x: x.lower())
        count = count.groupby(['targeting_type', 'targeting_value']
                              ).sum().reset_index()
        return count

    def get_producttype_mapping(self, retailer_data, retailer_dict, search_hash_keywords_list, sku_product_type_dict,
                                sentence_hash_embeddings):
        producttype_to_sku = retailer_data.groupby('productType')['sku'].apply(list).to_dict()
        producttype_to_sku1 = {}
        for product_type in producttype_to_sku.keys():
            producttype_to_sku1[self.KH.get_keyword_hash(product_type)] = producttype_to_sku[product_type]

        sku_producttype_keyword_map = {}
        product_type_list = list(producttype_to_sku1.keys())
        for hash in search_hash_keywords_list:
            product_type_present_list = []
            for product_type in product_type_list:
                if (product_type in hash):
                    product_type_present_list.append(product_type)
            if not product_type_present_list:
                continue
            products_list = []
            for producttype in product_type_present_list:
                products_list.extend(producttype_to_sku1[producttype])
            product_embeddings_list = []
            for product in products_list:
                product_embeddings_list.append(retailer_dict[product]['embedding'][0])
            product_embeddings_matrix = np.array(product_embeddings_list)
            sentence_embedding_matrix = sentence_hash_embeddings[hash]
            cosine_similarity = (1 + dot(product_embeddings_matrix,sentence_embedding_matrix)) / 2
            pairs_similairy_list = zip(*[products_list, cosine_similarity])
            for pair in pairs_similairy_list:
                try:
                    sku_producttype_keyword_map[pair[0]].extend([{'hash': hash, 'relevance_score': pair[1]}])
                except:
                    sku_producttype_keyword_map[pair[0]] = [{'hash': hash, 'relevance_score': pair[1]}]
        return sku_producttype_keyword_map

    def add_logs(self):
        log_file = "BatchJobLogs/year={}/month={}/day={}/" \
                   "SearchJob.log".format(
            self.date_string_split[0],
            self.date_string_split[1],
            self.date_string_split[2])

        self.read_write_blob.write_log_to_blob(
            Config.AzureConfig.RECOMMENDATION_OUT_STRING,
            Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME,
            log_file)


if __name__ == "__main__":
    start = time.time()
    KM = KeywordMining()
    parser = argparse.ArgumentParser(description='Running search mining')
    parser.add_argument('-i', '--id', help='ID', required=True)
    parser.add_argument('-p', '--path', help='search logs path', required=True)
    args = vars(parser.parse_args())

    retailer_id = eval(args['id'])
    search_logs_path = args['path']
    print(retailer_id)
    data_path = LocalConfig.DATA_FOLDER_PATH + str(retailer_id) + '/'
    retailer_data = KM.KT.get_data_from_blob("full_data_KT_" + str(retailer_id) + ".pkl")
    retailer_dict = KM.KT.get_data_from_blob(str(retailer_id) + '_keyword_targeting_base_data.pkl')
    retailer_faiss_index = faiss.read_index(data_path + str(retailer_id) + '_text_faiss_retailer_lite.index')

    search_data = pd.read_csv(search_logs_path).dropna()
    search_data1 = search_data.rename(columns={'count':'Count'}).groupby('keywords', as_index=False).agg({'Count': sum}).sort_values(by='Count',  ascending=False)
    search_data1['cumulative_sum'] = search_data1['Count'].cumsum()
    search_data2 = search_data1[search_data1.cumulative_sum <int(.7*search_data1['Count'].sum())].reset_index()
    search_keywords = list(search_data2.loc[:, 'keywords'])
    print("No of search terms ", len(search_keywords))
    search_hash_keywords_dict = KM.KT.get_hash_keyword_dict(search_data2)
    search_hash_keywords_keys = search_hash_keywords_dict.keys()

    #### Get unique keywords ###
    unique_keywords_list = []
    for hash in search_hash_keywords_dict:
        unique_keywords_list.append(search_hash_keywords_dict[hash][0])

        ## Generate and add search mapping ######
    sku_to_keyword = {}
    st = time.time()
    keywords_map_new = keyword_product_map_helper.main(retailer_data, unique_keywords_list, 100, 'keyword_onboarding',retailer_faiss_index)

    print("Time taken to get keywords product map from faiss is ", time.time() - st)
    sku_to_keyword_new = KM.PP.get_sku_keyword_faiss(keywords_map_new)
    BatchLog.info("[function]:search_keyword_targeting [message]:"
                  "No of skus to update with faiss mapping :{sku_count} for retailer:{retailer_id}".format(
        sku_count=len(sku_to_keyword_new), retailer_id=retailer_id))

    os.rename('model_nns.pkl', str(retailer_id) + '_search_model_nns.pkl')
    os.rename('sentences.pkl', str(retailer_id) + '_search_sentences.pkl')
    os.rename('sentence_embeddings.pkl', str(retailer_id) + '_search_sentence_embeddings.pkl')

    #### Generate and add producttype mapping #####
    st = time.time()
    print("Adding producttype mapping")

    with open(str(retailer_id) + '_search_sentence_embeddings.pkl', 'rb') as f:
        sentence_embeddings = pickle.load(f)
    sentence_hash_embeddings = {}
    for sentence in sentence_embeddings.keys():
        sentence_hash_embeddings[KM.KH.get_keyword_hash(sentence)] = sentence_embeddings[sentence]
    sku_product_type_dict = {}
    for index, row in retailer_data.iterrows():
        sku_product_type_dict[row.sku] = KM.KH.get_keyword_hash(row.productType)
    sku_producttype_keyword_map = KM.get_producttype_mapping(retailer_data, retailer_dict, search_hash_keywords_keys,
                                                             sku_product_type_dict, sentence_hash_embeddings)
    BatchLog.info("[function]:search_keyword_targeting [message]:"
                  "No of skus to update with producttype mapping:{sku_count} for retailer:{retailer_id}".format(
        sku_count=len(sku_producttype_keyword_map), retailer_id=retailer_id))
    new_sku_to_keyword_map1 = KM.KT.add_mapping(retailer_dict,sku_to_keyword_new, sku_producttype_keyword_map)

    print("Producttype mapping add done in: ", time.time() - st)

    ###### Creating broad and exact keyword targeting ##########
    sku_keyword_map_exact = {}
    sku_keyword_map_broad = {}
    for sku in new_sku_to_keyword_map1.keys():
        combined_hash_pairs = sorted(new_sku_to_keyword_map1[sku], key=lambda d: d['relevance_score'], reverse=True)[:1000]
        combined_hash_pairs_exact = [x for x in combined_hash_pairs if x['relevance_score'] > .85]
        sku_keyword_map_exact[sku] = combined_hash_pairs_exact
        combined_hash_pairs_broad = [x for x in combined_hash_pairs if x['relevance_score'] > .75]
        sku_keyword_map_broad[sku] = combined_hash_pairs_broad
    print("Created broad and exact match pairs")

    print("Adding boosting")
    st = time.time()
    sku_keyword_map_exact = KM.KT.add_boosting(retailer_dict,sku_keyword_map_exact)
    sku_keyword_map_broad = KM.KT.add_boosting(retailer_dict,sku_keyword_map_broad)
    new_sku_to_keyword_map1 = KM.KT.add_boosting(retailer_dict, new_sku_to_keyword_map1)
    print("Boosting done in: ",time.time()-st)



    st = time.time()
    KM.KT.push_data_to_blob(new_sku_to_keyword_map1, str(retailer_id) + '_combined_sku_hash_dict.pkl')
    KM.KT.push_data_to_blob(sku_keyword_map_exact, str(retailer_id) + '_sku_keyword_map_exact.pkl')
    KM.KT.push_data_to_blob(sku_keyword_map_broad, str(retailer_id) + '_sku_keyword_map_broad.pkl')
    print("time taken to push to blob ", time.time() - st)

    st= time.time()
    mongo_data_sku_hash_broad = KM.KT.create_mongo_data(sku_keyword_map_broad, 'sku_hash')
    KM.KT.push_data_to_mongo(mongo_data_sku_hash_broad, 'sku_hash_broad', retailer_id)
    print("Time taken to insert broad sku hash dict to mongo is", time.time() - st)

    st = time.time()
    mongo_data_sku_hash_exact = KM.KT.create_mongo_data(sku_keyword_map_exact, 'sku_hash')
    KM.KT.push_data_to_mongo(mongo_data_sku_hash_exact, 'sku_hash_exact', retailer_id)
    print("Time taken to insert exact sku hash dict to mongo is", time.time() - st)

    st = time.time()
    KM.KT.push_data_to_blob(search_data2, str(retailer_id) + '_keywords_count_df.pkl')
    mongo_data_hash_keyword = KM.KT.create_mongo_data(search_hash_keywords_dict, 'hash_keyword')
    KM.KT.push_data_to_mongo(mongo_data_hash_keyword, 'hash_keyword', retailer_id)
    print("time taken to push hash keyword to mongo ", time.time() - st)

    os.remove(str(retailer_id) + '_search_model_nns.pkl')
    os.remove(str(retailer_id) + '_search_sentences.pkl')
    os.remove(str(retailer_id) + '_search_sentence_embeddings.pkl')

    KM.add_logs()