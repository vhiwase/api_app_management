from config import Config, LocalConfig
from context.context import Context
import pandas as pd
import numpy as np
import argparse
import os
import time
import sys
from azure.storage.blob import BlobServiceClient
import yake
import re
import itertools
import multiprocessing
from multiprocessing import Process, Queue
import nltk
import pickle
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer, WordNetLemmatizer
from config import Config, LocalConfig
from relevance.keywordtargeting import KeywordTargeting
from util.keyword_targetting_utils import KeywordHash

if not os.path.exists('./nltk_data'):
    os.mkdir("./nltk_data")
nltk.download('stopwords', "./nltk_data/")
nltk.download('punkt', "./nltk_data/")
nltk.download('wordnet', "./nltk_data/")
nltk.data.path.append("./nltk_data/")


class YakeKeywordGen:
    def __init__(self, retailer_info, data=pd.DataFrame()):
        self.retailer_info = retailer_info
        Config.switch_env(self.retailer_info['env'])
        self.retailer_id = self.retailer_info['id']
        if data.empty:
            self.full_file_name = "full_data_KT_" + self.retailer_id + ".pkl"
            self.data_path = LocalConfig.DATA_FOLDER_PATH + self.retailer_info['id'] + '/'
            os.makedirs(self.data_path, exist_ok=True)
            Context.download_blob(self.full_file_name, self.data_path)
            self.data = pd.read_pickle(self.data_path + self.full_file_name)
        else:
            self.data = data
        self.porter = PorterStemmer()
        self.wordnet_lemmatizer = WordNetLemmatizer()
        self.stopwords_list = stopwords.words()
        self.KT = KeywordTargeting()
        self.KH = KeywordHash()

    def get_retailer_kwds_in_chunk(self, skus, sku_name_map, sku_desc_map, sku_brand_map, sku_pt_map, out_q, i):
        yake_model = self.KT.yake_model_initialize()
        final_keywords_hash = {}
        for ind, sku in enumerate(skus):
            if ind % 1000 == 0:
                print("Generated %d yake kwds in chunk %d" % (ind, i))
            final_keywords_list = []
            final_keywords_list1 = []
            brand = sku_brand_map.get(sku, '')
            product_type = sku_pt_map.get(sku, '')

            """Splitting the keywords to increase keywords list """
            try:
                brand_list = re.split(r'\W+', brand)
            except:
                brand_list = ''
            try:
                product_type_list = re.split(r'\W+', product_type)
            except:
                product_type_list = ''
            yake_keywords_name = yake_model.extract_keywords(sku_name_map.get(sku, ''))
            yake_keywords_description = yake_model.extract_keywords(sku_desc_map.get(sku, ''))
            yake_keywords_name_list = [i[0] for i in yake_keywords_name]
            yake_keywords_description_list = [i[0] for i in yake_keywords_description]
            yake_keywords_list = yake_keywords_name_list + yake_keywords_description_list
            for yake_keyword in yake_keywords_list:
                t = [brand_list, product_type_list, [yake_keyword]]
                combination = [item for sublist in t for item in sublist]
                combinations_list = []
                for L in range(0, len(combination) + 1):
                    for subset in itertools.permutations(combination, L):
                        combinations_list.append(list(subset))
                combinations_list_final = [' '.join(words) for words in combinations_list]
                final_keywords_list.extend(combinations_list_final)
                for final_keyword in final_keywords_list:
                    final_keyword = self.KH.preprocess_text_lite(final_keyword)
                    words = final_keyword.split()
                    if len(words) <= 4:
                        final_keywords_list1.append(final_keyword)
                    else:
                        final_keywords_list1.extend(self.KT.return_left_right(final_keyword))
                final_keywords_list1 = list(set(final_keywords_list1))
                final_keywords_list1.sort(key=len)
                final_keywords_list1.remove('')
            final_keywords_hash[sku] = final_keywords_list1
        out_q.put(final_keywords_hash)

    def get_retailer_kwds(self, skus, sku_name_map, sku_desc_map, sku_brand_map, sku_pt_map):
        num_cores = max(multiprocessing.cpu_count() - 4, 1)
        chunk_size = int(len(skus) / num_cores) + 1
        print("chunk size: %d" % chunk_size)
        dict_list = []
        process_list = []
        retailer_kwds = {}
        out_q = Queue()
        i = 0
        while i < num_cores:
            print("processing chunk %d" % i)
            st = i * chunk_size
            ed = (i + 1) * chunk_size
            sku_chunk = skus[st:ed]
            p = Process(target=self.get_retailer_kwds_in_chunk,
                        args=(sku_chunk, sku_name_map, sku_desc_map, sku_brand_map, sku_pt_map, out_q, i))
            process_list.append(p)
            p.start()
            i += 1
        for i in range(num_cores):
            dict_list.append(out_q.get())
        for p in process_list:
            p.join()
        for _dict in dict_list:
            retailer_kwds.update(_dict)
        return retailer_kwds

    def get_keyword_combinations(self, retailer_data):
        retailer_data.reset_index(inplace=True)
        sku_yake_dict = {}
        for index, row in retailer_data.iterrows():
            final_keywords_list = []
            final_keywords_list1 = []
            brand = row.brand
            product_type = row.productType
            sku = row.sku
            """Splitting the keywords to increase keywords list """
            brand_list = [brand] if brand else []
            product_type_list = [product_type] if product_type else []
            yake_keywords_name = self.KT.yake_model.extract_keywords(row['name'])
            yake_keywords_description = self.KT.yake_model.extract_keywords(row['description'])
            yake_keywords_name_list = [i[0] for i in yake_keywords_name]
            yake_keywords_description_list = [i[0] for i in yake_keywords_description]
            yake_keywords_list = yake_keywords_name_list + yake_keywords_description_list
            for yake_keyword in yake_keywords_list:
                t = [brand_list, product_type_list, [yake_keyword]]
                combination = [item for sublist in t for item in sublist]
                combinations_list = []
                for L in range(0, len(combination) + 1):
                    for subset in itertools.permutations(combination, L):
                        combinations_list.append(list(subset))
                combinations_list_final = [' '.join(words) for words in combinations_list]
                final_keywords_list.extend(combinations_list_final)
                for final_keyword in final_keywords_list:
                    final_keyword = self.KH.preprocess_text_lite(final_keyword)
                    words = final_keyword.split()
                    if len(words) <= 4:
                        final_keywords_list1.append(final_keyword)
                    else:
                        final_keywords_list1.extend(self.KT.return_left_right(final_keyword))
                final_keywords_list1 = list(set(final_keywords_list1))
                final_keywords_list1.sort(key=len)
                final_keywords_list1.remove('')
            sku_yake_dict[sku] = final_keywords_list1
            if (index % 1000 == 0):
                print("No of skus processed: ", index)

        return sku_yake_dict

    def main(self):
        if self.data.empty:
            err_msg = "Data for retailer %s is empty." % self.retailer_id
            sys.exit(err_msg)
        # list_of_skus = self.data['sku'].values.tolist()
        # list_of_names = self.data['name'].values.tolist()
        # sku_name_map = dict(zip(list_of_skus, list_of_names))
        # list_of_descs = self.data['description'].values.tolist()
        # sku_desc_map = dict(zip(list_of_skus, list_of_descs))
        # list_of_brands = self.data['brand'].values.tolist()
        # sku_brand_map = dict(zip(list_of_skus, list_of_brands))
        # list_of_pts = self.data['productType'].values.tolist()
        # sku_pt_map = dict(zip(list_of_skus, list_of_pts))
        # sku_kwds_dict = self.get_retailer_kwds(list_of_skus, sku_name_map, sku_desc_map, sku_brand_map, sku_pt_map)
        st = time.time()
        print("Generating keyword combinations")
        sku_kwds_dict = self.get_keyword_combinations(self.data)
        print("Time taken to generate keyword combinations ", time.time() - st)
        yake_kwds_file = self.retailer_id + '_yake_keywords_dict.pkl'

        st = time.time()
        self.KT.push_data_to_blob(sku_kwds_dict, yake_kwds_file)
        yake_keywords_list = []
        for sku, kwds in sku_kwds_dict.items():
            yake_keywords_list.extend(sku_kwds_dict[sku])
        final_keyword_list = list(set(yake_keywords_list))
        final_keywords_df = pd.DataFrame(final_keyword_list, columns=['keywords'])
        final_keywords_df['Count'] = 1
        self.KT.push_data_to_blob(final_keywords_df, str(self.retailer_info['id']) + '_keywords_count_df.pkl')
        hash_keyword_dict = self.KT.get_hash_keyword_dict(final_keywords_df)
        hash_kwds_file = self.retailer_id + '_hash_keyword_dict.pkl'
        self.KT.push_data_to_blob(hash_keyword_dict, hash_kwds_file)
        mongo_data_hash_keyword = self.KT.create_mongo_data(hash_keyword_dict, 'hash_keyword')
        self.KT.push_data_to_mongo(mongo_data_hash_keyword, 'hash_keyword', self.retailer_id)

        et = time.time()
        print("time taken to run keyboard onboarding:%s" % (et - st))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Keyword onboarding process of exisitng Retailers')
    parser.add_argument('-i', '--id', help='ID', required=True)
    parser.add_argument('-n', '--name', help='retailer_name', required=True)
    parser.add_argument('-e', '--env', help='environment', type=str, default='dev')
    args = vars(parser.parse_args())
    ko = YakeKeywordGen(args)
    ko.main()