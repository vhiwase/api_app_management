# pylint: disable=all
from config import Config, LocalConfig
from azure.cosmos.cosmos_client import CosmosClient
from sentence_transformers import SentenceTransformer
import pandas as pd
import random
from azure.storage.blob import BlobServiceClient
from context.context import Context
from config import Config, LocalConfig
import os, traceback, argparse
import nltk
import numpy as np
from relevance.keywordtargeting import KeywordTargeting
import faiss
import time
import shutil
import torch

class RetailerOnboardingLite:

    def __init__(self, retailer_info):
        self.retailer_info = retailer_info
        Config.switch_env(self.retailer_info['env'])
        self.file_name = "data_" + self.retailer_info['name'] + ".pkl"
        self.full_file_name = "full_data_" + self.retailer_info['name'] + ".pkl"
        self.data_path = LocalConfig.DATA_FOLDER_PATH + self.retailer_info['id'] + '/'
        os.makedirs(self.data_path, exist_ok=True)
        self.lemmatizer = nltk.stem.WordNetLemmatizer()
        self.w_tokenizer = nltk.tokenize.WhitespaceTokenizer()
        self.text_faiss_index_filename = self.retailer_info['id'] + '_text_faiss_retailer_lite.index'
        self.container_name = Config.AzureConfig.CONTAINER_NAME
        self.KT = KeywordTargeting()
        self.ROBERTA_BERT_MODEL = None
        self.blob_service_client = BlobServiceClient.from_connection_string(
            Config.AzureConfig.ICC_DS_STORAGE_CONNECTION_STRING)

    def __fetch_data_from_container(self):
        azure_sql_client = CosmosClient(Config.AzureConfig.COSMOS_SQL_ENDPOINT,
                                        Config.AzureConfig.COSMOS_SQL_PRIMARY_KEY)
        fetched_data = azure_sql_client.QueryItems(
            "dbs/" + Config.AzureConfig.COSMOS_SQL_DATABASE_NAME + "/colls/" + self.retailer_info["container"],
            {'query': 'SELECT * FROM root'}, {'enableCrossPartitionQuery': True}
        )
        return fetched_data

    @staticmethod
    def __download_model():
        print("Downloading model ", Config.AzureConfig.CPU_MODEL_BLOB_NAME, "  to ", LocalConfig.DATA_FOLDER_PATH)
        # make data directory if it not exist
        os.makedirs(LocalConfig.DATA_FOLDER_PATH, exist_ok=True)
        Context.download_blob(Config.AzureConfig.CPU_MODEL_BLOB_NAME, LocalConfig.DATA_FOLDER_PATH)
        shutil.unpack_archive(LocalConfig.DATA_FOLDER_PATH + Config.AzureConfig.CPU_MODEL_BLOB_NAME,
                              LocalConfig.MODEL_PATH)

    def __load_model(self):
        if not os.path.exists(LocalConfig.MODEL_PATH):
            self.__download_model()
        self.ROBERTA_BERT_MODEL = SentenceTransformer(LocalConfig.MODEL_PATH, device='cpu')

    def __preprocess_catalogue_data(self, data):
        data['category'] = data['category'].fillna('')
        data['brand'] = data['brand'].fillna('')
        data = data.rename(columns={'category':'category_path'})
        if "_ts" not in data.columns.values.tolist():
            data['_ts'] = pd.to_datetime('now')
        data = data.rename(columns={'productId': 'sku', 'title': 'name',
                                    'imageUrl': 'imageUrl',
                                    'subCategory': 'productType',
                                    'productUrl': 'link',
                                    '_ts': 'timestamp'})
        data['category'] = data['category_path'].apply(lambda x: x.split(">")[-2] if ">" in x else '')
        data['productType'] = data['category_path'].apply(lambda x: x.split(">")[-1] if ">" in x else x)
        #data['category'] = data['category_path'].str.split(">")[-2]
        #data['productType'] = data['category_path'].str.split(">")[-1]
        data = data[['sku', 'name', 'description', 'category', 'productType','price',
                     'category_path', 'brand', 'link', 'imageUrl', 'timestamp']]

        data['sku'] = data['sku'].astype(str).str.lower()
        data.drop_duplicates(subset='sku', inplace=True)
        data = data[~data['name'].isnull()]
        data = data.reset_index()
        data['FID'] = data.index

        data['description'].fillna('', inplace=True)
        data['productType'].fillna('', inplace=True)
        data['category'].fillna('', inplace=True)
        data['category'] = data['category'].str.replace('cat-', '')

        if 'category_path' in data.columns:
            #checking whether we have a place holder category_path
            #In such case all the entries will be na
            if data['category_path'].isna().sum() == data.shape[0] or sum(
                    data['category_path'] == '') == data.shape[0]:
                data['category_path'] = data['category'] + '>' + data['productType']
                category_path_col = None
            else:
                data['category_path'].fillna('', inplace=True)
                data['category_path'] = data.apply(
                    lambda x: (
                            x['category'] + '>' + x['productType']
                    ) if x['category_path'] == '' else x['category_path'], axis=1
                )
                category_path_col = 'Broad_Category'

            data.rename(
                columns={'category_path': 'Broad_Category'}, inplace=True
            )

        else:
            data['Broad_Category'] = data['category'] + '>' + data['productType']
            category_path_col = None

        #incase pt is also empty
        data['Broad_Category'] = data['Broad_Category'].str.strip(">")
        data['brand'] = data['brand'].str.lower()
        return data, category_path_col

    def __insert_embeddings(self, data):
        st = time.time()
        print('preprocessing data')
        data = self.__preprocess_titles(data)
        self.__load_model()
        print('Generating embeddings')
        num_cuda_devices = torch.cuda.device_count()
        cuda_devices = ["cuda:" + str(i) for i in range(0, num_cuda_devices)]
        pool = self.ROBERTA_BERT_MODEL.start_multi_process_pool(cuda_devices)
        embeddings = self.ROBERTA_BERT_MODEL.encode_multi_process(data['name'].to_list(),pool)
        embeddings = embeddings / np.expand_dims(np.linalg.norm(embeddings, axis=1), axis=1)
        self.ROBERTA_BERT_MODEL.stop_multi_process_pool(pool)
        data['embedding'] = list(embeddings)
        data['embedding'] = data['embedding'].apply(self.__change_dimensionality)
        et = time.time()
        print("time taken to calculate text embeddings: %s" % (et - st))
        return data

    def __change_dimensionality(self, embedding):
        return embedding.reshape(1, -1)

    def __fill_missing_price(self, price):
        if price is None or price == '':
            return float(random.randint(1, 50))
        else:
            return float(price)

    def __preprocess_titles(self, data):
        data['name'] = data['name'].str.lower()
        data['name'] = data['name'].apply(self.__lemmatize_title)
        data['name'] = data['name'].str.join(' ')
        data['description'] = data['description'].str.lower()
        data['description'] = data['description'].apply(self.__lemmatize_title)
        data['description'] = data['description'].str.join(' ')
        return data

    def __lemmatize_title(self, row):
        return [self.lemmatizer.lemmatize(w) for w in self.w_tokenizer.tokenize(row)]

    def __create_text_faiss_index(self, data, text_features, text_ids):
        vector_dimension = text_features[0].shape[1]
        nlist = int(data.shape[0] / 1000) + 1
        quantizer = faiss.IndexFlatL2(vector_dimension)
        text_features = np.vstack(text_features)
        text_ids = np.hstack(text_ids)
        faiss.normalize_L2(text_features)
        faiss_index = faiss.IndexIVFFlat(quantizer, vector_dimension, nlist)
        faiss_index.train(text_features)
        faiss_index.add_with_ids(text_features, text_ids)
        faiss_index_file = self.data_path + self.text_faiss_index_filename
        faiss.write_index(faiss_index, faiss_index_file)
        blob_push_status = self.__push_data_to_blob(self.data_path,
                                                    self.text_faiss_index_filename,
                                                    self.container_name)
        print("blob push status for text faiss index: %s" % blob_push_status)

        return faiss_index, nlist

    def __push_data_to_blob(self, data_path, file_name, container_name):
        blob_client = self.blob_service_client.get_blob_client(
            container=container_name, blob=file_name)
        print("\nUploading to Azure Storage as blob:\n\t" + file_name)
        with open(data_path + file_name, "rb") as data:
            blob_client.upload_blob(data, overwrite=True)
            return "File added/updated to Blob"
        return "Exception"

    def main(self):
        print("Running retailer onboarding lite in {env} environment".format(env=self.retailer_info['env']))
        print("Fetching data for onboarding lite in {env} environment from engg {src} catlog".format(
            env=self.retailer_info['env'],
            src=self.retailer_info['cat_src'])
        )
        Config.switch_env(self.retailer_info['cat_src'])
        data = self.__fetch_data_from_container()
        data = pd.DataFrame(data)
        retailer_id = self.retailer_info['id']
        retailer_name = self.retailer_info['name']
        print("Shape of the dataframe is ", data.shape)
        data, category_path_col = self.__preprocess_catalogue_data(data)
        print("Columns are ", data.columns)
        data = self.__insert_embeddings(data)
        text_features = data['embedding'].values.tolist()
        text_ids = data['FID'].values.tolist()
        text_skus = data['sku'].values.tolist()
        text_faiss_index, num_clusters = self.__create_text_faiss_index(data, text_features, text_ids)
        print("Pushing data to {env} environment".format(env=self.retailer_info['env']))
        Config.switch_env(self.retailer_info['env'])
        self.KT.push_data_to_blob(data, "full_data_KT_" + retailer_id + ".pkl")
        print("Done")


if __name__ == "__main__":
    KT = KeywordTargeting()
    parser = argparse.ArgumentParser(description='Onboarding process of new Retailers')
    parser.add_argument('-i', '--id', help='ID', required=True)
    parser.add_argument('-n', '--name', help='retailer_name', required=True)
    parser.add_argument('-c', '--container', help='retailer_container', required=True)
    parser.add_argument('-e', '--env', help='environment', type=str, default='dev')
    parser.add_argument('-cs', '--cat_src', help='catalog_source', type=str, default='prod')
    args = vars(parser.parse_args())
    retailer_lite = RetailerOnboardingLite(args)
    retailer_lite.main()