#Config.py
import re
import os


class LocalConfig:
    DATA_FOLDER_PATH = 'relevance_products/data/'
    LOGS_PATH = 'logs/'
    MODEL_PATH = DATA_FOLDER_PATH + "fine_tuned_roberta_cpu.pt"
    SPACEY_PATH = DATA_FOLDER_PATH + "spacy_v3"


class AzureConfigPROD:
    ENV = "prod"
    AZURE_SUBSCRIPTION = '9bf64ffb-08bc-4923-aa17-d2973640d5bc'
    RESOURCE_GROUP = 'icc_ds'
    TENANT_ID = '89359cf4-9e60-4099-80c4-775a0cfe27a7'
    SPACEY_BLOB_NAME = 'spacy_v3.zip'

    # Cosmos config
    COSMOS_URI = "mongodb://icc-ai-prod:oxJZQdDteb9Lbt0r8vb25v7OaFynM9qaOBbqshiG6vNiMMOn3vQISf7xOg3BRMwW63F8lxrUPQWymQbXnXLoEg==@icc-ai-prod.mongo.cosmos.azure.com:10255/?ssl=true&replicaSet=globaldb&retrywrites=false&maxIdleTimeMS=120000&appName=@icc-ai-prod@"
    COSMOS_DATABASE_NAME = "master"
    COSMOS_META_DATA_TABLE = "meta_data"
    COSMOS_KEYWORD_TARGETING_DB = "keyword_targets"
    COSMOS_BROAD_KEYWORD_TARGETING_DB = "broad_keyword_targets"
    COSMOS_HASH_TO_KEYWORD_DB = "keyword_hashes"
    COSMOS_PRODUCT_TARGETING_DB = "product_targets"
    COSMOS_CATEGORY_TARGETING_DB = "category_targets"
    COSMOS_BID_LANDSCAPE_DB = "bid_landscape"
    COSMOS_PLACEMENTS_META_TABLE = "placements_metadata"
    REJECTED_SUGGESTIONS_DB = "rejected_suggestions"
    COSMOS_PRODUCT_META_DB = "product_meta_data"
    COSMOS_ACTIVE_TARGETS_DB = "active_targets"
    COSMOS_ACTIVE_CAMPAIGNS_DB = "active_campaigns"

    # ICC DS Storage connection string
    ACCOUNT_NAME = 'iccai'
    ICC_DS_STORAGE_CONNECTION_STRING = 'DefaultEndpointsProtocol=https;AccountName=iccai;AccountKey=Ll/9rN3e8Dla8oYBvQvccy6pEW1YBKSHh3mCTlhzVZu/GqEu2T6K1YaIwsYbPp3T1Wu4kY8RI1DoXGBEHjrDDg==;EndpointSuffix=core.windows.net'
    CONTAINER_NAME = 'model-artifacts'
    ACCOUNT_KEY = 'Ll/9rN3e8Dla8oYBvQvccy6pEW1YBKSHh3mCTlhzVZu/GqEu2T6K1YaIwsYbPp3T1Wu4kY8RI1DoXGBEHjrDDg=='
    ACCOUNT_URL = 'https://iccai.blob.core.windows.net/'
    STORAGE_ACCOUNT_NAME = "iccai"

    # Azure ML Config
    MODEL_ID = 'fine_tuned_roberta_cpu:1'
    WS_NAME = 'baldor-test'

    # Azure Cache
    #REDIS_HOST_NAME = 'icc-ai.redis.cache.windows.net'
    #REDIS_PASSWORD = 'VmeptgjPxRng7SiTGHhDI5kalaeOkuthvAzCaGHdxzM='
    REDIS_HOST_NAME = 'icc-ai-prod.redis.cache.windows.net'
    REDIS_PASSWORD = 'kutS8jAi4KUgrleTlRhToXeez36W14BJPAzCaL6FDTc='

    # Campaign service cache
    CAMPAIGN_SVC_REDIS_HOST_NAME = 'icc-dev-redis.redis.cache.windows.net'
    CAMPAIGN_SVC_REDIS_PASSWORD = 'Zlat08QLaYLbgRiqXSQJ2mABj4KgbbydOAzCaEfeDxg='
    REDIS_ADSPENT_GROUP_NAME = 'adspent'

    # SQL Credentials
    COSMOS_SQL_ENDPOINT = "https://prod-icc-catalog-cosmosdb.documents.azure.com:443/"
    COSMOS_SQL_DATABASE_NAME = "icc-catalog-management"
    COSMOS_SQL_PRIMARY_KEY = {
        "masterKey": "kzPDwqGrYEC1reV16CwLTEkw8EBI16LfcNGCFFQGycoAy7ZbDTASZctNdCIS0kDSLzZ1Vo7w8OjmDwF8imBwAA=="
    }

    # Blob Path For Model
    CPU_MODEL_BLOB_NAME = 'fine_tuned_roberta_cpu.pt.zip'

    # Azure Monitor Key
    INSTRUMENTATION_KEY = '46806433-00fd-472f-8f64-4862ccb89619'

    # Auto suggestion & Organic DS engg containers
    SUGGESTIONS_INPUT_CONNECTION_STRING = 'DefaultEndpointsProtocol=https;AccountName=prodicccoredatalake;AccountKey=QlUf09BLviJVyijLb6Si23MN4SHJKe8KWS1V8mbxUTvH6kGYrpuJWHjd7E3jpN9lRfNrlBM6IA19835/zVA3xw==;EndpointSuffix=core.windows.net'
    SUGGESTION_INPUT_CONTAINER = 'datascience'
    SUGGESTION_INPUT_STRING = 'bid_calculation/retailer_id={retailer_id}/year={year}/month={month}/day={day}/job={job_name}/'
    ORGANIC_DS_INPUT_STRING = 'organic_data/retailer_id={retailer_id}/year={year}/month={month}/day={day}/job={job_name}/'

    # Recommendations
    RECOMMENDATION_INP_STRING = 'DefaultEndpointsProtocol=https;AccountName=iccds;AccountKey=I7D2/UnJ8FM97A41x8W+P8bpwBHTJji6pdY3ZLO0aL5OyBlQ/iFP9xh1T81gcKS7wXFHzOvjiTm3QljB/ymn4A==;EndpointSuffix=core.windows.net'
    RECOMMENDATION_INPUT_CONTAINERNAME = 'icc-test'
    RECOMMENDATION_OUT_STRING = 'DefaultEndpointsProtocol=https;AccountName=iccai;AccountKey=Ll/9rN3e8Dla8oYBvQvccy6pEW1YBKSHh3mCTlhzVZu/GqEu2T6K1YaIwsYbPp3T1Wu4kY8RI1DoXGBEHjrDDg==;EndpointSuffix=core.windows.net'
    RECOMMENDATION_OUTPUT_CONTAINERNAME = 'recommendation-output'
    BID_LANDSCAPE_STRING = 'DefaultEndpointsProtocol=https;AccountName=iccds;AccountKey=I7D2/UnJ8FM97A41x8W+P8bpwBHTJji6pdY3ZLO0aL5OyBlQ/iFP9xh1T81gcKS7wXFHzOvjiTm3QljB/ymn4A==;EndpointSuffix=core.windows.net'
    BID_LANDSCAPE_CONTAINER = 'bid-recommendation'
    COMBINED_OUTPUT_CONTAINERNAME = 'combined-output'
    DATABRICKS_OUTPUT_SOURCE = "wasbs://combined-output@iccai.blob.core.windows.net"

    #bid_distribution
    BID_DIST_OUTPUT_CONTAINERNAME = 'bid-landscape-dist'

    # bid landscape
    BID_LANDSCAPE_OUTPUT_CONTAINER = BID_LANDSCAPE_CONTAINER
    BID_LANDSCAPE_OUTPUT = '{year}/{month}/{day}/BidLandscape_{retailer_id}.csv'

    # Bid Intelligence
    BID_INTEL_PRIOR_CONTAINER = 'bid_intel_prior_info'
    PRIOR_INFO_BY_RETAILER = 'bid_intel_prior_{retailer_id}.csv'

    # Aggregation
    AGGREGATION_INPUT_STRING = 'DefaultEndpointsProtocol=https;AccountName=prodicccoredatalake;AccountKey=QlUf09BLviJVyijLb6Si23MN4SHJKe8KWS1V8mbxUTvH6kGYrpuJWHjd7E3jpN9lRfNrlBM6IA19835/zVA3xw==;EndpointSuffix=core.windows.net'
    AGGREGATION_INPUT_CONTAINER = 'campaign-snapshot'
    AGGREGATION_OUTPUT_STRING = 'DefaultEndpointsProtocol=https;AccountName=prodicccoredatalake;AccountKey=QlUf09BLviJVyijLb6Si23MN4SHJKe8KWS1V8mbxUTvH6kGYrpuJWHjd7E3jpN9lRfNrlBM6IA19835/zVA3xw==;EndpointSuffix=core.windows.net'
    AGGREGATION_OUTPUT_CONTAINER = 'datascience'

    #AzureCognitiveSearch
    AZURE_COGNITIVE_ENDPOINT = "https://icc-ai-search-service.search.windows.net"
    AZURE_COGNITIVE_ADMIN_KEY = "03A05D8723E1C4ED7BF9A58F02493D9B"

    # Campaign Metadata Eventhub - Engg (Campaign Service)
    CAMPAIGN_EVENTHUB_STRING = "Endpoint=sb://prod-campaign-eventhub.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=pTFR/AoRJ9CW0E8/LBvwZ44dHA6j0r8E0BUlnnhe5Bo="
    CAMPAIGN_CONSUMER_GROUP = "icc-ai-consumer_group1"
    CAMPAIGN_EVENTHUB_NAME = "campaign-audit-log-events"

    # Suggestions Eventhub
    AI_EVENTHUB_STRING = 'Endpoint=sb://icc-ai-prod.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=jO8K9klBLhoFmxkbooYmIVDLSiL0VOeHoude0rGdg9Y='
    SUGGESTIONS_EVENTHUB_NAME = 'campaign-suggestions'

    # Placement info URL
    PLACEMENT_URL = "http://inventory-svc.commerce.inmobi.com/api/v1/placements?retailerId={}&status=ACTIVE&sendFloorPrices=True"

    # CTR-CVR Estimations
    CTR_CVR_INPUT_CONNECTION_STRING = "DefaultEndpointsProtocol=https;AccountName=prodicccoredatalake;AccountKey=QlUf09BLviJVyijLb6Si23MN4SHJKe8KWS1V8mbxUTvH6kGYrpuJWHjd7E3jpN9lRfNrlBM6IA19835/zVA3xw==;EndpointSuffix=core.windows.net"
    CTR_CVR_INPUT_CONTAINER = "analytics"

    # Suggestions Rejection
    SUGGESTION_FEEDBACK_EN_CONNECTION = 'DefaultEndpointsProtocol=https;AccountName=prodicccoredatalake;AccountKey=QlUf09BLviJVyijLb6Si23MN4SHJKe8KWS1V8mbxUTvH6kGYrpuJWHjd7E3jpN9lRfNrlBM6IA19835/zVA3xw==;EndpointSuffix=core.windows.net'
    SUGGESTION_FEEDBACK_EN_CONTAINER = 'suggestion-events'
    SUGGESTION_FEEDBACK_AI_CONNECTION = 'DefaultEndpointsProtocol=https;AccountName=iccai;AccountKey=Ll/9rN3e8Dla8oYBvQvccy6pEW1YBKSHh3mCTlhzVZu/GqEu2T6K1YaIwsYbPp3T1Wu4kY8RI1DoXGBEHjrDDg==;EndpointSuffix=core.windows.net'
    SUGGESTION_FEEDBACK_AI_CONTAINER = 'feedback-events'

    # AD SPEND ENGINEERING DETAILS
    AD_SPEND_CONNECTION = 'DefaultEndpointsProtocol=https;AccountName=prodicccoredatalake;AccountKey=QlUf09BLviJVyijLb6Si23MN4SHJKe8KWS1V8mbxUTvH6kGYrpuJWHjd7E3jpN9lRfNrlBM6IA19835/zVA3xw==;EndpointSuffix=core.windows.net'
    AD_SPEND_CONTAINER = 'analytics'

    # CAMPAIGN DEBUG DETAILS
    ENGG_ACCOUNT_NAME = "prodicccoredatalake"
    ENGG_ACCOUNT_KEY = "QlUf09BLviJVyijLb6Si23MN4SHJKe8KWS1V8mbxUTvH6kGYrpuJWHjd7E3jpN9lRfNrlBM6IA19835/zVA3xw=="
    ENGG_ACCOUNT_CONNECTION_STRING = "DefaultEndpointsProtocol=https;AccountName=prodicccoredatalake;AccountKey=QlUf09BLviJVyijLb6Si23MN4SHJKe8KWS1V8mbxUTvH6kGYrpuJWHjd7E3jpN9lRfNrlBM6IA19835/zVA3xw==;EndpointSuffix=core.windows.net"
    AD_RENDER_CONTAINER = "enriched-tracking-parquet"
    AD_RENDER_PATTERN = "event-capture/retailerId={}/{}"
    AD_RENDER_PATH = "abfss://enriched-tracking-parquet@prodicccoredatalake.dfs.core.windows.net/"
    RR_PATH = "abfss://ad-serve-rrlogs-events@prodicccoredatalake.dfs.core.windows.net/"
    RR_PATTERN = "namespace=prod-campaign-eventhub/eventhub=ad-serve-rr-log/partition={}/{}"
    RR_CONTAINER = "ad-serve-rrlogs-events"
    AI_REQUEST_OUTPUT_PATH = "abfs://campaign-debug@iccai.dfs.core.windows.net/requests_data"
    AI_CAMPAIGN_OUTPUT_PATH = "abfs://campaign-debug@iccai.dfs.core.windows.net/campaign_data"
    AI_CAMPAIGN_CONSOLIDATED_PATH = "abfs://campaign-debug@iccai.dfs.core.windows.net/campaign_data_consolidated"

    # ORGANIC DATA DETAILS
    ORGANIC_CONNECTION = "DefaultEndpointsProtocol=https;AccountName=prodicccoredatalake;AccountKey=QlUf09BLviJVyijLb6Si23MN4SHJKe8KWS1V8mbxUTvH6kGYrpuJWHjd7E3jpN9lRfNrlBM6IA19835/zVA3xw==;EndpointSuffix=core.windows.net"
    ORGANIC_CONTAINER = "organic-data"
    ORGANIC_CONTAINER_PATTERN = "event-capture/retailer={}/event-type={}/{}"
    ORGANIC_DATABRICKS_PATH = "abfs://organic-data@prodicccoredatalake.dfs.core.windows.net/event-capture/retailer={}/event-type={}/{}"
    ORGANIC_DAILY_SUMMARY = "abfs://analytics@prodicccoredatalake.dfs.core.windows.net/facts/daily-summaries/daily_organic_targeting_summary/"
    ORGANIC_AD_REQUEST_SUMMARY = "abfs://analytics@prodicccoredatalake.dfs.core.windows.net/facts/hourly-summaries/hourly_ad_request_summary/"

    # FLOOR PRICE SUGGESTION DETAILS
    SENDGRID_API = "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"
    SENDER_MAIL = "ICC_DS@inmobi.com"

    AUDIENCE_BLOB_NAME = "organic_purchase_features/{}/{}_audience.pkl"

    # TARGETING LOGS
    TARGETING_LOGS_CONTAINER = "campaign-targeting-logs"
    TARGET_LOGS_BLOB_FORMAT = "year={}/month={}/day={}/retailer_id={}/campaignId={}/{}.parquet"


class AzureConfigDEV:
    ENV = "dev"
    AZURE_SUBSCRIPTION = '9bf64ffb-08bc-4923-aa17-d2973640d5bc'
    RESOURCE_GROUP = 'icc_ds'
    TENANT_ID = '89359cf4-9e60-4099-80c4-775a0cfe27a7'
    SPACEY_BLOB_NAME = 'spacy_v3.zip'

    # Cosmos config
    COSMOS_URI = "mongodb://cosmosdb-icc-ds" \
                 ":AIvFNlPQSF7K6V02iFgCJZVGEK4egy2OEw4KE4MOjEUYCguvlbEthSwidwfN4SEz1bDc9sOTzwqcZxEhT2MqOA==@cosmosdb" \
                 "-icc-ds.mongo.cosmos.azure.com:10255/?ssl=true&replicaSet=globaldb&retrywrites=false&maxIdleTimeMS" \
                 "=120000&appName=@cosmosdb-icc-ds@"
    COSMOS_DATABASE_NAME = "master"
    COSMOS_META_DATA_TABLE = "meta_data"
    COSMOS_KEYWORD_TARGETING_DB = "keyword_targetting"
    COSMOS_BROAD_KEYWORD_TARGETING_DB = "broad_keyword_targetting"
    COSMOS_HASH_TO_KEYWORD_DB = "hash_keyword"
    COSMOS_PRODUCT_TARGETING_DB = "product_targetting"
    COSMOS_CATEGORY_TARGETING_DB = "category_targetting"
    REJECTED_SUGGESTIONS_DB = "rejected_suggestions"
    COSMOS_BID_LANDSCAPE_DB = "dev_bid_landscape"
    COSMOS_PLACEMENTS_META_TABLE = "dev_placements_metadata"
    COSMOS_PRODUCT_META_DB = "product_meta_data"
    COSMOS_ACTIVE_TARGETS_DB = "active_targets"
    COSMOS_ACTIVE_CAMPAIGNS_DB = "active_campaigns"

    # ICC DS Storage connection string
    ACCOUNT_NAME = 'iccds'
    ICC_DS_STORAGE_CONNECTION_STRING = 'DefaultEndpointsProtocol=https;AccountName=iccds;AccountKey=I7D2/UnJ8FM97A41x8W+P8bpwBHTJji6pdY3ZLO0aL5OyBlQ/iFP9xh1T81gcKS7wXFHzOvjiTm3QljB/ymn4A==;EndpointSuffix=core.windows.net'
    CONTAINER_NAME = 'model-artifacts'
    ACCOUNT_KEY = 'I7D2/UnJ8FM97A41x8W+P8bpwBHTJji6pdY3ZLO0aL5OyBlQ/iFP9xh1T81gcKS7wXFHzOvjiTm3QljB/ymn4A=='
    ACCOUNT_URL = 'https://iccds.blob.core.windows.net/'

    # Azure ML Config
    MODEL_ID = 'fine_tuned_roberta_cpu:1'
    WS_NAME = 'baldor-test'

    # Azure Cache
    REDIS_HOST_NAME = 'icc-ds.redis.cache.windows.net'
    REDIS_PASSWORD = 'g83ISICCSbUHpKlNqu656cCcqfMJXndfa5951kYYgWw='

    #Campaign service cache
    CAMPAIGN_SVC_REDIS_HOST_NAME = 'icc-dev-redis.redis.cache.windows.net'
    CAMPAIGN_SVC_REDIS_PASSWORD = 'Zlat08QLaYLbgRiqXSQJ2mABj4KgbbydOAzCaEfeDxg='
    REDIS_ADSPENT_GROUP_NAME = 'adspent'

    # SQL Credentials
    COSMOS_SQL_ENDPOINT = "https://icc-catalog.documents.azure.com:443/"
    COSMOS_SQL_DATABASE_NAME = "icc-catalog"
    COSMOS_SQL_PRIMARY_KEY = {
        "masterKey": "5sqFyDHwErEHNS4LhYCcuMiK65M3MTskUjvklfsxceSbusOIPix3Axi3RL5LNI9ClSCceVfMQKwgYjMSkGCBqw=="
    }

    # Blob Path For Model
    CPU_MODEL_BLOB_NAME = 'fine_tuned_roberta_cpu.pt.zip'

    # Azure Monitor Key
    INSTRUMENTATION_KEY = '46806433-00fd-472f-8f64-4862ccb89619'

    # Auto suggestion & Organic DS engg containers
    SUGGESTIONS_INPUT_CONNECTION_STRING = 'DefaultEndpointsProtocol=https;AccountName=iccdevstorageacc;AccountKey=ijt5UzwW1da/7mnPYetJstMeALL5H/c/N2JJlmvbJU6vHTB98jY/akze7mSxpvcQnwqQorSa8JpN+AStobB7bQ==;EndpointSuffix=core.windows.net'
    SUGGESTION_INPUT_CONTAINER = 'datascience'
    SUGGESTION_INPUT_STRING = 'bid_calculation/retailer_id={retailer_id}/year={year}/month={month}/day={day}/job={job_name}/'
    ORGANIC_DS_INPUT_STRING = 'organic_data/retailer_id={retailer_id}/year={year}/month={month}/day={day}/job={job_name}/'

    # Recommendations
    RECOMMENDATION_INP_STRING = 'DefaultEndpointsProtocol=https;AccountName=iccds;AccountKey=I7D2/UnJ8FM97A41x8W+P8bpwBHTJji6pdY3ZLO0aL5OyBlQ/iFP9xh1T81gcKS7wXFHzOvjiTm3QljB/ymn4A==;EndpointSuffix=core.windows.net'
    RECOMMENDATION_INPUT_CONTAINERNAME = 'icc-test'
    RECOMMENDATION_OUT_STRING = 'DefaultEndpointsProtocol=https;AccountName=iccds;AccountKey=I7D2/UnJ8FM97A41x8W+P8bpwBHTJji6pdY3ZLO0aL5OyBlQ/iFP9xh1T81gcKS7wXFHzOvjiTm3QljB/ymn4A==;EndpointSuffix=core.windows.net'
    RECOMMENDATION_OUTPUT_CONTAINERNAME = 'recommendation-output'
    BID_LANDSCAPE_STRING = 'DefaultEndpointsProtocol=https;AccountName=iccds;AccountKey=I7D2/UnJ8FM97A41x8W+P8bpwBHTJji6pdY3ZLO0aL5OyBlQ/iFP9xh1T81gcKS7wXFHzOvjiTm3QljB/ymn4A==;EndpointSuffix=core.windows.net'
    BID_LANDSCAPE_CONTAINER = 'bid-recommendation'
    COMBINED_OUTPUT_CONTAINERNAME = 'combined-output'

    # Aggregation
    AGGREGATION_INPUT_STRING = 'DefaultEndpointsProtocol=https;AccountName=iccdevstorageacc;AccountKey=ijt5UzwW1da/7mnPYetJstMeALL5H/c/N2JJlmvbJU6vHTB98jY/akze7mSxpvcQnwqQorSa8JpN+AStobB7bQ==;EndpointSuffix=core.windows.net'
    AGGREGATION_INPUT_CONTAINER = 'campaign-snapshot'
    AGGREGATION_OUTPUT_STRING = 'DefaultEndpointsProtocol=https;AccountName=iccdevstorageacc;AccountKey=ijt5UzwW1da/7mnPYetJstMeALL5H/c/N2JJlmvbJU6vHTB98jY/akze7mSxpvcQnwqQorSa8JpN+AStobB7bQ==;EndpointSuffix=core.windows.net'
    AGGREGATION_OUTPUT_CONTAINER = 'datascience'

    # bid_distribution
    BID_DIST_OUTPUT_CONTAINERNAME = 'bid-landscape-dist'

    # bid landscape
    BID_LANDSCAPE_OUTPUT_CONTAINER = BID_LANDSCAPE_CONTAINER
    BID_LANDSCAPE_OUTPUT = '{year}/{month}/{day}/BidLandscape_{retailer_id}.csv'

    # AzureCognitiveSearch
    AZURE_COGNITIVE_ENDPOINT = "https://icc-ai.search.windows.net"
    AZURE_COGNITIVE_ADMIN_KEY = "mzWXbhF81rRPzHbVERHBl57KrJ0tyfMwdc7cpqFj5ZAzSeB7cseg"

    # CTR-CVR Estimations
    CTR_CVR_INPUT_CONNECTION_STRING = "DefaultEndpointsProtocol=https;AccountName=iccdevstorageacc;AccountKey=ijt5UzwW1da/7mnPYetJstMeALL5H/c/N2JJlmvbJU6vHTB98jY/akze7mSxpvcQnwqQorSa8JpN+AStobB7bQ==;EndpointSuffix=core.windows.net"
    CTR_CVR_INPUT_CONTAINER = "analytics"

    # For testing eventhub
    CAMPAIGN_EVENTHUB_STRING = "Endpoint=sb://event-tracking.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=5spQv5sb9801KgHBB+V4zQ8WTuvQw6BCrwV0dEuISRs="
    CAMPAIGN_CONSUMER_GROUP = "icc-ai-consumer_group1"
    CAMPAIGN_EVENTHUB_NAME = "campaign-audit-logs"

    # Suggestions Eventhub
    AI_EVENTHUB_STRING = 'Endpoint=sb://icc-ai-dev.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=LUFTx90hMy2/om2UuNjFEiW19a3z1zTfASF3VZQHe6I='
    SUGGESTIONS_EVENTHUB_NAME = 'campaign-suggestions'

    # Placement info URL
    PLACEMENT_URL = "http://dev-inventorysvc.commerce.inmobi.com/api/v1/placements?retailerId={}&status=ACTIVE&sendFloorPrices=True"

    # Suggestions Rejection
    SUGGESTION_FEEDBACK_EN_CONNECTION = 'DefaultEndpointsProtocol=https;AccountName=iccdevstorageacc;AccountKey=ijt5UzwW1da/7mnPYetJstMeALL5H/c/N2JJlmvbJU6vHTB98jY/akze7mSxpvcQnwqQorSa8JpN+AStobB7bQ==;EndpointSuffix=core.windows.net'
    SUGGESTION_FEEDBACK_EN_CONTAINER = 'suggestion-events'
    SUGGESTION_FEEDBACK_AI_CONNECTION = 'DefaultEndpointsProtocol=https;AccountName=iccds;AccountKey=I7D2/UnJ8FM97A41x8W+P8bpwBHTJji6pdY3ZLO0aL5OyBlQ/iFP9xh1T81gcKS7wXFHzOvjiTm3QljB/ymn4A==;EndpointSuffix=core.windows.net'
    SUGGESTION_FEEDBACK_AI_CONTAINER = 'feedback-events'

    # AD SPEND ENGINEERING DETAILS
    AD_SPEND_CONNECTION = 'DefaultEndpointsProtocol=https;AccountName=iccdevstorageacc;AccountKey=ijt5UzwW1da/7mnPYetJstMeALL5H/c/N2JJlmvbJU6vHTB98jY/akze7mSxpvcQnwqQorSa8JpN+AStobB7bQ==;EndpointSuffix=core.windows.net'
    AD_SPEND_CONTAINER = 'analytics'

    # TARGETING LOGS
    TARGETING_LOGS_CONTAINER = "campaign-targeting-logs"
    TARGET_LOGS_BLOB_FORMAT = "year={}/month={}/day={}/retailer_id={}/campaignId={}/{}.parquet"


class AzureConfigUAT:
    ENV = "uat"
    AZURE_SUBSCRIPTION = '9bf64ffb-08bc-4923-aa17-d2973640d5bc'
    RESOURCE_GROUP = 'icc_ds'
    TENANT_ID = '89359cf4-9e60-4099-80c4-775a0cfe27a7'
    SPACEY_BLOB_NAME = 'spacy_v3.zip'

    # Cosmos config
    COSMOS_URI = "mongodb://icc-ai-uat:WrXWZq5agQDKKIwDQRky98ABcY4kg2QPCmRrr7R7vB2I3f4w4Jvi48RBoKeTsWxqBvp11w5LhCSU6cWNzSXWBw==@icc-ai-uat.mongo.cosmos.azure.com:10255/?ssl=true&replicaSet=globaldb&retrywrites=false&maxIdleTimeMS=120000&appName=@icc-ai-uat@"
    COSMOS_DATABASE_NAME = "uat_master"
    COSMOS_META_DATA_TABLE = "meta_data"
    COSMOS_KEYWORD_TARGETING_DB = "uat_keyword_targets"
    COSMOS_BROAD_KEYWORD_TARGETING_DB = "uat_broad_keyword_targets"
    COSMOS_HASH_TO_KEYWORD_DB = "uat_keyword_hashes"
    COSMOS_PRODUCT_TARGETING_DB = "uat_product_targets"
    COSMOS_CATEGORY_TARGETING_DB = "uat_category_targets"
    REJECTED_SUGGESTIONS_DB = "uat_rejected_suggestions"
    COSMOS_BID_LANDSCAPE_DB = "uat_bid_landscape"
    COSMOS_PLACEMENTS_META_TABLE = "uat_placements_metadata"
    COSMOS_PRODUCT_META_DB = "product_meta_data"
    COSMOS_ACTIVE_TARGETS_DB = "active_targets"
    COSMOS_ACTIVE_CAMPAIGNS_DB = "active_campaigns"

    # ICC DS Storage connection string
    ACCOUNT_NAME = 'iccaiuat'
    ICC_DS_STORAGE_CONNECTION_STRING = 'DefaultEndpointsProtocol=https;AccountName=iccaiuat;AccountKey=0zcCt8sDhwlYdSAGn4dttDT5rKMdrM93B8ORSMTIpaflw/wgnfkAUkZ+bkJ9+Ogt/yuoDMKgYNwsF5w/H/utsQ==;EndpointSuffix=core.windows.net'
    CONTAINER_NAME = 'icc-ai-uat-files'
    ACCOUNT_KEY = '0zcCt8sDhwlYdSAGn4dttDT5rKMdrM93B8ORSMTIpaflw/wgnfkAUkZ+bkJ9+Ogt/yuoDMKgYNwsF5w/H/utsQ=='
    ACCOUNT_URL = 'https://iccaiuat.blob.core.windows.net/'

    # Azure ML Config
    MODEL_ID = 'fine_tuned_roberta_cpu:1'
    WS_NAME = 'baldor-test'

    # Azure Cache
    REDIS_HOST_NAME = 'icc-ds.redis.cache.windows.net'
    REDIS_PASSWORD = 'g83ISICCSbUHpKlNqu656cCcqfMJXndfa5951kYYgWw='

    # Campaign service cache
    CAMPAIGN_SVC_REDIS_HOST_NAME = 'icc-uat-redis.redis.cache.windows.net'
    CAMPAIGN_SVC_REDIS_PASSWORD = 'A8xt3Z5r7WR6LFpsgOB8rugObi5ePwTyMAzCaNz2wvw='
    REDIS_ADSPENT_GROUP_NAME = 'adspent'

    # SQL Credentials
    COSMOS_SQL_ENDPOINT = "https://icc-catalog.documents.azure.com:443/"
    COSMOS_SQL_DATABASE_NAME = "icc-catalog-uat"
    COSMOS_SQL_PRIMARY_KEY = {
        "masterKey": "5sqFyDHwErEHNS4LhYCcuMiK65M3MTskUjvklfsxceSbusOIPix3Axi3RL5LNI9ClSCceVfMQKwgYjMSkGCBqw=="
    }

    # Blob Path For Model
    CPU_MODEL_BLOB_NAME = 'fine_tuned_roberta_cpu.pt.zip'

    # Azure Monitor Key
    INSTRUMENTATION_KEY = '46806433-00fd-472f-8f64-4862ccb89619'

    # Auto suggestion & Organic DS engg containers
    SUGGESTIONS_INPUT_CONNECTION_STRING = 'DefaultEndpointsProtocol=https;AccountName=eventsadlsstage;AccountKey=0SJsrV+hLnv45A0bG8iiMM8+W7wSTnWppzSs/vfAPktLclTxNKT+4FV1l+mdUJKjUeEh1ZA9INjBOap4mbf9VA==;EndpointSuffix=core.windows.net'
    SUGGESTION_INPUT_CONTAINER = 'datascience'
    SUGGESTION_INPUT_STRING = 'bid_calculation/retailer_id={retailer_id}/year={year}/month={month}/day={day}/job={job_name}/'
    ORGANIC_DS_INPUT_STRING = 'organic_data/retailer_id={retailer_id}/year={year}/month={month}/day={day}/job={job_name}/'

    # Recommendations
    RECOMMENDATION_INP_STRING = 'DefaultEndpointsProtocol=https;AccountName=eventsadlsstage;AccountKey=0SJsrV+hLnv45A0bG8iiMM8+W7wSTnWppzSs/vfAPktLclTxNKT+4FV1l+mdUJKjUeEh1ZA9INjBOap4mbf9VA==;EndpointSuffix=core.windows.net'
    RECOMMENDATION_INPUT_CONTAINERNAME = 'datascience'
    RECOMMENDATION_OUT_STRING = 'DefaultEndpointsProtocol=https;AccountName=iccaiuat;AccountKey=0zcCt8sDhwlYdSAGn4dttDT5rKMdrM93B8ORSMTIpaflw/wgnfkAUkZ+bkJ9+Ogt/yuoDMKgYNwsF5w/H/utsQ==;EndpointSuffix=core.windows.net'
    RECOMMENDATION_OUTPUT_CONTAINERNAME = 'recommendation-output'
    BID_LANDSCAPE_STRING = 'DefaultEndpointsProtocol=https;AccountName=iccaiuat;AccountKey=0zcCt8sDhwlYdSAGn4dttDT5rKMdrM93B8ORSMTIpaflw/wgnfkAUkZ+bkJ9+Ogt/yuoDMKgYNwsF5w/H/utsQ==;EndpointSuffix=core.windows.net'
    BID_LANDSCAPE_CONTAINER = 'bid-recommendation'
    COMBINED_OUTPUT_CONTAINERNAME = 'combined-output'

    # Aggregation
    AGGREGATION_INPUT_STRING = 'DefaultEndpointsProtocol=https;AccountName=eventsadlsstage;AccountKey=0SJsrV+hLnv45A0bG8iiMM8+W7wSTnWppzSs/vfAPktLclTxNKT+4FV1l+mdUJKjUeEh1ZA9INjBOap4mbf9VA==;EndpointSuffix=core.windows.net'
    AGGREGATION_INPUT_CONTAINER = 'campaign-snapshot'
    AGGREGATION_OUTPUT_STRING = 'DefaultEndpointsProtocol=https;AccountName=eventsadlsstage;AccountKey=0SJsrV+hLnv45A0bG8iiMM8+W7wSTnWppzSs/vfAPktLclTxNKT+4FV1l+mdUJKjUeEh1ZA9INjBOap4mbf9VA==;EndpointSuffix=core.windows.net'
    AGGREGATION_OUTPUT_CONTAINER = 'datascience'

    # bid_distribution
    BID_DIST_OUTPUT_CONTAINERNAME = 'bid-landscape-dist'

    # bid lanscape
    BID_LANDSCAPE_OUTPUT_CONTAINER = BID_LANDSCAPE_CONTAINER
    BID_LANDSCAPE_OUTPUT = '{year}/{month}/{day}/BidLandscape_{retailer_id}.csv'

    # AzureCognitiveSearch
    AZURE_COGNITIVE_ENDPOINT = "https://icc-ai-uat.search.windows.net"
    AZURE_COGNITIVE_ADMIN_KEY = "1B6416D9014B995AE50E5F8FB2A2A4F9"

    # Campaign Metadata Eventhub - Engg (Campaign Service)
    CAMPAIGN_EVENTHUB_STRING = "Endpoint=sb://event-tracking-stage.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=hNMJtNIubAm6EwGWP/tDwcY8zDPYh0jOz4fFEzt9B80="
    CAMPAIGN_CONSUMER_GROUP = "icc-ai-consumer_group1"
    CAMPAIGN_EVENTHUB_NAME = "campaign-audit-logs"

    # Suggestions Eventhub
    AI_EVENTHUB_STRING = 'Endpoint=sb://icc-ai-uat.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=k0e3opMkR+WOP0PaKuc93o0mB3tuAL3xv6vT77RXsNc='
    SUGGESTIONS_EVENTHUB_NAME = 'campaign-suggestions'

    # Placement info URL
    PLACEMENT_URL = "http://uat-inventorysvc.commerce.inmobi.com/api/v1/placements?retailerId={}&status=ACTIVE&sendFloorPrices=True"

    # CTR-CVR Estimations
    CTR_CVR_INPUT_CONNECTION_STRING = "DefaultEndpointsProtocol=https;AccountName=eventsadlsstage;AccountKey=0SJsrV+hLnv45A0bG8iiMM8+W7wSTnWppzSs/vfAPktLclTxNKT+4FV1l+mdUJKjUeEh1ZA9INjBOap4mbf9VA==;EndpointSuffix=core.windows.net"
    CTR_CVR_INPUT_CONTAINER = "analytics"

    # Suggestions Rejection
    SUGGESTION_FEEDBACK_EN_CONNECTION = 'DefaultEndpointsProtocol=https;AccountName=eventsadlsstage;AccountKey=0SJsrV+hLnv45A0bG8iiMM8+W7wSTnWppzSs/vfAPktLclTxNKT+4FV1l+mdUJKjUeEh1ZA9INjBOap4mbf9VA==;EndpointSuffix=core.windows.net'
    SUGGESTION_FEEDBACK_EN_CONTAINER = 'suggestion-events'
    SUGGESTION_FEEDBACK_AI_CONNECTION = 'DefaultEndpointsProtocol=https;AccountName=iccaiuat;AccountKey=0zcCt8sDhwlYdSAGn4dttDT5rKMdrM93B8ORSMTIpaflw/wgnfkAUkZ+bkJ9+Ogt/yuoDMKgYNwsF5w/H/utsQ==;EndpointSuffix=core.windows.net'
    SUGGESTION_FEEDBACK_AI_CONTAINER = 'feedback-events'

    # AD SPEND ENGINEERING DETAILS
    AD_SPEND_CONNECTION = 'DefaultEndpointsProtocol=https;AccountName=eventsadlsstage;AccountKey=0SJsrV+hLnv45A0bG8iiMM8+W7wSTnWppzSs/vfAPktLclTxNKT+4FV1l+mdUJKjUeEh1ZA9INjBOap4mbf9VA==;EndpointSuffix=core.windows.net'
    AD_SPEND_CONTAINER = 'analytics'

    # TARGETING LOGS
    TARGETING_LOGS_CONTAINER = "campaign-targeting-logs"
    TARGET_LOGS_BLOB_FORMAT = "year={}/month={}/day={}/retailer_id={}/campaignId={}/{}.parquet"


class AzureConfigQA:
    ENV = "qa"
    AZURE_SUBSCRIPTION = '9bf64ffb-08bc-4923-aa17-d2973640d5bc'
    RESOURCE_GROUP = 'icc_ds'
    TENANT_ID = '89359cf4-9e60-4099-80c4-775a0cfe27a7'
    SPACEY_BLOB_NAME = 'spacy_v3.zip'

    # Cosmos config
    COSMOS_URI = "mongodb://icc-ai-qa:pBcvKp4CJhkuHgvkLfIgqfaIM6vgILIuAMNZCZDKu7ukOJ3uyef6GWwRriEZBr2kTRyuF7EFNOJ5B3yzeh6xnw==@icc-ai-qa.mongo.cosmos.azure.com:10255/?ssl=true&replicaSet=globaldb&retrywrites=false&maxIdleTimeMS=120000&appName=@icc-ai-qa@"
    COSMOS_DATABASE_NAME = "qa_master"
    COSMOS_META_DATA_TABLE = "meta_data"
    COSMOS_KEYWORD_TARGETING_DB = "qa_keyword_targets"
    COSMOS_BROAD_KEYWORD_TARGETING_DB = "qa_broad_keyword_targets"
    COSMOS_HASH_TO_KEYWORD_DB = "qa_keyword_hashes"
    COSMOS_PRODUCT_TARGETING_DB = "qa_product_targets"
    COSMOS_CATEGORY_TARGETING_DB = "qa_category_targets"
    REJECTED_SUGGESTIONS_DB = "qa_rejected_suggestions"
    COSMOS_BID_LANDSCAPE_DB = "qa_bid_landscape"
    COSMOS_PLACEMENTS_META_TABLE = "qa_placements_metadata"
    COSMOS_PRODUCT_META_DB = "product_meta_data"
    COSMOS_ACTIVE_TARGETS_DB = "active_targets"
    COSMOS_ACTIVE_CAMPAIGNS_DB = "active_campaigns"

    # ICC DS Storage connection string
    ACCOUNT_NAME = 'iccaiqa'
    ICC_DS_STORAGE_CONNECTION_STRING = 'DefaultEndpointsProtocol=https;AccountName=iccaiqa;AccountKey=GX13C6Qkg5agit4/U3Y/KqOHPN1ch1/Pn6Lk51aX8EJ6w4oz/gSnaAbX4U9lh8GJwXP/B6bB0HIGK7ewTIfxZg==;EndpointSuffix=core.windows.net'
    CONTAINER_NAME = 'icc-ai-qa-files'
    ACCOUNT_KEY = 'GX13C6Qkg5agit4/U3Y/KqOHPN1ch1/Pn6Lk51aX8EJ6w4oz/gSnaAbX4U9lh8GJwXP/B6bB0HIGK7ewTIfxZg=='
    ACCOUNT_URL = 'https://iccaiqa.blob.core.windows.net/'

    # Azure ML Config
    MODEL_ID = 'fine_tuned_roberta_cpu:1'
    WS_NAME = 'baldor-test'

    # Azure Cache
    REDIS_HOST_NAME = 'icc-ds.redis.cache.windows.net'
    REDIS_PASSWORD = 'g83ISICCSbUHpKlNqu656cCcqfMJXndfa5951kYYgWw='

    # Campaign service cache
    CAMPAIGN_SVC_REDIS_HOST_NAME = 'icc-qa-redis.redis.cache.windows.net'
    CAMPAIGN_SVC_REDIS_PASSWORD = '0XHoqsAeMVAIe5PVHaL0YxQ81OBohj8p1AzCaCt9s84='
    REDIS_ADSPENT_GROUP_NAME = 'adspent'

    # SQL Credentials
    COSMOS_SQL_ENDPOINT = "https://icc-catalog.documents.azure.com:443/"
    COSMOS_SQL_DATABASE_NAME = "icc-catalog-qa"
    COSMOS_SQL_PRIMARY_KEY = {
        "masterKey": "5sqFyDHwErEHNS4LhYCcuMiK65M3MTskUjvklfsxceSbusOIPix3Axi3RL5LNI9ClSCceVfMQKwgYjMSkGCBqw=="
    }

    # Blob Path For Model
    CPU_MODEL_BLOB_NAME = 'fine_tuned_roberta_cpu.pt.zip'

    # Azure Monitor Key
    INSTRUMENTATION_KEY = '46806433-00fd-472f-8f64-4862ccb89619'

    # Auto suggestion & Organic DS engg containers
    SUGGESTIONS_INPUT_CONNECTION_STRING = 'DefaultEndpointsProtocol=https;AccountName=eventsadlsqa;AccountKey=ozMK/QwF1mhIH0+2sz/7chu6cC5yxnMqEllcYw60YijHOp5yIhxodwfL3UdK4WnRbW6t4Bj3jhx+y6uO3JvPwA==;EndpointSuffix=core.windows.net'
    SUGGESTION_INPUT_CONTAINER = 'datascience'
    SUGGESTION_INPUT_STRING = 'bid_calculation/retailer_id={retailer_id}/year={year}/month={month}/day={day}/job={job_name}/'
    ORGANIC_DS_INPUT_STRING = 'organic_data/retailer_id={retailer_id}/year={year}/month={month}/day={day}/job={job_name}/'

    # Recommendations
    RECOMMENDATION_INP_STRING = 'DefaultEndpointsProtocol=https;AccountName=eventsadlsqa;AccountKey=ozMK/QwF1mhIH0+2sz/7chu6cC5yxnMqEllcYw60YijHOp5yIhxodwfL3UdK4WnRbW6t4Bj3jhx+y6uO3JvPwA==;EndpointSuffix=core.windows.net'
    RECOMMENDATION_INPUT_CONTAINERNAME = 'datascience'
    RECOMMENDATION_OUT_STRING = 'DefaultEndpointsProtocol=https;AccountName=iccaiqa;AccountKey=GX13C6Qkg5agit4/U3Y/KqOHPN1ch1/Pn6Lk51aX8EJ6w4oz/gSnaAbX4U9lh8GJwXP/B6bB0HIGK7ewTIfxZg==;EndpointSuffix=core.windows.net'
    RECOMMENDATION_OUTPUT_CONTAINERNAME = 'recommendation-output'
    BID_LANDSCAPE_STRING = 'DefaultEndpointsProtocol=https;AccountName=eventsadlsqa;AccountKey=ozMK/QwF1mhIH0+2sz/7chu6cC5yxnMqEllcYw60YijHOp5yIhxodwfL3UdK4WnRbW6t4Bj3jhx+y6uO3JvPwA==;EndpointSuffix=core.windows.net'
    BID_LANDSCAPE_CONTAINER = 'bid-recommendation'
    COMBINED_OUTPUT_CONTAINERNAME = 'combined-output'

    # Aggregation
    AGGREGATION_INPUT_STRING = 'DefaultEndpointsProtocol=https;AccountName=eventsadlsqa;AccountKey=ozMK/QwF1mhIH0+2sz/7chu6cC5yxnMqEllcYw60YijHOp5yIhxodwfL3UdK4WnRbW6t4Bj3jhx+y6uO3JvPwA==;EndpointSuffix=core.windows.net'
    AGGREGATION_INPUT_CONTAINER = 'campaign-snapshot'
    AGGREGATION_OUTPUT_STRING = 'DefaultEndpointsProtocol=https;AccountName=eventsadlsqa;AccountKey=ozMK/QwF1mhIH0+2sz/7chu6cC5yxnMqEllcYw60YijHOp5yIhxodwfL3UdK4WnRbW6t4Bj3jhx+y6uO3JvPwA==;EndpointSuffix=core.windows.net'
    AGGREGATION_OUTPUT_CONTAINER = 'datascience'

    # bid_distribution
    BID_DIST_OUTPUT_CONTAINERNAME = 'bid-landscape-dist'

    # bid lanscape
    BID_LANDSCAPE_OUTPUT_CONTAINER = BID_LANDSCAPE_CONTAINER
    BID_LANDSCAPE_OUTPUT = '{year}/{month}/{day}/BidLandscape_{retailer_id}.csv'

    # AzureCognitiveSearch
    AZURE_COGNITIVE_ENDPOINT = "https://icc-ai-qa.search.windows.net"
    AZURE_COGNITIVE_ADMIN_KEY = "AC427CF0066FB4E1FBDDD292B606B938"

    # Campaign Metadata Eventhub - Engg (Campaign Service)
    CAMPAIGN_EVENTHUB_STRING = "Endpoint=sb://event-tracking-qa.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=9YZx3bcPMVRPc+0bsCisNf1lnb5A90Buy4IaohZD+6k="
    CAMPAIGN_CONSUMER_GROUP = "icc-ai-consumer_group1"
    CAMPAIGN_EVENTHUB_NAME = "campaign-audit-logs"

    # Suggestions Eventhub
    AI_EVENTHUB_STRING = 'Endpoint=sb://icc-ai-qa.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=WzEI5PzgMdipv3xfRZYn98nG0ldnhjZnNNwFRjvKN0s='
    SUGGESTIONS_EVENTHUB_NAME = 'campaign-suggestions'

    # Placement info URL
    PLACEMENT_URL = "http://qa-inventorysvc.commerce.inmobi.com/api/v1/placements?retailerId={}&status=ACTIVE&sendFloorPrices=True"

    # CTR-CVR Estimations
    CTR_CVR_INPUT_CONNECTION_STRING = "DefaultEndpointsProtocol=https;AccountName=eventsadlsqa;AccountKey=ozMK/QwF1mhIH0+2sz/7chu6cC5yxnMqEllcYw60YijHOp5yIhxodwfL3UdK4WnRbW6t4Bj3jhx+y6uO3JvPwA==;EndpointSuffix=core.windows.net"
    CTR_CVR_INPUT_CONTAINER = "analytics"

    # Suggestions Rejection
    SUGGESTION_FEEDBACK_EN_CONNECTION = 'DefaultEndpointsProtocol=https;AccountName=eventsadlsqa;AccountKey=ozMK/QwF1mhIH0+2sz/7chu6cC5yxnMqEllcYw60YijHOp5yIhxodwfL3UdK4WnRbW6t4Bj3jhx+y6uO3JvPwA==;EndpointSuffix=core.windows.net'
    SUGGESTION_FEEDBACK_EN_CONTAINER = 'suggestion-events'
    SUGGESTION_FEEDBACK_AI_CONNECTION = 'DefaultEndpointsProtocol=https;AccountName=iccaiqa;AccountKey=GX13C6Qkg5agit4/U3Y/KqOHPN1ch1/Pn6Lk51aX8EJ6w4oz/gSnaAbX4U9lh8GJwXP/B6bB0HIGK7ewTIfxZg==;EndpointSuffix=core.windows.net'
    SUGGESTION_FEEDBACK_AI_CONTAINER = 'feedback-events'

    # AD SPEND ENGINEERING DETAILS
    AD_SPEND_CONNECTION = 'DefaultEndpointsProtocol=https;AccountName=eventsadlsqa;AccountKey=ozMK/QwF1mhIH0+2sz/7chu6cC5yxnMqEllcYw60YijHOp5yIhxodwfL3UdK4WnRbW6t4Bj3jhx+y6uO3JvPwA==;EndpointSuffix=core.windows.net'
    AD_SPEND_CONTAINER = 'analytics'

    # TARGETING LOGS
    TARGETING_LOGS_CONTAINER = "campaign-targeting-logs"
    TARGET_LOGS_BLOB_FORMAT = "year={}/month={}/day={}/retailer_id={}/campaignId={}/{}.parquet"


class ConstantConfig:
    NEGATION_TO_REMOVE = ['inorganic', 'in-organic', 'in organic', 'non-organic', 'non organic', 'nonorganic']
    LIST_OF_RELATIONS = ['above', 'under', 'over', 'below', 'less than', 'greater than', 'more than']
    REGEX_FOR_PRICE = [re.compile(r'\$[\s]?\d+(?:\.\d+)?'),
                       re.compile(r'\d*(?:\.\d+)?[\s]?\$'),
                       re.compile(r"\d*(?:\.\d+)?[\s]?dollar[s]?"),
                       re.compile(r"\d*(?:\.\d+)?[\s]?cents"),
                       re.compile(r"\d*(?:\.\d+)?[\s]?bucks")]


class AzureCognitiveSearchConfig:
    ENDPOINT = "https://icc-ai.search.windows.net"
    ADMIN_KEY = "mzWXbhF81rRPzHbVERHBl57KrJ0tyfMwdc7cpqFj5ZAzSeB7cseg"


class AzureCognitiveSearchSchema:
    SCHEMA = [
        {"fieldtype": "SimpleField", "name": "index", "type": "Edm.String",
         "key": "True", "sortable": "False", "facetable": "False", "filterable": "False"},
        {"fieldtype": "SearchableField", "name": "sku", "type": "Edm.String", "sortable": "False", "facetable": "False",
         "filterable": "False"},
        {"fieldtype": "SearchableField", "name": "name", "type": "Edm.String", "sortable": "True", "facetable": "True",
         "filterable": "True"},
        {"fieldtype": "SearchableField", "name": "description", "type": "Edm.String", "sortable": "True",
         "facetable": "True", "filterable": "True"}
    ]


class RelevanceConfig:
    RELEVANCE_RANGE = 0.5
    RELEVANCE_MEAN = 0.75


class Config:
    ENV = os.environ.get('ENV')
    AzureConfig = AzureConfigDEV
    if ENV == "prod":
        AzureConfig = AzureConfigPROD
    if ENV == 'uat':
        AzureConfig = AzureConfigUAT
    if ENV == 'qa':
        AzureConfig = AzureConfigQA

    @staticmethod
    def switch_env(env):
        if env == "prod":
            Config.AzureConfig = AzureConfigPROD
        if env == 'uat':
            Config.AzureConfig = AzureConfigUAT
        if env == 'qa':
            Config.AzureConfig = AzureConfigQA
        if env == 'dev':
            Config.AzureConfig = AzureConfigDEV

        return Config.AzureConfig
