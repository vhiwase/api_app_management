# pylint: disable=all
import pandas as pd
import os
import numpy as np
import time
from util.keyword_targetting_utils import KeywordHash
from util.meta_data_extractor import MetaDataExtractor
from relevance.keywordtargeting import KeywordTargeting
from relevance.relevance_engine import RelevanceEngine
from context.context import Context
from util.read_write_data_azure_blob import ReadAndWriteFromAzureBlob
import pickle
from numpy import dot
from datetime import datetime, timedelta
from config import Config
import argparse
import traceback

class KeywordMining:

    def __init__(self,retailer_info):
        self.retailer_info = retailer_info
        self.KT = KeywordTargeting()
        self.KH = KeywordHash()
        self.relevance_engine = RelevanceEngine()
        self.read_write_blob = ReadAndWriteFromAzureBlob()
        self.time_delta = 1
        self.date_string_split = datetime.strftime(
            datetime.now() - timedelta(self.time_delta),
            '%Y/%m/%d').split('/')

    def change_dimensionality(self, embedding):
        return embedding.reshape(1, -1)

    def add_logs(self):
        log_file = "BatchJobLogs/year={}/month={}/day={}/" \
                   "SearchJob.log".format(
            self.date_string_split[0],
            self.date_string_split[1],
            self.date_string_split[2])

        self.read_write_blob.write_log_to_blob(
            Config.AzureConfig.RECOMMENDATION_OUT_STRING,
            Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME,
            log_file)

    def main(self):
        MetaDataExtractor.get_retailer_matadata()
        Config.switch_env(self.retailer_info['env'])
        print("Getting retailers list from {env} environment".format(env=Config.AzureConfig.ENV))
        retailer_ids = []
        for retailer_metadata in MetaDataExtractor.get_retailer_matadata():
            retailer_ids.append(retailer_metadata['_id'])
        print(retailer_ids)
        for retailer_id in retailer_ids:
            try:
                Config.switch_env(self.retailer_info['cat_src'])
                print("Reading search logs from {env} environment for retailer"
                      " {retailer_id}".format(env=Config.AzureConfig.ENV,retailer_id=retailer_id))
                search_data = self.KT.get_lastn_days_job_data(retailer_id, 'organic_search', ndays=1).dropna()

                if not search_data.empty:
                    print("Reading atc data from {env} environment for retailer"
                          " {retailer_id}".format(env=Config.AzureConfig.ENV, retailer_id=retailer_id))
                    atc_data = self.KT.get_lastn_days_job_data(retailer_id, 'atc', ndays=15)
                    atc_data['Product'] = atc_data['Product'].astype(str).str.lower()
                    atc_keywords = list(set(atc_data['keywords']))
                    print("No of atc keywords to be mapped ", len(atc_keywords))

                    search_data1 = search_data.rename(columns={'count': 'Count'}).groupby('keywords',
                                                                                          as_index=False).agg(
                        {'Count': sum}).sort_values(by='Count', ascending=False)
                    search_data1['cumulative_sum'] = search_data1['Count'].cumsum()
                    search_data2 = search_data1[
                        search_data1.cumulative_sum < int(.7 * search_data1['Count'].sum())].reset_index()
                    search_keywords = list(search_data2.loc[:, 'keywords'])
                    print("No of search keywords to be mapped ", len(search_keywords))
                    search_hash_keywords_dict = self.KT.get_hash_keyword_dict(search_data2)

                    print('running context')
                    Config.switch_env(self.retailer_info['env'])
                    Context.init([retailer_id])
                    print('context running successfully for retailer id: {retailer_id} in {env} environment'.format(
                        retailer_id=retailer_id,
                        env=Config.AzureConfig.ENV))
                    retailer = Context.get_retailer(retailer_id)
                    retailer_data = retailer.data
                    print('Computing product embeddings')
                    st = time.time()
                    retailer_data['embedding'] = list(self.KT.get_embeddings(list(retailer_data['name'])))
                    retailer_data['embedding'] = retailer_data['embedding'].apply(self.change_dimensionality)
                    print('Calculation of embedding done in ', time.time() - st)
                    retailer_dict = retailer_data.set_index('sku')[
                        ['name', 'description', 'category', 'brand', 'productType', 'embedding']].to_dict('index')
                    sku_to_keywords_existing_exact = self.KT.get_data_from_blob(
                        str(retailer_id) + '_sku_keyword_map_exact.pkl')
                    ###### Getting new additional hashes ###########
                    Config.switch_env(self.retailer_info['env'])
                    print("Reading blob files from {env} environment".format(env=Config.AzureConfig.ENV))
                    try:
                        keywords_count_df = self.KT.get_data_from_blob(str(retailer_id) + '_keywords_count_df.pkl')
                    except:
                        keywords_count_df = pd.DataFrame(columns=['keywords', 'Count'])
                    hash_keyword_dict = self.KT.get_hash_keyword_dict(keywords_count_df)
                    new_hashes_search = list(set(search_hash_keywords_dict) - set(hash_keyword_dict))
                    hashes_not_present_dict = {your_key: search_hash_keywords_dict[your_key] for your_key in
                                               new_hashes_search}
                    print("No of new hashes to be mapped:{keywords_no} for retailer:{retailer_id}".format(
                        keywords_no=len(hashes_not_present_dict), retailer_id=retailer_id))

                    ########## Adding new hashes throgh search faiss  map #######

                    if new_hashes_search:
                        unique_keywords_list = [hashes_not_present_dict[hash][0] for hash in hashes_not_present_dict]
                        unique_keywords_hashes_list = list(map(KM.KH.get_keyword_hash, unique_keywords_list))
                        ## Generate search mapping ######
                        st = time.time()
                        keyword_ids = list(range(len(unique_keywords_list)))
                        keyword_ids_to_keywordhash = dict(zip(keyword_ids, unique_keywords_hashes_list))
                        print("Coumputing keyword embeddings")
                        keywords_embeddings = self.KT.get_embeddings(unique_keywords_list)
                        sku_embedding_dict = dict(zip(retailer_data['sku'], retailer_data['embedding']))
                        keywords_faiss_index = self.KT.create_faiss_index(keywords_embeddings, keyword_ids)
                        distances_list, neighbors_list = keywords_faiss_index.search(np.vstack(sku_embedding_dict.values()),
                                                                                     k=min(500,len(keyword_ids)-50))
                        print("Embedding shape ", np.shape(keywords_embeddings))

                        sku_to_keywords_search = {}
                        for i in range(len(sku_embedding_dict)):
                            sku_to_keywords_search[list(sku_embedding_dict.keys())[i]] = [
                                {'hash': keyword_ids_to_keywordhash[x], 'relevance_score': (4 - y) / 4} for
                                x, y in zip(neighbors_list[i], distances_list[i])]

                        print("Time taken to get keywords product map from faiss is ", time.time() - st)

                        ###### Creating broad and exact keyword pairs ##########
                        sku_keyword_map_search_exact = {}
        #                sku_keyword_map_search_broad = {}
                        for sku in sku_to_keywords_search.keys():
                            combined_hash_pairs = sorted(sku_to_keywords_search[sku], key=lambda d: d['relevance_score'],
                                                         reverse=True)[:1000]
                            combined_hash_pairs_exact = [x for x in combined_hash_pairs if x['relevance_score'] > .85]
                            sku_keyword_map_search_exact[sku] = combined_hash_pairs_exact
                            # combined_hash_pairs_broad = [x for x in combined_hash_pairs if x['relevance_score'] > .75]
                            # sku_keyword_map_search_broad[sku] = combined_hash_pairs_broad
                        print("Created broad and exact match pairs")
                    else:
                        sku_keyword_map_search_exact = {}

                    ##### Add atc search mapping ###########
                    st = time.time()
                    print("Adding search atc map")
                    print("Creating atc mapping")
                    sku_atc_search_map = self.KT.get_atc_keywords_product_map(atc_data, retailer_dict)
                    print("Length of atc map ", len(sku_atc_search_map))
                    print("Adding atc map to exisitng mapping")
                    st = time.time()
                    sku_keyword_map_search_exact = self.KT.add_mapping(sku_keyword_map_search_exact, sku_atc_search_map)
#                    sku_keyword_map_search_broad = self.KT.add_mapping(sku_keyword_map_search_broad, sku_atc_search_map)
                    print("time taken to add atc map is ", time.time() - st)

                    ##### Adding boosting ###########
                    print("Adding boosting")
                    st = time.time()
                    sku_keyword_map_search_exact = self.KT.add_boosting(retailer_dict, sku_keyword_map_search_exact)
    #                sku_keyword_map_search_broad = self.KT.add_boosting(retailer_dict, sku_keyword_map_search_broad)
                    print("Boosting done in: ", time.time() - st)

                    ######## Adding to existing mapping ##########
                    print("Adding to existing mappings")
                    st = time.time()
                    sku_keyword_map_exact = self.KT.add_mapping(sku_to_keywords_existing_exact, sku_keyword_map_search_exact)
                    print("Adding to exisiting mapping done in: ", time.time() - st)

                    ######### Pushing data to blob ################

                    ###### Creating hash keyword dictioanry ##########
                    Config.switch_env(self.retailer_info['env'])
                    print('Pushing to {env} environment '.format(env=self.retailer_info['env']))
                    st = time.time()
                    print("Pushing to blob")
                    self.KT.push_data_to_blob(sku_keyword_map_exact, str(retailer_id) + '_sku_keyword_map_exact.pkl')
                    print("time taken to push to blob ", time.time() - st)

                    print("Pushing data to mongo")
                    st = time.time()
                    mongo_data_sku_hash_exact = self.KT.create_mongo_data(sku_keyword_map_exact, 'sku_hash')
                    self.KT.push_data_to_mongo(mongo_data_sku_hash_exact, 'sku_hash_exact', retailer_id)
                    print("Time taken to insert exact sku hash dict to mongo is", time.time() - st)

                    st = time.time()
                    combined_keywords_data = pd.concat([keywords_count_df, search_data]).groupby('keywords',
                                                                                                  as_index=False).agg(
                        {'Count': sum})
                    hash_keywords_dict = self.KT.get_hash_keyword_dict(combined_keywords_data)
                    self.KT.push_data_to_blob(combined_keywords_data, str(retailer_id) + '_keywords_count_df.pkl')
                    mongo_data_hash_keyword = self.KT.create_mongo_data(hash_keywords_dict, 'hash_keyword')
                    self.KT.push_data_to_mongo(mongo_data_hash_keyword, 'hash_keyword', retailer_id)
                    print("time taken to push hash keyword to mongo ", time.time() - st)
                else:
                    print("No search data for retailer {retailer_id} hence not running for this retailer".format(retailer_id=retailer_id))

            except Exception as e:
                print(traceback.format_exc())
                pass

if __name__ == "__main__":
    start = time.time()
    parser = argparse.ArgumentParser(description='Running search mining')
    parser.add_argument('-e', '--env', help='environment', type=str, default='dev')
    parser.add_argument('-cs', '--cat_src', help='catalog_source', type=str, default='prod')
    args = vars(parser.parse_args())
    KM = KeywordMining(args)
    KM.main()
