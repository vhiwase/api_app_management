# pylint: disable=all
import gc
from numpy import dot
import os
import numpy as np
import time
from util.keyword_targetting_utils import KeywordHash
from relevance.keywordtargeting import KeywordTargeting
from util.read_write_data_azure_blob import ReadAndWriteFromAzureBlob
from datetime import datetime, timedelta
import argparse
from context.context import Context
from config import Config, LocalConfig
import torch
from sentence_transformers import SentenceTransformer
import shutil
from util.mongo_util import MongoUtil
import pickle

class KeywordMining:

    def __init__(self, retailer_info):
        self.retailer_info = retailer_info
        self.retailer_id = self.retailer_info['id']
        Config.switch_env(self.retailer_info['env'])
        self.KT = KeywordTargeting()
        self.KH = KeywordHash()
        self.read_write_blob = ReadAndWriteFromAzureBlob()
        self.time_delta = 1
        self.date_string_split = datetime.strftime(
            datetime.now() - timedelta(self.time_delta),
            '%Y/%m/%d').split('/')
        self.ROBERTA_BERT_MODEL = None
        self.product_meta_data_mongo_client = MongoUtil(
            Config.AzureConfig.COSMOS_URI,
            Config.AzureConfig.COSMOS_PRODUCT_META_DB,
            self.retailer_id)

    def __load_model(self):
        if not os.path.exists(LocalConfig.MODEL_PATH):
            self.__download_model()
        self.ROBERTA_BERT_MODEL = SentenceTransformer(LocalConfig.MODEL_PATH, device='cpu')

    @staticmethod
    def __download_model():
        print("Downloading model ", Config.AzureConfig.CPU_MODEL_BLOB_NAME, "  to ", LocalConfig.DATA_FOLDER_PATH)
        # make data directory if it not exist
        os.makedirs(LocalConfig.DATA_FOLDER_PATH, exist_ok=True)
        Context.download_blob(Config.AzureConfig.CPU_MODEL_BLOB_NAME, LocalConfig.DATA_FOLDER_PATH)
        shutil.unpack_archive(LocalConfig.DATA_FOLDER_PATH + Config.AzureConfig.CPU_MODEL_BLOB_NAME,
                              LocalConfig.MODEL_PATH)

    def add_logs(self):
        log_file = "BatchJobLogs/year={}/month={}/day={}/" \
                   "SearchJob.log".format(
            self.date_string_split[0],
            self.date_string_split[1],
            self.date_string_split[2])

        self.read_write_blob.write_log_to_blob(
            Config.AzureConfig.RECOMMENDATION_OUT_STRING,
            Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME,
            log_file)

    def main(self):
        self.__load_model()
        retailer_id = self.retailer_info['id']
        print(retailer_id)
        data_path = LocalConfig.DATA_FOLDER_PATH + str(retailer_id) + '/'
        retailer_data = self.KT.get_data_from_blob("full_data_KT_" + str(retailer_id) + ".pkl")
        retailer_dict = retailer_data.set_index('sku')[
            ['name', 'description', 'category', 'brand', 'productType', 'embedding']].to_dict('index')

        print("Updating product metadata")
        self.KT.update_product_metadata(retailer_data,self.product_meta_data_mongo_client)

        Config.switch_env(self.retailer_info['cat_src'])
        print('Reading search logs')
        search_data = self.KT.get_lastn_days_job_data(retailer_id, 'organic_search', ndays=30).dropna()
        if len(search_data):
            search_data1 = search_data.rename(columns={'count': 'Count'}).groupby('keywords', as_index=False).agg(
                {'Count': sum}).sort_values(by='Count', ascending=False)
            search_data1['cumulative_sum'] = search_data1['Count'].cumsum()
            search_data2 = search_data1[
                search_data1.cumulative_sum < int(.7 * search_data1['Count'].sum())].reset_index()
            search_hash_keywords_dict = self.KT.get_hash_keyword_dict(search_data2)
            search_hash_keywords_keys = search_hash_keywords_dict.keys()
            unique_keywords_list = [search_hash_keywords_dict[hash][0] for hash in search_hash_keywords_dict]
            print("No of unique search terms ", len(unique_keywords_list))

            ## Generate and add search mapping ######
            st = time.time()
            keyword_ids = list(range(len(unique_keywords_list)))
            unique_keywords_hashes_list = list(map(KM.KH.get_keyword_hash, unique_keywords_list))
            keyword_ids_to_keywordhash = dict(zip(keyword_ids, unique_keywords_hashes_list))
            print("Generating embeddings")
            keywords_embeddings = self.KT.get_embeddings(unique_keywords_list)
            sku_embedding_dict = dict(zip(retailer_data['sku'], retailer_data['embedding']))
            print("Time taken to generate embeddings for keywords ",time.time()-st)
            nn_to_map = 500
            st = time.time()
            keywords_faiss_index = self.KT.create_faiss_index(keywords_embeddings,keyword_ids,nn_to_map)
            print("Time taken to generate faiss index ",time.time()-st)
            st = time.time()
            distances_list, neighbors_list = keywords_faiss_index.search(np.vstack(sku_embedding_dict.values()), k=nn_to_map)
            print("Embedding shape ",np.shape(keywords_embeddings))
            print("Time taken to generate nn from faiss index ", time.time() - st)

            st = time.time()
            sku_keywords_map = {}
            for i in range(len(sku_embedding_dict)):
                sku_keywords_map[list(sku_embedding_dict.keys())[i]] = [
                    {'hash': keyword_ids_to_keywordhash[x], 'relevance_score': (4 - y) / 4} for
                    x, y in zip(neighbors_list[i], distances_list[i])]
                if (i % 1000 == 0):
                    print("Generated nn keywords for skus ",i)
            print("Time taken to generate keywords product map from faiss is ", time.time() - st)

        else:
            print("No keywords from organic search")
            search_keywords = []
            sku_keywords_map = {}

        ###### Creating broad and exact keyword targeting ##########
        sku_keyword_map_exact = {}
        for sku in sku_keywords_map.keys():

            exact_len = len([x for x in sku_keywords_map[sku] if x['relevance_score'] > .85])
            combined_hash_pairs_exact = sorted(sku_keywords_map[sku], key=lambda d: d['relevance_score'],reverse=True)[:max(25,exact_len)]
            sku_keyword_map_exact[sku] = combined_hash_pairs_exact
        print("Created exact match pairs")

        ######## Add brand and producttype heuristic keywords ####
        print("Adding heurisitc keywords")
        st = time.time()
        sku_brand_ptype_heuristic = self.KT.get_ptype_brand_key_hashes_heuristic(retailer_dict)
        sku_keyword_map_exact = self.KT.add_mapping(sku_keyword_map_exact,sku_brand_ptype_heuristic)
        print("Added heurisitc keywords in ",time.time()-st)
        ##### Add atc search mapping ###########
        st = time.time()
        print("Adding search atc map")
        Config.switch_env(self.retailer_info['cat_src'])
        atc_data = self.KT.get_lastn_days_job_data(retailer_id, 'atc', ndays=30)
        atc_data['Product'] = atc_data['Product'].str.lower()
        print("Shape of ATC data ", atc_data.shape)

        if not atc_data.empty:
            print("Creating atc mapping")
            sku_atc_search_map = self.KT.get_atc_keywords_product_map(atc_data, retailer_dict)
            print("Length of atc map ", len(sku_atc_search_map))
            print("Adding atc map to exisitng mapping")
            st = time.time()
            sku_keyword_map_exact = self.KT.add_mapping(sku_keyword_map_exact, sku_atc_search_map)
            print("time taken to add atc map is ", time.time() - st)

            ####  Add graph mapping #########
            # print("Adding graph mapping")
            # graph_dict = self.KT.get_missing_edges_graph(atc_data, retailer_data)
            # sku_keyword_map_exact = self.KT.add_mapping(sku_keyword_map_exact, graph_dict)
            # print("Adding missing edges from grap done in ",time.time()-st)

        else:
            print("No atc data available, please check")

        del sku_atc_search_map,sku_keywords_map,sku_brand_ptype_heuristic
        gc.collect()
        print("Adding boosting")
        st = time.time()
        sku_keyword_map_exact = self.KT.add_boosting(retailer_dict, sku_keyword_map_exact)
        print("Boosting done in: ", time.time() - st)
        gc.collect()
        Config.switch_env(self.retailer_info['env'])
        st = time.time()
        print('Pushing to {env} environment '.format(env=args['env']))
        print('Pushing to blob')
        self.KT.push_data_to_blob(sku_keyword_map_exact, str(retailer_id) + '_sku_keyword_map_exact.pkl')
        print("time taken to push to blob ", time.time() - st)

        print('Pushing to mongo')
        st = time.time()
        mongo_data_sku_hash_exact = self.KT.create_mongo_data(sku_keyword_map_exact, 'sku_hash')
        self.KT.push_data_to_mongo(mongo_data_sku_hash_exact, 'sku_hash_exact', retailer_id)
        print("Time taken to insert exact sku hash dict to mongo is", time.time() - st)

        st = time.time()
        ######## Creating hash dict to push #########
        hash_keywords_dict = self.KT.get_hash_keyword_dict(search_data)
        self.KT.push_data_to_blob(search_data, str(retailer_id) + '_keywords_count_df.pkl')
        mongo_data_hash_keyword = self.KT.create_mongo_data(hash_keywords_dict, 'hash_keyword')
        self.KT.push_data_to_mongo(mongo_data_hash_keyword, 'hash_keyword', retailer_id)
        print("time taken to push hash keyword to mongo ", time.time() - st)


if __name__ == "__main__":
    start = time.time()
    print("Starting")
    parser = argparse.ArgumentParser(description='Running search mining')
    parser.add_argument('-i', '--id', help='ID', required=True)
    parser.add_argument('-e', '--env', help='target enviroment', required=True)
    parser.add_argument('-cs', '--cat_src', help='catalog_source', type=str, default='prod')
    args = vars(parser.parse_args())
    KM = KeywordMining(args)
    KM.main()
