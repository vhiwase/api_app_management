import os
import asyncio
from datetime import datetime, timedelta
from util.meta_data_extractor import MetaDataExtractor
from config import *
from azure.storage.blob import ResourceTypes, AccountSasPermissions, \
    generate_account_sas, BlobServiceClient
import argparse
import pandas as pd
from util.azure_search_clients import AzureSearchClients, AzureSearchUtils
import pymongo


class DataPromotion:
    def __init__(self, promotion_info):
        self.promotion_info = promotion_info
        Config.switch_env(
            str(self.promotion_info['source_environment']).lower()
                          )
        self.meta_data = MetaDataExtractor.get_retailer_matadata(
            self.promotion_info['retailer_id'])
        self.source_config, self.destination_config = \
            self.eval_configs()
        self.source_sas_token, self.source_blob_client, \
            self.des_blob_service_client, self.source_container_client,\
            self.mongo_client, self.source_environment_container, \
            self.destination_environment_container, self.azure_admin_client, \
            self.azure_search_client = self.create_source_clients()

    def eval_configs(self):
        source_config = eval(
            'AzureConfig{}'.format(
                self.promotion_info['source_environment']
            )
        )
        destination_config = eval(
            'AzureConfig{}'.format(
                self.promotion_info['destination_environment']
            )
        )
        return source_config, destination_config

    def create_source_clients(self):
        source_sas_token = generate_account_sas(
            account_name=self.source_config.ACCOUNT_NAME,
            account_key=self.source_config.ACCOUNT_KEY,
            resource_types=ResourceTypes(
                service=True,
                container=True,
                object=True),
            permission=AccountSasPermissions(read=True),
            expiry=datetime.utcnow() + timedelta(hours=2))

        source_blob_service_client = BlobServiceClient(
            account_url=self.source_config.ACCOUNT_URL,
            credential=self.source_config.ACCOUNT_KEY)

        des_blob_service_client = BlobServiceClient(
            account_url=self.destination_config.ACCOUNT_URL,
            credential=self.destination_config.ACCOUNT_KEY)

        source_container_client = source_blob_service_client. \
            get_container_client(self.source_config.CONTAINER_NAME)

        mongo_client = MetaDataExtractor.initialize_mongo_client(
            self.destination_config.COSMOS_URI,
            self.destination_config.COSMOS_DATABASE_NAME,
            self.destination_config.COSMOS_META_DATA_TABLE
        )

        source_environment_container = self.source_config.CONTAINER_NAME
        destination_environment_container = \
            self.destination_config.CONTAINER_NAME

        azure_cognitive_client = AzureSearchClients(
            self.meta_data['retailer_name'],
            self.destination_config.AZURE_COGNITIVE_ENDPOINT,
            self.destination_config.AZURE_COGNITIVE_ADMIN_KEY
        )

        azure_admin_client = azure_cognitive_client.CreateIndexClient()
        azure_search_client = azure_cognitive_client.CreateSearchClient()

        return source_sas_token, source_blob_service_client, \
            des_blob_service_client, source_container_client, \
            mongo_client, source_environment_container, \
            destination_environment_container, azure_admin_client, \
            azure_search_client

    def get_data_path(self):
        files = [self.meta_data['data_file'], self.meta_data['full_data_file']]
        if 'image_faiss' in self.meta_data:
            files.append(self.meta_data['image_faiss'])
        if 'text_faiss' in self.meta_data:
            files.append(self.meta_data['text_faiss'])
        if 'sku_to_keyword' in self.meta_data:
            files.append(self.meta_data['sku_to_keyword'])
        if 'keywords_present_search' in self.meta_data:
            files.append(self.meta_data['keywords_present_search'])
        return files

    def promote_files(self):
        files = self.get_data_path()
        if files:
            for file in files:
                source_blob = self.source_container_client.\
                    get_blob_client(file)
                source_url = source_blob.url + '?' + self.source_sas_token
                self.des_blob_service_client.get_blob_client(
                    self.destination_environment_container,
                    source_blob.blob_name
                    ).start_copy_from_url(source_url)
        print("Successfully promoted files for retailer - {}".format(
            self.promotion_info['retailer_id'])
             )

    @staticmethod
    def update_meta_data_mongo(client, data):
        if client.find_one({'_id': data['_id']}):
            updated_dictionary = {key: data[key] for key in data.keys() if
                                  key != '_id'}
            client.update_one({'_id': data['_id']},
                              {'$set': updated_dictionary})
            return True
        return False

    def push_meta_data_mongo(self):
        try:
            update_counter = self.update_meta_data_mongo(self.mongo_client,
                                                         self.meta_data)
            if not update_counter:
                self.mongo_client.insert_one(self.meta_data)
        except Exception as e:
            print(e)
            return "Exception"
        print("Add/Update Successful for retailer - {}".format(
            self.promotion_info['retailer_id']
        ))

    def __get_targeting_db(self):
        mongo_client = pymongo.MongoClient(self.source_config.COSMOS_URI)

        # Targeting DBs
        potential_targeting_dbs = [
            'COSMOS_PRODUCT_META_DB',
            'COSMOS_KEYWORD_TARGETING_DB',
            'COSMOS_HASH_TO_KEYWORD_DB',
            'COSMOS_PRODUCT_TARGETING_DB',
            'COSMOS_CATEGORY_TARGETING_DB'
                         ]

        # Extracting only those targeting that contains the retailer_id
        targeting_dbs = []
        for db in potential_targeting_dbs:
            collection_list = mongo_client[eval(
                'self.source_config.{}'.format(
                    db))].list_collection_names()
            if str(self.promotion_info['retailer_id']) in collection_list:
                targeting_dbs.append(db)

        mongo_client.close()

        return targeting_dbs

    @staticmethod
    def __yield_rows(iterable, chunk_size):
        chunk = []
        for i, row in enumerate(iterable):
            if i % chunk_size == 0 and i > 0:
                yield chunk
                del chunk[:]
            chunk.append(row)
        yield chunk

    def update_targeting_mongo(self):
        source_db_coll_map = self.__get_targeting_db()
        source_client = pymongo.MongoClient(self.source_config.COSMOS_URI)

        for db in source_db_coll_map:
            print("Uploading {} for {}".format(db, str(self.meta_data['_id'])))
            db_ = source_client[eval(
                'self.source_config.{}'.format(
                    db))]
            collection = db_[str(self.meta_data['_id'])]
            cursor = collection.find({}, batch_size=10000)
            source_client.close()

            # Upload to Destination
            destination_client = pymongo.MongoClient(
                self.destination_config.COSMOS_URI)
            destination_db = destination_client[eval(
                'self.destination_config.{}'.format(
                    db))]
            destination_collection = destination_db[str(self.meta_data['_id'])]
            destination_collection.drop()

            chunks = self.__yield_rows(cursor, 10000)
            for chunk in chunks:
                destination_collection.insert_many(chunk, ordered=False)
            destination_client.close()
        print("Successfully promoted targeting data for retailer - {}".format(
            str(self.meta_data['_id'])))

    async def create_azure_index(self):
        azure_utils = AzureSearchUtils()
        blob_client_instance = self.source_blob_client.get_blob_client(
            self.source_environment_container,
            self.meta_data['data_file'],
            snapshot=None)
        with open('local_file', "wb") as my_blob:
            blob_data = blob_client_instance.download_blob(max_concurrency=10)
            print("Downloading file")
            blob_data.readinto(my_blob)
        data = pd.read_pickle('local_file')
        os.remove('local_file')
        azure_utils.create_azure_index(
            self.meta_data['retailer_name'],
            data,
            self.azure_admin_client,
            self.azure_search_client)

    def main(self):
        self.promote_files()
        self.push_meta_data_mongo()
        self.update_targeting_mongo()
        # asyncio.run(self.create_azure_index())


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description='Promotes necessary data from '
                    'one environment to another')
    parser.add_argument('-r', '--retailer_id', help='Retailer Id', type=int,
                        required=True)
    parser.add_argument('-source', '--source_environment',
                        help='Source Environment - DEV, QA, UAT, PROD',
                        required=True)
    parser.add_argument('-destination', '--destination_environment',
                        help='Destination Environment - DEV, QA, UAT, PROD',
                        required=True)
    args = vars(parser.parse_args())
    promotion = DataPromotion(args)
    promotion.main()
