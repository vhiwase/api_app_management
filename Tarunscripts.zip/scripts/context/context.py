# pylint: disable=all
from sentence_transformers import SentenceTransformer
import nltk
import spacy
from util.meta_data_extractor import MetaDataExtractor
from context.retailer import Retailer
from azure.storage.blob import BlobServiceClient
import os
from config import Config, LocalConfig
import shutil
import redis
from azure.cosmos.cosmos_client import CosmosClient
from tensorflow.keras.applications import DenseNet121
from applicationinsights import TelemetryClient, channel
from util.mongo_util import MongoUtil


class Context:
    azure_container_client = None
    __retailers = dict()
    LEMMATIZER = None
    WORD_TOKENIZE = None
    ROBERTA_BERT_MODEL = None
    IMAGE_MODEL = None
    NLP_SPACY = None
    azure_redis_client = None
    azure_sql_client = None
    logger_client = None

    @staticmethod
    def initialize_backbone_models():
        Context.__load_model()
        Context.__load_spacey()

    @staticmethod
    def init(retailer_ids=None, lite_mode=False, init_mongo_clients=True, download_data=True, download_models=True):

        sender = channel.AsynchronousSender()
        queue = channel.AsynchronousQueue(sender)
        channel_obj = channel.TelemetryChannel(None, queue)
        Context.logger_client = TelemetryClient(Config.AzureConfig.INSTRUMENTATION_KEY, channel_obj)
        Context.init_retailer_ids = retailer_ids

        if lite_mode:
            Context.refresh_meta_data()
        else:
            if download_models:
                Context.LEMMATIZER = nltk.stem.WordNetLemmatizer()
                Context.WORD_TOKENIZE = nltk.word_tokenize
                Context.__load_model()
                Context.__load_spacey()
            Context.__init_redis_client()

            meta_data_list = MetaDataExtractor.get_retailer_matadata()
            for meta_data in meta_data_list:
                if retailer_ids is not None and meta_data["_id"] not in retailer_ids:
                    continue
                print("Processing retailer: ", meta_data)
                if init_mongo_clients:
                    retailer_product_mongo_client = Context.init_retailer_product_mongo_client(str(meta_data["_id"]))
                    if not retailer_product_mongo_client:
                        print("Product mongo client for retailer %s is not initialized. "
                              "Hence not loading this retailer." % meta_data["_id"])
                        continue
                    retailer_category_mongo_client = Context.init_retailer_category_mongo_client(str(meta_data["_id"]))
                    if not retailer_category_mongo_client:
                        print("Category mongo client for retailer %s is not initialized. "
                              "Hence not loading this retailer." % meta_data["_id"])
                        continue
                    retailer_keyword_mongo_client = Context.init_retailer_product_to_hash_mongo_client(
                        str(meta_data["_id"]))
                    if not retailer_keyword_mongo_client:
                        print("product to hash mongo client for retailer %s is not initialized. "
                              "Hence not loading this retailer." % meta_data["_id"])
                        continue
                    retailer_broad_keyword_mongo_client = Context.init_retailer_product_to_broad_hash_mongo_client(
                        str(meta_data["_id"]))
                    if not retailer_broad_keyword_mongo_client:
                        print("product to broad hash mongo client for retailer %s is not initialized. "
                              "Hence not loading this retailer." % meta_data["_id"])
                        continue
                    retailer_hash_to_keyword_mongo_client = Context.init_retailer_hash_to_keyword_mongo_client(
                        str(meta_data["_id"])
                    )
                    if not retailer_hash_to_keyword_mongo_client:
                        print("hash to keyword mongo client for retailer %s is not initialized. "
                              "Hence not loading this retailer." % meta_data["_id"])
                        continue
                    retailer_bid_landscape_mongo_client = Context.init_retailer_bid_landscape_mongo_client(
                        str(meta_data["_id"])
                    )
                    if not retailer_bid_landscape_mongo_client:
                        print("bid landscape mongo client for retailer %s is not initialized. "
                              "Hence not loading this retailer." % meta_data["_id"])
                        continue

                else:
                    retailer_product_mongo_client = \
                        retailer_category_mongo_client = retailer_keyword_mongo_client = \
                        retailer_broad_keyword_mongo_client = \
                        retailer_hash_to_keyword_mongo_client = retailer_bid_landscape_mongo_client = None

                if download_data:
                    retailer_base_path = LocalConfig.DATA_FOLDER_PATH + str(meta_data["_id"]) + "/"
                    Context.__download_retailer_data(retailer_base_path, meta_data, lite_mode=lite_mode)
                else:
                    retailer_base_path = None

                retailer = Retailer(
                    retailer_base_path, meta_data,
                    retailer_category_mongo_client,
                    retailer_product_mongo_client,
                    retailer_keyword_mongo_client,
                    retailer_broad_keyword_mongo_client,
                    retailer_hash_to_keyword_mongo_client,
                    retailer_bid_landscape_mongo_client,
                    init_mongo_clients,
                    lite_mode=lite_mode
                )

                Context.__retailers[meta_data["_id"]] = retailer

    @staticmethod
    def get_retailer(retailer_id):
        return Context.__retailers.get(int(retailer_id))

    @staticmethod
    def __load_model():
        print("Loading model")
        if not os.path.exists(LocalConfig.MODEL_PATH):
            Context.__download_model()
        Context.ROBERTA_BERT_MODEL = SentenceTransformer(LocalConfig.MODEL_PATH, device='cpu')
        Context.IMAGE_MODEL = DenseNet121(weights='imagenet', include_top=False)

    @staticmethod
    def __download_model():
        print("Downloading model ", Config.AzureConfig.CPU_MODEL_BLOB_NAME, "  to ", LocalConfig.DATA_FOLDER_PATH)
        # make data directory if it not exist
        os.makedirs(LocalConfig.DATA_FOLDER_PATH, exist_ok=True)
        Context.download_blob(Config.AzureConfig.CPU_MODEL_BLOB_NAME, LocalConfig.DATA_FOLDER_PATH)
        shutil.unpack_archive(LocalConfig.DATA_FOLDER_PATH + Config.AzureConfig.CPU_MODEL_BLOB_NAME,
                              LocalConfig.MODEL_PATH)

    @staticmethod
    def __load_spacey():
        print("Loading spacey")
        if not os.path.exists(LocalConfig.SPACEY_PATH):
            Context.__download_spacey()
        Context.NLP_SPACY = spacy.load(LocalConfig.SPACEY_PATH)

    @staticmethod
    def __download_spacey():
        print("Downloading spacey")
        Context.download_blob(Config.AzureConfig.SPACEY_BLOB_NAME, LocalConfig.DATA_FOLDER_PATH)
        shutil.unpack_archive(LocalConfig.DATA_FOLDER_PATH + Config.AzureConfig.SPACEY_BLOB_NAME,
                              LocalConfig.SPACEY_PATH)

    @staticmethod
    def __download_retailer_data(retailer_base_path, meta_data, lite_mode):
        os.makedirs(retailer_base_path, exist_ok=True)
        if not os.path.exists(retailer_base_path + meta_data['data_file']):
            Context.download_blob(meta_data['data_file'], retailer_base_path)

        if not lite_mode:
            if not os.path.exists(retailer_base_path + meta_data['text_faiss']):
                Context.download_blob(meta_data['text_faiss'], retailer_base_path)
            if meta_data.get('is_image_sim_enabled', 'no') == 'yes':
                if not os.path.exists(retailer_base_path + meta_data['image_faiss']):
                    Context.download_blob(meta_data['image_faiss'], retailer_base_path)

    @staticmethod
    def init_azure_container_client():
        if Context.azure_container_client is None:
            blob_service_client = BlobServiceClient.from_connection_string(
                Config.AzureConfig.ICC_DS_STORAGE_CONNECTION_STRING)
            Context.azure_container_client = blob_service_client.get_container_client(Config.AzureConfig.CONTAINER_NAME)

    @staticmethod
    def download_blob(blob_name, local_base_path):
        print("Downloading blob : ", blob_name)
        Context.init_azure_container_client()
        with open(local_base_path + blob_name, "wb") as download_file:
            Context.azure_container_client.get_blob_client(blob_name).download_blob(
                max_concurrency=20).readinto(download_file)

    @staticmethod
    def __init_redis_client():
        if Context.azure_redis_client is None:
            Context.azure_redis_client = redis.StrictRedis(host=Config.AzureConfig.REDIS_HOST_NAME,
                                                           port=6380, db=0,
                                                           password=Config.AzureConfig.REDIS_PASSWORD,
                                                           ssl=True)

    @staticmethod
    def init_sql_client():
        if Context.azure_sql_client is None:
            Context.azure_sql_client = CosmosClient(Config.AzureConfig.COSMOS_SQL_ENDPOINT,
                                                    Config.AzureConfig.COSMOS_SQL_PRIMARY_KEY)

    @staticmethod
    def init_retailer_product_mongo_client(retailer_id):
        product_mongo_client = MongoUtil(
            Config.AzureConfig.COSMOS_URI,
            Config.AzureConfig.COSMOS_PRODUCT_TARGETING_DB,
            retailer_id
        )
        return product_mongo_client

    @staticmethod
    def init_retailer_category_mongo_client(retailer_id):
        category_mongo_client = MongoUtil(
            Config.AzureConfig.COSMOS_URI,
            Config.AzureConfig.COSMOS_CATEGORY_TARGETING_DB,
            retailer_id
        )
        return category_mongo_client

    @staticmethod
    def init_retailer_product_to_hash_mongo_client(retailer_id):
        product_hash_mongo_client = MongoUtil(
            Config.AzureConfig.COSMOS_URI,
            Config.AzureConfig.COSMOS_KEYWORD_TARGETING_DB,
            retailer_id
        )
        return product_hash_mongo_client

    @staticmethod
    def init_retailer_product_to_broad_hash_mongo_client(retailer_id):
        product_broad_hash_mongo_client = MongoUtil(
            Config.AzureConfig.COSMOS_URI,
            Config.AzureConfig.COSMOS_BROAD_KEYWORD_TARGETING_DB,
            retailer_id
        )
        return product_broad_hash_mongo_client

    @staticmethod
    def init_retailer_hash_to_keyword_mongo_client(retailer_id):
        hash_keyword_mongo_client = MongoUtil(
            Config.AzureConfig.COSMOS_URI,
            Config.AzureConfig.COSMOS_HASH_TO_KEYWORD_DB,
            retailer_id
        )
        return hash_keyword_mongo_client

    @staticmethod
    def init_retailer_bid_landscape_mongo_client(retailer_id):
        bid_landscape_mongo_client = MongoUtil(
            Config.AzureConfig.COSMOS_URI,
            Config.AzureConfig.COSMOS_BID_LANDSCAPE_DB,
            retailer_id
        )
        return bid_landscape_mongo_client

    @staticmethod
    def refresh_meta_data():
        meta_data_list = MetaDataExtractor.get_retailer_matadata()
        for meta_data in meta_data_list:
            if Context.init_retailer_ids is not None and meta_data["_id"] not in Context.init_retailer_ids:
                continue
            print("Processing retailer: ", meta_data)
            retailer_id = meta_data["_id"]
            if not Context.get_retailer(retailer_id):
                retailer = Retailer(
                    None, meta_data,
                    None,
                    None,
                    None,
                    None,
                    None,
                    None,
                    lite_mode=True
                )

                Context.__retailers[retailer_id] = retailer
            retailer = Context.get_retailer(retailer_id)
            retailer.update_meta_data(meta_data)
