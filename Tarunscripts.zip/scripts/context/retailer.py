# pylint: disable=all
# from _typeshed import FileDescriptorLike
import faiss
import pandas as pd
import numpy as np
import logging
from context.product import Product
from config import AzureCognitiveSearchConfig
from util.azure_search_clients import AzureSearchClients
import requests
from config import Config


class Retailer:

    def __init__(self, retailer_base_path, meta_data,
                 category_mongo_client, product_mongo_client,
                 product_to_hash_mongo_client, product_to_broad_hash_mongo_client,
                 hash_to_keyword_mongo_client,
                 bid_landscape_mongo_client, init_mongo_clients=True,
                 lite_mode=False):
        self.retailer_id = meta_data["_id"]
        self.meta_data = meta_data

        self.__products_by_sku = {}
        self.__fid_to_sku = {}
        self.__image_fid_to_sku = {}
        self.__adaptive_bid_flag = False

        if "adaptive_bid_flag" in meta_data:
            self.__adaptive_bid_flag = meta_data["adaptive_bid_flag"]
        self.__min_floor_price_info = self.refresh_placement_info()

        if not lite_mode:
            if init_mongo_clients:
                self.category_mongo_client = category_mongo_client
                self.product_mongo_client = product_mongo_client
                self.product_to_hash_mongo_client = product_to_hash_mongo_client
                self.product_to_broad_hash_mongo_client = product_to_broad_hash_mongo_client
                self.hash_to_keyword_mongo_client = hash_to_keyword_mongo_client
                self.bid_landscape_mongo_client = bid_landscape_mongo_client
            if retailer_base_path is not None:
                self.data = pd.read_pickle(retailer_base_path + meta_data['data_file'])
                self.data['Broad_Category'] = self.data['category'] + ">" + self.data['productType']
                self.data['Broad_Category'] = self.data['Broad_Category'].str.strip(">")
                self.faiss_nprobe = int(self.data.shape[0] / 1000) + 1

                self.__initialize_products(lite_mode=lite_mode)

                self.faiss_index = faiss.read_index(retailer_base_path + meta_data['text_faiss'])
                self.image_faiss_index = faiss.read_index(retailer_base_path + meta_data['image_faiss'])
                self.category_count = self.data.groupby("Broad_Category").size()
                self.category_embedding = self.__create_category_embedding()
                self.search_clients = self.create_search_client()
                self.data = self.data.drop(['embedding', 'image_embedding'], axis=1)

        # self.brands = set(self.data.brand)
        # self.skus = set(self.data.sku)
        #TODO: Remove below line once active products are in place
        # self.__products_for_catg_targeting = set(random.sample(self.skus, 200))

    def __create_category_embedding(self):
        category_embeddings = {}
        for category, embedding in self.data.groupby('Broad_Category')['embedding'].apply(np.mean).items():
            faiss.normalize_L2(embedding)
            category_embeddings[category] = embedding
        return category_embeddings

    def __initialize_products(self, lite_mode=False):
        for i, row in self.data.iterrows():
            sku = str(row.sku)
            try:
                title = row['name']
            except:
                title = ''
            if lite_mode:
                product = Product(
                    sku=sku, fid=None, embedding=None, category=row.category,
                    product_type=row.productType, origin=None, image_embedding=None,
                    image_fid=None, name=title, price=row.price,
                    broad_category=row.Broad_Category, brand=row.brand
                )

            elif 'origin' in row:
                product = Product(sku, row.FID, row.embedding,
                          row.category, row.productType, row.origin,
                          row.image_embedding, row.IMAGE_FID,
                          title, row.price, row.Broad_Category, row.brand)
            else:
                product = Product(sku, row.FID, row.embedding,
                          row.category, row.productType, "",
                          row.image_embedding, row.IMAGE_FID,
                          title, row.price, row.Broad_Category, row.brand)
            self.__products_by_sku[sku] = product
            self.__fid_to_sku[row.FID] = sku
            self.__image_fid_to_sku[row.IMAGE_FID] = sku

    def get_product_by_sku(self, sku):
        if sku in self.__products_by_sku:
            return self.__products_by_sku[sku]
        return None

    def get_sku_by_image_fid(self, image_fid):
        return self.__image_fid_to_sku[image_fid]

    def get_sku_by_fid(self, fid):
        return self.__fid_to_sku[fid]

    def get_category_embedding(self, category):
        return self.category_embedding[category]

    def get_active_products_for_category_targeting(self):
        return self.__products_for_catg_targeting

    def get_id(self):
        return self.retailer_id

    def add_active_products(self, skus):
        for sku in skus:
            self.__products_for_catg_targeting.add(sku)

    def create_search_client(self):
        client = AzureSearchClients(self.meta_data['retailer_name'], AzureCognitiveSearchConfig.ENDPOINT, AzureCognitiveSearchConfig.ADMIN_KEY)
        return client.CreateSearchClient()

    def update_meta_data(self, meta_data):
        self.meta_data = meta_data
        self.__min_floor_price_info = self.refresh_placement_info()
        self.__adaptive_bid_flag = False
        if "adaptive_bid_flag" in meta_data:
            self.__adaptive_bid_flag = meta_data["adaptive_bid_flag"]

    def refresh_placement_info(self):
        retailer_id = self.retailer_id
        placement_floor_price_dict = {}
        link = Config.AzureConfig.PLACEMENT_URL.format(str(retailer_id))
        try:
            placement_data = requests.get(link).json()
            for placement in placement_data:
                placement_id = placement["id"]
                value = placement["floor_price_cpm"]
                placement_floor_price_dict[str(placement_id)] = value
                floor_price_configs = placement.get("floor_price_configs")
                if floor_price_configs:
                    for config in placement["floor_price_configs"]:
                        placement_id = str(placement_id) + "_" + \
                                       str(config["target_value"]).lower()
                        placement_floor_price_dict[placement_id] = config[
                            "cpm"
                        ]
            logging.info(
                "{env}: Floor price info updated for retailer "
                "{retailer_id}".format(
                    env=Config.AzureConfig.ENV,
                    retailer_id=retailer_id
                )
            )
        except Exception as e:
            logging.exception(
                "{env}: Error in updating Floor price info for retailer "
                "{retailer_id} due to {e}".format(
                    env=Config.AzureConfig.ENV,
                    retailer_id=retailer_id,
                    e=e
                )
            )

        return placement_floor_price_dict

    def get_floor_price(self, placement_id, target_value=None):
        min_floor = 0.0
        if target_value:
            key = str(placement_id) + "_" + str(target_value)
            if key in self.__min_floor_price_info:
                min_floor = self.__min_floor_price_info[key]
            else:
                if str(placement_id) in self.__min_floor_price_info:
                    min_floor = self.__min_floor_price_info[
                        str(placement_id)
                    ]
        else:
            if str(placement_id) in self.__min_floor_price_info:
                min_floor = self.__min_floor_price_info[str(placement_id)]

        return min_floor

    def is_adaptive_bid_enabled(self):
        return self.__adaptive_bid_flag

    def get_meta_data(self):
        return self.meta_data
