from sentence_transformers import SentenceTransformer
import nltk
import spacy
from util.meta_data_extractor import MetaDataExtractor
from context.retailer import Retailer
from azureml.core import Workspace, Model
from azureml.core.authentication import InteractiveLoginAuthentication
from azure.storage.blob import BlobServiceClient
import os
from config import AzureConfig, LocalConfig
import shutil
import redis
from azure.cosmos.cosmos_client import CosmosClient


class Context:
    __azure_container_client = None
    __retailers = dict()
    LEMMATIZER = None
    WORD_TOKENIZE = None
    ROBERTA_BERT_MODEL = None
    NLP_SPACY = None
    azure_redis_client = None
    azure_sql_client = None  


    @staticmethod
    def init():
        Context.LEMMATIZER = nltk.stem.WordNetLemmatizer()
        Context.WORD_TOKENIZE = nltk.word_tokenize
        Context.__load_model()
        Context.__load_spacey()
        Context.__init_redis_client()

        meta_data_list = MetaDataExtractor.get_retailer_matadata()
        for meta_data in meta_data_list:
            retailer_base_path = LocalConfig.DATA_FOLDER_PATH + str(meta_data["_id"]) + "/"
            Context.__download_retailer_data(retailer_base_path, meta_data)
            Context.__retailers[meta_data["_id"]] = Retailer(retailer_base_path, meta_data)

    @staticmethod
    def get_retailer(retailer_id):
        return Context.__retailers[retailer_id]

    @staticmethod
    def __load_model():
        if not os.path.exists(LocalConfig.MODEL_PATH):
            Context.__download_model()
        Context.ROBERTA_BERT_MODEL = SentenceTransformer(LocalConfig.MODEL_PATH, device='cpu') 
            
    @staticmethod
    def __download_model():
        # make data directory if it not exist
        os.makedirs(LocalConfig.DATA_FOLDER_PATH, exist_ok=True)
        Context.__download_blob(AzureConfig.CPU_MODEL_BLOB_NAME, LocalConfig.DATA_FOLDER_PATH)
        shutil.unpack_archive(LocalConfig.DATA_FOLDER_PATH + AzureConfig.CPU_MODEL_BLOB_NAME, 
                            LocalConfig.MODEL_PATH)

    @staticmethod
    def __load_spacey():
        if not os.path.exists(LocalConfig.SPACEY_PATH):
            Context.__download_spacey()
        Context.NLP_SPACY = spacy.load(LocalConfig.SPACEY_PATH)

    @staticmethod
    def __download_spacey():
        Context.__download_blob(AzureConfig.SPACEY_BLOB_NAME, LocalConfig.DATA_FOLDER_PATH)
        shutil.unpack_archive(LocalConfig.DATA_FOLDER_PATH + AzureConfig.SPACEY_BLOB_NAME, LocalConfig.SPACEY_PATH)

    @staticmethod
    def __download_retailer_data(retailer_base_path, meta_data):
        os.makedirs(retailer_base_path, exist_ok=True)
        if not os.path.exists(retailer_base_path + meta_data['data_file']):
            Context.__download_blob(meta_data['data_file'], retailer_base_path)

    @staticmethod
    def __init_azure_container_client():
        if Context.__azure_container_client is None:
            blob_service_client = BlobServiceClient.from_connection_string(AzureConfig.ICC_DS_STORAGE_CONNECTION_STRING)
            Context.__azure_container_client = blob_service_client.get_container_client(AzureConfig.CONTAINER_NAME)

    @staticmethod
    def __download_blob(blob_name, local_base_path):
        Context.__init_azure_container_client()
        with open(local_base_path+blob_name, "wb") as download_file:
            download_file.write(Context.__azure_container_client.get_blob_client(blob_name).download_blob().readall())

    @staticmethod
    def __init_redis_client():
        if Context.azure_redis_client is None:
            Context.azure_redis_client = redis.StrictRedis(host=AzureConfig.REDIS_HOST_NAME,
                                                           port=6380, db=0, password=AzureConfig.REDIS_PASSWORD, 
                                                           ssl=True)

    @staticmethod
    def init_sql_client():
        if Context.azure_sql_client is None:
            Context.azure_sql_client = CosmosClient(AzureConfig.COSMOS_SQL_ENDPOINT, 
                                                    AzureConfig.COSMOS_SQL_PRIMARY_KEY)