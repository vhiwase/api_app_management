# pylint: disable=all
class Product:
    def __init__(self, sku, fid, embedding, category,
                 product_type, origin, image_embedding, 
                 image_fid, name, price, broad_category, brand):
        self.__sku = sku
        self.__fid = fid
        self.__embedding = embedding
        self.__category = category
        self.__product_type = product_type
        self.__origin = origin
        self.__image_embedding = image_embedding
        self.__image_fid = image_fid
        self.__name = name
        self.__price = price
        self.__broad_category = broad_category
        self.__brand = brand

    def get_product_meta(self):
        return {'sku': self.__sku, 'name': self.__name, 'price': self.__price,
                'FID': self.__fid, 'IMAGE_FID': self.__image_fid,
                'Broad_Category': self.__broad_category, 'category': self.__category,
                'productType': self.__product_type, 'brand': self.__brand} 

    def get_embeding(self):
        return self.__embedding

    def get_image_embeding(self):
        return self.__image_embedding

    def get_fid(self):
        return self.__fid

    def get_image_fid(self):
        return self.__image_fid

    def get_sku(self):
        return self.__sku

    def get_category(self):
        return self.__category

    def get_origin(self):
        return self.__origin

    def get_product_type(self):
        return self.__product_type

    def get_price(self):
        return self.__price

    def get_brand(self):
        return self.__brand

    def get_name(self):
        return self.__name
