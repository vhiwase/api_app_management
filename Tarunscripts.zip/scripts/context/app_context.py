# pylint: disable=all
from util.meta_data_extractor import MetaDataExtractor
from context.retailer import Retailer
from config import Config
from applicationinsights import TelemetryClient, channel


class AppContext:
    azure_container_client = None
    __retailers = dict()
    logger_client = None

    @staticmethod
    def init(retailer_ids=None):

        sender = channel.AsynchronousSender()
        queue = channel.AsynchronousQueue(sender)
        channel_obj = channel.TelemetryChannel(None, queue)
        AppContext.logger_client = TelemetryClient(Config.AzureConfig.INSTRUMENTATION_KEY, channel_obj)
        AppContext.init_retailer_ids = retailer_ids
        AppContext.refresh_meta_data()

    @staticmethod
    def get_retailer(retailer_id):
        return AppContext.__retailers.get(retailer_id)

    @staticmethod
    def refresh_meta_data():
        meta_data_list = MetaDataExtractor.get_retailer_matadata()
        for meta_data in meta_data_list:
            if AppContext.init_retailer_ids is not None and meta_data["_id"] not in AppContext.init_retailer_ids:
                continue
            retailer_id = meta_data["_id"]
            if not AppContext.get_retailer(retailer_id):
                retailer = Retailer(
                    None, meta_data,
                    None,
                    None,
                    None,
                    None,
                    None,
                    None,
                    lite_mode=True
                )

                AppContext.__retailers[retailer_id] = retailer
            retailer = AppContext.get_retailer(retailer_id)
            retailer.update_meta_data(meta_data)
