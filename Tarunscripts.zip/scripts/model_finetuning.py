import random
import nltk
from torch.utils.data import DataLoader
from sentence_transformers import SentenceTransformer, InputExample, losses, models, evaluation
import torch.nn as nn
import torch
from config import Config
import pandas as pd
import numpy as np
import time
import pickle
import argparse
from relevance.keywordtargeting import KeywordTargeting
from util.keyword_targetting_utils import KeywordHash
from retailer_onboarding_lite import RetailerOnboardingLite
import os
import distutils
from sklearn.metrics import auc
from pathlib import Path
import shutil

random.seed(100)


class ModelFineTuning:

    def __init__(self, retailer_info):
        self.retailer_info = retailer_info
        self.retailer_lite = RetailerOnboardingLite(retailer_info)
        self.lemmatizer = nltk.stem.WordNetLemmatizer()
        self.w_tokenizer = nltk.tokenize.WhitespaceTokenizer()
        self.n_gpus = torch.cuda.device_count()
        self.KT = KeywordTargeting()
        self.KH = KeywordHash()
        self.model = self.__get_model()
        self.parallel_net = nn.DataParallel(self.model, device_ids=list(range(torch.cuda.device_count())))
        self.catalogue_data = self.__get_catalogue_data()
        print("Shape of catalogue data ", self.catalogue_data.shape)
        self.__gen_data_dicts(self.catalogue_data)
        self.retailer_dict = self.catalogue_data.set_index('sku')[
            ['name', 'description', 'category', 'brand', 'productType']].to_dict('index')

    def __get_atc_dict(self,atc_data):
        print("Generating atc data dictionaries")
        atc_data['keyword_hash'] = atc_data['keywords'].apply(self.KT.KH.get_keyword_hash)
        atc_data.rename(columns={'Product': 'sku'}, inplace=True)
        atc_data['sku'] = atc_data['sku'].astype(str).str.lower()
        atc_data1 = atc_data.groupby(['sku', 'keyword_hash'], as_index=False).agg({'Count': sum}).sort_values(
            by='Count', ascending=False)
        atc_data1['cumulative_sum'] = atc_data1['Count'].cumsum()
        atc_data2 = atc_data1[atc_data1.Count > 1]
        self.sku_keywordhash_dict = atc_data2.groupby('sku')['keyword_hash'].apply(list).to_dict()
        self.hash_keywords_dict = self.KT.get_hash_keyword_dict(atc_data)
        self.atc_data = atc_data2

    def __get_catalogue_data(self):
        try:
            print("Getting fresh catalgoue data")
            catalogue_data = self.retailer_lite._RetailerOnboardingLite__fetch_data_from_container()
            catalogue_data = pd.DataFrame(catalogue_data)
            catalogue_data, category_path_col = self.retailer_lite._RetailerOnboardingLite__preprocess_catalogue_data(
                catalogue_data)
            print("Columns are ", catalogue_data.columns)
        except:
            print("Getting catalogue data from blob")
            retailer_id = self.retailer_info['id']
            catalogue_data = self.KT.get_data_from_blob("full_data_KT_" + str(retailer_id) + ".pkl")
        catalogue_data['sku'] = catalogue_data['sku'].str.lower()
        return catalogue_data

    def __get_model(self):
        model_arch = self.retailer_info["model"]
        if model_arch == 'tf2':
            model = SentenceTransformer('sentence-transformers/multi-qa-MiniLM-L6-cos-v1')
            for index, (name, param) in enumerate(model._first_module().auto_model.named_parameters()):
                if index > 94:  # Finetune only last encoder's dense layers
                    param.requires_grad = True
                else:
                    param.requires_grad = False

        elif model_arch == 'roberta-large':
            model = SentenceTransformer('roberta-large')

        elif model_arch == 'current':
            model = SentenceTransformer('../icc-ai-v5/scripts/relevance_products/data/fine_tuned_roberta_cpu.pt')

        elif model_arch == 'tf1':
            stage1_model = models.Transformer('sentence-transformers/multi-qa-MiniLM-L6-cos-v1')
            for param in stage1_model.parameters():
                param.requires_grad = False
            pooling_model = models.Pooling(stage1_model.get_word_embedding_dimension())
            dense_model1 = models.Dense(in_features=pooling_model.get_sentence_embedding_dimension(), out_features=256,
                                        activation_function=nn.Tanh())
            dense_model2 = models.Dense(in_features=dense_model1.get_sentence_embedding_dimension(), out_features=1024,
                                        activation_function=nn.Tanh())
            model = SentenceTransformer(modules=[stage1_model, pooling_model, dense_model1, dense_model2])

        else:
            model = SentenceTransformer(model_arch)
        return model

    def __gen_data_dicts(self,catalogue_data):
        self.sku_category_dict = dict(zip(catalogue_data.sku, catalogue_data.category))
        self.sku_producttype_dict = dict(zip(catalogue_data.sku,catalogue_data.productType))
        self.sku_name_dict = dict(zip(catalogue_data.sku, catalogue_data.name))

    def __model_training(self, modelling_pairs, evaluator,model_path,checkpoint_path):
        train_dataloader = DataLoader(modelling_pairs, shuffle=True, batch_size=4096)
        steps_per_epoch = len(train_dataloader)
        print(steps_per_epoch)
        train_loss = losses.CosineSimilarityLoss(self.parallel_net)
        self.parallel_net.module.fit(train_objectives=[(train_dataloader, train_loss)],
                                     optimizer_params={'lr': 4e-4},
                                      evaluator=evaluator,
                                     evaluation_steps=steps_per_epoch,
                                     output_path=model_path,
                                     epochs=self.retailer_info['epochs'],
                                     warmup_steps=100,
                                     save_best_model=True,
                                     checkpoint_path = checkpoint_path,
                                     checkpoint_save_steps = steps_per_epoch
                                     )
        return self.parallel_net.module

    def generate_sku_sku_pairs(self, catalogue_data, num_pairs=5):
        sku_sku_pairs_dict = {}
        all_skus = (list(catalogue_data.sku))
        category_sku_dict = catalogue_data.groupby('category')['sku'].apply(list).to_dict()
        producttype_sku_dict = catalogue_data.groupby('productType')['sku'].apply(list).to_dict()
        i = 0
        for sku in all_skus:
            sku_sku_pairs_dict[sku] = {}
            category = self.sku_category_dict[sku]
            producttype = self.sku_producttype_dict[sku]
            sim_producttype_skus_list = producttype_sku_dict[producttype]
            sim_category_skus_list = set(category_sku_dict[category]) - set(producttype_sku_dict[producttype])
            random_skus_list = set(all_skus) - set(category_sku_dict[category])
            same_producttype_skus = random.sample(sim_producttype_skus_list,
                                                  min(len(sim_producttype_skus_list), num_pairs))
            similar_category_skus = random.sample(sim_category_skus_list,
                                                  min(len(sim_category_skus_list), num_pairs))
            random_skus = random.sample(random_skus_list, min(len(random_skus_list), num_pairs*2))

            sku_sku_pairs_dict[sku]['same_producttype_skus'] = same_producttype_skus
            sku_sku_pairs_dict[sku]['same_category_skus'] = similar_category_skus
            sku_sku_pairs_dict[sku]['random_skus'] = random_skus
            i = i + 1
            if (i % 1000 == 0):
                print("Generated sku sku pairs for skus : ", i)

        return sku_sku_pairs_dict

    def generate_sku_sku_name_pairs(self, sku_sku_pairs_dict, skus_list):
        sku_sku_name_pairs = []
        for sku in skus_list:
            for same_producttype_sku in sku_sku_pairs_dict[sku]['same_producttype_skus']:
                sku_sku_name_pairs.append(
                    [self.sku_name_dict[sku], self.sku_name_dict[same_producttype_sku], random.uniform(0.75, 0.90)])

            for same_category_sku in sku_sku_pairs_dict[sku]['same_category_skus']:
                sku_sku_name_pairs.append(
                    [self.sku_name_dict[sku], self.sku_name_dict[same_category_sku], random.uniform(0.50, 0.75)])

            for random_sku in sku_sku_pairs_dict[sku]['random_skus']:
                sku_sku_name_pairs.append(
                    [self.sku_name_dict[sku], self.sku_name_dict[random_sku], random.uniform(0.10, 0.20)])

        return sku_sku_name_pairs

    def generate_sku_keywords_pairs(self, sku_sku_pairs_dict, skus_list):
        sku_keyword_pairs = []
        skus_list1 = list(set(sku_sku_pairs_dict.keys()).intersection(skus_list))
        for sku in skus_list1:
            for keyword_hash in self.sku_keywordhash_dict[sku]:
                sku_keyword_pairs.append([self.sku_name_dict[sku], self.hash_keywords_dict[keyword_hash][0], random.uniform(0.90, 1)])

            for same_producttype_sku in sku_sku_pairs_dict[sku]['same_producttype_skus']:
                for keyword_hash in self.sku_keywordhash_dict[same_producttype_sku]:
                    sku_keyword_pairs.append([self.sku_name_dict[sku], self.hash_keywords_dict[keyword_hash][0], random.uniform(0.75, 0.90)])

            for same_category_sku in sku_sku_pairs_dict[sku]['same_category_skus']:
                for keyword_hash in self.sku_keywordhash_dict[same_category_sku]:
                    sku_keyword_pairs.append([self.sku_name_dict[sku], self.hash_keywords_dict[keyword_hash][0], random.uniform(0.50, 0.75)])

            for random_sku in sku_sku_pairs_dict[sku]['random_skus']:
                for keyword_hash in self.sku_keywordhash_dict[random_sku]:
                    sku_keyword_pairs.append([self.sku_name_dict[sku], self.hash_keywords_dict[keyword_hash][0], random.uniform(0.10, 0.20)])

        return sku_keyword_pairs

    def gen_modelling_data(self, pairs_list):
        modelling_pairs = []
        for pair in pairs_list:
            modelling_pairs.append(InputExample(texts=[pair[0], pair[1]], label=pair[2]))
        return modelling_pairs

    def get_precision_recall_values(self,atc_mapping_test, model_mapping, cutoff_score):
        sku_precison_dict = {}
        sku_recall_dict = {}
        atc_missed_dict = {}
        for sku in atc_mapping_test:
            atc_data_sku = self.atc_data[self.atc_data.sku == sku]
            actual_keyword_hashes = list(atc_data_sku['keyword_hash'])
            model_keyword_hashes = [pair['hash'] for pair in model_mapping[sku] if pair['relevance_score']>cutoff_score]
            common_keyword_hashes = list(set(actual_keyword_hashes).intersection(model_keyword_hashes))

            total_atc_sku = atc_data_sku.Count.sum()
            common_atc_count = atc_data_sku.loc[atc_data_sku.keyword_hash.isin(common_keyword_hashes), 'Count'].sum()
            sku_recall_dict[sku] = len(common_keyword_hashes) / len(actual_keyword_hashes)
            if model_keyword_hashes:
                sku_precison_dict[sku] = len(common_keyword_hashes) / len(model_keyword_hashes)
            else:
                sku_precison_dict[sku] = 1
            atc_missed_dict[sku] = 1 - (common_atc_count / total_atc_sku)
        precision = np.mean(list(sku_precison_dict.values()))
        recall = np.mean(list(sku_recall_dict.values()))
        atc_missed = np.mean(list(atc_missed_dict.values()))
        return precision, recall,atc_missed

    def calculate_validation_metrics(self,retailer_data,test_skus,model):
        validation_atc_dict = self.sku_keywordhash_dict
        test_skus1 = list(set(test_skus).intersection(validation_atc_dict.keys()))
        validation_atc_dict1 = { your_key: validation_atc_dict[your_key] for your_key in test_skus1}

        search_data_path = '/dbfs/tarun/model_finetuned_data/{retailer_id}_search_data.csv'.format(retailer_id=self.retailer_info["id"])
        if not os.path.exists(search_data_path):
            search_data = self.KT.get_lastn_days_job_data(self.retailer_info['id'], 'organic_search', ndays=7)
            search_data.to_csv(search_data_path)
        else:
            search_data = pd.read_csv(search_data_path)
        search_data1 = search_data.rename(columns={'count': 'Count'}).groupby('keywords', as_index=False).agg(
            {'Count': sum}).sort_values(by='Count', ascending=False)
        search_data1['cumulative_sum'] = search_data1['Count'].cumsum()
        search_data2 = search_data1[
            search_data1.cumulative_sum < int(.7 * search_data1['Count'].sum())].reset_index()
        search_hash_keywords_dict = self.KT.get_hash_keyword_dict(search_data2)
        unique_keywords_list = [search_hash_keywords_dict[hash][0] for hash in search_hash_keywords_dict]
        print("No of unique keywords ",len(unique_keywords_list))

        st = time.time()
        keyword_ids = list(range(len(unique_keywords_list)))
        unique_keywords_hashes_list = list(map(self.KH.get_keyword_hash, unique_keywords_list))
        keyword_ids_to_keywordhash = dict(zip(keyword_ids, unique_keywords_hashes_list))
        print("Generating keyword embeddings")
        num_cuda_devices = torch.cuda.device_count()
        cuda_devices = ["cuda:" + str(i) for i in range(0, num_cuda_devices)]
        pool = model.start_multi_process_pool(cuda_devices)
        keywords_embeddings = model.encode_multi_process(unique_keywords_list, pool)
        keywords_embeddings = keywords_embeddings / np.expand_dims(np.linalg.norm(keywords_embeddings, axis=1), axis=1)

        model.stop_multi_process_pool(pool)

        retailer_data1 = retailer_data[retailer_data.sku.isin(test_skus1)]
        print("Generating product embeddings")
        num_cuda_devices = torch.cuda.device_count()
        cuda_devices = ["cuda:" + str(i) for i in range(0, num_cuda_devices)]
        pool = model.start_multi_process_pool(cuda_devices)
        product_embeddings = model.encode_multi_process(retailer_data1['name'], pool)
        product_embeddings = product_embeddings / np.expand_dims(np.linalg.norm(product_embeddings, axis=1), axis=1)
        model.stop_multi_process_pool(pool)

        sku_embedding_dict = dict(zip(retailer_data1['sku'], product_embeddings))
        print("Time taken to generate embeddings for keywords ", time.time() - st)
        nn_to_map = 2000
        st = time.time()
        keywords_faiss_index = self.KT.create_faiss_index(keywords_embeddings, keyword_ids, nn_to_map)
        print("Time taken to generate faiss index ", time.time() - st)
        st = time.time()
        distances_list, neighbors_list = keywords_faiss_index.search(np.vstack(sku_embedding_dict.values()),
                                                                     k=nn_to_map)
        print("Embedding shape ", np.shape(keywords_embeddings))
        print("Time taken to generate nn from faiss index ", time.time() - st)

        st = time.time()
        sku_keywords_map = {}
        for i in range(len(sku_embedding_dict)):
            sku_keywords_map[list(sku_embedding_dict.keys())[i]] = [
                {'hash': keyword_ids_to_keywordhash[x], 'relevance_score': (4 - y) / 4} for
                x, y in zip(neighbors_list[i], distances_list[i])]
            if (i % 1000 == 0):
                print("Generated nn keywords for skus ", i)
        print("Time taken to generate keywords product map from faiss is ", time.time() - st)

        #final_map_validation_products = {your_key: sku_keywords_map[your_key] for your_key in test_skus }
        final_map_validation_products = sku_keywords_map

        cutoff_list = []
        precision_list = []
        recall_list = []
        atc_missed_list = []
        st = time.time()
        for cutoff in np.arange(0, 1.00, .01):
            cutoff_list.append(cutoff)
            precision, recall,atc_missed = self.get_precision_recall_values(validation_atc_dict1,final_map_validation_products, cutoff)
            precision_list.append(precision)
            recall_list.append(recall)
            atc_missed_list.append(atc_missed)
        metrics_dataframe = pd.DataFrame({'cutoff': cutoff_list,
                                          'precision': precision_list,
                                          'recall': recall_list,
                                          'atc_missed_percent': atc_missed_list
                                          })
        print("time taken to generate precision recall at cutoffs is ",time.time()-st)
        return metrics_dataframe


    def main(self):

        Path('/dbfs/tarun/model_finetuned_data').mkdir(parents=True, exist_ok=True)
        Path('/dbfs/tarun/output').mkdir(parents=True, exist_ok=True)

        training_data_path = '/dbfs/tarun/model_finetuned_data/{retailer_id}_training_pairs.pkl'.format(
            retailer_id=self.retailer_info["id"])
        validation_data_path = '/dbfs/tarun/model_finetuned_data/{retailer_id}_validation_pairs.pkl'.format(
            retailer_id=self.retailer_info["id"])
        atc_data_path = '/dbfs/tarun/model_finetuned_data/{retailer_id}_atc_data.pkl'.format(
            retailer_id=self.retailer_info["id"])

        if self.retailer_info.get('model_save_name') is None:
            self.retailer_info["model_save_name"] = self.retailer_info["model"]

        model_path = "/databricks/driver/{name}-atc-{model}-{epochs}epochs".format(
            name=self.retailer_info['name'],
            model=self.retailer_info['model_save_name'],
            epochs=self.retailer_info['epochs'])

        model_path1 = "/dbfs/tarun/output/{name}-atc-{model}-{epochs}epochs".format(
            name=self.retailer_info['name'],
            model=self.retailer_info['model_save_name'],
            epochs=self.retailer_info['epochs'])

        checkpoint_path1 = "/dbfs/tarun/output/{name}-atc-{model}-{epochs}epochs_checkpoint".format(
            name=self.retailer_info['name'],
            model=self.retailer_info['model_save_name'],
            epochs=self.retailer_info['epochs'])

        train_test_split =.8
        all_skus = (list(self.catalogue_data.sku))
        training_size = int(np.ceil(len(list(self.catalogue_data.sku)) * train_test_split))
        training_skus = random.sample(list(self.catalogue_data.sku), training_size)
        test_skus = list(set(all_skus) - set(training_skus))

        if not os.path.exists(training_data_path):
            print("Getting atc data")
            Config.switch_env('prod')
            atc_data = self.KT.get_lastn_days_job_data(self.retailer_info['id'], 'atc', ndays=30)
            self.__get_atc_dict(atc_data)
            Config.switch_env('dev')
            print("Generating modelling pairs")
            st = time.time()
            print("Generating sku sku dictionary for entire catalogue")
            sku_sku_pairs_dict = self.generate_sku_sku_pairs(self.catalogue_data)
            print("Generating sku sku dictionary for filtered catalogue")
            catalogue_data_filtered = self.catalogue_data[self.catalogue_data.sku.isin(self.sku_keywordhash_dict)]
            print("Shape of filtered catalogue data ", catalogue_data_filtered.shape)
            sku_sku_pairs_dict_atc_filtered = self.generate_sku_sku_pairs(catalogue_data_filtered)
            print("time taken to generate sku sku dictionaries in ",time.time()-st)
            st = time.time()
            print("Generating training data")
            sku_sku_name_pairs_train = self.generate_sku_sku_name_pairs(sku_sku_pairs_dict, training_skus)
            sku_keywords_pairs_train = self.generate_sku_keywords_pairs(sku_sku_pairs_dict_atc_filtered, training_skus)
            training_pairs = sku_sku_name_pairs_train + sku_keywords_pairs_train
            print("time taken to generate training data for finetuning ", time.time() - st)
            with open(training_data_path, 'wb') as handle:
                pickle.dump(training_pairs, handle)

            st = time.time()
            sku_sku_name_pairs_val = self.generate_sku_sku_name_pairs(sku_sku_pairs_dict, test_skus)
            sku_keywords_pairs_val = self.generate_sku_keywords_pairs(sku_sku_pairs_dict_atc_filtered, test_skus)
            validation_pairs = sku_sku_name_pairs_val + sku_keywords_pairs_val
            print("time taken to generate validation data for finetuning ", time.time() - st)
            with open(validation_data_path, 'wb') as handle:
                pickle.dump(validation_pairs, handle)
            with open(atc_data_path, 'wb') as handle:
                pickle.dump(atc_data, handle)

        else:
            print("training pairs data exist, so not generating again")
            with open(training_data_path, 'rb') as f:
                training_pairs = pickle.load(f)
            with open(validation_data_path, 'rb') as f:
                validation_pairs = pickle.load(f)
            with open(atc_data_path, 'rb') as f:
                atc_data = pickle.load(f)
            self.__get_atc_dict(atc_data)

        if self.retailer_info['train']:
            print("Length of training data ", len(training_pairs))
            print("Length of validation data ", len(validation_pairs))
            validation_data = list(map(list, zip(*validation_pairs)))
            training_data = self.gen_modelling_data(training_pairs)
            evaluator = evaluation.EmbeddingSimilarityEvaluator(validation_data[0],
                                                                validation_data[1],
                                                                validation_data[2],
                                                                show_progress_bar=True)

            model = self.__model_training(training_data, evaluator,model_path,checkpoint_path1)
            print('Model training done')
            print("Moving model folder to dbfs")
            distutils.dir_util.copy_tree(model_path, model_path1)


        if self.retailer_info['validation']:
            print("Calculating validation metrics")
            model = SentenceTransformer(model_path1, device='cuda')

            precision_recall_df = self.calculate_validation_metrics(self.catalogue_data,test_skus,model)
            auc_pr_roc = auc(precision_recall_df['recall'], precision_recall_df['precision'])
            print(precision_recall_df)
            print("AUC-PR is ", auc_pr_roc)
            precision_recall_df.to_csv(model_path1 + '_pr_df.csv')
            with open("/dbfs/tarun/output/keyword_targeting_valuation_metrics.txt", "r") as myfile:
                lines = myfile.readlines()
            lines.extend("\n model {model_path} metrics : auc-pr = {auc_pr_roc}".format(model_path=model_path,
                                                                                            auc_pr_roc=auc_pr_roc))
            with open("/dbfs/tarun/output/keyword_targeting_valuation_metrics.txt", "r+") as myfile:
                myfile.write(''.join(lines))

            pr_file_name = "pr_values_{name}-atc-{model}-{epochs}epochs.pkl".format(
            name=self.retailer_info['name'],
            model=self.retailer_info['model_save_name'],
            epochs=self.retailer_info['epochs'])
            Config.switch_env(self.retailer_info['env'])
            self.KT.push_data_to_blob(precision_recall_df,pr_file_name)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Model finetuning')
    parser.add_argument('-i', '--id', help='ID', required=True)
    parser.add_argument('-n', '--name', help='retailer_name', required=True)
    parser.add_argument('-c', '--container', help='retailer_container', required=True)
    parser.add_argument('-m', '--model', help='model', required=True)
    parser.add_argument('-ep', '--epochs', help='model', nargs='?', const=5, type=int, default=5)
    parser.add_argument('-t', '--train', help='train model', action='store_true')
    parser.add_argument('-v', '--validation', help='validate model', action='store_true')
    parser.add_argument('-e', '--env', help='environment', type=str, default='dev')
    parser.add_argument('-sn', '--model_save_name', help='model save name', const=None, default=None)
    args = vars(parser.parse_args())
    FT = ModelFineTuning(args)
    FT.main()