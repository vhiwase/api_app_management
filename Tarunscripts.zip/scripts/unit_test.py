# pylint: disable=all
import requests as req

class UnitTest:
    def run_all_test_cases():
        assert True == True
