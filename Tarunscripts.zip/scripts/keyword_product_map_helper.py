from sentence_transformers import SentenceTransformer
import pandas as pd
from context.context import Context
import time
import multiprocessing
from multiprocessing import Process, Queue
from sklearn.preprocessing import MinMaxScaler
import pickle
import numpy as np
import torch
import sys
import os


def get_kwd_nns_from_model_in_chunk(text_faiss_index, kwd_chunk, sku_map, num_clusters, k_nearest):
    nn_hash = {}
    kwds_list = [_tup[0] for _tup in kwd_chunk]
    emb_list = np.array([_tup[1] for _tup in kwd_chunk])
    text_faiss_index.nprobe = num_clusters
    distances_list, neighbors_list = text_faiss_index.search(emb_list, k=k_nearest)
    for distances, neighbors, kwd in zip(distances_list, neighbors_list, kwds_list):
        neighbor_skus_obj = {}
        distance_iter = distances.tolist()
        neighbor_iter = neighbors.tolist()
        for distance, neighbor in zip(distance_iter, neighbor_iter):
            neighbor_sku = sku_map.get(neighbor)
            neighbor_skus_obj[neighbor_sku] = distance
        nn_hash[kwd] = neighbor_skus_obj
    return nn_hash

def get_kwd_nns_from_model(text_faiss_index, kwds_hash, text_sku_map, num_clusters, k_nearest):
    st = time.time()
    chunk_size = max(2 * (multiprocessing.cpu_count() - 4), 10)
    kwds_list = list(kwds_hash.items())
    kwds_chunks = [kwds_list[i:i + chunk_size] for i in range(0, len(kwds_list), chunk_size)]
    model_nns = {}
    for index, kwd_chunk in enumerate(kwds_chunks):
        if index % 100 == 0:
            print("processed %d chunks" % index)
        nn_hash = get_kwd_nns_from_model_in_chunk(text_faiss_index, kwd_chunk, text_sku_map, num_clusters, k_nearest)
        model_nns.update(nn_hash)
    et = time.time()
    print("time taken to generate nearest neighbors using model for keywords:")
    print(str(et - st) + " seconds")
    fp = open("model_nns.pkl", "bw")
    pickle.dump(model_nns, fp)
    fp.close()
    return model_nns

def create_embeddings(sentences, roberta_model):
    fp = open("sentences.pkl", "bw")
    pickle.dump(sentences, fp)
    fp.close()
    try:
        os.system("python generate_kwd_embeddings.py sentences.pkl")
    except:
        err_msg = "embeddings could not be generated"
        sys.exit(err_msg)

    fp1 = open("sentence_embeddings.pkl", "br")
    emb_dict = pickle.load(fp1)
    fp1.close()
    return emb_dict

def get_product_by_query_from_azure(retailer, query, k_nearest):
    azure_df = pd.DataFrame(
        list(retailer.search_clients.search(search_text=query, select='sku', top=k_nearest, query_type='simple')))[
        ['sku', '@search.score']]
    if azure_df.shape[0] > 0:
        azure_df['scaled_score'] = np.round(MinMaxScaler().fit_transform(azure_df[['@search.score']]), 4)
        azure_df = azure_df.drop(columns=['@search.score'])
    return dict(zip(azure_df['sku'].values.tolist(), azure_df['scaled_score'].values.tolist()))

def get_kwd_nns_from_azure_in_chunk(retailer, keyword_list, out_q, chunk_num, k_nearest):
    final_kwds = {}
    for index, keyword in enumerate(keyword_list):
        try:
            if index % 1000 == 0:
                print("processed azure search for %d records in chunk %d" % (index, chunk_num))
            azure_prods = get_product_by_query_from_azure(retailer, keyword, k_nearest)
            final_kwds[keyword] = azure_prods
        except:
            pass
    out_q.put(final_kwds)

def get_kwd_nns_from_azure(sentences, retailer, k_nearest):
    st = time.time()
    num_cores = max(multiprocessing.cpu_count() - 4, 1)
    print("num cores used")
    print(num_cores)
    chunk_size = int(len(sentences) / num_cores) + 1
    print("chunk size used")
    print(chunk_size)
    i = 0
    print('Running multiprocess for azure cognitive search')
    process_list = []
    dict_list = []
    azure_nns = {}
    out_q = Queue()
    while i < num_cores:
        print("processing chunk %d" % i)
        st = i * chunk_size
        ed = (i + 1) * chunk_size
        keyword_list_chunk = sentences[st:ed]
        p = Process(target=get_kwd_nns_from_azure_in_chunk,
                    args=(retailer, keyword_list_chunk, out_q, i, k_nearest))
        process_list.append(p)
        p.start()
        i += 1
    for i in range(num_cores):
        dict_list.append(out_q.get())
    for p in process_list:
        p.join()
    for _dict in dict_list:
        azure_nns.update(_dict)

    fp = open("azure_nns.pkl", "bw")
    pickle.dump(azure_nns, fp)
    fp.close()
    et = time.time()
    print("time taken to get nn from keywords using azure:")
    print(str(et - st) + " seconds")
    return azure_nns

def combine_model_azure_outputs(model_nns, azure_nns, keywords_list, k_nearest):
    kwd_map = {}
    st = time.time()
    for index, kwd in enumerate(keywords_list):
        if index % 1000 == 0:
            print("combined output for %d keywords" % index)
        a_nns = azure_nns.get(kwd, {})
        m_nns = model_nns.get(kwd, {})
        nns = [a_nns, m_nns]
        all_skus = list(set().union(*nns))
        relevant_skus = {}
        for sku in all_skus:
            a_score = a_nns.get(sku, 0.0)
            m_dist = m_nns.get(sku, 4.0)
            m_score = (4 - m_dist) / 4.0
            combined_score = (0.55 * a_score) + (0.45 * m_score)
            relevant_skus[sku] = combined_score
        sorted_skus = dict(sorted(relevant_skus.items(), key=lambda item: item[1], reverse=True)[:k_nearest])
        kwd_map[kwd] = sorted_skus
    et = time.time()
    print("time taken to combine azure and model output:")
    print(str(et - st) + " seconds")
    return kwd_map


def main(retailer, keyword_list, k_nearest, mapping_type, retailer_faiss_index=None):
    if mapping_type == 'search_mapping':
        text_faiss_index = retailer.faiss_index
        num_clusters = int(retailer.data.shape[0] / 1000) + 1
        fid_sku_map = dict(zip(retailer.data['FID'].values.tolist(), retailer.data['sku'].values.tolist()))
        emb_dict = create_embeddings(keyword_list, '')
        model_nns = get_kwd_nns_from_model(text_faiss_index, emb_dict, fid_sku_map, num_clusters, k_nearest)
        return model_nns
    elif mapping_type == 'keyword_onboarding':
        text_faiss_index = retailer_faiss_index
        num_clusters = int(retailer.shape[0] / 1000) + 1
        fid_sku_map = dict(zip(retailer['FID'].values.tolist(), retailer['sku'].values.tolist()))
        emb_dict = create_embeddings(keyword_list, '')
        model_nns = get_kwd_nns_from_model(text_faiss_index, emb_dict, fid_sku_map, num_clusters, k_nearest)
        return model_nns