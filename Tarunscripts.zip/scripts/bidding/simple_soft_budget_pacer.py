from util.redis_utils import RedisUtil
from config import Config
import datetime


class SimpleSoftBudgetPacer:
    def __init__(self):
        self.redis_client = RedisUtil(
            Config.AzureConfig.CAMPAIGN_SVC_REDIS_HOST_NAME,
            Config.AzureConfig.CAMPAIGN_SVC_REDIS_PASSWORD
        )

    def get_budget_pacing_factor(self, retailer, campaign_id_list):
        result = dict()

        if (
                not retailer.get_meta_data().get("budget_pacing_flag") or
                not retailer.get_meta_data().get("traffic_pattern")
        ):
            return result

        traffic_pattern = retailer.get_meta_data().get("traffic_pattern")
        current_hour = datetime.datetime.now().hour
        if current_hour >= len(traffic_pattern) or traffic_pattern[current_hour] > 99:
            return result

        traffic_left_percent = 100.0 - traffic_pattern[current_hour]

        budget_info_map = self.redis_client.multi_hash_get(
            Config.AzureConfig.REDIS_ADSPENT_GROUP_NAME,
            campaign_id_list
        )
        for campaign_id, budget_info in budget_info_map.items():
            if not budget_info:
                continue

            budget_left = budget_info["campaignBudget"] - budget_info["adspent"]
            if budget_left < 1:
                continue

            budget_left_percent = 100.0 * budget_left / budget_info["campaignBudget"]
            budget_pacing_factor = budget_left_percent / traffic_left_percent
            budget_pacing_factor = min(budget_pacing_factor, 1)

            result[campaign_id] = budget_pacing_factor

        return result
