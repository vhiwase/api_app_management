from util.azure_batch_logger import BatchLog
from datetime import datetime, timedelta
import pandas as pd
import argparse
from bidding.bid_landscape import BidLandScape
from util.read_write_data_azure_blob import ReadAndWriteFromAzureBlob
from util.mongo_util import MongoUtil
from config import Config
from util.suggestions_util import SuggestionsUtil
from util.floor_price_extractor import FloorPriceExtractor
from util.meta_data_extractor import MetaDataExtractor


class GenerateBidDistribution:
    __WINNER_AGG_JOB = 'winner_aggregation'
    __KEYWORD_COUNT_JOB = 'keyword_count'
    __TARGETING_VALUE = 'targeting_value'
    __TARGETING_TYPE = 'targeting_type'
    __KEY_COL = 'key_col'
    __ECPM_DIST = 'ecpm_dist'
    __ID_COL = '_id'
    __TARGET_COL = 'target'
    __CUM_SUM = 'cumulative_sum_impressions'
    __MIN_FLOOR_PRICES = 'min_floor_prices'
    __BLOB_NAME_FORMAT = "retailer_id={retailer_id}/year={year}/month={month}/day={day}/" \
                         "BID_LANDSCAPE_DIST.csv"
    __MAPPING_DICT = {'keyword': 'kt',
                      'category': 'ct',
                      'product': 'pt'
                      }
    __LOG_FILE_FORMAT = "BatchJobLogs/year={}/month={}/day={}/" \
                        "bid_landscape_suggestions.log"
    __CHUNK_SIZE = 1000

    def __init__(self, time_to_look_back=7):
        self.time_to_look_back = time_to_look_back
        self.read_write_blob = ReadAndWriteFromAzureBlob()
        self.bid_landscape = BidLandScape()
        self.suggestions_util = SuggestionsUtil()
        self.date_string_split = datetime.strftime(
            datetime.now() - timedelta(1),
            '%Y/%m/%d').split('/')

    def __get_winner_ecpm_and_search_volume_data(self, retailer_id):
        winner_ecpm = pd.DataFrame()
        search_volume = pd.DataFrame()
        for i in range(1, self.time_to_look_back + 1):
            temp_df_winner_ecpm = self.suggestions_util.get_winner_ecpm(
                retailer_id, i, infer_retailer_id=False
            )
            winner_ecpm = pd.concat([winner_ecpm, temp_df_winner_ecpm])
            temp_df_search_vol = self.suggestions_util.get_search_count(
                retailer_id, i, infer_retailer_id=False
            )
            search_volume = pd.concat([search_volume, temp_df_search_vol])

        return winner_ecpm, search_volume

    def __save_to_blob(self, retailer_id, bid_landscape_dist):
        # save data to a blob
        blob_name = self.__BLOB_NAME_FORMAT.format(
            retailer_id=retailer_id,
            year=self.date_string_split[0],
            month=self.date_string_split[1],
            day=self.date_string_split[2]
        )

        self.read_write_blob.write_to_blob(
            Config.AzureConfig.RECOMMENDATION_OUT_STRING,
            Config.AzureConfig.BID_DIST_OUTPUT_CONTAINERNAME,
            blob_name,
            bid_landscape_dist)

    def generate_bid_dist_and_save(
            self,
            retailer_id,
            target_value_col_name,
            winning_ecpm_col_name,
            impression_count_col_name,
            targeting_type_col_name,
            search_volume_col_name,
            bucket_size,
            include_floor_price
    ):
        try:
            winner_ecpm, search_volume = self.__get_winner_ecpm_and_search_volume_data(retailer_id)
            min_floor_prices = FloorPriceExtractor.get_ecpm_floor_price_targeting_type(retailer_id).get(
                self.__MIN_FLOOR_PRICES
            )
            message = "Floor prices updated"
            BatchLog.info(message)
            bid_landscape_dist = self.bid_landscape.get_bid_landscape_distribution(
                winner_ecpm,
                search_volume,
                target_value_col_name,
                winning_ecpm_col_name,
                impression_count_col_name,
                targeting_type_col_name,
                search_volume_col_name,
                min_floor_prices,
                bucket_size,
                include_floor_price=include_floor_price
            )

            message = "Bid landscape core logic is finished running"
            BatchLog.info(message)

            if len(bid_landscape_dist) == 0:
                return None
            bid_landscape_dist[self.__TARGETING_TYPE] = bid_landscape_dist[self.__TARGETING_TYPE].apply(
                lambda x: self.__MAPPING_DICT.get(x.lower())
            )
            # save data to a blob
            # Commented as of now as arenot using the blob data in the flow as of now
            # self.__save_to_blob()

            # save data into mongo
            bid_landscape_dist[
                self.__KEY_COL] = bid_landscape_dist[
                                      self.__TARGETING_TYPE] + "_" + bid_landscape_dist[self.__TARGETING_VALUE]
            bid_landscape_dist[self.__ECPM_DIST] = bid_landscape_dist.apply(
                lambda x: [{str(round(x[winning_ecpm_col_name], 2)): x[self.__CUM_SUM]}], axis=1)

            bid_landscape_dist = bid_landscape_dist.groupby([self.__KEY_COL])[self.__ECPM_DIST].sum().reset_index()

            bid_landscape_dist.rename(
                columns={self.__KEY_COL: self.__ID_COL, self.__ECPM_DIST: self.__TARGET_COL}, inplace=True
            )

            bid_landscape_dist = bid_landscape_dist.to_dict(orient='records')

            for each in bid_landscape_dist:
                temp_target = {}
                for target_val in each[self.__TARGET_COL]:
                    for key_val in target_val:
                        temp_target[key_val] = target_val[key_val]
                each[self.__TARGET_COL] = temp_target

            # flusing out data as targets need to be updated according to latest data
            bid_landscape_mongo_client = MongoUtil(
                Config.AzureConfig.COSMOS_URI,
                Config.AzureConfig.COSMOS_BID_LANDSCAPE_DB,
                str(retailer_id)
            )

            bid_landscape_mongo_client.flush_all_keys()
            message = "Deleted old landscape"
            BatchLog.info(message)
            # inserting in chunks
            for i in range(0, len(bid_landscape_dist), self.__CHUNK_SIZE):
                bid_landscape_mongo_client.insert_many(
                    bid_landscape_dist[i:i + self.__CHUNK_SIZE],
                    ordered=False
                )

            message = "Done, updated landscape!! Go ahead and bid"
            BatchLog.info(message)
        except Exception as e:
            message = 'Exception occured:{e}'.format(e=e)
            BatchLog.info(message)
            print(message)

        # Write logs to Blob
        log_file = self.__LOG_FILE_FORMAT.format(
            self.date_string_split[0],
            self.date_string_split[1],
            self.date_string_split[2]
        )

        self.read_write_blob.write_log_to_blob(
            Config.AzureConfig.RECOMMENDATION_OUT_STRING,
            Config.AzureConfig.COMBINED_OUTPUT_CONTAINERNAME,
            log_file)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Bid landscape dist master job')
    parser.add_argument('-d', '--day_count', type=int, default=1,
                        help='Number of days to look backward from current '
                             'date for aggreating bid landscape data')
    parser.add_argument('-tv', '--target_value_col_name', type=str, default='targeting_value',
                        help='target_value column name')
    parser.add_argument('-wecpm', '--winning_ecpm_col_name', type=str, default='winner_ecpm',
                        help='winner ecpm column name')
    parser.add_argument('-imc', '--impression_count_col_name', type=str, default='search_count',
                        help='impression count column name')
    parser.add_argument('-ttyp', '--targeting_type_col_name', type=str, default='targeting_type',
                        help='targeting_type column name')
    parser.add_argument('-sc', '--search_volume_col_name', type=str, default='search_count',
                        help='search count column name')
    parser.add_argument('-bs', '--bucket_size', type=int, default=5,
                        help='bucket_size defines percent of impression share in each impression bucket')
    parser.add_argument('-env', '--environment', type=str,
                        default='dev,qa,uat',
                        help='List of environments to run suggestions')
    parser.add_argument('-fp', '--include_floor_price',
                        help='Boolean flag to include floor price',
                        action='store_true')

    input_args = vars(parser.parse_args())

    for env in input_args['environment'].strip().split(','):
        Config.switch_env(env)
        print(
            "Running for environment - {}".format(
                Config.AzureConfig.ENV)
        )
        bid_distribution = GenerateBidDistribution(
            time_to_look_back=input_args['day_count']
        )
        # getting retailers where auto_suggestion is true to run landscape
        retailers_to_run_bid_dist = \
            MetaDataExtractor.get_retailer_list_for_job(
                "auto_suggestion"
            )
        for retailer_id in retailers_to_run_bid_dist:
            bid_distribution.generate_bid_dist_and_save(
                str(retailer_id),
                input_args['target_value_col_name'],
                input_args['winning_ecpm_col_name'],
                input_args['impression_count_col_name'],
                input_args['targeting_type_col_name'],
                input_args['search_volume_col_name'],
                input_args['bucket_size'],
                input_args['include_floor_price']
            )
