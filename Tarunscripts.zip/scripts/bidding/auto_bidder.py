# pylint: disable=all
import random
from util.redis_utils import RedisUtil, RedisKeyGen
from config import Config
from math import ceil

class AutoBidder:
    def __init__(self):
        self.redis_util = RedisUtil(
            Config.AzureConfig.REDIS_HOST_NAME,
            Config.AzureConfig.REDIS_PASSWORD
        )
        self._EXPLOIT_FACTOR = 0.8

    def compute_bid(self, retailer, acos, sku_info_list):
        factor = 0.0
        total_value = 0.0
        acos = acos/100.0

        for sku_info in sku_info_list:
            factor += sku_info["ctr"]
            aov = retailer.get_product_by_sku(sku_info["sku"]).get_price()
            total_value += sku_info["pc_cvr"] * aov * acos * sku_info["ctr"]

        return round(total_value/factor, 2)

    def compute_campaign_ctr(self, sku_info_list):
        probabilities = []

        for sku_info in sku_info_list:
            probabilities.append(sku_info["ctr"])

        prob_union = self._prob_union(probabilities)

        return prob_union

    def compute_ecpm(self, campaign_ctr, bid):
        return round(bid*campaign_ctr*1000, 2)

    def _prob_union(self, probabilities):
        if len(probabilities) == 0:
            return 0

        prob_union = 0
        for i in range(0, len(probabilities)):
            prob_union += probabilities[i]
            for j in range(i + 1, len(probabilities)):
                prob_union -= probabilities[i] * probabilities[j]

        return prob_union

    def get_winner_info(self, retailer, target_type, target_value_list, placement_id_list):
        target_value = str("_".join(sorted(target_value_list)))
        key_set = set()
        for placement_id in placement_id_list:
            key = RedisKeyGen.get_winner_ecpm_key(
                retailer.retailer_id, target_type, target_value, placement_id
            )
            key_set.add(key)
        key_val = self.redis_util.multi_get(list(key_set))
        winners = dict()
        for placement_id in placement_id_list:
            floor_price = retailer.get_floor_price(placement_id, target_value_list[0])
            winners[placement_id] = key_val[key]

            if key_val[key] is None:
                winners[placement_id] = {
                    "ecpm": floor_price,
                    "campaign_id": None,
                    "floor_price": floor_price
                }
            else:
                winners[placement_id] = {
                    "ecpm": key_val[key]["ecpm"],
                    "campaign_id": key_val[key]["campaign_id"],
                    "floor_price": floor_price
                }
                
        return winners

    def apply_adaptive_bidder(self, campaign_list, winner, floor_price):
        campaign_list = sorted(campaign_list, key=lambda x: x["ecpm"])

        prev_ecpm = 0.0
        winner_ecpm = max(winner["ecpm"], floor_price)
        winner_campaign_id = winner.get("campaign_id")
        for campaign in campaign_list:
            if winner_campaign_id is None or winner_ecpm > campaign["ecpm"]:
                adapted_bid = campaign["ecpm"]
            elif winner_campaign_id == campaign.get("campaign_id"):
                rand = random.random()
                if rand < self._EXPLOIT_FACTOR:
                    adapted_bid = max(winner_ecpm, prev_ecpm+0.01)
                else:
                    adapted_bid = max(winner_ecpm * 0.9, floor_price, prev_ecpm+0.01)
            else:
                adapted_bid = max(winner_ecpm+0.01, prev_ecpm+0.01)

            prev_ecpm = campaign["ecpm"]
            adapted_bid = min(campaign["ecpm"], adapted_bid)
            campaign["ecpm"] = adapted_bid
            campaign["bid"] = self._compute_bid_from_ecpm(campaign["ecpm"], campaign["ctr"])
            if campaign["bid"] < 0.01:
                campaign["bid"] = 0.01

        campaign_list = sorted(campaign_list, key=lambda x: x["ecpm"], reverse=True)
        return campaign_list

    @staticmethod
    def _compute_bid_from_ecpm(ecpm, ctr):
        cpc = ecpm/ctr/1000
        return ceil(cpc*100)/100.0