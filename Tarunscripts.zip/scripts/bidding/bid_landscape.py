from util.keyword_targetting_utils import KeywordHash
import pandas as pd

class BidLandScape:
    __CUM_SUM_IMP = 'cumulative_sum_impressions'
    __IMPRESSION_COUNT_SUM = 'impression_count_sum'
    __PERCENT_IMP = 'per_imp_left_exclusive_of_current_row'
    __MIN = 'min'
    __MAX = 'max'
    __MIN_ECPM = 'min_ecpm'
    __MAX_ECPM = 'max_ecpm'
    __IMPRESSION_SHARE = 'impression_share'
    __BUCKET = 'impression_bucket'
    __IMPRESSION_DIFF = 'impression_diff'
    __FLOOR_PRICE = 'floor_price'
    __RENAMED_SEARCH_VOLUME = 'renamed_search_volume'

    def get_bid_landscape(
            self,
            winner_ecpm_df,
            target_value_col_name,
            winning_ecpm_col_name,
            impression_count_col_name,
            targeting_type_col_name,
            impression_coverage_threshold=0.95
    ):
        """
        Calculates bid landscape range based on winning ecpm and
        impression count. Trims max ecpms that dont have significant search
        volume based on impression_coverage_threshold parameter
            winner_ecpm_df : winner_ecpm df
        target_value_col_name :
            Represents column name containing keywords/categories/product
        winning_ecpm_col_name :
            Represents column name for winning ecpm values
        impression_count_col_name :
            Represents column name for impression values
        targeting_type_col_name:
            Represents col name of targeting_type
            containing KEYWORD/PRODUCT/CATEGORY
        impression_coverage_threshold:
            Ignores impression volume that above this threshold and having high
            ecpms
        """

        winner_ecpm_df = winner_ecpm_df.groupby(
            by=[targeting_type_col_name,
                target_value_col_name,
                winning_ecpm_col_name,
                ],
            as_index=False
        )[impression_count_col_name].sum()

        winner_ecpm_df.sort_values(
            by=[targeting_type_col_name,
                target_value_col_name,
                winning_ecpm_col_name
                ], inplace=True
        )

        # getting cumulative sum to later on filter all the impressions
        # that contribute to threshold percentage
        winner_ecpm_df[self.__CUM_SUM_IMP] = winner_ecpm_df.groupby(
            by=[targeting_type_col_name,
                target_value_col_name
                ])[impression_count_col_name].cumsum()

        winner_ecpm_df_total_count = winner_ecpm_df.groupby(
            by=[targeting_type_col_name,
                target_value_col_name], as_index=False)[
            impression_count_col_name].sum()

        winner_ecpm_df_total_count.rename(
            columns={
                impression_count_col_name: self.__IMPRESSION_COUNT_SUM
            }, inplace=True
        )

        winner_ecpm_df = winner_ecpm_df.merge(winner_ecpm_df_total_count)

        # get percent of impressions left to be covered by the current ecpm
        winner_ecpm_df[self.__PERCENT_IMP] = 1 - (
            ((winner_ecpm_df[
                  self.__CUM_SUM_IMP] - winner_ecpm_df[
                  impression_count_col_name]) / winner_ecpm_df[
                 self.__IMPRESSION_COUNT_SUM])
        )
        # filter left over impressions with high ecpm and
        # above the impressions coverage threshlod
        winner_ecpm_df = winner_ecpm_df[
            winner_ecpm_df[
                self.__PERCENT_IMP
            ] >= (1 - impression_coverage_threshold)]

        winner_ecpm_df = winner_ecpm_df.groupby(
            by=[targeting_type_col_name,
                target_value_col_name], as_index=False).agg(
            {winning_ecpm_col_name: [self.__MIN, self.__MAX]})

        winner_ecpm_df.columns = [
            targeting_type_col_name,
            target_value_col_name,
            self.__MIN_ECPM,
            self.__MAX_ECPM,
        ]

        return winner_ecpm_df

    def get_bid_landscape_distribution(
            self,
            winner_ecpm_df,
            search_volume_df,
            target_value_col_name,
            winning_ecpm_col_name,
            impression_count_col_name,
            targeting_type_col_name,
            search_volume_col_name,
            min_floor_prices,
            bucket_size=5,
            keyword_target_type='KEYWORD',
            hash_keywords=True,
            include_floor_price=False
    ):
        """
        Computes bid landscape dist based on winning ecpm and
        impression count. Based on bucket size provided,
        we take the max possible impression share in that bucket
        winner_ecpm_df : winner_ecpm df
        target_value_col_name :
            Represents column name containing keywords/categories/product
        winning_ecpm_col_name :
            Represents column name for winning ecpm values
        impression_count_col_name :
            Represents column name for impression values
        targeting_type_col_name:
            Represents col name of targeting_type
            containing KEYWORD/PRODUCT/CATEGORY
        min_floor_prices:
            minnimum floor price per targeting type.DICT
        bucket_size:
            buckets into which impression share needs to be bucketed. Defaults to 5
            Example: Consider we took buket size to be 5 then, possible buckets-[5,10,15...100]
            [
            {'cumulative_impressions':1000,'ecpm':1.5,'impression_share_at_ecpm':3.4},
            {'cumulative_impressions':1700,'ecpm':1.8,'impression_share_at_ecpm':4.3},
            {'cumulative_impressions':2900,'ecpm':2.4,'impression_share_at_ecpm':5.03},
            {'cumulative_impressions':4500,'ecpm':3.6,'impression_share_at_ecpm':7.6},
            {'cumulative_impressions':6000,'ecpm':4.2,'impression_share_at_ecpm':8.4}
            ]
            4.3 is the max impression share in the bucket 5 we consider index-1 in list above for 5
            And 8.4 is max impression share in the bucket 10 we consider index-4 in the list above for 10
        """

        if len(winner_ecpm_df) == 0 or len(search_volume_df) == 0:
            return pd.DataFrame()

        # renaming to avoid any conflict with winnerecpm search volume col if they are same during merges
        search_volume_df.rename(
            columns={search_volume_col_name: self.__RENAMED_SEARCH_VOLUME}, inplace=True
        )
        search_volume_col_name = self.__RENAMED_SEARCH_VOLUME

        keyword_hash = KeywordHash()

        winner_ecpm_df[
            winning_ecpm_col_name] = winner_ecpm_df[winning_ecpm_col_name].apply(
            lambda x: round(x, 2)
        )

        if hash_keywords:
            winner_ecpm_df[target_value_col_name] = winner_ecpm_df.apply(
                lambda x: keyword_hash.get_keyword_hash(
                    x[target_value_col_name]) if x[targeting_type_col_name].lower() == keyword_target_type.lower() else
                x[
                    target_value_col_name
                ],
                axis=1
            )

            # hash keywords in search volume dfs to merge with winner ecpm later
            search_volume_df[target_value_col_name] = search_volume_df.apply(
                lambda x: keyword_hash.get_keyword_hash(
                    x[target_value_col_name]) if x[targeting_type_col_name].lower() == keyword_target_type.lower() else
                x[
                    target_value_col_name
                ],
                axis=1
            )

        search_volume_df = search_volume_df.groupby(
            by=[targeting_type_col_name,
                target_value_col_name
                ],
            as_index=False
        )[search_volume_col_name].sum()

        # removing rows below the floor price, retaining this step irrespective of floor price inclusion
        # since those with less than floor price in suggestion might not even be shown in ads

        winner_ecpm_df[self.__FLOOR_PRICE] = winner_ecpm_df.apply(
            lambda x: min_floor_prices.get(
                x[targeting_type_col_name].lower(),
                0.0
            ),
            axis=1
        )

        winner_ecpm_df = winner_ecpm_df[
            winner_ecpm_df[winning_ecpm_col_name] > winner_ecpm_df[self.__FLOOR_PRICE]
            ]

        winner_ecpm_df = winner_ecpm_df.groupby(
            by=[targeting_type_col_name,
                target_value_col_name,
                winning_ecpm_col_name,
                ],
            as_index=False
        )[impression_count_col_name].sum()

        if include_floor_price:
            # finding targets in organic search with no ad impressions
            winner_ecpm_present = winner_ecpm_df[[targeting_type_col_name, target_value_col_name]]
            winner_ecpm_present.drop_duplicates(inplace=True)
            winner_ecpm_present['to_keep'] = 0
            targets_with_no_ad_impresions = search_volume_df.merge(winner_ecpm_present, how='left')
            # dropping na now so that we are left with only those with no ad impressions
            targets_with_no_ad_impresions.fillna(1, inplace=True)
            targets_with_no_ad_impresions = targets_with_no_ad_impresions[
                targets_with_no_ad_impresions['to_keep'] == 1
                ]
            targets_with_no_ad_impresions = targets_with_no_ad_impresions[[
                targeting_type_col_name,
                target_value_col_name,
                search_volume_col_name
            ]]

            targets_with_no_ad_impresions[
                winning_ecpm_col_name] = targets_with_no_ad_impresions[targeting_type_col_name].apply(
                lambda x: min_floor_prices.get(x.lower(), 0.0)
            )
            targets_with_no_ad_impresions.rename(columns={search_volume_col_name: self.__CUM_SUM_IMP}, inplace=True)

        winner_ecpm_df_total_count = winner_ecpm_df.groupby(
            by=[targeting_type_col_name,
                target_value_col_name], as_index=False)[
            impression_count_col_name].sum()

        winner_ecpm_df_total_count.rename(
            columns={
                impression_count_col_name: self.__IMPRESSION_COUNT_SUM
            }, inplace=True
        )

        winner_ecpm_df_total_count = winner_ecpm_df_total_count.merge(
            search_volume_df, how='left', on=[targeting_type_col_name, target_value_col_name]
        )

        # dropping rows which are not present in search volume df
        winner_ecpm_df_total_count.dropna(axis=0, inplace=True)

        winner_ecpm_df_total_count[
            self.__IMPRESSION_DIFF
        ] = winner_ecpm_df_total_count[search_volume_col_name] - winner_ecpm_df_total_count[self.__IMPRESSION_COUNT_SUM]

        winner_ecpm_df_total_count[self.__IMPRESSION_COUNT_SUM] = winner_ecpm_df_total_count.apply(
            lambda x: max(x[self.__IMPRESSION_COUNT_SUM], x[search_volume_col_name]), axis=1
        )

        floor_price_insertions = winner_ecpm_df_total_count[
            winner_ecpm_df_total_count[self.__IMPRESSION_DIFF] > 0
            ]

        floor_price_insertions = floor_price_insertions[[
            targeting_type_col_name,
            target_value_col_name,
            self.__IMPRESSION_DIFF
        ]
        ]

        floor_price_insertions.rename(
            columns={self.__IMPRESSION_DIFF: impression_count_col_name}, inplace=True
        )

        if include_floor_price:
            floor_price_insertions[winning_ecpm_col_name] = floor_price_insertions[targeting_type_col_name].apply(
                lambda x: min_floor_prices.get(x.lower(), 0.0)
            )
        else:
            # Replace the diff impressions by min bid in cases where we don't want floor price
            winner_ecpm_df_min_bid = winner_ecpm_df.groupby(
                by=[targeting_type_col_name,
                    target_value_col_name,
                    ],
                as_index=False
            )[winning_ecpm_col_name].min()

            floor_price_insertions = floor_price_insertions.merge(winner_ecpm_df_min_bid, how='left')

        winner_ecpm_df = pd.concat([winner_ecpm_df, floor_price_insertions])

        winner_ecpm_df = winner_ecpm_df.groupby(
            by=[targeting_type_col_name,
                target_value_col_name,
                winning_ecpm_col_name,
                ],
            as_index=False
        )[impression_count_col_name].sum()

        winner_ecpm_df_total_count = winner_ecpm_df_total_count[
            [targeting_type_col_name,
             target_value_col_name,
             self.__IMPRESSION_COUNT_SUM
             ]
        ]
        winner_ecpm_df = winner_ecpm_df.merge(winner_ecpm_df_total_count)

        winner_ecpm_df.sort_values(
            by=[targeting_type_col_name,
                target_value_col_name,
                winning_ecpm_col_name
                ], inplace=True
        )

        # getting cumulative sum
        winner_ecpm_df[self.__CUM_SUM_IMP] = winner_ecpm_df.groupby(
            by=[targeting_type_col_name,
                target_value_col_name
                ])[impression_count_col_name].cumsum()

        # Compute cumulative share till now for the given ecpm
        winner_ecpm_df[self.__IMPRESSION_SHARE] = round((winner_ecpm_df[
                                                             self.__CUM_SUM_IMP] / winner_ecpm_df[
                                                             self.__IMPRESSION_COUNT_SUM
                                                         ]) * 100, 2)

        # Compute the bucket into which impression share falls into
        winner_ecpm_df[self.__BUCKET] = winner_ecpm_df[
            self.__IMPRESSION_SHARE].apply(
            lambda x: bucket_size * (x // bucket_size) if x % bucket_size == 0 else bucket_size * (
                    (x // bucket_size) + 1)
        )

        winner_ecpm_df[self.__FLOOR_PRICE] = winner_ecpm_df[targeting_type_col_name].apply(
            lambda x: min_floor_prices.get(
                x.lower(),
                0.0
            )
        )

        floor_price_insertions = winner_ecpm_df[
            winner_ecpm_df[winning_ecpm_col_name] <= winner_ecpm_df[self.__FLOOR_PRICE]
            ]

        winner_ecpm_df.drop(
            self.__FLOOR_PRICE,
            axis=1,
            inplace=True
        )

        floor_price_insertions.drop(
            self.__FLOOR_PRICE,
            axis=1,
            inplace=True
        )

        # keep only the max share possible inside the bucket size defined
        winner_ecpm_df.drop_duplicates(
            [targeting_type_col_name, target_value_col_name, self.__BUCKET], keep='last', inplace=True
        )

        # concatenating to keep floor price in the distribution irrepective of bucket
        winner_ecpm_df = pd.concat([winner_ecpm_df, floor_price_insertions])

        winner_ecpm_df.drop_duplicates(inplace=True)

        # returning winning_ecpm & cumulative impressions
        winner_ecpm_df = winner_ecpm_df[
            [targeting_type_col_name, target_value_col_name, winning_ecpm_col_name, self.__CUM_SUM_IMP]]

        if include_floor_price:
            targets_with_no_ad_impresions = targets_with_no_ad_impresions[
                [targeting_type_col_name, target_value_col_name, winning_ecpm_col_name, self.__CUM_SUM_IMP]
            ]

            winner_ecpm_df = pd.concat([winner_ecpm_df, targets_with_no_ad_impresions])

        winner_ecpm_df.sort_values(
            by=[targeting_type_col_name,
                target_value_col_name,
                winning_ecpm_col_name
                ], inplace=True
        )

        return winner_ecpm_df
