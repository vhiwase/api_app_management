import math
import scipy.stats as st
from config import Config
from util.read_write_data_azure_blob import ReadAndWriteFromAzureBlob
from relevance.relevance_engine import RelevanceEngine
import pandas as pd

class BidIntelligence:
    __RELEVANCE_RANGE = 0.1
    __RELEVANCE_MEAN = 0.6
    __CONF_INTERVAL = 0.95
    __DEFAULT_DEVIATION_LB = 0.5
    __DEFAULT_DEVIATION_UB = 1.2
    __TOP_K_RELEVANCE = 10
    __SKU = 'sku'
    __SKU_ID = 'sku_id'
    __KEYWORD = 'keyword'
    __CPM = 'cpm'
    __CPC = 'cpc'
    __CTR = 'ctr'
    __PC_CVR = 'pc_cvr'
    __AOV = 'aov'
    __REL_SCORE = 'relevance_score'
    __EXECPTION_CTR = 'CTR CANT BE NONE FOR CPM TYPE CAMPAIGN'
    __CONSERVATIVE_BID = False
    __IMPRESSION_THRESHOLD = 100
    __DEFAULT_ROAS = 10.0
    __DEFAULT_PC_CVR = 0.02  # 2%
    __DEFAULT_CTR = 0.01  # 1%

    def __init__(self):
        self.relevance_engine = RelevanceEngine()
        self.read_write_from_blob = ReadAndWriteFromAzureBlob()

    def get_upper_and_lower_bounds(self, mean_metric, impressions, confidence_interval):
        """Using impressions as base for pccvr confidence interval
        """
        if impressions > self.__IMPRESSION_THRESHOLD:
            # compute z value & multiply it with standard error in estimate to get deviation & thus get bounds
            z_value = st.norm.ppf(1 - (1 - confidence_interval) / 2.)
            deviation = z_value * math.sqrt((mean_metric * (1 - mean_metric)) / impressions)
        else:
            return mean_metric * self.__DEFAULT_DEVIATION_LB, mean_metric * self.__DEFAULT_DEVIATION_UB

        if self.__CONSERVATIVE_BID:
            return mean_metric - deviation, mean_metric

        return mean_metric - deviation, mean_metric + deviation

    def get_bid_suggestion(
            self, retailer, sku, relevance_score, roas,
            pc_cvr, ctr, aov=None, prior_at_sku_level=True, impressions=0
    ):
        """
        Descrpition: Calculates final bid value using
        """

        if roas is None:
            roas = self.__DEFAULT_ROAS
        if pc_cvr is None:
            pc_cvr = self.__DEFAULT_PC_CVR
        if ctr is None:
            ctr = self.__DEFAULT_CTR
        if aov is None:
            aov = float(retailer.get_product_by_sku(sku).get_price())

        acos = 1/roas
        # get relevance score of sku relative to the top k products
        # relevance_score = self.relevance_engine.get_products_by_query_bid_intelligence(
        #     retailer, keyword, self.__TOP_K_RELEVANCE, sku
        # )
        #
        # relevance_score = relevance_score[relevance_score[self.__SKU] == sku][self.__REL_SCORE].values[0]

        # scaled score
        scaled_score = (relevance_score - self.__RELEVANCE_MEAN) / self.__RELEVANCE_RANGE
        calibrated_score = 1 / (1 + math.exp(-scaled_score))

        # get pccvr bounds
        pc_cvr_lb, pc_cvr_ub = self.get_upper_and_lower_bounds(pc_cvr, impressions, self.__CONF_INTERVAL)
        pc_cv_lb_ub_diff = pc_cvr_ub - pc_cvr_lb

        # compute bid in cpc scenario - final cvr = pccvr_lb + (relevance_score*((pccvr_lb-pccvr_ub))))
        value_per_click = aov * (pc_cvr_lb + (calibrated_score * pc_cv_lb_ub_diff))

        final_bid_value = value_per_click * acos

        cpc = round(final_bid_value, 2)
        if prior_at_sku_level:
            # get ctr bounds
            ctr_lb, ctr_ub = self.get_upper_and_lower_bounds(ctr, impressions, self.__CONF_INTERVAL)
            ctr_range = ctr_ub - ctr_lb
            calibrated_ctr = (ctr_lb + (calibrated_score * ctr_range))
            cpm = round(final_bid_value * calibrated_ctr * 1000, 2)
        else:
            cpm = round(final_bid_value * ctr * 1000, 2)

        return cpc, cpm

    def __filter_prior_from_df(self, prior_df):
        aov = prior_df[self.__PC_CVR].values[0]
        pc_cvr = prior_df[self.__AOV].values[0]
        ctr = prior_df[self.__CTR].values[0]
        return aov, pc_cvr, ctr

    def get_bid_suggestion_from_proir_in_blob(
            self, retailer_id, retailer, sku_keywords, acos, campaign_type, prior_at_sku_level=True
    ):
        """
        Descrpition: Calculates final bid value using prior pccvr & aov values.
        We expect sku_keywords as [{'sku_id':'sku1','keywords':['k1','k2','k3']},
        {'sku_id':'sku2','keywords':['k1','k2','k3']}]
        Returns: Float
        """
        prior_cvr_aov_df = self.read_write_from_blob.read_data_by_stream(
            Config.AzureConfig.ICC_DS_STORAGE_CONNECTION_STRING,
            Config.AzureConfig.BID_INTEL_PRIOR_CONTAINER,
            Config.AzureConfig.PRIOR_INFO_BY_RETAILER.format(retailer_id=retailer_id)
        )

        final_recommended_bids = []
        for sku in sku_keywords:
            if prior_at_sku_level:
                prior_cvr_aov_df_sku = prior_cvr_aov_df[prior_cvr_aov_df[self.__SKU_ID] == sku]
                aov, pc_cvr, ctr = self.__filter_prior_from_df(prior_cvr_aov_df_sku)

            for keyword in sku_keywords[self.__SKU_ID]:
                if not prior_at_sku_level:
                    prior_cvr_aov_df_sku_kwd = prior_cvr_aov_df[
                        (prior_cvr_aov_df[self.__SKU_ID] == sku) &
                        (prior_cvr_aov_df[self.__KEYWORD] == keyword)
                        ]
                    aov, pc_cvr, ctr = self.__filter_prior_from_df(prior_cvr_aov_df_sku_kwd)

                final_recommended_bids.append(
                    self.get_bid_suggestion(
                        retailer,
                        sku,
                        keyword,
                        acos,
                        aov,
                        pc_cvr,
                        campaign_type,
                        prior_at_sku_level,
                        ctr
                    )
                )

        return pd.DataFrame(final_recommended_bids)
