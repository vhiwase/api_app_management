# pylint: disable=all
from datetime import date


class Store_In_Redis:
    def get_count_for_key(client, key):
        if key in client:
            return int(client[key])
        else:
            return 0

    def send_data_to_cache(client, retailer, product_name):
        compound_key = retailer+'_'+product_name+'_'+str(date.today())
        try:
            if compound_key in client:
                client[compound_key] = Store_In_Redis.get_count_for_key(client, compound_key) + 1
                return True
            else:
                client.mset({compound_key:1})
                return True
        except Exception as e:
            return False
