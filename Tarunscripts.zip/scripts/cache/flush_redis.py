# pylint: disable=all
import schedule
import time
from context.context import Context


class Dump_Cache_In_DB:
    
    def __init__(self, client):
        print("started")
        schedule.every(1).minutes.do(self.flush_cache, client=client)
        while 1:
            schedule.run_pending()
            time.sleep(1)

    def flush_cache(self, client):
        print("Run Completed")
        return "Cache Flushed to DB"    

Dump_Cache_In_DB(Context.azure_redis_client)
