# pylint: disable=all
import numpy as np

class CategoryRelevance:
    __BRODCATG_COL = 'Broad_Category'
    __CATGEORY_SCORE = 'category_score'
    __CATEGORY_PERCENT = 'category_percent'
    def category_wise_scoring_v0(self, retailer, output, query_embedding):
        """
        Description: Calculate highest recommended category penalized by its total occurence in the DB.
        Returns: Dataframe object
        """
        cat_importance_dict = {}
        output_cat_count = output['Broad_Category'].value_counts()  # Count of recommended categories
        for i, val in output_cat_count.iteritems():
            cat_importance_dict[i] = (val / retailer.category_count[i]) * 100  # Penalize
        output['category_percent'] = 0  # Initialize a DF column
        for i, val in output.iterrows():
            output.loc[i, 'category_percent'] = cat_importance_dict[output.loc[i, 'Broad_Category']]  # Update the DB
        return output

    def get_catg_score_for_query(self, retailer, result_df, query_embedding):
        """
        Description: Calculate highest recommended category by taking the dot product with average broad
        catg_representations with query embeddings. We assume normalized query and broad category embeddings
        Returns: Dataframe object
        """
        broad_categories_embeding_df = result_df[[self.__BRODCATG_COL]].drop_duplicates()
        broad_categories_embeding_df[self.__CATGEORY_SCORE] = broad_categories_embeding_df.apply(
            lambda x: np.dot(
                retailer.get_category_embedding(x[self.__BRODCATG_COL]), query_embedding.T
            )[0][0]
            , axis=1
        )
        broad_categories_embeding_df = broad_categories_embeding_df[
            [self.__BRODCATG_COL, self.__CATGEORY_SCORE]
        ]

        result_df = result_df.merge(
            broad_categories_embeding_df, on=[self.__BRODCATG_COL], how='left'
        )

        return result_df

    def get_catg_score_for_prod(self, result_df, target_product):
        result_df[self.__CATGEORY_SCORE] = result_df.apply(
            lambda x: self.__gen_catg_score(x["category"], x["productType"], target_product),
            axis=1
        )
        return result_df

    def __gen_catg_score(self, category, product_type, product):
        score = 0
        if category == product.get_category():
            score += 0.5
        if product_type == product.get_product_type():
            score += 0.5
        return score
