# pylint: disable=all
from context.context import Context
import yake
import pandas as pd
import numpy as np
import nltk
import pickle
from nltk.stem import PorterStemmer, WordNetLemmatizer
import re
from scipy import spatial
from relevance.relevance_engine import RelevanceEngine
from nltk.corpus import stopwords
import os
import itertools
from util.keyword_targetting_utils import KeywordHash
from config import Config, LocalConfig
import time
from datetime import datetime, timedelta
from azure.storage.blob import BlobServiceClient
from util.mongo_util import MongoUtil
from sentence_transformers import SentenceTransformer
from numpy import dot
from util.read_write_data_azure_blob import ReadAndWriteFromAzureBlob
import torch
import faiss
import networkx as nx

if not os.path.exists('./nltk_data'):
    os.mkdir("./nltk_data")
nltk.download('stopwords', "./nltk_data/")
nltk.data.path.append("./nltk_data/")


class KeywordTargeting:

    def __init__(self):
        self.yake_model = self.yake_model_initialize()
        self.relevance_engine = RelevanceEngine()
        self.porter = PorterStemmer()
        self.wordnet_lemmatizer = WordNetLemmatizer()
        self.stopwords_set = stopwords.words('english')
        self.KH = KeywordHash()
        self.read_write_blob = ReadAndWriteFromAzureBlob()

    def get_similar_products(self, retailer, sku, n):
        return self.relevance_engine.get_products_by_product(retailer, sku)

    def get_keywords_data(self, retailer, sku):
        try:
            product_data = retailer.data.loc[
                retailer.data['sku'] == sku, ['brand', 'category', 'productType', 'name', 'description']]
            if product_data.shape[0] == 0:
                raise Exception()

        except:
            properties = {'sku_id': sku}
            Context.logger_client.track_trace("EK101: ERROR IN RETRIEVING DATA GIVEN SKU ID", properties)
            return None

        product_data['relevance_score'] = 1

        #         sim_products_data = self.get_similar_products(retailer, sku, n)
        #         sim_products_data1 = sim_products_data[['brand', 'category',
        #         'productType', 'name','description', 'relevance_score']]

        final_data = product_data
        #        final_data = product_data.append(sim_products_data1,ignore_index=True).drop_duplicates()
        final_data['brand_category'] = final_data['brand'] + ' ' + final_data['category']
        final_data['brand_productType'] = final_data['brand'] + ' ' + final_data['productType']
        final_data['category_productType'] = final_data['category'] + ' ' + final_data['productType']

        final_data['yake_keywords_name'] = final_data['name'].apply(self.yake_model.extract_keywords)
        final_data['yake_keywords_description'] = final_data['description'].apply(self.yake_model.extract_keywords)
        return final_data

    @staticmethod
    def yake_model_initialize():
        language = "en"
        max_ngram_size = 3
        deduplication_threshold = 0.9
        numofkeywords = 5
        custom_kw_extractor = yake.KeywordExtractor(lan=language, n=max_ngram_size, dedupLim=deduplication_threshold,
                                                    top=numofkeywords, features=None)
        return custom_kw_extractor

    def get_complementary_keywords(self, retailer, sku, keywords_list):
        full_keywords_list = self.get_keywords_with_relevance(retailer, sku)
        return full_keywords_list[~full_keywords_list['keyword'].isin(keywords_list)]

    def get_keyword_combinations(self, retailer, sku, sku_description_hash=None):
        final_keywords_list = []
        final_keywords_list1 = []
        brand = retailer.get_product_by_sku(sku).get_brand()
        product_type = retailer.get_product_by_sku(sku).get_product_type()

        """Splitting the keywords to increase keywords list """
        brand_list = re.split('; |& |, |\*|\n', brand)
        product_type_list = re.split('; |& |, |\*|\n', product_type)
        yake_keywords_name = self.yake_model.extract_keywords(retailer.get_product_by_sku(sku).get_name())
        yake_keywords_description = self.yake_model.extract_keywords(sku_description_hash[sku])
        yake_keywords_name_list = [i[0] for i in yake_keywords_name]
        yake_keywords_description_list = [i[0] for i in yake_keywords_description]
        yake_keywords_list = yake_keywords_name_list + yake_keywords_description_list
        for yake_keyword in yake_keywords_list:
            t = [brand_list, product_type_list, [yake_keyword]]
            combination = [item for sublist in t for item in sublist]
            combinations_list = []
            for L in range(0, len(combination) + 1):
                for subset in itertools.permutations(combination, L):
                    combinations_list.append(list(subset))
            combinations_list_final = [' '.join(words) for words in combinations_list]
            final_keywords_list.extend(combinations_list_final)
            for final_keyword in final_keywords_list:
                final_keyword = self.preprocess_text(final_keyword)
                words = final_keyword.split()
                if len(words) <= 4:
                    final_keywords_list1.append(final_keyword)
                else:
                    final_keywords_list1.extend(self.return_left_right(final_keyword))
            final_keywords_list1 = list(set(final_keywords_list1))
            final_keywords_list1.sort(key=len)
            final_keywords_list1.remove('')
        return final_keywords_list1


    def preprocess_text(self, string):
        stem_tokens_list = []
        regex = re.compile('[^A-Za-z0-9]+')
        string = regex.sub(r' ',string)
        string = string.strip()
        text_tokens = string.split()
        tokens_without_sw = [word for word in text_tokens if not word in self.stopwords_set]
        for word in tokens_without_sw:
            stem_token = self.porter.stem(word)
            stem_tokens_list.append(stem_token)
        indexes = np.sort([stem_tokens_list.index(x) for x in set(stem_tokens_list)])
        preprocessed_string = " ".join(([tokens_without_sw[index] for index in indexes]))
        return preprocessed_string

    @staticmethod
    def get_string_permutations(string):
        combinations_list = []
        tokens_list = [string.split()]
        combination = [item for sublist in tokens_list for item in sublist]
        for L in range(0, len(combination) + 1):
            for subset in itertools.permutations(combination, L):
                combinations_list.append(list(subset))
        combinations_string = [' '.join(words) for words in combinations_list]
        combinations_string.remove('')
        return (combinations_string)

    def get_hash_to_mined_keywords_dict(self, keywords_list):
        mined_keywords_dict = {}
        for keyword in keywords_list:
            preprocessed_string = self.preprocess_text(keyword)
            string_permutations = self.get_string_permutations(preprocessed_string)
            mined_keywords_dict[self.KH.get_keyword_hash(keyword)] = string_permutations
        return (mined_keywords_dict)

    @staticmethod
    def return_left_right(string):
        left = ' '.join(string.split()[:3])
        right = ' '.join(string.split()[-3:])
        return [left, right]

    def get_embeddings_list(self, keywords_list):
        keyword_embeddings_list = []
        for keyword in keywords_list:
            keyword_embedding = self.relevance_engine.get_query_embedding(keyword)[0]
            keyword_embeddings_list.append(keyword_embedding)
        return keyword_embeddings_list

    def keyword_ranker(self, retailer, keywords_list, sku, keyword_embeddings=None):
        try:
            data = self.get_keywords_data(retailer, sku)
            brand_list = re.split(r'\W+', data['brand'].values[0])
            product_type_list = re.split(r'\W+', data['productType'].values[0])
            product_embedding = retailer.get_product_by_sku(sku).get_embeding()
        except:
            properties = {'sku_id': sku}
            Context.logger_client.track_trace("EK102: ERROR IN RETRIEVING PRODUCT EMBEDDING GIVEN SKU ID",
                                              properties)
            return pd.DataFrame([['None', 0.0]], columns=['keyword', 'similarity_score'])
        cosine_similarity_list = []

        if keyword_embeddings is None:
            keyword_embeddings = self.get_embeddings_list(keywords_list)

        for i in range(len(keyword_embeddings)):
            keyword_embedding = keyword_embeddings[i]
            try:
                embedding_similarity = 1 - spatial.distance.cosine(keyword_embedding, product_embedding)
            except:
                embedding_similarity = 0
            cosine_similarity_list.append(embedding_similarity)
        similarity_frame = pd.DataFrame(data={'keyword': keywords_list,
                                              'similarity_score': cosine_similarity_list})

        similarity_frame["key"] = similarity_frame["keyword"].apply(self.KH.get_keyword_hash)
        avg_score_df = similarity_frame.groupby('key')[['similarity_score']].mean()
        similarity_frame.drop('similarity_score', inplace=True, axis=1)
        similarity_frame = similarity_frame.join(avg_score_df, on=['key'])
        similarity_frame.drop('key', inplace=True, axis=1)

        similarity_frame['brand_ratio'] = similarity_frame['keyword'].apply(self.string_matcher, args=([brand_list]))
        similarity_frame['productType_ratio'] = similarity_frame['keyword'].apply(self.string_matcher,
                                                                                  args=([product_type_list]))
        similarity_frame['similarity_score'] = (0.5 * similarity_frame['similarity_score']) + \
                                               (0.3 * similarity_frame['brand_ratio']) + (
                                                       0.2 * similarity_frame['productType_ratio'])
        similarity_frame.drop(['brand_ratio', 'productType_ratio'], axis=1, inplace=True)
        similarity_frame.sort_values(by='similarity_score', ascending=False, inplace=True)
        return similarity_frame

    def get_keywords_with_relevance(self, retailer, sku):
        keyword_list = self.get_keyword_combinations(retailer, sku)
        if not keyword_list:
            return pd.DataFrame()
        ranked_keywords = self.keyword_ranker(retailer, keyword_list, sku)
        ranked_keywords = ranked_keywords[ranked_keywords['similarity_score'] > 0.3]
        return ranked_keywords

    @staticmethod
    def string_matcher(string, keywords_list):
        keyword_set = set(' '.join(keywords_list).lower().split(' '))
        string_set = set(string.lower().split(' '))
        ratio = len(list(keyword_set & string_set)) / len(list(keyword_set))
        return ratio

    def get_data_from_blob(self, blob_name):
        if not os.path.exists(LocalConfig.DATA_FOLDER_PATH):
            os.makedirs(LocalConfig.DATA_FOLDER_PATH)
        Context.download_blob(blob_name, LocalConfig.DATA_FOLDER_PATH)
        with open(LocalConfig.DATA_FOLDER_PATH + blob_name, 'rb') as data:
            blob = pickle.load(data)
            return blob

    def push_data_to_blob(self, file, file_name):
        blob_service_client = BlobServiceClient.from_connection_string(
            Config.AzureConfig.ICC_DS_STORAGE_CONNECTION_STRING)
        blob_client = blob_service_client.get_blob_client(container=Config.AzureConfig.CONTAINER_NAME,
                                                          blob=file_name)
        with open(LocalConfig.DATA_FOLDER_PATH + file_name, 'wb') as handle:
            pickle.dump(file, handle, protocol=pickle.HIGHEST_PROTOCOL)

        with open(LocalConfig.DATA_FOLDER_PATH + file_name, 'rb') as data:
            blob_client.upload_blob(data, overwrite=True)

    def get_retailer_keywords_dict_v1(self, retailer):
        retailer_id = retailer.meta_data['_id']
        skus = list(retailer.data.sku.unique())
        st = time.time()
        sku_description_hash = retailer.data.set_index('sku')['description'].to_dict()
        print("time taken to calculate desription hash is ", time.time() - st)
        sku_keywords_dict = {}
        i = 0
        temp_file_name = str(retailer_id) + '_yake_keywords_dict_temp.pkl'
        for sku in skus:
            try:
                st = time.time()
                keyword_list = self.get_keyword_combinations(retailer, sku, sku_description_hash)
                print("time taken to get keyword combintions for single sku ", time.time() - st)
                sku_keywords_dict[sku] = keyword_list
            except:
                pass
            i = i + 1
            if (i % 1000 == 0):
                print("No of Skus processed: ", i)
            if (i % 10000 == 0):
                self.push_data_to_blob(sku_keywords_dict, temp_file_name)
        return sku_keywords_dict

    @staticmethod
    def get_nearest_keywords(retailer, faiss_index, keyword_list, sku):
        """ To change to n nearest based on score cutoff"""
        try:
            product_embedding = retailer.get_product_by_sku(sku).get_embeding()
            distance, index = faiss_index.search(product_embedding, k=50)
            nearest_keywords = [keyword_list[i] for i in index[0]]
        except:
            return ['None']
        return nearest_keywords, distance[0]

    def get_hash_keyword_dict(self, keywords_df):
        if type(keywords_df) is list:
            keywords_df = pd.DataFrame({'keywords':keywords_df})
        keywords_list = list(set(keywords_df['keywords']))
        keyword_hash = list(map(self.KH.get_keyword_hash, keywords_list))
        keywords_list = list(map(self.KH.preprocess_text_lite, keywords_list))
        hash_to_keyword_df = pd.DataFrame(list(zip(keyword_hash, keywords_list)),columns =['keyword_hash', 'keyword'])
        if 'Count' not in hash_to_keyword_df.columns:
            hash_to_keyword_df['Count'] = 1
        hash_to_keyword_agg = hash_to_keyword_df.groupby(['keyword_hash','keyword'],
            as_index=False).agg({'Count':sum}).sort_values(by=['keyword_hash','Count'],ascending=False)
        hash_keywords_dict = hash_to_keyword_agg.groupby('keyword_hash')['keyword'].apply(list).to_dict()
        return hash_keywords_dict

    def create_mongo_data(self, dictionary_data, dict_type):
        final_data = []
        for key in list(dictionary_data.keys()):
            mongo_dict = {}
            mongo_dict['_id'] = key
            if dict_type == 'sku_hash':
                mongo_dict['target'] = dictionary_data[key]
            elif dict_type == 'hash_keyword':
                mongo_dict['keywords'] = dictionary_data[key]
            else:
                print("Wrong dictionary type")
            final_data.append(mongo_dict)
        return final_data

    def push_data_to_mongo(self, mongo_data, dict_type, retailer_id):
        if dict_type == 'sku_hash_exact':
            mongo_client = MongoUtil(Config.AzureConfig.COSMOS_URI, Config.AzureConfig.COSMOS_KEYWORD_TARGETING_DB,
                                     str(retailer_id))
        elif dict_type == 'sku_hash_broad':
            mongo_client = MongoUtil(Config.AzureConfig.COSMOS_URI, Config.AzureConfig.COSMOS_BROAD_KEYWORD_TARGETING_DB,
                                     str(retailer_id))
        elif dict_type == 'hash_keyword':
            mongo_client = MongoUtil(Config.AzureConfig.COSMOS_URI, Config.AzureConfig.COSMOS_HASH_TO_KEYWORD_DB,
                                     str(retailer_id))
        else:
            print("Wrong dictionary type")

        try:
            mongo_client.upsert_bulk(mongo_data)
        except:
            print("Cannot push data to mongo")


    @staticmethod
    def add_mapping(existing_map, new_mapping):
        final_map = existing_map.copy()
        for sku in new_mapping:
            new_pairs = new_mapping[sku]
            existing_pairs = existing_map.get(sku,[])
            combined = new_pairs+existing_pairs
            unique_pairs = list({each['hash'] : each for each in combined }.values())
            unique_pairs1 = sorted(unique_pairs, key=lambda d: d['relevance_score'],reverse=True)
            final_map[sku] = unique_pairs1
        return final_map

    def add_boosting(self,retailer_dict,mapping):
        boosted_mapping = {}
        for sku in mapping:
            try:
                brand = retailer_dict[sku]['brand']
                brand_list_hashes = list(map(self.KH.get_keyword_hash, re.split(r'\W+', brand)))
            except:
                brand_list_hashes = ' '
            try:
                product_type = retailer_dict[sku]['productType']
                product_type_list_hashes = list(map(self.KH.get_keyword_hash, re.split(r'\W+', product_type)))
            except:
                product_type_list_hashes = ' '
            try:
                category = retailer_dict[sku]['category']
                category_list_hashes = list(map(self.KH.get_keyword_hash, re.split(r'\W+', category)))
            except:
                category_list_hashes = ' '

            boosted_pairs = []
            for pair in mapping[sku]:
                hash_keyword_list = pair['hash'].split(' ')
                cat_boost = 0.1 * len(list(set(hash_keyword_list).intersection(category_list_hashes))) / len(
                    category_list_hashes)
                brand_boost = 0.2 * len(list(set(hash_keyword_list).intersection(brand_list_hashes))) / len(
                    brand_list_hashes)
                product_type_boost = 0.2 * len(
                    list(set(hash_keyword_list).intersection(product_type_list_hashes))) / len(
                    product_type_list_hashes)
                final_relevance_score = .5 * pair['relevance_score'] + brand_boost + product_type_boost + cat_boost
                boosted_pairs.extend([{'hash': pair['hash'], 'relevance_score': final_relevance_score}])
            boosted_pairs1 = sorted(boosted_pairs, key=lambda d: d['relevance_score'], reverse=True)
            boosted_mapping[sku] = boosted_pairs1
        return boosted_mapping


    def get_sku_keyword_faiss(self, keywords_map):
        sku_to_keyword_faiss = {}
        for keyword in list(keywords_map.keys()):
            hash = self.KH.get_keyword_hash(keyword)
            for sku in keywords_map[keyword].keys():
                try:
                    "To change the score  here"
                    sku_to_keyword_faiss[sku].extend(
                        [{'hash': hash, 'relevance_score': (4 - keywords_map[keyword][sku]) / 4}])
                except:
                    sku_to_keyword_faiss[sku] = [
                        {'hash': hash, 'relevance_score': (4 - keywords_map[keyword][sku]) / 4}]
        return sku_to_keyword_faiss



    def get_lastn_days_job_data(self, retailer_id, job_type, ndays=10):
        if job_type == 'atc':
            job_name = 'OrganicProductKeywordMap.csv'
            data_path_string = 'retailer_id={retailer_id}/year={year}/month={month}/day={day}/{job_name}'
            connection_string = Config.AzureConfig.ICC_DS_STORAGE_CONNECTION_STRING
            container_name = 'combined-output'
            read_flag = False
        elif job_type == 'organic_search':
            job_name = 'keyword_count'
            data_path_string = 'organic_data/retailer_id={retailer_id}/year={year}/month={month}/day={day}/job={job_name}/'
            connection_string = Config.AzureConfig.SUGGESTIONS_INPUT_CONNECTION_STRING
            container_name = Config.AzureConfig.SUGGESTION_INPUT_CONTAINER
            read_flag = True
        job_nday_data = pd.DataFrame()
        for day in range(1, ndays + 1):
            try:
                date_string = datetime.strftime(datetime.now() - timedelta(day), '%Y/%m/%d')
                year, month, day = date_string.split("/")
                blob_path = data_path_string.format(retailer_id=retailer_id, year=year, month=month, day=day,
                                                    job_name=job_name)
                print(blob_path)
                job_data_daily = self.read_write_blob.find_blob_name_from_container_and_read_df(connection_string,
                                                                                                container_name,
                                                                                                [blob_path],
                                                                                                do_csv_check=read_flag)
                job_data_daily['Date'] = date_string
                job_nday_data = pd.concat([job_nday_data, job_data_daily])
            except:
                pass
        if job_type == 'atc':
            job_nday_data.rename(columns={'Keyword': 'keywords'}, inplace=True)
        elif job_type == 'organic_search':
            job_nday_data.rename(columns={'keyword': 'keywords'}, inplace=True)
        if job_nday_data.empty:
            job_nday_data = pd.DataFrame(columns = ['Product','keywords','Count'])
        job_nday_data['keywords'] = job_nday_data['keywords'].astype(str)
        return job_nday_data

    def get_atc_keywords_product_map(self,atc_data, retailer_dict, cutoff=0.75):

        ######## Getting unique keywords list for embeddings ####
        keywords_list_atc = list(atc_data['keywords'].unique())
        atc_keywords_hash_dict = self.get_hash_keyword_dict(keywords_list_atc)
        unique_keywords_list_atc = [atc_keywords_hash_dict[hash][0] for hash in atc_keywords_hash_dict]

        ######## Getting keywords embeddings dict #############

        unique_keywords_embeddings = self.get_embeddings(unique_keywords_list_atc)
        unique_keywords_to_embeddings_dict = dict(zip(unique_keywords_list_atc, unique_keywords_embeddings))
        kh_to_embedd_dict = {}
        for keyword in unique_keywords_to_embeddings_dict:
            kh_to_embedd_dict[self.KH.get_keyword_hash(keyword)] = unique_keywords_to_embeddings_dict[keyword]

        atc_data['keywords'] = atc_data['keywords'].astype(str)
        atc_data['Product'] = atc_data['Product'].str.lower()
        atc_data['keyword_hash'] = atc_data['keywords'].apply(self.KH.get_keyword_hash)
        atc_data1 = atc_data.groupby(['Product', 'keyword_hash'], as_index=False).agg({'Count': sum}).sort_values(
            by=['Product', 'Count'], ascending=[True, False]).reset_index()
        atc_data1 = atc_data1[atc_data1.Count > 1]
        atc_data1['cumulative_sum'] = atc_data1.groupby('Product')['Count'].cumsum()
        total_atc = atc_data1.groupby('Product', as_index=False).agg({'Count': sum}).rename(
            columns={'Count': 'total_count'})
        atc_data2 = atc_data1.merge(total_atc, on='Product')
        atc_data2['percent_cum_count'] = atc_data2['cumulative_sum'] / atc_data2['total_count']

        similairty_score_list = []
        st = time.time()
        for index, row in atc_data2.iterrows():
            try:
                relevance_score = (1 + dot(retailer_dict[row.Product]['embedding'][0],
                                           kh_to_embedd_dict[row.keyword_hash])) / 2
            except:
                relevance_score = 0
            similairty_score_list.append(relevance_score)
        atc_data2['relevance_score'] = similairty_score_list
        print("Relevance score calculated in ", time.time() - st)
        atc_data3 = pd.DataFrame()
        st = time.time()
        for sku in atc_data2.Product.unique():
            temp = atc_data2[atc_data2.Product == sku]
            temp1 = temp[(temp.percent_cum_count < .80)]
            if temp1.empty:
                temp1 = temp.head(1)
            temp2 = temp[((temp.percent_cum_count < 0.95) & (temp.percent_cum_count > .80) & (temp.relevance_score > cutoff))]
            atc_data3 = pd.concat([atc_data3,temp1,temp2])
        print("Data appended in ", time.time() - st)
        atc_data3.drop_duplicates(inplace=True)

        sku_atc_map = {}
        for index, row in atc_data3.iterrows():
            sku = row.Product
            if sku in sku_atc_map:
                sku_atc_map[sku].extend([{'hash': row.keyword_hash, 'relevance_score': row.relevance_score}])
            else:
                sku_atc_map[sku] = [{'hash': row.keyword_hash, 'relevance_score': row.relevance_score}]
        return sku_atc_map

    def get_embeddings(self,keywords_list,model_path = LocalConfig.MODEL_PATH):
        num_cuda_devices = torch.cuda.device_count()
        cuda_devices = ["cuda:" + str(i) for i in range(0, num_cuda_devices)]
        print(cuda_devices)
        if num_cuda_devices>1:
            print("Using multiprocess pool to generate embeddings")
            model = SentenceTransformer(model_path, device='cuda')
            pool = model.start_multi_process_pool(cuda_devices)
            embeddings = model.encode_multi_process(keywords_list,pool)
            model.stop_multi_process_pool(pool)
        else:
            print("Using single gpu pool to generate embeddings")
            model = SentenceTransformer(model_path, device='cuda')
            embeddings = model.encode(keywords_list)
        embeddings = embeddings / np.expand_dims(np.linalg.norm(embeddings, axis=1), axis=1)
        return embeddings

    def change_dimensionality(self, embedding):
        return embedding.reshape(1, -1)

    def create_faiss_index(self,embeddings,ids,nn_to_map=2000):
        vector_dimension = embeddings[0].shape[0]
        cluster_size = nn_to_map
        nlist = int(np.ceil(len(embeddings) / cluster_size))
        quantizer = faiss.IndexFlatL2(vector_dimension)
        embeddings = np.vstack(embeddings)
        ids = np.hstack(ids)
        faiss.normalize_L2(embeddings)
        faiss_index = faiss.IndexIVFFlat(quantizer, vector_dimension, nlist)
        faiss_index.train(embeddings)
        faiss_index.add_with_ids(embeddings, ids)
        faiss_index.nprobe = min(10,nlist)
        return faiss_index

    def get_precison_recall_by_cutoff(self,atc_mapping, current_mapping, cutoff):
        precision_list = []
        recall_list = []
        for sku in atc_mapping:
            if sku in current_mapping:
                atc_mapping_keys = [d['hash'] for d in atc_mapping[sku]]
                current_mapping_keys = [d['hash'] for d in current_mapping[sku] if d['relevance_score'] > cutoff]
                try:
                    precision = len(set(atc_mapping_keys).intersection(current_mapping_keys)) / len(
                        current_mapping_keys)
                except:
                    precision = 1
                recall = len(set(atc_mapping_keys).intersection(current_mapping_keys)) / len(atc_mapping_keys)
                precision_list.append(precision)
                recall_list.append(recall)
            else:
                pass
        mean_precision = np.mean(precision_list)
        mean_recall = np.mean(recall_list)
        return cutoff, mean_precision, mean_recall

    def get_precision_recall(self,atc_mapping, current_mapping):
        precison_recall_values = []
        for cutoff in np.arange(0, 1, .01):
            precison_recall_values.append(self.get_precison_recall_by_cutoff(atc_mapping, current_mapping, cutoff))
        precison_recall_df = pd.DataFrame(precison_recall_values, columns=['cutoff', 'precision', 'recall'])
        return precison_recall_df

    def get_missing_edges_graph(self,atc_data,retailer_data):
        retailer_data1 = retailer_data[['sku', 'category', 'productType']]
        sku_id_to_embedding_dict = dict(zip(retailer_data['sku'], retailer_data['embedding']))
        atc_data['Product'] = atc_data['Product'].str.lower()
        atc_data1 = atc_data.merge(retailer_data1, left_on='Product', right_on='sku')
        atc_data1['keyword_hash'] = atc_data1['keywords'].apply(self.KH.get_keyword_hash)
        atc_data2 = atc_data1.groupby(['keyword_hash', 'Product', 'productType', 'category'], as_index=False).agg(
            {'Count': sum}).rename(columns={'Count': 'weight'}).sort_values(by='weight', ascending=False)
        atc_data2 = atc_data2[atc_data2.weight>1]
        atc_data3 = atc_data2.copy()
        atc_data2['keyword_hash'] = 'keyhash_' + atc_data2['keyword_hash']
        atc_data2['Product'] = 'sku_' + atc_data2['Product']
        atc_data_dict = atc_data3.groupby('Product')['keyword_hash'].apply(list).to_dict()

        ######  Getting unique keywords to embeddings dict #######

        hash_keywords_dict = self.get_hash_keyword_dict(list(atc_data.keywords.unique()))
        unique_keywords_list = [hash_keywords_dict[hash][0] for hash in hash_keywords_dict]
        unique_keywords_hashes_list = list(map(self.KH.get_keyword_hash, unique_keywords_list))
        unqiue_keywords_embeddings = self.get_embeddings(unique_keywords_list)
        hashes_to_embeddings_dict = dict(zip(unique_keywords_hashes_list, unqiue_keywords_embeddings))

        ###### Adding missing edges to graph ##########

        final_edges_df = pd.DataFrame()
        print("Total productType is ", atc_data2.productType.nunique())
        for productType in atc_data2.productType.unique():
            subgraph_data = atc_data2.loc[
                atc_data2['productType'] == productType, ['keyword_hash', 'Product', 'weight']]
            edges = list(subgraph_data.itertuples(index=False))
            UBG = nx.Graph()
            UBG.add_weighted_edges_from(edges)
            missing_edges_degree1 = list(nx.jaccard_coefficient(UBG))
            edges_degree1_nonzero = [edge for edge in missing_edges_degree1 if edge[2] > 0]
            UBG.add_weighted_edges_from(edges_degree1_nonzero)
            missing_edges_degree2 = nx.jaccard_coefficient(UBG)
            missing_edges_df = pd.DataFrame(missing_edges_degree2, columns=['edge1', 'edge2', 'weight']).sort_values(
                by='weight', ascending=False).reset_index(drop=True)
            final_edges_df = final_edges_df.append(missing_edges_df)
            print("Adding 2nd degree missing  edges for productType ", productType)

        ######### Getting final edges ###########

        final_edges_df.sort_values(by='weight', ascending=False, inplace=True)
        final_edges_df1_sku_to_key = final_edges_df[
            (final_edges_df['edge1'].str.startswith('sku_') & final_edges_df['edge2'].str.startswith('keyhash_'))]
        final_edges_df1_key_to_sku = final_edges_df[
            (final_edges_df['edge1'].str.startswith('keyhash_') & final_edges_df['edge2'].str.startswith('sku_'))]
        final_edges_df1_key_to_sku.rename(columns={'edge1': 'edge2', 'edge2': 'edge1'}, inplace=True)
        final_edges_df1 = final_edges_df1_sku_to_key.append(final_edges_df1_key_to_sku)
        final_edges_df2 = final_edges_df1.groupby(['edge1', 'edge2'], as_index=False).agg({'weight': np.mean})
        final_edges_df2.rename(columns={'edge1': 'sku', 'edge2': 'keyword_hash'}, inplace=True)
        final_edges_df2['sku'] = final_edges_df2['sku'].str.replace('^sku_', '')
        final_edges_df2['keyword_hash'] = final_edges_df2['keyword_hash'].str.replace('^keyhash_', '')
        final_edges_df2.sort_values(by=['sku', 'weight'], ascending=False, inplace=True)
        final_edges_df2_dict = final_edges_df2.groupby('sku').apply(
            lambda x: list(zip(x['keyword_hash'], x['weight']))).to_dict()
        final_missing_dict = {}
        for sku in final_edges_df2_dict:
            final_missing_dict[sku] = [x for x in final_edges_df2_dict[sku] if
                                       ((x[0] not in atc_data_dict[sku]) & (x[1] > 0))]

        final_missing_dict1 = {}
        for sku in final_missing_dict:
            keyword_pairs = final_missing_dict[sku]
            final_missing_dict1[sku] = [{'hash':pair[0],'relevance_score':(1 + dot(sku_id_to_embedding_dict[sku][0],
            hashes_to_embeddings_dict[pair[0]]))/2} for pair in keyword_pairs]
        return final_missing_dict1


    def update_product_metadata(self,retailer_data,product_meta_data_mongo_client):
        price_dicts = []
        for index, row in retailer_data.iterrows():
            if index % 1000 == 0:
                print("calculated score for %d records" % index)
            sku = row['sku']
            price = float(row['price'])
            catg = row['category']
            broad_category = row['Broad_Category']
            price_dicts.append({'_id': sku, 'price': price, 'aov': price, 'Broad_Category': broad_category, 'category': catg})
        product_meta_data_mongo_client.upsert_bulk(price_dicts)



    def get_producttype_mapping(self, retailer_data, retailer_dict, search_hash_keywords_list, sku_product_type_dict,
                                sentence_hash_embeddings):
        producttype_to_sku = retailer_data.groupby('productType')['sku'].apply(list).to_dict()
        producttype_to_sku1 = {}
        for product_type in producttype_to_sku.keys():
            producttype_to_sku1[self.KH.get_keyword_hash(product_type)] = producttype_to_sku[product_type]

        sku_producttype_keyword_map = {}
        product_type_list = list(producttype_to_sku1.keys())
        for hash in search_hash_keywords_list:
            product_type_present_list = []
            for product_type in product_type_list:
                if (product_type in hash):
                    product_type_present_list.append(product_type)
            if not product_type_present_list:
                continue
            products_list = []
            for producttype in product_type_present_list:
                products_list.extend(producttype_to_sku1[producttype])
            product_embeddings_list = []
            for product in products_list:
                product_embeddings_list.append(retailer_dict[product]['embedding'][0])
            product_embeddings_matrix = np.array(product_embeddings_list)
            sentence_embedding_matrix = sentence_hash_embeddings[hash]
            cosine_similarity = (1 + dot(product_embeddings_matrix, sentence_embedding_matrix)) / 2
            pairs_similairy_list = zip(*[products_list, cosine_similarity])

            for pair in pairs_similairy_list:
                try:
                    sku_producttype_keyword_map[pair[0]].extend([{'hash': hash, 'relevance_score': pair[1]}])
                except:
                    sku_producttype_keyword_map[pair[0]] = [{'hash': hash, 'relevance_score': pair[1]}]
        return sku_producttype_keyword_map


    def get_sku_hash_pairs_from_keywords(self,sku_keyword_dict,retailer_dict,model_path=LocalConfig.MODEL_PATH):
        sku_hash_pairs = {}
        common_skus = list(set(sku_keyword_dict).intersection(retailer_dict))
        keywords_list_full = list(set(itertools.chain.from_iterable(sku_keyword_dict.values())))
        print("No of total unique keywords ",len(keywords_list_full))
        keyword_to_hash_dict = dict(zip(keywords_list_full,list(map(self.KH.get_keyword_hash,keywords_list_full))))
        hash_keywords_dict = self.get_hash_keyword_dict(keywords_list_full)
        unique_keywords_list = [hash_keywords_dict[key_hash][0] for key_hash in hash_keywords_dict]
        unique_keywords_hashes_list = list(map(self.KH.get_keyword_hash, unique_keywords_list))
        keyword_embeddings = self.get_embeddings(unique_keywords_list,model_path)
        print(keyword_embeddings.shape)
        keyword_hash_to_embeddings = dict(zip(unique_keywords_hashes_list,keyword_embeddings))
        i = 0
        for sku in common_skus:
            key_hash_pairs = []
            keywords_list_sku = sku_keyword_dict[sku]
            hash_list_sku = set([keyword_to_hash_dict[keyword] for keyword in keywords_list_sku])
            for keyword_hash in hash_list_sku:
                cosine_similarity = (1 + dot(retailer_dict[sku]['embedding'][0],keyword_hash_to_embeddings[keyword_hash])) / 2
                key_hash_pairs.extend([{'hash': keyword_hash, 'relevance_score': cosine_similarity}])
            sku_hash_pairs[sku] = key_hash_pairs
            i = i+1
            if (i%10000==0):
                print("No of skus processed: ",i)
        return sku_hash_pairs

    def get_ptype_brand_key_hashes_heuristic(self,retailer_dict,model_path=LocalConfig.MODEL_PATH):
        sku_heuristic_keywords_dict = {}
        for sku in retailer_dict:
            keywords = [retailer_dict[sku]['brand'],retailer_dict[sku]['productType'],retailer_dict[sku]['brand']+' '+retailer_dict[sku]['productType']]
            sku_heuristic_keywords_dict[sku] = keywords
        sku_hash_pairs_heuristic =  self.get_sku_hash_pairs_from_keywords(sku_heuristic_keywords_dict,retailer_dict,model_path)
        return sku_hash_pairs_heuristic