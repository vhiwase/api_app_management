# pylint: disable=all
import re
from typing_extensions import ParamSpecKwargs


class PriceFilter:
    RELATION = {
        ">=": ("greater than", "min", "over", "\\>+", "\\+>\\=+", "above"),
        "==": ("eq[a-z]*", "\\=+", "at", "for"),
        "<=": ("le(s)*\\s*(t(h)?an)?", "max", "\\<+", "\\<+=+", "under", "(up)?to"),
    }

    def __init__(self):
        self.__relation_regex = {}
        for key, value in self.RELATION.items():
            regex_str = None
            for vals in value:
                if regex_str is None:
                    regex_str = "(" + vals + ")"
                else:
                    regex_str = regex_str + "|(" + vals + ")"
            self.__relation_regex[key] = re.compile("(" + regex_str + ")")
           
    def price_matcher(self, query, df, entities):
        entities=self.currency_unit_conversion(entities)
        for i in range(len(entities)):
            try:
                entities[i] = float(re.findall(r'\d*\.\d+|\d+', entities[i])[0])
            except Exception as e:
                print('EXCEPTION IN PRICE_MATCHER')
        entities = sorted(entities)
        if len(entities) == 0:
            return df
        if len(entities) == 1:
            return self.apply_single_condition(query, df, float(entities[0]))
        else:
            return self.apply_multi_condition(df, entities)

    def apply_single_condition(self, query, df, value):
        for operator,regex in self.__relation_regex.items():
            if regex.search(query):
                return df.query("price "+operator+" "+str(value))

    def apply_multi_condition(self, df, entities):
        min = max = entities[0]
        for value in entities:
            if value < min:
                min = value
            if value > max:
                max = value
        return df[df["price"] >= min][df["price"] <= max]


    def cents_to_dollars(self, entities):
        if (len(entities) == 1):
            return ['$' + str(entities[0]/100)]
        elif (len(entities) == 2): 
            return ['$' + str(entities[0] + entities[1]/100)]


    def currency_unit_conversion(self, entities):
        #4 dollars 50 cents - 4 dollars, 50 cents
        #4 cents - 4 cents
        #4 dollars 50 cents and 7 dollars 30 cents - 4 dollars, 50 cents, 7 dollars, 30 cents
        if (len(entities) == 1) and ('cent' in entities[0]):
            entities[0] = float(re.findall(r'\d*\.\d+|\d+', entities[0])[0])
            return self.cents_to_dollars(entities)
        elif (len(entities) == 2) and ('cent' in entities[1]):
            entities[0] = float(re.findall(r'\d*\.\d+|\d+', entities[0])[0])
            entities[1] = float(re.findall(r'\d*\.\d+|\d+', entities[1])[0])
            return self.cents_to_dollars(entities)
        else:
            for ind, ent in enumerate(entities):
                if 'cent' in ent:
                    del entities[ind]
            return entities
            
