# pylint: disable=all
import pandas as pd
import numpy as np
import faiss
from multiprocessing import Process, Queue
import multiprocessing


class SimilarCategoryPredictor:
    __CATEGORIES_COL = 'Broad_Category'
    __PARENT_CATEGORY = 'category'
    __SIMILAR_CATEGORIES_BY_HEURISTIC = 'similar_categories_by_heuristic'
    __PRODUCT_EMBEDDING = 'embedding'
    __CATEGORY_PATH_SEPARATOR = ">"

    def group_skus_by_similar_category(
            self, list_of_products, data, category_path_col, query_threshold=5, similarity_threshold=0.95,
            scaling_factor=0.75, retain_only_leaf_node=False, retain_superdepartment=True, exact_match=True,
            exact_match_threshold=0.6, do_refresh=False
    ):
        """
        Returns dict of category and related skus with relevance score
        """
        __PRODUCT_TYPE_COL = 'productType'
        __PARENT_CATEGORY_PATHS = 'parent_category_paths'
        __CATEGORY_EMBEDDINGS = 'category_embeddings'
        __SIMILAR_CATEGORIES_CENTROID = 'similar_categories_by_centroid'
        __SIMILAR_CATEGORIES_QUERY = 'similar_categories_by_query'
        __SIMILAR_CATEGORIES = 'similar_categories'
        __SIMILAR_TEXT_SKUS = 'similar_text_skus'
        __SKU = 'sku'
        __ID = 'id'
        __SKU_TITLE = 'name'
        __DICT_FORMAT_COL = 'dict_catg_score'
        __RELEVANCE_SCORE = 'relevance_score'
        __CATEGORY_PATH_LEN = 'category_path_len'
        __CATEGORY_STR = 'category'
        __NUM_LEVELS_IN_PATH = 4
        __RELEVANCE_SCORE_HEURISTIC = 0.6
        data['origin'] = ''
        data[__SIMILAR_TEXT_SKUS] = data[__SIMILAR_TEXT_SKUS].apply(
            lambda x: x[0:query_threshold]
        )
        print(data.shape)
        if category_path_col is not None:
            data[category_path_col] = data[category_path_col].str.strip()
            data[self.__CATEGORIES_COL] = data[category_path_col]
            data[self.__PARENT_CATEGORY] = data[category_path_col].apply(
                lambda x: self.__CATEGORY_PATH_SEPARATOR.join(x.split(self.__CATEGORY_PATH_SEPARATOR)[:-1]) if len(
                    x.split(self.__CATEGORY_PATH_SEPARATOR)) > 1 else x
            )
        else:
            data[self.__PARENT_CATEGORY] = data[self.__PARENT_CATEGORY].str.strip()
            data[__PRODUCT_TYPE_COL] = data[__PRODUCT_TYPE_COL].str.strip()
            data[self.__CATEGORIES_COL] = data[self.__PARENT_CATEGORY] + self.__CATEGORY_PATH_SEPARATOR + data[
                __PRODUCT_TYPE_COL]
            data[self.__CATEGORIES_COL] = data[self.__CATEGORIES_COL].str.strip(self.__CATEGORY_PATH_SEPARATOR)
            data[self.__CATEGORIES_COL] = data[self.__CATEGORIES_COL].str.strip()

        data = data[data[self.__CATEGORIES_COL] != '']
        data.reset_index(drop=True, inplace=True)

        category_embeddings = self.__create_category_embedding(data)
        sku_catg_map = dict(zip(data[__SKU].values.tolist(), data[self.__CATEGORIES_COL].values.tolist()))
        # centroid based: similar categories by centroid
        all_broad_categories_df = data[[self.__CATEGORIES_COL]]
        all_broad_categories_df.drop_duplicates(inplace=True)
        all_broad_categories_df.reset_index(drop=True, inplace=True)
        all_broad_categories_df[__CATEGORY_EMBEDDINGS] = all_broad_categories_df[
            self.__CATEGORIES_COL].apply(
            lambda x: category_embeddings[x])
        category_embeddings_df = all_broad_categories_df.copy()
        all_broad_categories_df[__SIMILAR_CATEGORIES_CENTROID] = all_broad_categories_df[
            self.__CATEGORIES_COL].apply(
            lambda x: self.__get_similar_categories_by_centroid(
                x, category_embeddings_df, __CATEGORY_EMBEDDINGS, self.__CATEGORIES_COL, similarity_threshold)
        )

        print("centroid based category similarity calculation done\n")

        # heuristic based similar categories
        if category_path_col is not None:
            categories_in_parent_catg = data[[self.__PARENT_CATEGORY, self.__CATEGORIES_COL]]
            categories_in_parent_catg = categories_in_parent_catg[
                categories_in_parent_catg[self.__PARENT_CATEGORY] != '']
            categories_in_parent_catg.drop_duplicates(inplace=True)
            categories_in_parent_catg = self.__get_similar_categories_heuristic(
                categories_in_parent_catg)

            # categories for current sku
            categories_in_parent_catg_sku = categories_in_parent_catg.merge(
                data[[__SKU, __SKU_TITLE, self.__PARENT_CATEGORY, category_path_col]])
            if len(list_of_products) != data[__SKU].nunique():
                categories_in_parent_catg_sku = categories_in_parent_catg_sku[
                    categories_in_parent_catg_sku[__SKU].isin(list_of_products)]
            categories_in_parent_catg_sku[__CATEGORY_PATH_LEN] = categories_in_parent_catg_sku.apply(
                lambda x: len(x[category_path_col].split(self.__CATEGORY_PATH_SEPARATOR)), axis=1)
            categories_in_parent_catg_sku = categories_in_parent_catg_sku[
                categories_in_parent_catg_sku[__CATEGORY_PATH_LEN] >= __NUM_LEVELS_IN_PATH]
            categories_in_parent_catg_sku.reset_index(drop=True, inplace=True)
            categories_in_parent_catg_sku.rename(columns={__SKU: __ID}, inplace=True)
            categories_in_parent_catg_sku[__RELEVANCE_SCORE] = __RELEVANCE_SCORE_HEURISTIC
            sim_catg_heuristic_map = dict(zip(categories_in_parent_catg_sku[self.__PARENT_CATEGORY].values.tolist(),
                                              categories_in_parent_catg_sku[
                                                  self.__SIMILAR_CATEGORIES_BY_HEURISTIC].values.tolist()))

            print("heuristic based category similarity calculation done\n")
        else:
            sim_catg_heuristic_map = {}
            categories_in_parent_catg_sku = pd.DataFrame()

            # query based: categories among top k results for sku
        products_df = pd.DataFrame({'sku': list_of_products})
        products_df = products_df.merge(
            data[[__SKU, __SKU_TITLE, self.__PARENT_CATEGORY, self.__CATEGORIES_COL, __SIMILAR_TEXT_SKUS]]
        )
        products_df[__SIMILAR_CATEGORIES_QUERY] = products_df[__SIMILAR_TEXT_SKUS].apply(
            lambda x: list(set(sku_catg_map.get(sku) for sku in x if sku_catg_map.get(sku)))
        )
        print("relevance based category similarity calculation done\n")
        # merge similar categories by centroid approach
        products_df = products_df.drop([__SIMILAR_TEXT_SKUS], axis=1)
        products_df = products_df.merge(
            all_broad_categories_df[[self.__CATEGORIES_COL, __SIMILAR_CATEGORIES_CENTROID]]
        )
        # merge similar categories by heuristic approach
        products_df[self.__SIMILAR_CATEGORIES_BY_HEURISTIC] = products_df[self.__PARENT_CATEGORY].apply(
            lambda x: sim_catg_heuristic_map.get(x) if sim_catg_heuristic_map.get(x) else []
        )
        products_df[__SIMILAR_CATEGORIES] = products_df.apply(
            lambda x: list(
                set(x[__SIMILAR_CATEGORIES_CENTROID] + x[__SIMILAR_CATEGORIES_QUERY] + x[
                    self.__SIMILAR_CATEGORIES_BY_HEURISTIC])
            ), axis=1
        )

        products_df = products_df[[__SKU, __SKU_TITLE, self.__CATEGORIES_COL, __SIMILAR_CATEGORIES]]
        products_df = products_df.merge(data[[__SKU, self.__PRODUCT_EMBEDDING]])
        products_df.rename(columns={__SKU: __ID}, inplace=True)
        category_embeddings_df.rename(
            columns={self.__CATEGORIES_COL: __SIMILAR_CATEGORIES}, inplace=True
        )
        products_df = self.__calculate_sim_score_for_prod_catg(
            products_df,
            category_embeddings_df,
            self.__CATEGORIES_COL,
            __CATEGORY_EMBEDDINGS,
            self.__PRODUCT_EMBEDDING,
            __SIMILAR_CATEGORIES,
            __RELEVANCE_SCORE
        )

        products_df = products_df[[__ID, __SKU_TITLE, __SIMILAR_CATEGORIES, __RELEVANCE_SCORE]]

        # concat with the heuristic to take max of the heuristic score and actual rel score
        if categories_in_parent_catg_sku.shape[0] > 0:
            categories_in_parent_catg_sku.rename(
                columns={self.__SIMILAR_CATEGORIES_BY_HEURISTIC: __SIMILAR_CATEGORIES},
                inplace=True
            )
            categories_in_parent_catg_sku = categories_in_parent_catg_sku.explode(__SIMILAR_CATEGORIES,
                                                                                  ignore_index=True)
            categories_in_parent_catg_sku = categories_in_parent_catg_sku[
                [__ID, __SKU_TITLE, __SIMILAR_CATEGORIES, __RELEVANCE_SCORE]
            ]
            products_df = pd.concat([products_df, categories_in_parent_catg_sku], ignore_index=True)

        products_df = products_df.groupby(
            by=[__ID, __SKU_TITLE, __SIMILAR_CATEGORIES], as_index=False)[__RELEVANCE_SCORE].max()

        # Generating score for all the other parent categories by scaling scores
        if category_path_col is not None:
            products_df[__PARENT_CATEGORY_PATHS] = products_df[__SIMILAR_CATEGORIES].apply(
                lambda x: self.__get_all_parent_paths(
                    x,
                    retain_superdepartment
                )
            )
        else:
            products_df[__PARENT_CATEGORY_PATHS] = products_df[__SIMILAR_CATEGORIES].apply(
                lambda x: [self.__CATEGORY_PATH_SEPARATOR.join(x.split(self.__CATEGORY_PATH_SEPARATOR)[:-1])] if len(
                    x.split(self.__CATEGORY_PATH_SEPARATOR)) > 1 else None
            )

        # get parent paths and explode and scale down relevance score by a factor of leaf node
        parent_categories_df = products_df[[__ID, __PARENT_CATEGORY_PATHS, __RELEVANCE_SCORE]]
        products_df = products_df[[__ID, __SIMILAR_CATEGORIES, __RELEVANCE_SCORE]]
        parent_categories_df.dropna(inplace=True)
        if len(parent_categories_df) > 0:
            parent_categories_df = parent_categories_df.explode(__PARENT_CATEGORY_PATHS)
            parent_categories_df = parent_categories_df.groupby(
                by=[__ID, __PARENT_CATEGORY_PATHS], as_index=False)[__RELEVANCE_SCORE].max()
            parent_categories_df.rename(columns={__PARENT_CATEGORY_PATHS: __SIMILAR_CATEGORIES}, inplace=True)
            parent_categories_df[__RELEVANCE_SCORE] = parent_categories_df[__RELEVANCE_SCORE].apply(
                lambda x: x * scaling_factor)
            parent_categories_df = parent_categories_df[[__ID, __SIMILAR_CATEGORIES, __RELEVANCE_SCORE]]
            # Combining parent category & category into single df & dict later on
            products_df = pd.concat([products_df, parent_categories_df], ignore_index=True)

        # Adding logic to include latest leaf-node's category path changes
        if retain_only_leaf_node:
            products_df[__SIMILAR_CATEGORIES] = products_df[__SIMILAR_CATEGORIES].apply(
                lambda x: x.split(self.__CATEGORY_PATH_SEPARATOR)[-1]
            )

        # taking max to resolve multiple relevance score at same level
        products_df = products_df.groupby(by=[__ID, __SIMILAR_CATEGORIES], as_index=False)[
            __RELEVANCE_SCORE].max()
        # filters by the cutoff relevance score we deceided - exact_match_threshold
        if exact_match:
            products_df = products_df[products_df[__RELEVANCE_SCORE] > exact_match_threshold]
            products_df.reset_index(drop=True, inplace=True)
        products_df.rename(columns={__SIMILAR_CATEGORIES: __CATEGORY_STR}, inplace=True)

        # changing formatting & aggregating to store in dbs
        products_df[__DICT_FORMAT_COL] = products_df.apply(
            lambda x: [{__ID: x[__ID], __RELEVANCE_SCORE: x[__RELEVANCE_SCORE]}], axis=1)
        products_df = products_df[[__CATEGORY_STR, __DICT_FORMAT_COL]]
        ct_products_df = products_df.groupby(by=__CATEGORY_STR)[__DICT_FORMAT_COL].sum()
        ct_hash = ct_products_df.to_dict()
        sorted_ct_hash = self.__sort_category_hash(ct_hash, __RELEVANCE_SCORE)

        products_df[__ID] = products_df[__DICT_FORMAT_COL].apply(lambda x: x[0][__ID])
        products_df[__RELEVANCE_SCORE] = products_df[__DICT_FORMAT_COL].apply(lambda x: x[0][__RELEVANCE_SCORE])
        products_df = products_df[[__ID, __CATEGORY_STR, __RELEVANCE_SCORE]]
        products_df[__DICT_FORMAT_COL] = products_df.apply(
            lambda x: [{__CATEGORY_STR: x[__CATEGORY_STR], __RELEVANCE_SCORE: x[__RELEVANCE_SCORE]}],
            axis=1
        )
        products_df = products_df.groupby(by=__ID)[__DICT_FORMAT_COL].sum()
        ci_hash = products_df.to_dict()
        sorted_ci_hash = self.__sort_category_hash(ci_hash, __RELEVANCE_SCORE)

        return sorted_ci_hash, sorted_ct_hash

    def __get_all_parent_paths(self, path, retain_superdepartment):
        path = path.split(self.__CATEGORY_PATH_SEPARATOR)
        all_parent_paths = None
        path_len = len(path)
        if retain_superdepartment:
            loop_threshold = path_len
        else:
            loop_threshold = path_len - 1
        if path_len > 1:
            all_parent_paths = []
            for i in range(1, loop_threshold):
                all_parent_paths.append(
                    self.__CATEGORY_PATH_SEPARATOR.join(path[0:path_len - i]).strip()
                )
        return all_parent_paths

    def __create_category_embedding(self, df):
        category_embeddings = {}
        for category, embedding in df.groupby(
                self.__CATEGORIES_COL)[self.__PRODUCT_EMBEDDING].apply(np.mean).items():
            faiss.normalize_L2(embedding)
            category_embeddings[category] = embedding
        return category_embeddings

    @staticmethod
    def __calculate_sim_score_for_prod_catg_in_chunk(products_df_chunk, category_embeddings_df,
                                                     catgs_col, catg_embs_col, prod_embs_col, sim_catgs_col,
                                                     rel_score_col, out_q, i):
        print("processing chunk %d" % i)
        products_df_chunk = products_df_chunk.explode(sim_catgs_col, ignore_index=True)
        products_df_chunk = products_df_chunk.merge(
            category_embeddings_df[[sim_catgs_col, catg_embs_col]]
        )
        products_df_chunk[rel_score_col] = products_df_chunk.apply(
            lambda x: 1 if x[catgs_col] == x[sim_catgs_col] else np.dot(
                x[prod_embs_col], x[catg_embs_col].T)[0][0], axis=1)
        out_q.put(products_df_chunk)

    @staticmethod
    def __calculate_sim_score_for_prod_catg(products_df, category_embeddings_df,
                                            catgs_col, catg_embs_col, prod_embs_col, sim_catgs_col, rel_score_col):
        products_df_cols = products_df.columns.values.tolist()
        products_df_cols.append(rel_score_col)
        processed_products_df = pd.DataFrame(columns=products_df_cols)
        if products_df.empty:
            return processed_products_df
        num_cores = max(multiprocessing.cpu_count() - 4, 1)
        _len = products_df.shape[0]
        chunk_size = int(_len / num_cores) + 1
        if chunk_size <= num_cores:
            num_cores = 1
        process_list = []
        df_list = []
        start = 0
        out_q = Queue()
        for i in range(num_cores):
            if i == num_cores - 1:
                products_df_chunk = products_df.iloc[start:_len]
            else:
                products_df_chunk = products_df.iloc[start:start + chunk_size]

            p = Process(target=SimilarCategoryPredictor.__calculate_sim_score_for_prod_catg_in_chunk,
                        args=(products_df_chunk, category_embeddings_df, catgs_col, catg_embs_col,
                              prod_embs_col, sim_catgs_col, rel_score_col, out_q, i))
            process_list.append(p)
            start = start + chunk_size
            p.start()

        for i in range(num_cores):
            df_list.append(out_q.get())

        for p in process_list:
            p.join()

        print("processed all chunks\n\n")
        if df_list:
            processed_products_df = pd.concat(df_list, ignore_index=True)
        return processed_products_df

    @staticmethod
    def __sort_category_hash(catg_hash, rel_score_col):
        sorted_catg_hash = {}
        for k, v in catg_hash.items():
            sorted_v = sorted(v, key=lambda i: i[rel_score_col], reverse=True)
            sorted_catg_hash[k] = sorted_v
        return sorted_catg_hash

    @staticmethod
    def __get_similar_categories_by_centroid(
            category_name, category_embeddings_df,
            category_embeddings_col_name, category_col_name, threshold=0.9
    ):
        """
        Returns the similar categories for a given category name
        """
        __SIMILARITY_COL = 'similarity'
        __SIMILARITY_NORMALIZED_COL = 'normalized_similarity'
        embeddings_bc = category_embeddings_df[
            category_embeddings_df[category_col_name] == category_name][category_embeddings_col_name].values[0]
        category_embeddings_df[__SIMILARITY_COL] = category_embeddings_df[category_embeddings_col_name].apply(
            lambda x: np.dot(
                x, embeddings_bc.T
            )[0][0]
        )
        category_embeddings_df = category_embeddings_df[
            category_embeddings_df[category_col_name] != category_name]
        category_embeddings_df = category_embeddings_df.sort_values(
            __SIMILARITY_COL, ascending=False
        )
        category_embeddings_df.reset_index(drop=True, inplace=True)
        max_val = category_embeddings_df[__SIMILARITY_COL].max()
        category_embeddings_df[
            __SIMILARITY_NORMALIZED_COL] = category_embeddings_df[__SIMILARITY_COL] / max_val
        category_embeddings_df = category_embeddings_df[
            category_embeddings_df[__SIMILARITY_NORMALIZED_COL] >= threshold]
        similar_categories = list(category_embeddings_df[category_col_name].unique())
        similar_categories = similar_categories + [category_name]
        return similar_categories

    def __get_similar_categories_heuristic(self, category_prod_type_data):
        category_prod_type_data[self.__CATEGORIES_COL] = category_prod_type_data[self.__CATEGORIES_COL].apply(
            lambda x: [x]
        )
        category_prod_type_data = category_prod_type_data.groupby(
            by=self.__PARENT_CATEGORY)[self.__CATEGORIES_COL].sum()
        category_prod_type_data = category_prod_type_data.reset_index()
        category_prod_type_data.rename(
            columns={self.__CATEGORIES_COL: self.__SIMILAR_CATEGORIES_BY_HEURISTIC}, inplace=True
        )
        return category_prod_type_data
