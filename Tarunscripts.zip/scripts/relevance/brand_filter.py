# pylint: disable=all
class BrandFilter:

    def __init__(self):
        pass

    def brand_filter(self, output, brand_name):
        if brand_name == '':
            return output
        else:
            output = output[output['brand'] == brand_name]
            output['relevance_score'], output['category_score'], output['distance'] = 1, 0, 0
            output.rename({'sku':'id'}, axis=1, inplace=True)
            return output


