# pylint: disable=all
from context.retailer import Retailer
import faiss
import pandas as pd
import torch
import cv2
import urllib
import requests
from context.context import Context
from relevance.category_relevance import CategoryRelevance
from nltk.corpus import stopwords
# nltk.download('stopwords')
from nltk.tokenize import word_tokenize
from relevance.price_filteration import PriceFilter
from util.spacy_ner import SpacyNer
from util.pair_similarity import PairWiseCosineSimilarity
from relevance.brand_filter import BrandFilter
from tensorflow.keras.layers import GlobalAveragePooling2D
from sklearn.preprocessing import MinMaxScaler
import numpy as np
from relevance.auto_target import AutoTarget

class RelevanceEngine:
    SCORE_REGULARIZER = 0.02
    NEGATION_TO_REMOVE = ['inorganic', 'in-organic', 'in organic', 'non-organic', 'non organic', 'nonorganic']

    def __init__(self):
        self.__category_relevance = CategoryRelevance()
        self.__stopword = set(stopwords.words())
        self.__pwc = PairWiseCosineSimilarity()
        self.__ner = SpacyNer()
        self.headers = {'User-Agent': "Mozilla/5.0 (X11; Linux x86_64) \
                       AppleWebKit/537.36 \
                       (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36"}
        self.image_similarity_threshold = 0.9
        self.auto_target = AutoTarget()

    #TODO: if brand is not there in list of brands, we are ignoring the brand and we are not replacing it. also, we will replace in entities dictionary.
    def __query_decomposition(self, retailer, query, entities):
        for key, val in entities.items():
            if (key == 'PRC') or (key == 'PRC_REL'):
                for ent in entities[key]:
                    query = query.replace(ent, '')
            elif key == 'BRAND':
                if val not in retailer.brands:
                    entities['BRAND'] = ''
                    continue
                else:
                    query = query.replace(val, '')
            else:
                query = query.replace(val, '')
        query_tokens = word_tokenize(query)
        query = [word for word in query_tokens if not word in self.__stopword]
        query = ' '.join(query)
        return query, entities

    def __query_with_only_entity(self, query, entities, data):
        if query == '':
            if entities['BRAND'] == '':
                return pd.DataFrame(), True
            else:
                brand_filteration = BrandFilter()
                data = brand_filteration.brand_filter(data, entities['BRAND'])
                return data, True
        else:
            return query, False

    def get_products_by_query(self, retailer, query, k_nearest, bid_intelligence_input=False):
        """
        Description: Takes a string (query) as an input. Embeds it and searches the most similar products given the embeddings.
        """
        entities = self.__ner.entity_extraction(query)
        query = self.__preprocess_query(query)  # Normalize the query
        azure_df = pd.DataFrame(list(retailer.search_clients.search(search_text=query, top=k_nearest * 10, query_type='simple')))
        if azure_df.shape[0] > 0:
            azure_df['scaled_score'] = (1 - np.round(MinMaxScaler().fit_transform(azure_df[['@search.score']]), 4))
            azure_df = azure_df.merge(retailer.data, on=['sku', 'name', 'description'])
            azure_df = azure_df.drop(columns=['embedding'])
        self.__remove_negation_from_query(query)
        decomposed_query, entities = self.__query_decomposition(retailer, query, entities)
        decomposed_query, processing_flag = self.__query_with_only_entity(decomposed_query, entities, retailer.data)
        if processing_flag:
            if bid_intelligence_input:
                return decomposed_query, 1
            return decomposed_query
        query_embedding = Context.ROBERTA_BERT_MODEL.encode([decomposed_query], device = torch.device('cpu'))  # Encode the query into a vector
        faiss.normalize_L2(query_embedding)  # Normalize the vector, helps in calculating cosine similarity
        retailer.faiss_index.nprobe = retailer.faiss_nprobe  # NProbe are the number of segments to be searched
        if bid_intelligence_input:
            # search through entire catalog size for bid intell- later on we will have filter logic
            distance, fid = retailer.faiss_index.search(query_embedding, k=k_nearest)
        else:
            distance, fid = retailer.faiss_index.search(query_embedding, k=k_nearest * 10)  # Search through the index

        df = self.__filter_data(fid[0], retailer.data, distance[0])  # Filters the dataframe
        df['distance'] = np.round(MinMaxScaler().fit_transform(df[['distance']]), 4)
        if azure_df.shape[0] > 0:
            df = azure_df.merge(df, how='outer',on=['sku', 'price', 'category', 'name', 'FID', 'Broad_Category', 'brand','productType'])
            df.fillna({'scaled_score': 1, 'distance': 1}, inplace=True)
            df['combined_score'] = (df['scaled_score'] * 0.55) + (df['distance'] * 0.45)
            df.rename(columns={'distance': 'semantic_score', 'combined_score': 'distance'}, inplace=True)
        df = df.sort_values(['distance'], ascending=True).head(k_nearest * 2)
        category_output = self.__category_relevance.get_catg_score_for_query(retailer, df, query_embedding)  # Add the category score
        if bid_intelligence_input:
            return category_output, 0
        output_df = self.__generate_relevance_score(category_output, True)  # Calculate relevance score and store in a df with ids
        output_df['kevel_score'] = 500
        output_df = output_df.rename(columns = {"sku": "id"})
        output_df = output_df[output_df['id'] != 'NA']
        output_df = output_df.sort_values(by ='relevance_score', axis=0, ascending = False)[:k_nearest]
        output_df = self.__drop_duplicate_skus(output_df)
        pf = PriceFilter()
        brand_filteration = BrandFilter()
        output_df = brand_filteration.brand_filter(output_df, entities['BRAND'])
        return pf.price_matcher(query, output_df, entities['PRC'])

    def get_products_by_query_bid_intelligence(self, retailer, query, k_nearest, sku):
        query_relevance_df, brand_indicator = self.get_products_by_query(retailer, query, retailer.data.shape[0], True)
        if brand_indicator:
            query_relevance_df.rename(columns={'id':'sku'}, inplace=True)
            query_relevance_df = query_relevance_df[["sku", "relevance_score"]]
            if sku not in query_relevance_df.sku.unique():
                query_relevance_df_sku = pd.DataFrame({'sku':[sku], 'relevance_score': [1e-5]})
            else:
                query_relevance_df_sku = pd.DataFrame()
        else:
            query_relevance_df = self.__generate_relevance_score(query_relevance_df, is_normalise=False)
            query_relevance_df = query_relevance_df[["sku", "relevance_score"]]
            query_relevance_df_sku = query_relevance_df[query_relevance_df["sku"] == sku]
            query_relevance_df = query_relevance_df.sort_values(by='relevance_score', axis=0, ascending=True)[:k_nearest]
        query_relevance_df = pd.concat([query_relevance_df, query_relevance_df_sku])
        query_relevance_df.drop_duplicates(inplace=True)
        query_relevance_df.reset_index(drop=True, inplace=True)
        query_relevance_df = self.__normalize_relevance_score(query_relevance_df)
        return query_relevance_df

    def __get_image_array(self, image_content):
        """
        Convert image into an array

        """
        img_array = np.asarray(bytearray(image_content), dtype="uint8")
        img_array = cv2.imdecode(img_array, cv2.IMREAD_COLOR)
        img_array = cv2.resize(img_array, tuple([224,224])).astype(np.float32)
        # Normalize pixels
        img_array[:,:,0] = (img_array[:,:,0] - 103.94) * 0.017
        img_array[:,:,1] = (img_array[:,:,1] - 116.78) * 0.017
        img_array[:,:,2] = (img_array[:,:,2] - 123.68) * 0.017

        img_array = np.expand_dims(img_array, axis=0)

        return img_array

    def __get_image_representation(self, response):
        image_array = self.__get_image_array(response.content)
        image_emb = Context.IMAGE_MODEL.predict(image_array)
        image_emb = GlobalAveragePooling2D()(image_emb)
        image_emb = image_emb.numpy()
        image_emb = image_emb / np.linalg.norm(image_emb)
        image_emb = np.float32(image_emb)
        return image_emb

    def get_similar_images_from_catalog(self, retailer, img_url, k_nearest):
        """
        This function is used for influencer shop auto tagging

        """
        try:
            img_url = urllib.parse.unquote(img_url)
            img_url = urllib.parse.urljoin(img_url,
                      urllib.parse.urlparse(img_url).path)
            response = requests.request("GET", img_url, headers=self.headers)
            image_emb = self.__get_image_representation(response)
            _scores, _ids = retailer.image_faiss_index.search(image_emb,
                            k = k_nearest)
            _skus = [retailer.get_product_by_image_fid(_id) for _id in
                    _ids[0].tolist()]
            _scores = _scores[0].tolist()
        except:
            print("unable to get similar images for url: %s" %img_url)
            _skus = []
            _scores = []

        output_df = self.__filter_data_by_sku(_skus,
                    retailer.data, _scores)
        output_df['relevance_score'] = (2 - output_df['distance']) / 2
        output_df = output_df[output_df['relevance_score']
                    >= self.image_similarity_threshold]
        output_df.rename({'sku': 'id'}, axis=1, inplace=True)
        output_df = output_df[output_df['id'] != 'NA']
        output_df = self.__drop_duplicate_skus(output_df)
        output_df = output_df.sort_values(by='relevance_score',
                    axis=0, ascending=False)[:k_nearest]
        return output_df

    def get_products_by_category(self, retailer, category):
        # Function to be implemented
        output = []
        output_df = pd.DataFrame(output, columns=['id', 'relevance_score'])
        return output_df

    def get_relevance_score(self, retailer, search_type, search_term, target_sku):

        if search_type == 'query':
            entities = self.__ner.entity_extraction(search_term)
            search_term = self.__preprocess_query(search_term)
            decomposed_query, entities = self.__query_decomposition(retailer, search_term, entities)                           # Process the query
            query_vector = Context.ROBERTA_BERT_MODEL.encode([decomposed_query], device = torch.device('cpu'))  # Encode the query into a vector
            faiss.normalize_L2(query_vector)
            results, ids = self.__pwc.pair_wise_similarity(query_vector, target_sku, retailer)
            df = pd.DataFrame({'sku':ids,'distance':results})
            df = pd.merge(df, retailer.data, how='inner', on=['sku'])
            category_output = self.__category_relevance.get_catg_score_for_query(retailer,
                                                                            df, query_vector)  # Add the category score
            output_df = self.__generate_relevance_score(category_output, False)                  # Calculate relevance score and store in a df with ids
            return 1 - output_df['relevance_score'].tolist()[0]

        else:
            try:
                fid = retailer.data[retailer.data['sku'] == search_term].FID.tolist()[0]
            except Exception as e:
                print("EXCEPTION IN PRODUCT WISE MANUAL TARGETTING")
                return 0
            product_vector = retailer.faiss_index.reconstruct(fid)
            results, ids = self.__pwc.pair_wise_similarity(product_vector, target_sku, retailer)
            return 1 - results[0]

    def __normalize_relevance_score(self, df):
        """
        Description: Calculate relevance score by using weighted averages.
        Returns: Dataframe object
        """
        shortest = df.relevance_score.min() + self.SCORE_REGULARIZER
        df['relevance_score'] = shortest / (df['relevance_score'] + self.SCORE_REGULARIZER)
        sum_ = df.relevance_score.sum()
        df['relevance_score'] = df['relevance_score'] * 0.55 * df.shape[0] / sum_
        return df

    def __preprocess_query(self, query):
        """
        Description: Lowers and stems a given string.
        Returns: String
        """
        query = query.lower()
        tokenized_query = Context.WORD_TOKENIZE(query)
        lemmatized_query = ' '.join([Context.LEMMATIZER.lemmatize(w) for w in tokenized_query])
        return lemmatized_query

    def __remove_negation_from_query(self,query):
        for words in self.NEGATION_TO_REMOVE:
            if words in query:
                return query.replace(words, '')
        return query

    def __filter_data(self, fid, df, distance):
        """
        Description: Filter only the recommended rows from the Dataframe
        Returns: Dataframe object
        """
        rec_df = pd.DataFrame({'distance': distance, 'FID': fid})
        df = df[df["FID"].isin(fid)]
        output = df.merge(rec_df, on='FID')[['sku', 'name', 'price',
                                             'distance', 'FID', 'IMAGE_FID',
                                             'Broad_Category', 'category', 'productType', 'brand']]
        return output

    def __filter_data_by_sku(self, skus, df, distance):
        """
        Description: Filter only the recommended rows from the Dataframe
        Returns: Dataframe object
        """
        dtypes = {'sku':'object','distance':'float64'}
        rec_df = pd.DataFrame({'distance': distance, 'sku': skus})
        for c in rec_df.columns:
            rec_df[c] = rec_df[c].astype(dtypes[c])

        df = df[df["sku"].isin(skus)]
        output = df.merge(rec_df, on='sku')[['sku', 'name', 'price',
                                             'distance', 'FID', 'IMAGE_FID',
                                             'Broad_Category', 'category', 'productType', 'brand']]
        return output

    def __generate_relevance_score(self, df, is_normalise=True):
        """
        Description: Calculates relevance score from weighted average.
        Returns: Dataframe object
        """
        df['relevance_score'] = (df['distance'] * 0.7) + \
                                ((1 - df['category_score']) * 0.3)
        if is_normalise:
            df = self.__normalize_relevance_score(df)
        return df

    def __generate_relevance_score_for_products(self, df):
        """
        Description: Calculates relevance score for products from weighted average.
        Returns: Dataframe object
        """
        df['relevance_score'] = (((4 - df['distance'])/4) * 0.7) + \
                                (df['category_score'] * 0.3)
        return df

    def __drop_duplicate_skus(self, df):
        df = df.drop_duplicates(subset = ['id'])
        return df

    def get_query_embedding(self,query):
        query = self.__preprocess_query(query)  # Normalize the query
        query_embedding = Context.ROBERTA_BERT_MODEL.encode([query], device=torch.device(
                'cpu'))  # Encode the query into a vector
        return (query_embedding)

    def get_products_by_product(self, retailer, sku):
        """
        Description: Takes sku  as an input. Searches the most similar products given the extracted embeddings.
        """
        relevant_products = self.auto_target.get_products_by_product(retailer, sku)
        output_df = pd.DataFrame(relevant_products)
        output_df.rename({'sku': 'id'}, axis=1, inplace=True)
        if not output_df.empty:
            output_df = output_df.sort_values(by='relevance_score', axis=0, ascending=False)
        return output_df

    def get_keywords_for_product(self, retailer, product_id):
        """
        Description: Takes sku  as an input. Searches the most similar products given the extracted embeddings.
        """
        targets = self.auto_target.get_keywords_for_product(retailer, product_id)

        return pd.DataFrame(targets)

    def get_similar_categories(self, retailer, sku):

        output = self.auto_target.get_category_targets(retailer, sku)
        output_df = pd.DataFrame(output)
        output_df.columns = ['category', 'relevance_score']
        return output_df
