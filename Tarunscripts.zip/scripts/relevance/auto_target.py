from util.icc_logger import Log
from config import Config
from util.redis_utils import RedisCache, RedisKeyGen
from metric_estimation.metric_estimator import MetricsEstimator
from util.keyword_targetting_utils import KeywordHash
from bidding.auto_bidder import AutoBidder
from bidding.simple_soft_budget_pacer import SimpleSoftBudgetPacer
from util.simple_ab_tester import SimpleABTest


class AutoTarget:
    _PLACEMENTS = 'placements'

    def __init__(self):
        # self.redis_client = RedisUtil(Config.AzureConfig.REDIS_HOST_NAME, Config.AzureConfig.REDIS_PASSWORD)
        self.redis_client = RedisCache(Config.AzureConfig.REDIS_HOST_NAME, Config.AzureConfig.REDIS_PASSWORD)
        self.metric_estimator = MetricsEstimator()
        self.keyword_hash = KeywordHash()
        self.auto_bidder = AutoBidder()
        self.budget_pacer = SimpleSoftBudgetPacer()
        self.ab_tester = SimpleABTest()

    @staticmethod
    def __explode_ad_units(targets, placement_id_list, target_type, target_value):
        exploded_targets = dict()
        for key, value in targets.items():
            if not value:
                continue
            for campaign in value:
                for placement in campaign["placements"]:
                    if (
                            placement_id_list and
                            placement not in placement_id_list
                    ):
                        continue

                    if not exploded_targets.get(key):
                        exploded_targets[key] = []
                    campaign_data = {
                        "campaign_id": campaign["campaign_id"],
                        "ad_group_id": campaign["ad_group_id"],
                        "uid": campaign["uid"],
                        "bid": campaign["bid"],
                        "ecpm": campaign["ecpm"],
                        "ctr": campaign["ctr"],
                        "products_to_promote": campaign[
                            "products_to_promote"
                        ],
                        "placement_id": placement,
                        "match_type": "exact",
                        "campaign_mode": "automatic",
                        "cost_type": "cpc"
                    }

                    if "target_value" in campaign:
                        campaign_data["target_value"] = campaign["target_value"].lower()
                    else:
                        campaign_data["target_value"] = target_value

                    if "target_type" in campaign:
                        campaign_data["target_type"] = campaign["target_type"].lower()
                    else:
                        campaign_data["target_type"] = target_type

                    if "match_type" in campaign:
                        campaign_data["match_type"] = campaign["match_type"].lower()
                    if "campaign_type" in campaign:
                        campaign_data["campaign_mode"] = campaign["campaign_type"].lower()
                    if "cost_type" in campaign:
                        campaign_data["cost_type"] = campaign["cost_type"].lower()

                    exploded_targets[key].append(campaign_data)

        return exploded_targets

    def get_target_campaigns_v3(
            self, retailer, target_type, target_value_list, placement_id_list,
            user_id, guest_id, trace_id=None
    ):
        result = []
        keys = []
        processed_target_value_list = []
        apply_intelligence = True
        for target_value in target_value_list:
            if target_type == "product":
                key = RedisKeyGen.get_product_targeting_key_v2(
                    retailer.retailer_id, target_value
                )
            elif target_type == "category":
                key = RedisKeyGen.get_category_targeting_key_v2(
                    retailer.retailer_id, target_value
                )

            elif target_type == "audience":
                if user_id:
                    audience_id = user_id
                else:
                    audience_id = guest_id
                key = RedisKeyGen.get_targeting_key_v2(
                    retailer.retailer_id, "audience", audience_id
                )
            elif target_type == "keyword":
                hashed_target_value = self.keyword_hash.get_keyword_hash(target_value)
                key = RedisKeyGen.get_keyword_targeting_key_v2(
                    retailer.retailer_id, hashed_target_value
                )
                keys.append(key)
                key = RedisKeyGen.get_exact_keyword_targeting_key_v2(
                    retailer.retailer_id, target_value
                )
            else:
                apply_intelligence = False
                key = RedisKeyGen.get_other_targeting_key_v2(
                    retailer.retailer_id, target_type, target_value
                )

            processed_target_value_list.append(target_value)
            keys.append(key)

        all_ad_units = self.redis_client.multi_get(keys)

        # Exploding and clone the ad units by placement id
        all_ad_units = self.__explode_ad_units(all_ad_units, placement_id_list, target_type, target_value)

        # Apply AB test filter
        ab_test_filtered_ad_units = self.ab_tester.apply_ab_test_filter_at_campaign_level(
            retailer, user_id, guest_id, all_ad_units
        )

        # Apply placement filters
        selected_ad_units = dict()
        for key, ad_units in ab_test_filtered_ad_units.items():
            if ad_units:
                for campaign_data in ad_units:
                    uid = campaign_data["uid"]+"_"+str(campaign_data["placement_id"])
                    if (selected_ad_units.get(uid) and
                            selected_ad_units[uid]["ecpm"] >
                            campaign_data["ecpm"]):
                        continue

                    floor_price = retailer.get_floor_price(
                        str(campaign_data["placement_id"]),
                        target_value_list[0]
                    )

                    if campaign_data["ecpm"] < floor_price:
                        continue

                    campaign_data["floor_price"] = floor_price
                    selected_ad_units[uid] = campaign_data

        if apply_intelligence:
            # Apply soft budget pacing
            if retailer.get_meta_data().get("budget_pacing_flag"):
                campaign_ids = set()
                for key, ad_unit in selected_ad_units.items():
                    campaign_ids.add(ad_unit["campaign_id"])
                budget_pacing_factor_map = self.budget_pacer. \
                    get_budget_pacing_factor(retailer, list(campaign_ids))

                for key, ad_unit in selected_ad_units.items():
                    budget_pacing_factor = budget_pacing_factor_map.get(
                        ad_unit["campaign_id"]
                    )
                    if budget_pacing_factor:
                        ad_unit["ecpm"] = ad_unit["ecpm"] * budget_pacing_factor
                        ad_unit["bid"] = ad_unit["bid"] * budget_pacing_factor

            # Apply adaptive bidding
            if retailer.is_adaptive_bid_enabled() and placement_id_list:

                winners = self.auto_bidder.get_winner_info(
                    retailer, target_type, processed_target_value_list, placement_id_list
                )

                ad_units_by_placement = dict()
                for key, ad_unit in selected_ad_units.items():
                    if ad_unit["placement_id"] not in ad_units_by_placement:
                        ad_units_by_placement[ad_unit["placement_id"]] = list()
                    ad_units_by_placement[ad_unit["placement_id"]].append(ad_unit)

                for placement_id, ad_unit_list in ad_units_by_placement.items():
                    floor_price = retailer.get_floor_price(
                        str(campaign_data["placement_id"]),
                        target_value_list[0]
                    )
                    self.auto_bidder.apply_adaptive_bidder(
                        ad_unit_list, winners[placement_id], floor_price
                    )

        if not selected_ad_units:
            Log.info(
                "[function]:get_target_campaigns [trace_id]:{trace_id} "
                "[message]:No auto campaigns present for following parameters "
                "retailer:{retailer_id},target_type:{target_type},"
                "target_value:{target_value},placement_id:{placement_id}".
                format(
                    trace_id=trace_id,
                    retailer_id=retailer.retailer_id,
                    target_type=target_type,
                    target_value=target_value_list,
                    placement_id=placement_id_list
                )
            )
            return result

        for uid, campaign_data in selected_ad_units.items():
            result.append(
                {
                    "campaign_id": campaign_data["campaign_id"],
                    "ad_group_id": campaign_data["ad_group_id"],
                    "bid_value": campaign_data["bid"],
                    "cost_type": campaign_data["cost_type"],
                    "ctr": campaign_data["ctr"],
                    "ecpm": campaign_data["ecpm"],
                    "products_to_promote": campaign_data["products_to_promote"],
                    "placement_id": campaign_data["placement_id"],
                    "campaign_mode": campaign_data["campaign_mode"],
                    "match_type": campaign_data["match_type"],
                    "target_type": campaign_data["target_type"],
                    "target_value": campaign_data["target_value"]
                }
            )

        return result

    def get_target_campaigns_v2(
            self, retailer, target_type, target_value_list, placement_id_list,
            user_id, guest_id, trace_id=None
    ):
        result = []
        keys = []
        processed_target_value_list = []
        for target_value in target_value_list:
            if target_type == "product":
                key = RedisKeyGen.get_product_targeting_key_v2(
                    retailer.retailer_id, target_value
                )
            elif target_type == "category":
                key = RedisKeyGen.get_category_targeting_key_v2(
                    retailer.retailer_id, target_value
                )
            else:
                target_value = self.keyword_hash.get_keyword_hash(target_value)
                key = RedisKeyGen.get_keyword_targeting_key_v2(
                    retailer.retailer_id, target_value
                )
            processed_target_value_list.append(target_value)
            keys.append(key)

        all_ad_units = self.redis_client.multi_get(keys)

        # Exploding and clone the ad units by placement id
        all_ad_units = self.__explode_ad_units(all_ad_units, placement_id_list, target_type, target_value)

        # Apply AB test filter
        ab_test_filtered_ad_units = self.ab_tester.apply_ab_test_filter_at_campaign_level(
            retailer, user_id, guest_id, all_ad_units
        )

        # Apply placement filters
        selected_ad_units = dict()
        for key, ad_units in ab_test_filtered_ad_units.items():
            if ad_units:
                for campaign_data in ad_units:
                    uid = campaign_data["uid"]+"_"+str(campaign_data["placement_id"])
                    if (selected_ad_units.get(uid) and
                            selected_ad_units[uid]["ecpm"] >
                            campaign_data["ecpm"]):
                        continue

                    floor_price = retailer.get_floor_price(
                        str(campaign_data["placement_id"]),
                        target_value_list[0]
                    )

                    if campaign_data["ecpm"] < floor_price:
                        continue

                    campaign_data["floor_price"] = floor_price
                    selected_ad_units[uid] = campaign_data

        # Apply soft budget pacing
        if retailer.get_meta_data().get("budget_pacing_flag"):
            campaign_ids = set()
            for key, ad_unit in selected_ad_units.items():
                campaign_ids.add(ad_unit["campaign_id"])
            budget_pacing_factor_map = self.budget_pacer. \
                get_budget_pacing_factor(retailer, list(campaign_ids))

            for key, ad_unit in selected_ad_units.items():
                budget_pacing_factor = budget_pacing_factor_map.get(
                    ad_unit["campaign_id"]
                )
                if budget_pacing_factor:
                    ad_unit["ecpm"] = ad_unit["ecpm"] * budget_pacing_factor
                    ad_unit["bid"] = ad_unit["bid"] * budget_pacing_factor

        # Apply adaptive bidding
        if retailer.is_adaptive_bid_enabled() and placement_id_list:

            winners = self.auto_bidder.get_winner_info(
                retailer, target_type, processed_target_value_list, placement_id_list
            )

            ad_units_by_placement = dict()
            for key, ad_unit in selected_ad_units.items():
                if ad_unit["placement_id"] not in ad_units_by_placement:
                    ad_units_by_placement[ad_unit["placement_id"]] = list()
                ad_units_by_placement[ad_unit["placement_id"]].append(ad_unit)

            for placement_id, ad_unit_list in ad_units_by_placement.items():
                floor_price = retailer.get_floor_price(
                    str(campaign_data["placement_id"]),
                    target_value_list[0]
                )
                self.auto_bidder.apply_adaptive_bidder(
                    ad_unit_list, winners[placement_id], floor_price
                )

        if not selected_ad_units:
            Log.info(
                "[function]:get_target_campaigns [trace_id]:{trace_id} "
                "[message]:No auto campaigns present for following parameters "
                "retailer:{retailer_id},target_type:{target_type},"
                "target_value:{target_value},placement_id:{placement_id}".
                format(
                    trace_id=trace_id,
                    retailer_id=retailer.retailer_id,
                    target_type=target_type,
                    target_value=target_value_list,
                    placement_id=placement_id_list
                )
            )
            return result

        for uid, campaign_data in selected_ad_units.items():
            result.append(
                {
                    "campaign_id": campaign_data["campaign_id"],
                    "ad_group_id": campaign_data["ad_group_id"],
                    "cpc_bid": campaign_data["bid"],
                    "ctr": campaign_data["ctr"],
                    "ecpm": campaign_data["ecpm"],
                    "products_to_promote": campaign_data["products_to_promote"],
                    "placement_id": campaign_data["placement_id"],
                    "campaign_mode": campaign_data["campaign_mode"]
                }
            )

        return result

    def get_expected_revenue(self, retailer, sku_list):
        prod_cvr_map = self.metric_estimator.get_sku_pccvr_for_list_of_skus(
            retailer,
            sku_list
        )
        sku_info = []
        for product in sku_list:
            sku_info.append(
                {
                    "sku": product,
                    "pc_cvr": prod_cvr_map[product]
                }
            )

        expected_revenue = self.auto_bidder.compute_bid(
            retailer, 100, sku_info
        )

        return expected_revenue

    def _get_campaign_details(self, retailer_id, product_list):
        # Extract campaign ids
        keys = [RedisKeyGen.get_prod_camapaign_map_key(retailer_id, x) for x in product_list]
        key_val = self.redis_client.multi_get(keys)

        # Extract campaign meta-data
        keys = [
            RedisKeyGen.get_camapaign_meta_key(retailer_id, campaign)
            for key in key_val
            for campaign in key_val[key]
        ]
        key_val = self.redis_client.multi_get(keys)

        return key_val

    def get_similar_categories(self, retailer, sku, trace_id=None):
        targets = []

        output_obj = retailer.category_mongo_client.get_document(sku)
        if output_obj is None:
            Log.info(
                "[function]:get_similar_categories [trace_id]:{trace_id} "
                "[message]:Could not get similar categories for product- "
                "retailer:{retailer_id},sku:{sku}".format(
                    trace_id=trace_id,
                    retailer_id=retailer.retailer_id,
                    sku=sku)
            )

            return targets
        output = output_obj.get('target', [])

        for category_obj in output:
            targets.append({
                "target_value": category_obj.get("category"),
                "relevance_score": category_obj.get("relevance_score")
            })

        return targets

    def get_products_by_product(self, retailer, product_id, trace_id=None):
        """
        Description: Takes sku  as an input. Searches the most similar products given the extracted embeddings.
        """
        targets = []
        product_id = product_id.lower()
        output_obj = retailer.product_mongo_client.get_document(product_id)
        if output_obj is None:
            Log.info(
                "[function]:get_products_by_product [trace_id]:{trace_id} "
                "[message]:Could not get products for product- "
                "retailer:{retailer_id},sku:{product_id}".format(
                    trace_id=trace_id,
                    retailer_id=retailer.retailer_id,
                    product_id=product_id
                )
            )
            return targets
        output = output_obj.get('target', [])

        for sku_obj in output:
            sku = sku_obj.get('sku')
            score = sku_obj.get('relevance_score')
            targets.append({
                "target_value": sku,
                "relevance_score": score
            })

        return targets

    def get_keywords_for_product(self, retailer, product_id, match_type='exact', trace_id=None):
        """
        Description: Takes sku  as an input. Searches the most similar products given the extracted embeddings.
        """
        targets = []
        product_id = product_id.lower()
        if (match_type == 'exact'):
            output_obj = retailer.product_to_hash_mongo_client.get_document(product_id)
        elif (match_type == 'broad'):
            output_obj = retailer.product_to_broad_hash_mongo_client.get_document(product_id)
        if output_obj is None:
            Log.info("[function]:get_keywords_for_product [trace_id]:{trace_id} "
                     "[message]:Could not get keywords for product- "
                     "retailer:{retailer_id},sku:{product_id}".format(
                trace_id=trace_id,
                retailer_id=retailer.retailer_id,
                product_id=product_id
                )
            )
            return targets
        hash_targets = output_obj.get('target', [])

        hash_to_relevance = {}
        for hash_entry in hash_targets:
            hash_to_relevance[hash_entry['hash']] = hash_entry['relevance_score']

        hash_to_keywords = retailer.hash_to_keyword_mongo_client.get_documents(list(hash_to_relevance.keys()))
        for row in hash_to_keywords:
            for keyword in row['keywords']:
                targets.append({
                    "target_value": keyword,
                    "relevance_score": hash_to_relevance[row["_id"]]
                })
        return targets
